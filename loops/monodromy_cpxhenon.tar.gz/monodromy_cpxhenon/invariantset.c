#include <string.h>
#include <gaio/Iter.h>
#include <gaio/Tree.h>
#include <gaio/Box.h>
#include <gaio/Rectangle.h>
#include <gaio/SparseMatrix.h>
#include "mex.h"

void map(int n, double *param_inf, double *param_sup, double *pR, double *infv, double *supv);
void TreeSearchBoxRec(Tree *tree, double *a, double *b, unsigned long depth, SparseVector *nos);

int nnz(char v[], int n){
    int i, j;
    j = 0;
    for (i=0;i<n;i++){
        if (v[i]!=0) j++;
    }
    return j;
}

void TreeSubdivideAll(Tree *tree) 
{
    if (TreeFirstBox(tree, -1)) do {
	BoxSubdivide(tree->box, tree->sd[tree->depth]);
    } while (TreeNextBox(tree, -1));
}

void TreeSetFlagsVect(Tree *tree, int depth, char *vect, byte flag)
{
    int i = 0;
    if (TreeFirstBox(tree, depth)) do {
        if (vect[i]) {
            BoxSetFlag(tree->box, flag);
        } else {
            BoxUnsetFlag(tree->box, flag);
        }
        i++;
    } while (TreeNextBox(tree, depth));
}

int InvariantSet(Tree *tree, double *param_inf, double *param_sup)
{
    int n, last_n, i, j, dim, depth;
    SparseVector *nos;
    double *infv, *supv;
    char *hit, *remain, *invset;
    double *pR;

    dim = tree->Q->dim;
    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree,depth);

    do {
        last_n = n;
        pR = (double *) malloc(sizeof(double) * (2*dim+2) * n);
        infv = (double *) malloc(sizeof(double) * dim * n);
        supv = (double *) malloc(sizeof(double) * dim * n);
        TreePrintToMatrix(tree, depth, pR);
        map(n,param_inf,param_sup,pR,infv,supv);
        free(pR);
        hit = (char *) malloc(sizeof(char) * n);
        remain = (char *) malloc(sizeof(char) * n);
        invset = (char *) malloc(sizeof(char) * n);
        
        // initialization
        for (i=0;i<n;i++){
            hit[i] = 0;
            remain[i] = 0;
            invset[i] = 1;
        }
        
        // main part
        for (i=0;i<n;i++){
            nos = SparseVectorNew(0, 16);
            TreeReset(tree);
            TreeSearchBoxRec(tree, infv+dim*i, supv+dim*i, depth, nos);
            if (nos->nz > 0) {
                remain[i] = 1;
                for (j=0; j<nos->nz; j++){
                    hit[nos->rows[j]] = 1;
                }
            }
            SparseVectorFree(&nos);
        }
        for (i=0;i<n;i++) {
            invset[i] = remain[i] & hit[i];
        }
        // remove non-invariant cubes
        TreeSetFlagsVect(tree,depth,invset,1);
        TreeRemove(tree->root,1);
        if (nnz(invset,n) == 0) {
            return 0;
        }
        n = TreeCountDepth(tree,depth);
        free(hit);
        free(remain);
        free(invset);
        free(infv);
        free(supv);
    } while (n != last_n);
    return n;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    int i;
    mxArray *ptr;
    double *pl;
    Iter *iter;
    double *param_inf, *param_sup, *nsubdiv;

    ptr = mxGetField(prhs[0], 0, "handle");
    iter = *(Iter **)mxGetData(ptr);
    if (iter==NULL) mexErrMsgTxt("Tree: tree is empty.");

    param_inf = (double*) mxGetPr(prhs[1]);
    param_sup = (double*) mxGetPr(prhs[2]);
    nsubdiv = (double*) mxGetPr(prhs[3]);

    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    pl = mxGetPr(plhs[0]);
    pl[0] = 0;

    if (*nsubdiv == 0) {
        pl[0] = InvariantSet(iter->tree, param_inf, param_sup);
        printf("number of inv. cubs = %7d\n",TreeCountDepth(iter->tree,-1));
        return;
    }

    for (i=0; i<*nsubdiv; i++) {
        TreeSubdivideAll(iter->tree);
        printf("detph %2d:\t ",TreeDepth(iter->tree->root));
        pl[0] = InvariantSet(iter->tree, param_inf, param_sup);
        printf("number of inv. cubs = %7d\n",TreeCountDepth(iter->tree,-1));
    }
    return;
}
