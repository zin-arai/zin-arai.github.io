depth = input('Enter the depth: ');

% Make the initial partition N_0^1, N_0^1
filename = sprintf('data/depth%.3d-%.8d.tree', depth, 0)
tree = Tree(filename);
dim = tree.dim;
center = tree.center;
radius = tree.radius;
restrict(tree, [center(1)-radius(1); center(1)+radius(1); 
                center(2)-radius(2); center(2)+radius(2);
                center(3)-radius(3);                   0;
                center(3)-radius(4); center(3)+radius(4)]);
tree.save(sprintf('%s_0', filename));
tree = Tree(filename);
restrict(tree, [center(1)-radius(1); center(1)+radius(1); 
                center(2)-radius(2); center(2)+radius(2);
                                  0; center(3)+radius(3);
                center(3)-radius(4); center(3)+radius(4)]);
tree.save(sprintf('%s_1', filename));

hit = 1;
leaf = -1;

for i = 0 : 2^depth - 2
  for symbol = 0:1 
    % compute N_i^symbol (symbol = 0 or 1)
    display(sprintf('Compute the continuation (%d/%d) for symbol %1d',...
                    i+1, 2^depth, symbol));

    % data loading
    % tree_adjecent: the data of N_{i-1}^{symbol} for t \in I_{i-1}
    filename = sprintf('data/depth%.3d-%.8d.tree_%1d', depth, i, symbol);
    tree_adjecent = Tree(filename);
    filename = sprintf('data/depth%.3d-%.8d.tree', depth, i+1);
    tree = Tree(filename);

    n = tree.count(leaf);
    n_adjecent = tree_adjecent.count(leaf);
    tree.unset_flags('all', hit);
    flags = zeros(1, n);
    done = zeros(1, n);

    % Find cubes in 'tree' which is in the cubical nbd of 'tree_adjecaent'
    % and set their flags to 1
    b = tree_adjecent.first_box(leaf);
    for j = 1:n_adjecent
      flags(tree.search_box(b(1:dim), 2*b(dim+1:2*dim), leaf)) = 1;
      b = tree_adjecent.next_box(leaf);
    end

    % Expand cubes with flags = 1 in 'tree'
    last = 0;
    while last ~= nnz(flags)
      last = nnz(flags);
      b = tree.first_box(leaf);
      for j = 1:n
        if ((flags(j) == 1) & (done(j) == 0))
          flags(tree.search_box(b(1:dim), 2*b(dim+1:2*dim), leaf)) = 1;
          done(j) = 1;
        end
        b = tree.next_box(leaf);
      end
    end

    % Save the data of cubes with flags = 1
    tree.set_flags(sprintf('%1d', flags), hit);
    tree.remove(hit);
    tree.save(sprintf('%s_%1d', filename, symbol));
    tree_adjecent.delete(0); delete(tree_adjecent); clear tree_adjecent;
    tree.delete(0); delete(tree); clear tree;
  end
  
  % Check that N_i^0 and N_i^1 does not intersect
  display('Checking the decomposition..')
  tree_0 = Tree(sprintf('%s_0', filename));
  tree_1 = Tree(sprintf('%s_1', filename));
  if treeintersect(tree_0, tree_1)
    display('Error: decomposition collides!')
    return
  else
    display('OK.')
  end
  tree_0.delete(0); delete(tree_0); clear tree_0;
  tree_1.delete(0); delete(tree_1); clear tree_1;
end
