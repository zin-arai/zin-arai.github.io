function ans = treeintersect(tree, tree2)

% treecut - return 1 if two trees intersects
% Zin ARAI, 2005/08/08

hit = 1;
dim = tree.dim;
depth = tree2.depth;
if dim ~= tree2.dim
  disp('Error: dim of two trees must agree!')
  return;
end

tree.set_flags('all', hit);
tree2.set_flags('all', hit);

n = tree.count(depth);
unset = zeros(1,n);
boxes = tree.boxes(depth);
unset = (tree2.search(boxes(1:dim,:),depth) ~= -1);
if nnz(unset) ~= 0
  ans = 1;
  return
else 
  ans = 0;
  return
end