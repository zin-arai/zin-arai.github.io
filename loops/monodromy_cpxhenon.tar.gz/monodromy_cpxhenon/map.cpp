#include <interval/interval.h>

extern "C" {
    void map(int n, double *param_inf, double *param_sup,
             double *pR, double *infv, double *supv);
}

void computeBeta(const interval t, interval& aR, interval& aI, interval& cR, interval& cI)
{
    // a is constant on beta
    aR = 0.25;
    aI = 0;

    // loop definition
    const double cR_inf = -2.75;
    const double cR_sup = -2.25;
    const double cI_inf = -0.25;
    const double cI_sup = +0.25;
    const double length = 2.0;

    // when the time interval is too large
    if (t.right_b() - t.left_b() > 1.0/8) {
        cR = interval(cR_inf, cR_sup);
        cI = interval(cI_inf, cI_sup);
        return;
    }

    // main part
    if (t <= 1.0/8) { 
        // t \in [0, 1/8]
        cR = cR_inf;
        cI = 0 - (t - 0.0/8) * length;
    } else if (t <= 3.0/8) {
        // t \ in [1/8, 3/8]
        cR = cR_inf + (t - 1.0/8) * length;
        cI = cI_inf;
    } else if (t <= 5.0/8) {
        // t \in [3/8, 05/8]
        cR = cR_sup;
        cI = cI_inf + (t - 3.0/8) * length;
    } else if (t <= 7.0/8) {
        // t \in [5/8, 7/8]
        cR = cR_sup - (t - 5.0/8) * length;
        cI = cI_sup;
    } else {
        // t \in [7/8, 1]
        cR = cR_inf;
        cI = cI_sup - (t - 7.0/8) * length;
    }
    return;
}

void computeGamma(const interval t, interval& aR, interval& aI, interval& cR, interval& cI)
{
    // aI is always 0;
    aI = 0;

    // when the time interval is too large
    if (t.right_b() - t.left_b() > 1.0/16) {
        aR = interval(0.25, 1);
        cR = interval(-10, -2.25);
        if ((t <= 7.0/16) || (t >= 9.0/16)) {
            cI = 0;
        } else {
            cI = interval(-0.25, 0.25);
        }
        return;
    }

    // main part
    if (t <= 1.0/16) { 
        // t \in [0, 1/16]
        aR = 1 - (t - 0.0/16) * 16 * 0.75;
        cR = -10;
        cI = 0;
    } else if (t <= 7.0/16) {
        // t \ in [1/16, 7/16]
        aR = 0.25;
        cR = -10 + (t - 1.0/16) * 16 * interval(7.25) / interval(6);
        cI = 0;
    } else if (t <= 9.0/16) {
        // t \in [7/16, 9/16]
        computeBeta((t - 7.0/16) * 8, aR, aI, cR, cI);
    } else if (t <= 15.0/16) {
        // t \in [9/8, 15/8]
        aR = 0.25;
        cR = -2.75 - (t - 9.0/16) * 16 * interval(7.25) / interval(6);
        cI = 0;
    } else {
        // t \in [15/16, 1]
        aR = 0.25 + (t - 15.0/16) * 16 * 0.75;
        cR = -10;
        cI = 0;
    }
    return;
}

void map(int n, double *param_inf, double *param_sup, double *pR, double *infv, double *supv)
{
    int i;
    interval t;
    interval aR, aI, cR, cI;
    interval xR, xI, yR, yI;
    interval XR, XI, YR, YI;
    
    t = interval(param_inf[0], param_sup[0]);
    computeGamma(t, aR, aI, cR, cI);

    for (i=0; i<n; i++) {
        // domain cube
        xR = interval(*(pR + i*10 + 0) - *(pR + i*10 + 4), 
                      *(pR + i*10 + 0) + *(pR + i*10 + 4));
        xI = interval(*(pR + i*10 + 1) - *(pR + i*10 + 5), 
                      *(pR + i*10 + 1) + *(pR + i*10 + 5));
        yR = interval(*(pR + i*10 + 2) - *(pR + i*10 + 6), 
                      *(pR + i*10 + 2) + *(pR + i*10 + 6));
        yI = interval(*(pR + i*10 + 3) - *(pR + i*10 + 7), 
                      *(pR + i*10 + 3) + *(pR + i*10 + 7));

        // Henon map
        XR = xR*xR - xI*xI + cR - aR*yR + aI*yI;
        XI = 2*xR*xI    + cI - aR*yI - aI*yR;
        YR = mid(xR);
        YI = mid(xI);

        // image cube
        *(infv + i*4 + 0) = XR.left_b();
        *(infv + i*4 + 1) = XI.left_b();
        *(infv + i*4 + 2) = YR.left_b();
        *(infv + i*4 + 3) = YI.left_b();
        *(supv + i*4 + 0) = XR.right_b();
        *(supv + i*4 + 1) = XI.right_b();
        *(supv + i*4 + 2) = YR.right_b();
        *(supv + i*4 + 3) = YI.right_b();
    }
    round_nearest();
}
