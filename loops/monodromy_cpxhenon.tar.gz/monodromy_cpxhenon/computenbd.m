depth_max = input('Enter the Maximal Depth: ');

tree = Tree([0;0;0;0],[8;8;8;8]);
subdivideall(tree, 4);
tree.save('data/depth000-00000000.tree');
t_tree = Tree(0.5,0.5);

while t_tree.depth < depth_max
  subdivideall(t_tree, 1);
  d = t_tree.depth;
  disp(sprintf('\n***** subdivision depth of [0,1] is %.3d *****',d));
  n = t_tree.count(t_tree.depth);
  b = t_tree.first_box(t_tree.depth);
  for i = 0 : n - 1
    % read the data of the previous step
    n_previous = floor(i / 2);
    filename = sprintf('data/depth%.3d-%.8d.tree', d - 1, n_previous);
    tree = Tree(filename);
    % compute the invariant part
    disp(sprintf('Computing the invariantset for t = [%12.10f,%12.10f]',... 
                 b(1)-b(2), b(1)+b(2)));
    invariantset(tree, b(1)-b(2), b(1)+b(2), 4);
    % save the data
    tree.save(sprintf('data/depth%.3d-%.8d.tree', d, i));
    b = t_tree.next_box(t_tree.depth);
    tree.delete(0); delete(tree); clear tree;
  end
end
