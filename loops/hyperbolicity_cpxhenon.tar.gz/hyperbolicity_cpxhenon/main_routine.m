function run(param_tree, hyp_tree, param_stack, phase_sd, resume_time, fixed_param)
!date
!uname -mnps

phase_dim = 8;
pdim = param_tree.dim;
pcenter = zeros(pdim,1);
param_sd = param_tree.sd;
last_saved_time = resume_time; 
last_data_number = max(param_stack(:,4));

tic;
while 1
  param_stack = sortrows(param_stack,1);
  param_depth = param_stack(1,2);
  phase_depth = param_stack(1,3);
  data_number = param_stack(1,4);
  for i = 1:pdim
    pcenter(i) = param_stack(1,4+i);
  end
  param_cubs = param_tree.boxes(-1);
  current_cub = param_cubs(:,param_tree.search(pcenter,-1));
  param_inf = [fixed_param; current_cub(1:pdim) - current_cub(pdim+1:2*pdim)];
  param_sup = [fixed_param; current_cub(1:pdim) + current_cub(pdim+1:2*pdim)];
  filename = sprintf('data/%.8d.tree', data_number);
  if isempty(dir(filename))
      eval(sprintf('!gunzip %s.gz',filename));
  end
  tree = Tree(filename);
  eval(sprintf('!gzip -1f %s',filename));
  disp(sprintf('\ndata loaded from %s', filename));
  tree.sd = phase_sd;
  tree.set_flags('all',1); tree.subdivide(1);
  disp(sprintf('processing: [%13.10f, %13.10f] x [%13.10f, %13.10f]',...
                 param_inf(3), param_sup(3), param_inf(4), param_sup(4)));
  hypflag = hyperbolicity(tree,param_inf,param_sup);
  if hypflag
    % hyperbolic or empty set
    if hypflag == 1
        disp(sprintf('Hyperbolic parameter: [%13.10f, %13.10f] x [%13.10f, %13.10f]',...
                     param_inf(3), param_sup(3), param_inf(4), param_sup(4)));
    else
        disp(sprintf('Empty set: [%13.10f, %13.10f] x [%13.10f, %13.10f]',...
                     param_inf(3), param_sup(3), param_inf(4), param_sup(4)));
    end
    % insert the current box to hyp_tree
    hyp_tree.insert(pcenter, param_depth);
    hyp_tree.save('data/hyperbolic.tree');
    % remove the current box from param_tree and param_stack
    param_tree.set_flags('all',1);
    param_tree.unset_flags(pcenter,1,param_depth);
    param_tree.remove(1);
    param_stack = param_stack(2:size(param_stack,1),:);
    param_tree.save('data/remaining.tree');
  else
    % non-hyperbolic case
    if mod(tree.depth, phase_dim/pdim) == 0 % subdivide the parameter cube
      pcenter_l = pcenter;
      pcenter_r = pcenter;
      subdivide_axis = param_sd(param_depth + 1) + 1;
      r = current_cub(pdim + subdivide_axis) / 2;
      pcenter_l(subdivide_axis) = pcenter(subdivide_axis) - r;
      pcenter_r(subdivide_axis) = pcenter(subdivide_axis) + r;
      filename1 = sprintf('data/%.8d.tree', last_data_number + 1);
      filename2 = sprintf('data/%.8d.tree', last_data_number + 2);
      tree.save(filename1);
      eval(sprintf('!ln -f %s %s',filename1, filename2));
      disp(sprintf('data saved to %s, %s', filename1, filename2));
      param_tree.insert(pcenter_l, param_depth+1);
      param_tree.insert(pcenter_r, param_depth+1);
      weight = tree.count(tree.depth);
      param_stack = param_stack(2:size(param_stack,1),:);
      param_stack(size(param_stack,1)+1,:) = [weight, param_depth+1, phase_depth+1, last_data_number+1, pcenter_l'];
      param_stack(size(param_stack,1)+1,:) = [weight, param_depth+1, phase_depth+1, last_data_number+2, pcenter_r'];
      last_data_number = last_data_number + 2;
      param_tree.save('data/remaining.tree');
    else
      % no parameter subdivision
      filename1 = sprintf('data/%.8d.tree', last_data_number + 1);
      disp(sprintf('data saved to %s', filename1));
      tree.save(filename1);
      weight = tree.count(tree.depth);
      param_stack(1,:) = [weight, param_depth, phase_depth+1, last_data_number+1, pcenter'];
      last_data_number = last_data_number + 1;
    end
  end
  tree.delete(0); delete(tree); clear tree;
  save 'data/param_stack' param_stack;
  %% save the current trees every one hour
  if (toc + resume_time - last_saved_time >= 3600)
    last_saved_time = round(toc + resume_time);
    filename = sprintf('snapshots/remaining_%.8d.tree',last_saved_time);
    param_tree.save(filename);
    filename = sprintf('snapshots/hyperbolic_%.8d.tree',last_saved_time);
    hyp_tree.save(filename);
    filename = sprintf('snapshots/param_stack_%.8d',last_saved_time);
    eval(sprintf('save %s param_stack', filename));
    disp(sprintf('\n%.8d seconds has passed since the beggining.\n',last_saved_time));
  end
end
