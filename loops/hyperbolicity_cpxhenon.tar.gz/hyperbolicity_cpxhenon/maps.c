#include <fenv.h>
#include <gaio/defs.h>

#define SQMAX(x, y) (max(((x)*(x)),((y)*(y))))
#define SQMIN(x, y) (min(((x)*(x)),((y)*(y))))
#define IPMAX(a, b, c, d) (max(max(((a)*(c)), ((b)*(d))), max(((a)*(d)), ((b)*(c)))))
#define IPMIN(a, b, c, d) (min(min(((a)*(c)), ((b)*(d))), min(((a)*(d)), ((b)*(c)))))

void map_t(double *p, double *P, double *c, double *r, double *image, double *IMAGE)
{
    double xr, xi, yr, yi, vr, vi, wr, wi; // lower bounds
    double XR, XI, YR, YI, VR, VI, WR, WI; // upper bounds

    // paramters
    // ar = p[0]; AR = P[0];
    // ai = p[1]; AI = P[1];
    // cr = p[2]; CR = P[2];
    // ci = p[3]; CI = P[3];

    // domain cube
    fesetround(FE_DOWNWARD);
    xr = c[0] - r[0]; 
    xi = c[1] - r[1]; 
    yr = c[2] - r[2]; 
    yi = c[3] - r[3]; 
    vr = c[4] - r[4];
    vi = c[5] - r[5]; 
    wr = c[6] - r[6];
    wi = c[7] - r[7]; 

    fesetround(FE_UPWARD);
    XR = c[0] + r[0];
    XI = c[1] + r[1];
    YR = c[2] + r[2];
    YI = c[3] + r[3];
    VR = c[4] + r[4];
    VI = c[5] + r[5];
    WR = c[6] + r[6];
    WI = c[7] + r[7];

    // lower bounds of the image
    fesetround(FE_DOWNWARD);
    image[0] = SQMIN(xr,XR) + IPMIN(-xi,-XI,xi,XI) + p[2] + IPMIN(-p[0],-P[0],yr,YR) + IPMIN(p[1],P[1],yi,YI);
    image[1] = 2*IPMIN(xr,XR,xi,XI) + p[3] + IPMIN(-p[0],-P[0],yi,YI) + IPMIN(-p[1],-P[1],yr,YR);
    image[2] = c[0];
    image[3] = c[1];
    image[4] = 2*IPMIN(xr,XR,vr,VR) + 2*IPMIN(-xi,-XI,vi,VI) + IPMIN(-p[0],-P[0],wr,WR) + IPMIN(p[1],P[1],wi,WI);
    image[5] = 2*IPMIN(xi,XI,vr,VR) + 2*IPMIN(xr,XR,vi,VI) + IPMIN(-p[0],-P[0],wi,WI) + IPMIN(-p[1],-P[1],wr,WR);
    image[6] = c[4];
    image[7] = c[5];

    // upper bounds of the image
    fesetround(FE_UPWARD);
    IMAGE[0] = SQMAX(xr,XR) + IPMAX(-xi,-XI,xi,XI) + P[2] + IPMAX(-p[0],-P[0],yr,YR) + IPMAX(p[1],P[1],yi,YI);
    IMAGE[1] = 2*IPMAX(xr,XR,xi,XI) + P[3] + IPMAX(-p[0],-P[0],yi,YI) + IPMAX(-p[1],-P[1],yr,YR);
    IMAGE[2] = c[0];
    IMAGE[3] = c[1];
    IMAGE[4] = 2*IPMAX(xr,XR,vr,VR) + 2*IPMAX(-xi,-XI,vi,VI) + IPMAX(-p[0],-P[0],wr,WR) + IPMAX(p[1],P[1],wi,WI);
    IMAGE[5] = 2*IPMAX(xi,XI,vr,VR) + 2*IPMAX(xr,XR,vi,VI) + IPMAX(-p[0],-P[0],wi,WI) + IPMAX(-p[1],-P[1],wr,WR);
    IMAGE[6] = c[4];
    IMAGE[7] = c[5];

    fesetround(FE_TONEAREST);
}

void map(int n, double *param_inf, double *param_sup, double *pR, double *infv, double *supv)
{
    int i;
    double ar, ai, cr, ci; // lower bounds
    double AR, AI, CR, CI; // upper bounds
    double xr, xi, yr, yi; // lower bounds
    double XR, XI, YR, YI; // upper bounds

    // paramters
    ar = *param_inf;
    ai = *(param_inf + 1);
    cr = *(param_inf + 2);
    ci = *(param_inf + 3);
    AR = *param_sup;
    AI = *(param_sup + 1);
    CR = *(param_sup + 2);
    CI = *(param_sup + 3);

    for (i = 0; i < n; i++) {
        // domain cube
        fesetround(FE_DOWNWARD);
        xr = *(pR + i*10 + 0) - *(pR + i*10 + 4);
        xi = *(pR + i*10 + 1) - *(pR + i*10 + 5); 
        yr = *(pR + i*10 + 2) - *(pR + i*10 + 6); 
        yi = *(pR + i*10 + 3) - *(pR + i*10 + 7); 

        fesetround(FE_UPWARD);
        XR = *(pR + i*10 + 0) + *(pR + i*10 + 4);
        XI = *(pR + i*10 + 1) + *(pR + i*10 + 5);
        YR = *(pR + i*10 + 2) + *(pR + i*10 + 6);
        YI = *(pR + i*10 + 3) + *(pR + i*10 + 7);

        // lower bounds of the image
        fesetround(FE_DOWNWARD);
        *(infv + i*4 + 0) = SQMIN(xr,XR) + IPMIN(-xi,-XI,xi,XI) + cr + IPMIN(-ar,-AR,yr,YR) + IPMIN(ai,AI,yi,YI);
        *(infv + i*4 + 1) = 2*IPMIN(xr,XR,xi,XI) + ci + IPMIN(-ar,-AR,yi,YI) + IPMIN(-ai,-AI,yr,YR);
        *(infv + i*4 + 2) = xr;
        *(infv + i*4 + 3) = xi;

        // upper bounds of the image
        fesetround(FE_UPWARD);
        *(supv + i*4 + 0) = SQMAX(xr,XR) + IPMAX(-xi,-XI,xi,XI) + CR + IPMAX(-ar,-AR,yr,YR) + IPMAX(ai,AI,yi,YI);
        *(supv + i*4 + 1) = 2*IPMAX(xr,XR,xi,XI) + CI + IPMAX(-ar,-AR,yi,YI) + IPMAX(-ai,-AI,yr,YR);
        *(supv + i*4 + 2) = XR;
        *(supv + i*4 + 3) = XI;
    }
    fesetround(FE_TONEAREST);
}
