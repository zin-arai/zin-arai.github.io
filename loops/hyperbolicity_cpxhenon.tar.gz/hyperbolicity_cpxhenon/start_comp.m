%%
%% parameter setting
%%
re_a = 1;
im_a = 0;

%%
%% tree for TM
%%
center = [0;0;0;0;0;0;0;0];
radius = [8;8;8;8;1;1;1;1];
treeTM = Tree(center,radius);

treeTM_sd = treeTM.sd;
for i = 0:3
    treeTM_sd(i * 4 + 1) = 0; 
    treeTM_sd(i * 4 + 2) = 1;
    treeTM_sd(i * 4 + 3) = 2;
    treeTM_sd(i * 4 + 4) = 3;
end
treeTM.sd = treeTM_sd;

%%
%% tree for the parameter space
%%
param_center = [0;8];
param_radius = [8;8];
param_tree = Tree(param_center,param_radius);
hyp_tree = Tree(param_center,param_radius);
for i = 1:3
    param_tree.set_flags('all',1); param_tree.subdivide(1);
end
restrict(param_tree, [-8 8 0 8])

% param_stack = [weight, param_depth, phase_depth, data_number, Re c, Im c]
b = param_tree.first_box(-1);
for i = 1:param_tree.count(-1)
    param_stack(i, :) = [0, param_tree.depth, treeTM.depth, i, b(1), b(2)];
    filename = sprintf('data/%.8d.tree', i);
    treeTM.save(filename);
    b = param_tree.next_box(-1);
end

%%
%% Call the main routine
%%
resume_time = 0;
main_routine(param_tree, hyp_tree, param_stack, treeTM_sd, time, [re_a; im_a]);
