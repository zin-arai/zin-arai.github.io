#include <string.h>
#include <gaio/Tree.h>
#include <gaio/Vec.h>

inline int TreeDownLeft(Tree *tree) {
    if (tree->box->child[0]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] -= tree->r[sd];
        tree->box = tree->box->child[0];
        tree->branchStack[tree->depth] = 0;
        tree->depth++;
        return 1;
    } else return 0;
}

inline int TreeDownRight(Tree *tree) {
    if (tree->box->child[1]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] += tree->r[sd];
        tree->box = tree->box->child[1];
        tree->branchStack[tree->depth] = 1;
        tree->depth++;
        return 1;
    } else return 0;
}

inline void TreeSetFlagRec(Tree *tree, double *a, double *b, byte flag, char *found)
{
    int i;

    if (!(tree->box->child[0]) && !(tree->box->child[1])) {
        BoxSetFlag(tree->box, flag);
        *found = 1;
        return;
    }

    i = tree->box->sd;
    if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
        if (TreeDownLeft(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
        if (TreeDownRight(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    return;
}

void TreeSubdivideAll(Tree *tree) 
{
    if (TreeFirstBox(tree, -1)) {
        do {
            BoxSubdivide(tree->box, tree->sd[tree->depth]);
        } while (TreeNextBox(tree, -1));
    }
}

void TreeUnsetFlagsAll(Tree *tree, byte flag)
{
    if (TreeFirstBox(tree, -1)) {
        do {
            BoxUnsetFlag(tree->box, flag);
        } while (TreeNextBox(tree, -1));
    }
}

void TreeSetFlagsAll(Tree *tree, byte flag)
{
    if (TreeFirstBox(tree, -1)) {
        do {
            BoxSetFlag(tree->box, flag);
        } while (TreeNextBox(tree, -1));
    }
}

void TreeSetFlagsVect(Tree *tree, int depth, char *vect, byte flag)
{
    int i = 0;
    if (TreeFirstBox(tree, depth)) do {
        if (vect[i]) {
            BoxSetFlag(tree->box, flag);
        } else {
            BoxUnsetFlag(tree->box, flag);
        }
        i++;
    } while (TreeNextBox(tree, depth));
}
