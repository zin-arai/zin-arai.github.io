#include <string.h>
#include <gaio/Iter.h>
#include <gaio/Tree.h>
#include <gaio/Box.h>
#include <gaio/Rectangle.h>
#include <gaio/SparseMatrix.h>
#include "defs.h"
#include "mex.h"

// CheckIsolated: check if the zero-section is isolated inv set. 
int CheckIsolated(Tree *tree, int dim)
{
    int i;
    if (TreeFirstBox(tree, -1)) do {
        for (i = dim; i < 2*dim; i++) {
            if (fabs(tree->c[i]) + 2 * tree->r[i] >= 1) {
                return 0;
            }
        }
    } while (TreeNextBox(tree, -1));
    return 1;
}

 
// BaseFind: find the cubes of treeTM whose projection
// to the basespace is contained in treeM 
void BaseFind(Tree *treeTM, Tree *treeM, char *crset, char *remain)
{
    int i, j, dim, ncubTM, depthTM, ncubM, depthM;
    double *ll, *ur;
    SparseVector *nos;

    dim = treeM->Q->dim;
    depthTM = TreeDepth(treeTM->root);
    ncubTM = TreeCountDepth(treeTM,depthTM);
    depthM = TreeDepth(treeM->root);
    ncubM = TreeCountDepth(treeM,depthM);
         
    for (i=0; i<ncubTM; i++) {
        remain[i] = 1;
    }

    ll = (double *) malloc(sizeof(double) * 2 * dim);
    ur = (double *) malloc(sizeof(double) * 2 * dim);
    for (i=dim; i<2*dim; i++) {
        *(ll+i) = -1.0; *(ur+i) =  1.0;
    }

    TreeFirstBox(treeM, depthM);
    for (i=0; i<ncubM; i++) {
        if (!crset[i]) {
            nos = SparseVectorNew(0, 16);
            for (j=0; j<dim; j++) {
                ll[j] = treeM->c[j];
                ur[j] = ll[j];
            }
            TreeReset(treeTM);
            TreeSearchBoxRec(treeTM, ll, ur, depthTM, nos);
            for (j=0; j<nos->nz; j++) {
                remain[nos->rows[j]] = 0;
            }
            SparseVectorFree(&nos);
        }
        TreeNextBox(treeM, depthM);
    }
    free(ll);
    free(ur);
    return;
}

int InvariantSet(Tree *tree, Tree *searchTree, double *param_inf, double *param_sup)
{
    int n, last_n, i, dim, depth;
    double *infv, *supv; // vector for image cubes
    char *domain;

    dim = tree->Q->dim;
    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree, depth);
    infv = (double *) malloc(sizeof(double) * dim);
    supv = (double *) malloc(sizeof(double) * dim);

    do {
        last_n = n;
        domain = (char *) malloc(sizeof(char) * n);
        for (i = 0; i < n; i++) {*(domain + i) = 0;}

        // main part
        //     flag 1: the cube is in the image
        //     flag 2: the image of the cube intersects the tree
        TreeUnsetFlagsAll(tree, 3);
        TreeFirstBox(tree, depth);
        for (i = 0; i < n; i++) {
            map_t(param_inf, param_sup, tree->c, tree->r, infv, supv);
            TreeReset(searchTree);
            TreeSetFlagRec(searchTree, infv, supv, 1, domain + i);
            TreeNextBox(tree, depth);
        }

        // remove non-invariant cubes
        TreeSetFlagsVect(tree, depth, domain ,2);
        TreeRemove(tree->root, 3);
        n = TreeCountDepth(tree, depth);
        free(domain);
    } while (n != last_n);
    free(infv);
    free(supv);
    return n;
}

inline int TreeFindBoxToVisit(Tree *tree, double *a, double *b, int *val, int *m, int k) 
{
    int i, j;
    
    if (!(tree->box->child[0]) && !(tree->box->child[1])) {
        if (!val[tree->box->no]) {
            return tree->box->no;
        } else {
            m[k] = min(m[k], val[tree->box->no]);
            return -1;
        }
    } 
    i = tree->box->sd;
    if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
        if (TreeDownLeft(tree)) {
            j = TreeFindBoxToVisit(tree, a, b, val, m, k);
            if (j != -1) {
                return j;
            }
            TreeUp(tree);
        }
    }
    if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
        if (TreeDownRight(tree)) {
            j = TreeFindBoxToVisit(tree, a, b, val, m, k);
            if (j != -1) {
                return j;
            }
            TreeUp(tree);
        }
    }
    return -1;
}

int SccMain(Tree *tree, int dim, char *crset, double *infv, double *supv)
{
    int i, s, k, n, depth, next, p, q;
    int id, *val, *minimum,*m;
    char *fixed_point;
    int *stack, *track;

    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree,depth);

    stack = (int *) malloc(sizeof(int) * (n+1));
    track = (int *) malloc(sizeof(int) * (n+1));

    val = (int *) malloc(sizeof(int) * n);
    m = (int *) malloc(sizeof(int) * n);
    minimum = (int *) malloc(sizeof(int) * n);
    fixed_point = (char *) malloc(sizeof(char) * n);

    for (i=0; i<n; i++) {
        val[i] = 0;
        m[i] = n+1;
        minimum[i] = n+1;
        fixed_point[i] = 0;
    }

    // stack
    // track
    // p: pointer of "stack"
    // q: pointer of "track"
    // n: number of vertices
    // s: start vertex
    // k: current vertex
    // next: next vertex

    //printf("there are %d boxes...\n",n);

    for (s=0;s<n;s++) {
        if (val[s]==0) {            
            //printf("start with %d\n",s);
            id = 1;
            k = s;
            p = 0;
            q = 0;
            stack[p] = k;
            track[q] = k;
            val[k] = id;
            m[k] = id;
            p = p + 1;
            q = q + 1;
            while(1) {
                TreeReset(tree);
                next = TreeFindBoxToVisit(tree, infv+dim*k, supv+dim*k, val, m, k);
                //printf("next cube is %d\n",next);
                if (next == -1) {
                    minimum[k] = m[k];
                    //printf("OUT! k=%d, min=%d, val=%d\n",k,minimum[k],val[k]);
                    if ((minimum[k] == val[k])) {
                        // if the sc component has only one element
                        if (stack[p - 1] == k) { 
                            p = p - 1;
                            if (fixed_point[k] == 1) {
                                crset[k] = 1;
                            }
                            val[k] = n + 1;
                        } else do {
                            p = p - 1;
                            //printf("stack[%d] = %d is crset\n",p,stack[p]);
                            crset[stack[p]] = 1;
                            val[stack[p]] = n + 1;
                        } while (stack[p] != k);
                    }
                    if (k == s) {
                        break;
                    } else {
                        q = q - 1;
                        m[track[q-1]] = min(m[track[q-1]],minimum[k]);
                        k = track[q-1];
                    }
                } else {
                    if (next == k) {
                        fixed_point[k] = 1;
                    }
                    id = id + 1;
                    k = next;
                    stack[p] = k;
                    track[q] = k;
                    val[k] = id;
                    m[k] = id;
                    q = q + 1;
                    p = p + 1;
                }
            }
        }
    }
    free(stack);
    free(track);
    free(val);
    free(m);
    free(minimum);
    free(fixed_point);
    return 0;
}

// ComputeScc: crset(n) is set to 1 iff the corresponding cube is in SCC
void ComputeScc(Tree *tree, double *param_inf, double *param_sup, char *crset)
{ 
    int n, i, dim, depth;
    double *infv, *supv;
    double *pR, eps, tmp;

    dim = tree->Q->dim;
    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree,depth);

    for (i=0; i<n; i++) {
        crset[i] = 0;
    }

    pR = (double *) malloc(sizeof(double) * (2*dim+2) * n);
    infv = (double *) malloc(sizeof(double) * dim * n);
    supv = (double *) malloc(sizeof(double) * dim * n);

    TreePrintToMatrix(tree, depth, pR);
    map(n, param_inf, param_sup, pR, infv, supv);
    free(pR);

    // Calculation of Epsilon (min { x > 0 })
    tmp = 1.0;
    do {
        eps = tmp;
        tmp = tmp / 2.0;
    } while (tmp > 0.0);

    // for safety
    eps = eps * 4;

    // enlarge the cubes
    for (i=0; i<dim*n; i++) {
        *(infv+i) = *(infv+i) - eps;
        *(supv+i) = *(supv+i) + eps;
    }
    
    // call main routine
    SccMain(tree, dim, crset, infv, supv);
    free(infv);
    free(supv);
}


int BaseChainRecSet(Tree *treeTM, Tree *treeM, double *param_inf, double *param_sup)
{
    int i, dim, tmp, ncubTM, ncubM, depthTM, depthM;
    int depth_table[256];
    double *x;
    char *crset, *remain;

    dim = treeM->Q->dim;
    x = (double *) malloc(sizeof(double) * dim);

    depthTM = TreeDepth(treeTM->root);
    ncubTM = TreeCountDepth(treeTM, depthTM);

    // depth_table: a table to compute the depth of M
    // corresponding to the given depth of TM
    tmp = 0;
    for (i=0; i<256; i++) {
        depth_table[i] = tmp;
        if (treeTM->sd[i] < dim) {
            treeM->sd[tmp] = treeTM->sd[i];
            tmp++;
        }
    }

    depthM = depth_table[depthTM];
    TreeDeleteDepth(treeM, 0);

    // project TM to M
    if (TreeFirstBox(treeTM, depthTM)) do {
        for (i=0; i<dim; i++) {
            x[i] = treeTM->c[i];
        }
	TreeInsert(treeM, x, depthM, 1, 1, 0);
    } while (TreeNextBox(treeTM, depthTM));

    // compute scc
    ncubM = TreeCountDepth(treeM, depthM);
    crset = (char *) malloc(sizeof(char) * ncubM);
    ComputeScc(treeM, param_inf, param_sup, crset);

    // find the cubes of TM that lies on the crset of f:M -> M
    remain = (char *) malloc(sizeof(char) * ncubTM);
    for (i=0; i<ncubTM; i++) {
        remain[i] = 1;
    }
    BaseFind(treeTM, treeM, crset, remain);

    // remove the cubes of TM that is not on the crset of f: M -> M
    TreeSetFlagsVect(treeTM, depthTM, remain, 1);
    TreeRemove(treeTM->root, 1);
    ncubTM = TreeCountDepth(treeTM, depthTM);

    free(x);
    free(crset);
    free(remain);
    return ncubTM;
}

// MATLAB interface
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    int i;
    unsigned char dim;
    mxArray *ptr;
    double *pl;
    Iter *iter;
    double *center, *radius;
    double *param_inf, *param_sup;
    Rectangle *QM;
    Tree *treeM;

    // iter->tree: tree for TM (input)
    // treeM: tree for M (created in this function)

    ptr = mxGetField(prhs[0], 0, "handle");
    iter = *(Iter **)mxGetData(ptr);
    if (iter==NULL) mexErrMsgTxt("Tree: tree is empty.");
    dim = iter->tree->Q->dim / 2;

    // parameter setting
    param_inf = (double*) mxGetPr(prhs[1]);
    param_sup = (double*) mxGetPr(prhs[2]);

    // pl[0]: variable for the answer: 
    // pl[0] = 0: hyperbolicity is NOT achieved
    // pl[0] = 1: hyperbolicity is achieved
    // pl[0] = 2: the chain recurrent set is empty
    plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
    pl = mxGetPr(plhs[0]);
    pl[0] = 0;

    // Make treeM
    center = (double*) malloc(sizeof(double) * dim);
    radius = (double*) malloc(sizeof(double) * dim);
    for (i = 0; i < dim; i++) {
        center[i] = iter->tree->Q->c[i];
        radius[i] = iter->tree->Q->r[i];
    }
    QM = RectangleNew(center, radius, dim);
    treeM = TreeNew(QM);
    RectangleFree(&QM);
    free(center);
    free(radius);

    //
    // Main part
    //

    // Compute R(f)
    // We compute R(f) only when the grid size of the base space was 
    // refined by the previous decomposition.
    if (iter->tree->sd[TreeDepth(iter->tree->root)] < dim) {
        if (!BaseChainRecSet(iter->tree, treeM, param_inf, param_sup)) {
            // empty set is hyperbolic (by definition)
            pl[0] = 2; 
            TreeDeleteDepth(treeM,0);
            TreeFree(&treeM);
            return;
        }
    }

    // Compute INV(N, Tf)
    if (!InvariantSet(iter->tree, iter->searchTree, param_inf, param_sup)) {
            // empty set is hyperbolic (by definition)
            pl[0] = 2; 
            TreeDeleteDepth(treeM,0);
            TreeFree(&treeM);
            return;
    }

    // Check if the zero section is isolated invariant set
    if (CheckIsolated(iter->tree, dim)) {
        // answer is YES
        pl[0] = 1; 
    } else {
        // answer is NO
        pl[0] = 0; 
    }
    TreeDeleteDepth(treeM,0);
    TreeFree(&treeM);
    return;
}
