void map_t(double *param_inf, double *param_sup, double *c, double *rR, double *infv, double *supv);
void map(int n, double *param_inf, double *param_sup, double *pR, double *infv, double *supv);


// the following declaration is  missing in Tree.h of the original GAIO (version 2.2.6)
void TreeSearchBoxRec(Tree *tree, double *a, double *b, unsigned long depth, SparseVector *nos);

// additional functions to GAIO, written by Zin ARAI
int TreeDownLeft(Tree *tree);
int TreeDownRight(Tree *tree);
void TreeSetFlagRec(Tree *tree, double *a, double *b, byte flag, char *found);
void TreeSubdivideAll(Tree *tree);
void TreeUnsetFlagsAll(Tree *tree, byte flag);
void TreeSetFlagsAll(Tree *tree, byte flag);
void TreeSetFlagsVect(Tree *tree, int depth, char *vect, byte flag);

