#!/usr/bin/python
import sys, shutil, subprocess

period = 7
argvs = sys.argv
argc = len(argvs)

if argc == 1:
    process_number = 0
    max_process = 1
elif argc == 3:
    process_number = int(argvs[1])
    max_process = int(argvs[2])
else:
    print("Usage: ./run_pp.py [process_number max_process]")
    
for b_num in range(0, 2047):
    if (b_num % max_process) == process_number:
        print("period = " + str(period) + ", b_num = " + str(b_num))
        subprocess.call(['../bin/check_pp', str(period), str(b_num)])
