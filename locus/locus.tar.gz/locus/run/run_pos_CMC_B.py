#!/usr/bin/env python
import sys, shutil, subprocess
import math

argvs = sys.argv
argc = len(argvs)

if argc == 1:
    process_number = 0
    max_process = 1
elif argc == 3:
    process_number = int(argvs[1])
    max_process = int(argvs[2])

b_num_min = 0
b_num_max = 1000
a_num_min = 0
a_num_max = 80
a_im_step = 0.01
npoints_ini =  128
npoints_max = 4096
depth_ini = 32
depth_max = 48

for b_num in range(b_num_min, b_num_max):
    if (b_num % max_process) == process_number:
        for a_num in range(a_num_min, a_num_max):
            print("b_num = " + str(b_num) + ", a_num = " + str(a_num))
            file0 = "../data/positive/{:04}".format(b_num + 0) + "-" + "{:02}".format(a_num + 0) + ".dat"
            file1 = "../data/positive/{:04}".format(b_num + 0) + "-" + "{:02}".format(a_num + 1) + ".dat"
            file2 = "../data/positive/{:04}".format(b_num + 1) + "-" + "{:02}".format(a_num + 0) + ".dat"
            file3 = "../data/positive/{:04}".format(b_num + 1) + "-" + "{:02}".format(a_num + 1) + ".dat"
            radius = 0.1;
            tmp_0 = math.sqrt(max(1 - (abs(40.0 - a_num + 0)/40) ** 2, 0))
            tmp_1 = math.sqrt(max(1 - (abs(40.0 - a_num - 1)/40) ** 2, 0))
            tmp_2 = math.sqrt(max(1 - (abs(40.0 - a_num + 1)/40) ** 2, 0))
            a_im_rad = radius * max(tmp_0, tmp_1, tmp_2)
            a_im = 0.0
            while a_im < a_im_rad + a_im_step/2:
                CMC_for = False
                CMC_inv = False
                Num_B   = False
                npoints = npoints_ini
                # Check CMC for the forward iteration of the Henon
                while npoints <= npoints_max:
                    result = subprocess.call(['../bin/check_CMC_pos_for', file0, file1, file2, file3, str(a_im), str(a_im + a_im_step), str(npoints)])
                    if (result == 0):
                        CMC_for = True
                        break
                    else:
                        npoints = npoints * 2
                # Check CMC for the backward iteration of the Henon
                npoints = npoints_ini
                while npoints <= npoints_max:
                    result = subprocess.call(['../bin/check_CMC_pos_inv', file0, file1, file2, file3, str(a_im), str(a_im + a_im_step), str(npoints)])
                    if (result == 0):
                        CMC_inv = True
                        break
                    else:
                        npoints = npoints * 2
                # Check Numerical Check B
                depth = depth_ini
                while depth <= depth_max:
                    result = subprocess.call(['../bin/check_B_pos', file0, file1, file2, file3, str(a_im), str(a_im + a_im_step), str(depth)])
                    if (result == 0):
                        Num_B = True
                        break
                    else:
                        depth = depth + 4
                # Exit if CMC is not satisfied
                if ((not CMC_for) or (not CMC_inv) or (not Num_B)):
                    print("Error: b_num = " + str(b_num) + ", a_num = " + str(a_num) + ", a_im = " + str(a_im))
                    exit() 
                a_im = a_im + a_im_step
