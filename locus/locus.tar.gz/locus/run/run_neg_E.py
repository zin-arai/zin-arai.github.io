#!/usr/bin/env python
import sys, shutil, subprocess
import math

argvs = sys.argv
argc = len(argvs)

if argc == 1:
    process_number = 0
    max_process = 1
elif argc == 3:
    process_number = int(argvs[1])
    max_process = int(argvs[2])

b_num_min = 0
b_num_max = 2000
a_num_min = 0
a_num_max = 400
param_depth_max = 24

for b_num in range(b_num_min, b_num_max):
    if (b_num % max_process) == process_number:
        for a_num in range(a_num_min, a_num_max):
            re_V_size = 0.002
            im_V_size = 0.004
            if   (b_num ==   0):
                param_depth =  8
                tree_depth  = 50
            elif (b_num <  500):
                param_depth =  4
                tree_depth  = 44
            elif (b_num < 1000):
                param_depth =  4
                tree_depth  = 40
            elif (b_num < 1200):
                param_depth =  4
                tree_depth  = 42
            elif (b_num < 1400):
                param_depth =  6
                tree_depth  = 44
            elif (b_num < 1600):
                param_depth =  8
                tree_depth  = 44
            elif (b_num < 1800):
                param_depth = 10
                tree_depth  = 44
            else:
                param_depth = 12
                tree_depth  = 44
            Num_E = False
            while param_depth <= param_depth_max:
                print("b_num = " + str(b_num) + ", a_num = " + str(a_num) + ", param_depth = " + str(param_depth) + ", tree_depth = " + str(tree_depth))
                result = subprocess.call(['../bin/check_E_neg', str(b_num), str(a_num), str(tree_depth), str(param_depth), str(param_depth)])
                if (result == 0):
                    Num_E = True
                    break
                else:
                    param_depth = param_depth + 2
                    tree_depth = tree_depth + 2
            if (not Num_E):
                print("Error: b_num = " + str(b_num) + ", a_num = " + str(a_num))
                exit() 
