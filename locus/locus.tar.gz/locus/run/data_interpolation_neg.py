#!/usr/bin/env python
import sys, shutil, subprocess

print("Interpolating horizontally...")

a_seq = [2.00, 2.25, 2.53, 2.85, 3.21, 3.61, 4.04, 4.52, 5.04, 5.60, 6.20]

for b_num in range(0, 11):
    b = - 0.1 * b_num
    a_tang = a_seq[b_num]
    #radius = 0.0625 + 0.4375 * abs(b)
    #radius = 0.1 + 0.4 * abs(b)
    #radius = 0.0546875 + 0.4375 * abs(b)
    radius = 0.0546875 + 0.3125 * abs(b)
    a_min = a_tang - radius
    step = 2 * radius / 200
    eps = step / 100
    for a_num in range(0, 201):
        filename = "../data/negative/{:04}".format(b_num * 200) + "-" + "{:03}".format(a_num) + ".dat"
        a = a_min + a_num * step
        dist = a - a_tang
        if dist < -0.3 - eps:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.5) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.3) * 100))) + ".dat"
            t =  5 * (dist + 0.5)
        elif dist < -0.1 - eps:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.3) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
            t =  5 * (dist + 0.3)
        elif dist < 0.0 - eps:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
            t = 10 * (dist + 0.1)
        elif dist < 0.1 - eps:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
            t = 10 * (dist - 0.0)
        elif dist < 0.3 - eps:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.3) * 100))) + ".dat"
            t =  5 * (dist - 0.1)
        else:
            filename_L = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.3) * 100))) + ".dat"
            filename_R = "../data/negative_distinguished/crossed-{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.5) * 100))) + ".dat"
            t =  5 * (dist - 0.3)
        subprocess.call(['../bin/interpolation_neg', str(t), filename, filename_L, filename_R])

print("Interpolating vertically...")

for b_base in [000, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800]:
    for i in range(1, 200):
        t = i / 200.0
        print("Generating " + str(b_base + i))
        for j in range(0, 201):
            filename_d = "../data/negative/{:04}".format(b_base      ) + "-" + "{:03}".format(j) + ".dat"
            filename_u = "../data/negative/{:04}".format(b_base + 200) + "-" + "{:03}".format(j) + ".dat"
            filename   = "../data/negative/{:04}".format(b_base + i  ) + "-" + "{:03}".format(j) + ".dat"
            subprocess.call(['../bin/interpolation_neg', str(t), filename, filename_d, filename_u])
