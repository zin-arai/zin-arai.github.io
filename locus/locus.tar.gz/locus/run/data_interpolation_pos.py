#!/usr/bin/python
import sys, shutil, subprocess, random

print("Interpolating horizontally...")

a_seq = [2.00, 2.21, 2.45, 2.72, 3.03, 3.37, 3.76, 4.18, 4.65, 5.15, 5.70]
t_step = 0.05

for b_num in range(0, 9):
    filename_left   = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
    filename_center = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
    filename_right  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
    for j in range(0, 41):
        filename = "../data/positive/{:04}".format(b_num * 100) + "-" + "{:02}".format(j) + ".dat"
        if j == 0:
            subprocess.call(['cp', filename_left, filename])
        elif (0 < j) & (j < 20):
            t = t_step * j
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left, filename_center])
        elif j == 20:
            subprocess.call(['cp', filename_center, filename])
        elif (20 < j) & (j < 40):
            t = t_step * (j - 20)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_center, filename_right])
        else:
            subprocess.call(['cp', filename_right, filename])

for b_num in range(9, 11):
    filename_left1  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
    filename_left2  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] -0.05) * 100))) + ".dat"
    filename_center = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
    filename_right  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
    for j in range(0, 41):
        filename = "../data/positive/{:04}".format(b_num * 100) + "-" + "{:02}".format(j) + ".dat"
        if j == 0:
            subprocess.call(['cp', filename_left1, filename])
        elif (0 < j) & (j < 10):
            t = 2 * t_step * j
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left1, filename_left2])
        elif j == 10:
            subprocess.call(['cp', filename_left2, filename])
        elif (10 < j) & (j < 20):
            t = 2 * t_step * (j - 10)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left2, filename_center])
        elif j == 20:
            subprocess.call(['cp', filename_center, filename])
        elif (20 < j) & (j < 40):
            t = t_step * (j - 20)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_center, filename_right])
        else:
            subprocess.call(['cp', filename_right, filename])

print("Interpolating vertically...")

for b_base in [000, 100, 200, 300, 400, 500, 600, 700, 800, 900]:
    for i in range(1, 100):
        t = i / 100.0
        print("Generating " + str(b_base + i))
        for j in range(0, 41):
            filename_d = "../data/positive/{:04}".format(b_base      ) + "-" + "{:02}".format(j) + ".dat"
            filename_u = "../data/positive/{:04}".format(b_base + 100) + "-" + "{:02}".format(j) + ".dat"
            filename   = "../data/positive/{:04}".format(b_base + i  ) + "-" + "{:02}".format(j) + ".dat"
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_d, filename_u])
