#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>
//#include <iomanip.h>

static const int nBoxes = 5; // The number of boxes
static const int nData  = 4; // The number of input data files

#include "locuslib.hpp"

int main(int argc, char * argv [])
{
    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double re_a[nData], re_b[nData];

    string inputFileName[nData];

    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    inputFileName[0] = argv[optind + 0];
    inputFileName[1] = argv[optind + 1];
    inputFileName[2] = argv[optind + 2];
    inputFileName[3] = argv[optind + 3];
    const double im_a_inf = atof(argv[optind + 4]);
    const double im_a_sup = atof(argv[optind + 5]);

    if (verbose) {
        cout << inputFileName[0] << endl;
        cout << inputFileName[1] << endl;
        cout << inputFileName[2] << endl;
        cout << inputFileName[3] << endl;
    }

    // Read the data file
    for (int i = 0; i < nData; i++) {
        input_data_negative(inputFileName[i],
                            re_a[i], re_b[i],
                            tx[i], ty[i], 
                            ax[i], ay[i], bx[i], by[i], 
                            Px[i], Py[i], Qx[i], Qy[i]);
    }

    // Parameter Setting
    const Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    const Interval Im_a (im_a_inf, im_a_sup);
    const Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    const Interval Im_b (0, 0);
    const CpxInterval a (Re_a, Im_a);
    const CpxInterval b (Re_b, Im_b);
    if (verbose) {cout << "a = " << a << ", b = " << b << endl;}

    for (int i = 0; i < nData; i++) {
        compute_focuses(tx[i], ty[i], fx[i], fy[i], gx[i], gy[i], px[i], py[i], qx[i], qy[i]);
        adjust_pq(px[i], py[i], qx[i], qy[i], Px[i], Py[i], Qx[i], Qy[i]);
    }

    const int dim = 4;
    double center[dim];
    double radius[dim];
    center[0] = 0;
    center[1] = 0;
    center[2] = 0;
    center[3] = 0;
    radius[0] = 8;
    radius[1] = 8;
    radius[2] = 8;
    radius[3] = 8;
    Tree T = Tree(center, radius, dim);

    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    const CpxInterval fx2 (ifx[2]);
    const CpxInterval fy2 (ify[2]);
    const CpxInterval fx3 (ifx[3]);
    const CpxInterval fy3 (ify[3]);
    const CpxInterval gx3 (igx[3]);
    const CpxInterval gy3 (igy[3]);
    const Interval CX = (ipx[0] + iqx[4]) / 2.0;
    const Interval RX = (ipx[0] - iqx[4]) / 2.0;
    const Interval CY = (ipy[4] + iqy[4]) / 2.0;
    const Interval RY = (ipy[4] - iqy[4]) / 2.0;

    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
    }

    //
    // Main Part
    //
    const int maxDepth = 80;
    const int to_be_kept = 1;
    bool Numerical_Check_C = false;
    Interval Re, Im;
    CpxInterval x, y, u, v, tmp;
    while (getHeight(T) < maxDepth) {
        subdivide(T);
        unsetFlagsAll(T, to_be_kept);
        getFirstCube(T);
        do {
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            x = CpxInterval(Re, Im);
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            y = CpxInterval(Re, Im);
            //euc2proj(fx3, fy3, gx3, gy3, x, y, u, v);
            if (zero_in(df3(a, b, fx3, fy3, gx3, gy3, fx2, fy2, x, y))) {
                if (intersect_with(3, x, y, CX, CY, RX, RY, 
                                   ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                   maxPx, maxPy, minQx, minQy)) {
                    tmp = x;
                    x = square(x) - a - b * y;
                    y = tmp;
                    if (intersect_with(4, x, y, CX, CY, RX, RY, 
                                       ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                       maxPx, maxPy, minQx, minQy)) {
                        tmp = x;
                        x = square(x) - a - b * y;
                        y = tmp;
                        if (intersect_with(1, x, y, CX, CY, RX, RY, 
                                           ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                           maxPx, maxPy, minQx, minQy)) {
                            tmp = x;
                            x = square(x) - a - b * y;
                            y = tmp;
                            if (intersect_with(2, x, y, CX, CY, RX, RY, 
                                               ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                               maxPx, maxPy, minQx, minQy)) {
                                setFlag(T.currentCube, to_be_kept);
                            }
                        }
                    }
                }
            }
        } while (getNextCube(T));
        remove(T, to_be_kept);
        if (getHeight(T) == 0) {
            Numerical_Check_C = true;
            break;
        } else {
            if (verbose) {cout << "Depth " << getHeight(T) << ": " 
                               << countCubes(T) << " cubes remaining." << endl;}
        }
    }
    
    if (Numerical_Check_C) {
        if (verbose) {cout << "OK." << endl;}
        return 0;
    } else {
        if (verbose) {cout << "Numerical Check C Fails." << endl;}
        return 1;
    }
}
