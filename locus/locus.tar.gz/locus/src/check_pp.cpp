#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>
//#include <iomanip.h>

static const int nBoxes = 0; // Dummy
static const int nData  = 0;  // Dummy
#include "locuslib.hpp"

#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/lu.hpp>
#include <boost/numeric/ublas/io.hpp>

namespace bnu = boost::numeric::ublas;

template <class T>
bool invert(const bnu::matrix<T>& a, bnu::matrix<T>& b) 
{
    bnu::matrix<T> tmp(a);
    bnu::permutation_matrix<size_t> pm(tmp.size1());
    
    if (bnu::lu_factorize(tmp, pm) != 0) {
        return false;
    }

    b = bnu::identity_matrix<T>(tmp.size1());
    bnu::lu_substitute(tmp, pm, b);

    return true;
}

template <class T>
int F(const int p, const T a, const T b, const bnu::vector<T> x, bnu::vector<T>& y) 
{
    for (int i = 0; i < p - 1; i ++) {
        y(2 * i    ) = x(2 * i + 2) - x(2 * i) * x(2 * i) + a + b * x(2 * i + 1);
        y(2 * i + 1) = x(2 * i + 3) - x(2 * i);
    }
    y(2 * (p - 1)    ) = x(0) - x(2 * (p - 1)) * x(2 * (p - 1)) + a + b * x(2 * (p - 1) + 1);
    y(2 * (p - 1) + 1) = x(1) - x(2 * (p - 1));

    return 0;
}

template <class T>
int dF_init(const int p, const T b, bnu::matrix<T>& D)
{
    for (int i = 0; i < 2 * p; i++) {
        for (int j = 0; j < 2 * p; j++) {
            D(i, j) = 0.0;
        }
    }

    for (int i = 0; i < p; i++) {
        D(2 * i, 2 * i + 1) = b;
        D(2 * i + 1, 2 * i) = 1.0;
    }

    for (int i = 0; i < p - 1; i++) {
        D(2 * i,     2 * i + 2) = 1.0;
        D(2 * i + 1, 2 * i + 3) = 1.0;
    }

    D(2 * (p - 1),      0) = 1.0;
    D(2 * (p - 1) + 1,  1) = 1.0;

    return 0;
}

template <class T>
int dF_change(const int p, const bnu::vector<T> x, bnu::matrix<T>& D)
{
    for (int i = 0; i < p; i++) {
        D(2 * i, 2 * i) = - 2.0 * x(2 * i);
    }
    return 0;
}

int dF(const int p, const CpxInterval b, const bnu::vector<CpxInterval> x, bnu::matrix<CpxInterval>& D)
{
    for (int i = 0; i < 2 * p; i++) {
        for (int j = 0; j < 2 * p; j++) {
            D(i, j) = Interval(0.0);
        }
    }

    for (int i = 0; i < p; i++) {
        D(2 * i, 2 * i) = - 2.0 * x(2 * i);
    }

    for (int i = 0; i < p; i++) {
        D(2 * i, 2 * i + 1) = b;
        D(2 * i + 1, 2 * i) = Interval(1.0);
    }

    for (int i = 0; i < p - 1; i++) {
        D(2 * i,     2 * i + 2) = Interval(1.0);
        D(2 * i + 1, 2 * i + 3) = Interval(1.0);
    }

    D(2 * (p - 1),      0) = Interval(1.0);
    D(2 * (p - 1) + 1,  1) = Interval(1.0);

    return 0;
}

bool check_pp_escaping(const int p, const CpxInterval A, const CpxInterval B)
{
    bnu::vector< complex<double> > x(2 * p);
    bnu::vector< complex<double> > x_prev(2 * p);
    bnu::vector< complex<double> > y(2 * p);
    bnu::matrix< complex<double> > C(2 * p, 2 * p);
    bnu::matrix< complex<double> > D(2 * p, 2 * p);

    complex<double> a, b;
    a = complex<double> ((A.getRe().lower() + A.getRe().upper()) / 2, 0);
    b = complex<double> ((B.getRe().lower() + B.getRe().upper()) / 2, 0);

    const double tolerance_Newton = 1e-13;
    const double tolerance_imag = 1.0 / 256;
    const double eps = tolerance_imag / 1.0625;
    const int max_try = 2048;

    dF_init(p, b, D);
    for (int j = 0; j < max_try; j++) {
        for (int i = 0; i < 2 * p; i++) {
            x(i) = complex<double> (c_rand(-8, 8), c_rand(-8, 8));
        }

        // Newton's method
        int ite = 0;
        const int max_iteration = 256;
        do{
            ite++;
            x_prev = x;
            dF_change(p, x, D); // D = Df(x)
            invert(D, C);       // C = D^{-1}
            F(p, a, b, x, y);   // y = F(x)
            x = x - prod(C, y);
        } while((norm_1(x - x_prev) > tolerance_Newton) && (ite < max_iteration));
        double tmp = 0;
        for (int i = 1; i < 2 * p; i++) {
            tmp = max(tmp, abs(x(i).imag()));
        }

        if (tmp > tolerance_imag) {
            // Krawczyk method
            bnu::vector<CpxInterval> x0(2 * p);
            bnu::vector<CpxInterval> X(2 * p);
            bnu::vector<CpxInterval> Y(2 * p);
            bnu::vector<CpxInterval> K(2 * p);
            bnu::matrix<CpxInterval> int_C(2 * p, 2 * p);
            bnu::matrix<CpxInterval> int_D(2 * p, 2 * p);
            bnu::matrix<CpxInterval> Id(2 * p, 2 * p);
            
            for (int i = 0; i < 2 * p; i++) {
                Id(i, i) = CpxInterval(1.0);
                for (int j = 0; j < 2 * p; j++) {
                    int_C(i, j) = CpxInterval(C(i, j).real(), C(i,j).imag());
                }
            }
            
            for (int i = 0; i < 2 * p; i++) {
                x0(i) = CpxInterval(x(i).real(), x(i).imag());
                X(i)  = CpxInterval(Interval(x(i).real() - eps, x(i).real() + eps), 
                                    Interval(x(i).imag() - eps, x(i).imag() + eps));
            }
            
            F(p, A, B, x0, Y);  // Y = F(x_0)
            dF(p, B, X, int_D); // D = DF(X)
            K = x0 - prod(int_C, Y) + prod((Id - prod(int_C, int_D)), (X - x0));

            bool ans = true;
            for (int i = 0; i < 2 * p; i++) {
                if (!(proper_subset(K(i), X(i)))) {
                    ans = false;
                }
            }
            if (ans) {
                return true;
            }
        }
    }
    return false;
}

int main(int argc, char * argv [])
{
    const int n_subdiv = 2048;
    const int period = atoi(argv[1]);
    const int b_num = atoi(argv[2]); // Job number, from 0 to 2047

    const double b_step = 1.0 / n_subdiv;
    const double a_step = 1.0 / n_subdiv;

    const double eps = 1.0/68719476736;
    
    const double b = -1.0 + b_num * b_step;
    double chi;
    if (b > 0) {
        chi = 0.1;
    } else {
        chi = 0.0546875 + 0.3125 * abs(b);
    }
    chi = chi - a_step * 2;

    // a = sn is the saddle node paramter
    double sn = - (b + 1) * (b + 1) / 4; 
    sn = sn - a_step * 2;

    // a = pd is the fist period doubling paramter
    //double pd = (b - 1) * (b - 1) * 3 / 4; 
    //pd = pd - a_step * 2;
    
    CpxInterval A;
    const CpxInterval B(Interval(b - eps, b + b_step + eps));

    for (double a = sn; a < tang(b) - chi; a += a_step) {
        A = CpxInterval(Interval(a - eps, a + a_step + eps));
        if (!(check_pp_escaping(period, A, B))) {
            cout << "Error: b = " << b << ", a = " << a << endl;
            break;
        }
    }
}
