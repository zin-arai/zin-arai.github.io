#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>
//#include <iomanip.h>

static const int nBoxes = 4; // The number of boxes
static const int nData  = 4; // The number of input data files
enum SDirection {Right = 0, Up = 1, Down = 2};

#include "locuslib.hpp"

void computeURegion(Tree &T, const double fx[nData][nBoxes], const double fy[nData][nBoxes], CpxInterval &ans)
{
    Interval ifx[nBoxes], ify[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = Interval(min4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]), 
                            max4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]));
        ify[box] = Interval(min4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]), 
                            max4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]));
    }

    // Prepare vector X and Y
    int n = countCubes(T);
    vector<CpxInterval> X (n); // Euclidian
    vector<CpxInterval> Y (n); // Euclidian
    Interval Re, Im;
    int cube_iter = 0;
    if (getFirstCube(T)) {
        do {
            // X
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            X[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            Y[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(T));
    }

    CpxInterval U; // Projective Coordinates
    double reUmax, reUmin, imUmax, imUmin;

    const int box = 3;
    U = X[0] - Y[0] * (ifx[box] - X[0]) / (ify[box] - Y[0]);
    reUmin = U.getRe().lower();
    reUmax = U.getRe().upper();
    imUmin = U.getIm().lower();
    imUmax = U.getIm().upper();

    for (int i = 1; i < n; i++) {
        U = X[i] - Y[i] * (ifx[box] - X[i]) / (ify[box] - Y[i]);
        reUmin = min2(reUmin, U.getRe().lower());
        reUmax = max2(reUmax, U.getRe().upper());
        imUmin = min2(imUmin, U.getIm().lower());
        imUmax = max2(imUmax, U.getIm().upper());
    }

    Re = Interval(reUmin, reUmax);
    Im = Interval(imUmin, imUmax);
    ans = CpxInterval(Re, Im);
}

void computeUnstable(Tree &T,
                     Tree &unstable_b1, Tree &unstable_b2, Tree &unstable_b3, Tree &unstable_b4, 
                     const CpxInterval a, const CpxInterval b, 
                     const double fx[nData][nBoxes], const double fy[nData][nBoxes], 
                     const double gx[nData][nBoxes], const double gy[nData][nBoxes],                         
                     const double ax[nData][nBoxes], const double ay[nData][nBoxes], 
                     const double bx[nData][nBoxes], const double by[nData][nBoxes], 
                     const double px[nData][nBoxes], const double py[nData][nBoxes],
                     const double qx[nData][nBoxes], const double qy[nData][nBoxes],
                     const double Px[nData][nBoxes], const double Py[nData][nBoxes], 
                     const double Qx[nData][nBoxes], const double Qy[nData][nBoxes])
{
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], 
        iax[nBoxes], ibx[nBoxes], iay[nBoxes], iby[nBoxes], 
        ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    Interval Re, Im;

    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        //minPx[box] = min4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        //minPy[box] = min4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
        //maxQx[box] = max4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        //maxQy[box] = max4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
    }

    CpxInterval X_f1, Y_f1, X_f2, Y_f2, X_f3, Y_f3, X_f4, Y_f4; // Forward Images
    CpxInterval X_b1, Y_b1, X_b2, Y_b2, X_b3, Y_b3, X_b4, Y_b4, X_b5, Y_b5; // Backward Images
    CpxInterval tmp;

    const Interval CX = (ipx[0] + iqx[3]) / 2.0;
    const Interval RX = (ipx[0] - iqx[3]) / 2.0;
    const Interval CY = (ipy[3] + iqy[3]) / 2.0;
    const Interval RY = (ipy[3] - iqy[3]) / 2.0;
    int n; 
    double A[4], B[4];
    vector<CpxInterval> X; // Euclidian
    vector<CpxInterval> Y; // Euclidian
    int cube_iter;
    
    CpxInterval x1, y1, x2, y2, x3, y3;

    //
    // unstable_b1
    //
    n = countCubes(unstable_b1);
    vector<CpxInterval> Xb1 (n); // Euclidian
    vector<CpxInterval> Yb1 (n); // Euclidian
    cube_iter = 0;
    if (getFirstCube(unstable_b1)) {
        do {
            // X
            Re = Interval(unstable_b1.center[0] - unstable_b1.radius[0], unstable_b1.center[0] + unstable_b1.radius[0]);
            Im = Interval(unstable_b1.center[1] - unstable_b1.radius[1], unstable_b1.center[1] + unstable_b1.radius[1]);
            Xb1[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b1.center[2] - unstable_b1.radius[2], unstable_b1.center[2] + unstable_b1.radius[2]);
            Im = Interval(unstable_b1.center[3] - unstable_b1.radius[3], unstable_b1.center[3] + unstable_b1.radius[3]);
            Yb1[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(unstable_b1));
    }

    char flag_b1tree[n];
    for (int i = 0; i < n; i++) {
        flag_b1tree[i] = 0;
        if (intersect_with(0, Xb1[i], Yb1[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, 
                           ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(Xb1[i]) - a - b * Yb1[i];
            Y_f1 = Xb1[i];
            if (intersect_with(0, X_f1, Y_f1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                if (intersect_with(2, X_f2, Y_f2, CX, CY, RX, RY,
                                   ifx, ify, igx, igy, iax, iay,
                                   ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    if (intersect_with(3, X_f3, Y_f3, CX, CY, RX, RY,
                                       ifx, ify, igx, igy, iax, iay, 
                                       ibx, iby,  
                                       maxPx, maxPy, minQx, minQy)) {
                        flag_b1tree[i] = 1;
                    }
                }
            }
        }
    }

    if (!zero_in(b.getRe())) {
        char flag_b1[n];
        char flag_b2[n];
        char flag_b3[n];
        char flag_b4[n];
        char flag_b5[n];
        for (int i = 0; i < n; i++) {
            flag_b1[i] = 0;
            flag_b2[i] = 0;
            flag_b3[i] = 0;
            flag_b4[i] = 0;
            flag_b5[i] = 0;
            X_b1 = Yb1[i];
            Y_b1 = (square(Yb1[i]) - Xb1[i] - a) / b;
            if (intersect_with(0, X_b1, Y_b1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b1[i] = 1;
            }
            X_b2 = Y_b1;
            Y_b2 = (square(Y_b1) - X_b1 - a) / b;
            if (intersect_with(0, X_b2, Y_b2, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b2[i] = 1;
            }
            X_b3 = Y_b2;
            Y_b3 = (square(Y_b2) - X_b2 - a) / b;
            if (intersect_with(0, X_b3, Y_b3, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b3[i] = 1;
            }
            X_b4 = Y_b3;
            Y_b4 = (square(Y_b3) - X_b3 - a) / b;
            if (intersect_with(0, X_b4, Y_b4, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b4[i] = 1;
            }
            X_b5 = Y_b4;
            Y_b5 = (square(Y_b4) - X_b4 - a) / b;
            if (intersect_with(0, X_b5, Y_b5, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b5[i] = 1;
            }
        }
        for (int i = 0; i < n; i++) {
            flag_b1tree[i] = flag_b1tree[i] * flag_b1[i] * flag_b2[i] * flag_b3[i] * flag_b4[i] * flag_b5[i];
        }
    } else {
        char flag_b1[n];
        for (int i = 0; i < n; i++) {
            tmp = square(Yb1[i]) - a - b * Interval(-8, 8) - Xb1[i];
            if ((tmp.getRe().lower() * tmp.getRe().upper() <= 0) && 
                (tmp.getIm().lower() * tmp.getIm().upper() <= 0)){
                flag_b1[i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            flag_b1tree[i] = flag_b1tree[i] * flag_b1[i];
        }
    }
    setFlagsVect(unstable_b1, flag_b1tree, 1);
    remove(unstable_b1, 1);
    //
    // unstable_b1 (end)
    //

    //
    // unstable_b2
    //
    n = countCubes(unstable_b2);
    vector<CpxInterval> Xb2 (n); // Euclidian
    vector<CpxInterval> Yb2 (n); // Euclidian
    cube_iter = 0;
    if (getFirstCube(unstable_b2)) {
        do {
            // X
            Re = Interval(unstable_b2.center[0] - unstable_b2.radius[0], unstable_b2.center[0] + unstable_b2.radius[0]);
            Im = Interval(unstable_b2.center[1] - unstable_b2.radius[1], unstable_b2.center[1] + unstable_b2.radius[1]);
            Xb2[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b2.center[2] - unstable_b2.radius[2], unstable_b2.center[2] + unstable_b2.radius[2]);
            Im = Interval(unstable_b2.center[3] - unstable_b2.radius[3], unstable_b2.center[3] + unstable_b2.radius[3]);
            Yb2[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(unstable_b2));
    }

    char flag_b2tree[n];
    for (int i = 0; i < n; i++) {
        flag_b2tree[i] = 0;
        if (intersect_with(0, Xb2[i], Yb2[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, 
                           ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(Xb2[i]) - a - b * Yb2[i];
            Y_f1 = Xb2[i];
            if (intersect_with(0, X_f1, Y_f1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                if (intersect_with(0, X_f2, Y_f2, CX, CY, RX, RY,
                                   ifx, ify, igx, igy, iax, iay,
                                   ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    if (intersect_with(2, X_f3, Y_f3, CX, CY, RX, RY,
                                       ifx, ify, igx, igy, iax, iay, 
                                       ibx, iby,  
                                       maxPx, maxPy, minQx, minQy)) {
                        X_f4 = square(X_f3) - a - b * Y_f3;
                        Y_f4 = X_f3;
                        if (intersect_with(3, X_f4, Y_f4, CX, CY, RX, RY,
                                           ifx, ify, igx, igy, iax, iay, 
                                           ibx, iby,  
                                           maxPx, maxPy, minQx, minQy)) {
                            flag_b2tree[i] = 1;
                        }
                    }
                }
            }
        }
    }

    if (!zero_in(b.getRe())) {
        char flag_b1[n];
        char flag_b2[n];
        char flag_b3[n];
        char flag_b4[n];
        char flag_b5[n];
        for (int i = 0; i < n; i++) {
            flag_b1[i] = 0;
            flag_b2[i] = 0;
            flag_b3[i] = 0;
            flag_b4[i] = 0;
            flag_b5[i] = 0;
            X_b1 = Yb2[i];
            Y_b1 = (square(Yb2[i]) - Xb2[i] - a) / b;
            if (intersect_with(0, X_b1, Y_b1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b1[i] = 1;
            }
            X_b2 = Y_b1;
            Y_b2 = (square(Y_b1) - X_b1 - a) / b;
            if (intersect_with(0, X_b2, Y_b2, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b2[i] = 1;
            }
            X_b3 = Y_b2;
            Y_b3 = (square(Y_b2) - X_b2 - a) / b;
            if (intersect_with(0, X_b3, Y_b3, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b3[i] = 1;
            }
            X_b4 = Y_b3;
            Y_b4 = (square(Y_b3) - X_b3 - a) / b;
            if (intersect_with(0, X_b4, Y_b4, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b4[i] = 1;
            }
            X_b5 = Y_b4;
            Y_b5 = (square(Y_b4) - X_b4 - a) / b;
            if (intersect_with(0, X_b5, Y_b5, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b5[i] = 1;
            }
        }
        for (int i = 0; i < n; i++) {
            flag_b2tree[i] = flag_b2tree[i] * flag_b1[i] * flag_b2[i] * flag_b3[i] * flag_b4[i] * flag_b5[i];
        }
    } else {
        char flag_b1[n];
        for (int i = 0; i < n; i++) {
            tmp = square(Yb2[i]) - a - b * Interval(-8, 8) - Xb2[i];
            if ((tmp.getRe().lower() * tmp.getRe().upper() <= 0) && 
                (tmp.getIm().lower() * tmp.getIm().upper() <= 0)){
                flag_b1[i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            flag_b2tree[i] = flag_b2tree[i] * flag_b1[i];
        }
    }
    setFlagsVect(unstable_b2, flag_b2tree, 1);
    remove(unstable_b2, 1);
    //
    // unstable_b2 (end)
    //

    //
    // unstable_b3
    //
    n = countCubes(unstable_b3);
    vector<CpxInterval> Xb3 (n); // Euclidian
    vector<CpxInterval> Yb3 (n); // Euclidian
    cube_iter = 0;
    if (getFirstCube(unstable_b3)) {
        do {
            // X
            Re = Interval(unstable_b3.center[0] - unstable_b3.radius[0], unstable_b3.center[0] + unstable_b3.radius[0]);
            Im = Interval(unstable_b3.center[1] - unstable_b3.radius[1], unstable_b3.center[1] + unstable_b3.radius[1]);
            Xb3[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b3.center[2] - unstable_b3.radius[2], unstable_b3.center[2] + unstable_b3.radius[2]);
            Im = Interval(unstable_b3.center[3] - unstable_b3.radius[3], unstable_b3.center[3] + unstable_b3.radius[3]);
            Yb3[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(unstable_b3));
    }

    char flag_b3tree[n];
    for (int i = 0; i < n; i++) {
        flag_b3tree[i] = 0;
        if (intersect_with(0, Xb3[i], Yb3[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, 
                           ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(Xb3[i]) - a - b * Yb3[i];
            Y_f1 = Xb3[i];
            if (intersect_with(0, X_f1, Y_f1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                if (intersect_with(0, X_f2, Y_f2, CX, CY, RX, RY,
                                   ifx, ify, igx, igy, iax, iay,
                                   ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    if (intersect_with(0, X_f3, Y_f3, CX, CY, RX, RY,
                                       ifx, ify, igx, igy, iax, iay, 
                                       ibx, iby,  
                                       maxPx, maxPy, minQx, minQy)) {
                        X_f4 = square(X_f3) - a - b * Y_f3;
                        Y_f4 = X_f3;
                        if (intersect_with(2, X_f4, Y_f4, CX, CY, RX, RY,
                                           ifx, ify, igx, igy, iax, iay, 
                                           ibx, iby,  
                                           maxPx, maxPy, minQx, minQy)) {
                            flag_b3tree[i] = 1;
                        }
                    }
                }
            }
        }
    }

    if (!zero_in(b.getRe())) {
        char flag_b1[n];
        char flag_b2[n];
        char flag_b3[n];
        char flag_b4[n];
        char flag_b5[n];
        for (int i = 0; i < n; i++) {
            flag_b1[i] = 0;
            flag_b2[i] = 0;
            flag_b3[i] = 0;
            flag_b4[i] = 0;
            flag_b5[i] = 0;
            X_b1 = Yb3[i];
            Y_b1 = (square(Yb3[i]) - Xb3[i] - a) / b;
            if (intersect_with(0, X_b1, Y_b1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b1[i] = 1;
            }
            X_b2 = Y_b1;
            Y_b2 = (square(Y_b1) - X_b1 - a) / b;
            if (intersect_with(0, X_b2, Y_b2, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b2[i] = 1;
            }
            X_b3 = Y_b2;
            Y_b3 = (square(Y_b2) - X_b2 - a) / b;
            if (intersect_with(0, X_b3, Y_b3, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b3[i] = 1;
            }
            X_b4 = Y_b3;
            Y_b4 = (square(Y_b3) - X_b3 - a) / b;
            if (intersect_with(0, X_b4, Y_b4, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b4[i] = 1;
            }
            X_b5 = Y_b4;
            Y_b5 = (square(Y_b4) - X_b4 - a) / b;
            if (intersect_with(0, X_b5, Y_b5, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b5[i] = 1;
            }
        }
        for (int i = 0; i < n; i++) {
            flag_b3tree[i] = flag_b3tree[i] * flag_b1[i] * flag_b2[i] * flag_b3[i] * flag_b4[i] * flag_b5[i];
        }
    } else {
        char flag_b1[n];
        for (int i = 0; i < n; i++) {
            tmp = square(Yb3[i]) - a - b * Interval(-8, 8) - Xb3[i];
            if ((tmp.getRe().lower() * tmp.getRe().upper() <= 0) && 
                (tmp.getIm().lower() * tmp.getIm().upper() <= 0)){
                flag_b1[i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            flag_b3tree[i] = flag_b3tree[i] * flag_b1[i];
        }
    }
    setFlagsVect(unstable_b3, flag_b3tree, 1);
    remove(unstable_b3, 1);
    //
    // unstable_b3 (end)
    //

    //
    // unstable_b4
    //
    //depth = getCubeDepth(unstable_b4.rootCube);
    n = countCubes(unstable_b4);
    vector<CpxInterval> Xb4 (n); // Euclidian
    vector<CpxInterval> Yb4 (n); // Euclidian
    cube_iter = 0;
    if (getFirstCube(unstable_b4)) {
        do {
            // X
            Re = Interval(unstable_b4.center[0] - unstable_b4.radius[0], unstable_b4.center[0] + unstable_b4.radius[0]);
            Im = Interval(unstable_b4.center[1] - unstable_b4.radius[1], unstable_b4.center[1] + unstable_b4.radius[1]);
            Xb4[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b4.center[2] - unstable_b4.radius[2], unstable_b4.center[2] + unstable_b4.radius[2]);
            Im = Interval(unstable_b4.center[3] - unstable_b4.radius[3], unstable_b4.center[3] + unstable_b4.radius[3]);
            Yb4[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(unstable_b4));
    }

    char flag_b4tree[n];
    for (int i = 0; i < n; i++) {
        flag_b4tree[i] = 0;
        if (intersect_with(0, Xb4[i], Yb4[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, 
                           ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(Xb4[i]) - a - b * Yb4[i];
            Y_f1 = Xb4[i];
            if (intersect_with(0, X_f1, Y_f1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                if (intersect_with(0, X_f2, Y_f2, CX, CY, RX, RY,
                                   ifx, ify, igx, igy, iax, iay,
                                   ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    if (intersect_with(0, X_f3, Y_f3, CX, CY, RX, RY,
                                       ifx, ify, igx, igy, iax, iay, 
                                       ibx, iby,  
                                       maxPx, maxPy, minQx, minQy)) {
                        X_f4 = square(X_f3) - a - b * Y_f3;
                        Y_f4 = X_f3;
                        if (intersect_with(0, X_f4, Y_f4, CX, CY, RX, RY,
                                           ifx, ify, igx, igy, iax, iay, 
                                           ibx, iby,  
                                           maxPx, maxPy, minQx, minQy)) {
                            flag_b4tree[i] = 1;
                        }
                    }
                }
            }
        }
    }

    if (!zero_in(b.getRe())) {
        char flag_b1[n];
        char flag_b2[n];
        char flag_b3[n];
        char flag_b4[n];
        char flag_b5[n];
        for (int i = 0; i < n; i++) {
            flag_b1[i] = 0;
            flag_b2[i] = 0;
            flag_b3[i] = 0;
            flag_b4[i] = 0;
            flag_b5[i] = 0;
            X_b1 = Yb4[i];
            Y_b1 = (square(Yb4[i]) - Xb4[i] - a) / b;
            if (intersect_with(0, X_b1, Y_b1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b1[i] = 1;
            }
            X_b2 = Y_b1;
            Y_b2 = (square(Y_b1) - X_b1 - a) / b;
            if (intersect_with(0, X_b2, Y_b2, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b2[i] = 1;
            }
            X_b3 = Y_b2;
            Y_b3 = (square(Y_b2) - X_b2 - a) / b;
            if (intersect_with(0, X_b3, Y_b3, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b3[i] = 1;
            }
            X_b4 = Y_b3;
            Y_b4 = (square(Y_b3) - X_b3 - a) / b;
            if (intersect_with(0, X_b4, Y_b4, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b4[i] = 1;
            }
            X_b5 = Y_b4;
            Y_b5 = (square(Y_b4) - X_b4 - a) / b;
            if (intersect_with(0, X_b5, Y_b5, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b5[i] = 1;
            }
        }
        for (int i = 0; i < n; i++) {
            flag_b4tree[i] = flag_b4tree[i] * flag_b1[i] * flag_b2[i] * flag_b3[i] * flag_b4[i] * flag_b5[i];
        }
    } else {
        char flag_b1[n];
        for (int i = 0; i < n; i++) {
            tmp = square(Yb4[i]) - a - b * Interval(-8, 8) - Xb4[i];
            if ((tmp.getRe().lower() * tmp.getRe().upper() <= 0) && 
                (tmp.getIm().lower() * tmp.getIm().upper() <= 0)){
                flag_b1[i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            flag_b4tree[i] = flag_b4tree[i] * flag_b1[i];
        }
    }
    setFlagsVect(unstable_b4, flag_b4tree, 1);
    remove(unstable_b4, 1);
    //
    // unstable_b4 (end)
    //

    //
    //
    //
    n = countCubes(T);
    X.resize(n); // Euclidian
    Y.resize(n); // Euclidian
    cube_iter = 0;
    if (getFirstCube(T)) {
        do {
            // X
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            X[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            Y[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(T));
    }

    char flag[n];
    for (int i = 0; i < n; i++) {
        flag[i] = 0;
        if (intersect_with(0, X[i], Y[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, 
                           ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(X[i]) - a - b * Y[i];
            Y_f1 = X[i];
            if (intersect_with(2, X_f1, Y_f1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                if (intersect_with(3, X_f2, Y_f2, CX, CY, RX, RY,
                                   ifx, ify, igx, igy, iax, iay,
                                   ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) {
                    flag[i] = 1;
                }
            }
        }
    }

    if (!zero_in(b.getRe())) {
        char flag_b1[n];
        char flag_b2[n];
        char flag_b3[n];
        char flag_b4[n];
        char flag_b5[n];
        //double A[4], B[4];
        for (int i = 0; i < n; i++) {
            flag_b1[i] = 0;
            flag_b2[i] = 0;
            flag_b3[i] = 0;
            flag_b4[i] = 0;
            flag_b5[i] = 0;
            X_b1 = Y[i];
            Y_b1 = (square(Y[i]) - X[i] - a) / b;
            if (intersect_with(0, X_b1, Y_b1, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b1[i] = 1;
            }
            X_b2 = Y_b1;
            Y_b2 = (square(Y_b1) - X_b1 - a) / b;
            if (intersect_with(0, X_b2, Y_b2, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b2[i] = 1;
            }
            X_b3 = Y_b2;
            Y_b3 = (square(Y_b2) - X_b2 - a) / b;
            if (intersect_with(0, X_b3, Y_b3, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b3[i] = 1;
            }
            X_b4 = Y_b3;
            Y_b4 = (square(Y_b3) - X_b3 - a) / b;
            if (intersect_with(0, X_b4, Y_b4, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b4[i] = 1;
            }
            X_b5 = Y_b4;
            Y_b5 = (square(Y_b4) - X_b4 - a) / b;
            if (intersect_with(0, X_b5, Y_b5, CX, CY, RX, RY,
                               ifx, ify, igx, igy, iax, iay, 
                               ibx, iby,  
                               maxPx, maxPy, minQx, minQy)) {
                flag_b5[i] = 1;
            }
        }
        for (int i = 0; i < n; i++) {
            flag[i] = flag[i] * flag_b1[i] * flag_b2[i] * flag_b3[i] * flag_b4[i] * flag_b5[i];
        }
    } else {
        char flag_b1[n];
        for (int i = 0; i < n; i++) {
            tmp = square(Y[i]) - a - b * Interval(-8, 8) - X[i];
            if ((tmp.getRe().lower() * tmp.getRe().upper() <= 0) && 
                (tmp.getIm().lower() * tmp.getIm().upper() <= 0)){
                flag_b1[i] = 1;
            }
        }

        for (int i = 0; i < n; i++) {
            flag[i] = flag[i] * flag_b1[i];
        }
    }
    setFlagsVect(T, flag, 1);
    remove(T, 1);
    //
    //
    //

    int counter = 0;
    //
    // unstable_b4 (start), shirink unstable_b4
    //
    unsetFlagsAll(unstable_b3, 1);
    n = countCubes(unstable_b4);
    char image_in_b3[n];
    if (getFirstCube(unstable_b4)) {
        CpxInterval X0, Y0, X1, Y1;
        do {
            // X
            Re = Interval(unstable_b4.center[0] - unstable_b4.radius[0], unstable_b4.center[0] + unstable_b4.radius[0]);
            Im = Interval(unstable_b4.center[1] - unstable_b4.radius[1], unstable_b4.center[1] + unstable_b4.radius[1]);
            X0 = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b4.center[2] - unstable_b4.radius[2], unstable_b4.center[2] + unstable_b4.radius[2]);
            Im = Interval(unstable_b4.center[3] - unstable_b4.radius[3], unstable_b4.center[3] + unstable_b4.radius[3]);
            Y0 = CpxInterval(Re, Im);
            X1 = square(X0) - a - b * Y0;
            Y1 = X0;
            A[0] = X1.getRe().lower();
            A[1] = X1.getIm().lower();
            A[2] = mid(Y1.getRe());
            A[3] = mid(Y1.getIm());
            B[0] = X1.getRe().upper();
            B[1] = X1.getIm().upper();
            B[2] = mid(Y1.getRe());
            B[3] = mid(Y1.getIm());
            image_in_b3[counter] = 0;
            setFlagRec(unstable_b3, A, B, 1, image_in_b3 + counter);
            counter++;
        } while (getNextCube(unstable_b4));
    }
    remove(unstable_b3, 1);
    setFlagsVect(unstable_b4, image_in_b3, 1);
    remove(unstable_b4, 1);
    //
    // unstable_b4 (end)
    //

    //
    // unstable_b3 (start), shirink unstable_b3
    //
    unsetFlagsAll(unstable_b2, 1);
    n = countCubes(unstable_b3);
    char image_in_b2[n];
    counter = 0;
    if (getFirstCube(unstable_b3)) {
        CpxInterval X0, Y0, X1, Y1;
        do {
            // X
            Re = Interval(unstable_b3.center[0] - unstable_b3.radius[0], unstable_b3.center[0] + unstable_b3.radius[0]);
            Im = Interval(unstable_b3.center[1] - unstable_b3.radius[1], unstable_b3.center[1] + unstable_b3.radius[1]);
            X0 = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b3.center[2] - unstable_b3.radius[2], unstable_b3.center[2] + unstable_b3.radius[2]);
            Im = Interval(unstable_b3.center[3] - unstable_b3.radius[3], unstable_b3.center[3] + unstable_b3.radius[3]);
            Y0 = CpxInterval(Re, Im);
            X1 = square(X0) - a - b * Y0;
            Y1 = X0;
            A[0] = X1.getRe().lower();
            A[1] = X1.getIm().lower();
            A[2] = mid(Y1.getRe());
            A[3] = mid(Y1.getIm());
            B[0] = X1.getRe().upper();
            B[1] = X1.getIm().upper();
            B[2] = mid(Y1.getRe());
            B[3] = mid(Y1.getIm());
            //reset(unstable_b2);
            //setFlagRec(T, A, B, 1);
            image_in_b2[counter] = 0;
            setFlagRec(unstable_b2, A, B, 1, image_in_b2 + counter);
            counter++;
        } while (getNextCube(unstable_b3));
    }
    remove(unstable_b2, 1);
    setFlagsVect(unstable_b3, image_in_b2, 1);
    remove(unstable_b3, 1);
    //
    // unstable_b3 (end)
    //

    //
    // unstable_b2 (start), shirink unstable_b2
    //
    unsetFlagsAll(unstable_b1, 1);
    n = countCubes(unstable_b2);
    char image_in_b1[n];
    counter = 0;
    if (getFirstCube(unstable_b2)) {
        CpxInterval X0, Y0, X1, Y1;
        do {
            // X
            Re = Interval(unstable_b2.center[0] - unstable_b2.radius[0], unstable_b2.center[0] + unstable_b2.radius[0]);
            Im = Interval(unstable_b2.center[1] - unstable_b2.radius[1], unstable_b2.center[1] + unstable_b2.radius[1]);
            X0 = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b2.center[2] - unstable_b2.radius[2], unstable_b2.center[2] + unstable_b2.radius[2]);
            Im = Interval(unstable_b2.center[3] - unstable_b2.radius[3], unstable_b2.center[3] + unstable_b2.radius[3]);
            Y0 = CpxInterval(Re, Im);
            X1 = square(X0) - a - b * Y0;
            Y1 = X0;
            A[0] = X1.getRe().lower();
            A[1] = X1.getIm().lower();
            A[2] = mid(Y1.getRe());
            A[3] = mid(Y1.getIm());
            B[0] = X1.getRe().upper();
            B[1] = X1.getIm().upper();
            B[2] = mid(Y1.getRe());
            B[3] = mid(Y1.getIm());
            //setFlagRec(T, A, B, 1);
            image_in_b1[counter] = 0;
            setFlagRec(unstable_b1, A, B, 1, image_in_b1 + counter);
            counter++;
        } while (getNextCube(unstable_b2));
    }
    remove(unstable_b1, 1);
    setFlagsVect(unstable_b2, image_in_b1, 1);
    remove(unstable_b2, 1);
    //
    // unstable_b2 (end)
    //

    //
    // unstable_b1 (start), shirink unstable_b1
    //
    unsetFlagsAll(T, 1);
    n = countCubes(unstable_b1);
    char image_in_T[n];
    counter = 0;
    if (getFirstCube(unstable_b1)) {
        CpxInterval X0, Y0, X1, Y1;
        do {
            // X
            Re = Interval(unstable_b1.center[0] - unstable_b1.radius[0], unstable_b1.center[0] + unstable_b1.radius[0]);
            Im = Interval(unstable_b1.center[1] - unstable_b1.radius[1], unstable_b1.center[1] + unstable_b1.radius[1]);
            X0 = CpxInterval(Re, Im);
            // Y
            Re = Interval(unstable_b1.center[2] - unstable_b1.radius[2], unstable_b1.center[2] + unstable_b1.radius[2]);
            Im = Interval(unstable_b1.center[3] - unstable_b1.radius[3], unstable_b1.center[3] + unstable_b1.radius[3]);
            Y0 = CpxInterval(Re, Im);
            X1 = square(X0) - a - b * Y0;
            Y1 = X0;
            A[0] = X1.getRe().lower();
            A[1] = X1.getIm().lower();
            A[2] = mid(Y1.getRe());
            A[3] = mid(Y1.getIm());
            B[0] = X1.getRe().upper();
            B[1] = X1.getIm().upper();
            B[2] = mid(Y1.getRe());
            B[3] = mid(Y1.getIm());
            //setFlagRec(T, A, B, 1);
            image_in_T[counter] = 0;
            setFlagRec(T, A, B, 1, image_in_T + counter);
            counter++;
        } while (getNextCube(unstable_b1));
    }
    remove(T, 1);
    setFlagsVect(unstable_b1, image_in_T, 1);
    remove(unstable_b1, 1);
    //
    // unstable_b1 (end)
    //
}

void computeStable(Tree &T, Tree &T_local, Tree &T_f1, const CpxInterval a, const CpxInterval b, 
                   const double fx[nData][nBoxes], const double fy[nData][nBoxes], 
                   const double gx[nData][nBoxes], const double gy[nData][nBoxes],                         
                   const double ax[nData][nBoxes], const double ay[nData][nBoxes], 
                   const double bx[nData][nBoxes], const double by[nData][nBoxes], 
                   const double px[nData][nBoxes], const double py[nData][nBoxes],
                   const double qx[nData][nBoxes], const double qy[nData][nBoxes],
                   const double Px[nData][nBoxes], const double Py[nData][nBoxes], 
                   const double Qx[nData][nBoxes], const double Qy[nData][nBoxes])
{
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], 
        ibx[nBoxes], iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    
    //
    // Compute Local Stable in B_0
    //
    // Prepare vector X and Y
    int n = countCubes(T_local);
    vector<CpxInterval> X (n); // Euclidian
    vector<CpxInterval> Y (n); // Euclidian
    Interval Re, Im;
    int cube_iter = 0;
    if (getFirstCube(T_local)) {
        do {
            // X
            Re = Interval(T_local.center[0] - T_local.radius[0], T_local.center[0] + T_local.radius[0]);
            Im = Interval(T_local.center[1] - T_local.radius[1], T_local.center[1] + T_local.radius[1]);
            X[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(T_local.center[2] - T_local.radius[2], T_local.center[2] + T_local.radius[2]);
            Im = Interval(T_local.center[3] - T_local.radius[3], T_local.center[3] + T_local.radius[3]);
            Y[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(T_local));
    }

    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
    }

    CpxInterval X_f1, Y_f1, X_f2, Y_f2, X_f3, Y_f3, X_f4, Y_f4; // Forward Images
    CpxInterval X_b1, Y_b1; // Backward Images

    const Interval CX = (ipx[0] + iqx[3]) / 2.0;
    const Interval RX = (ipx[0] - iqx[3]) / 2.0;
    const Interval CY = (ipy[3] + iqy[3]) / 2.0;
    const Interval RY = (ipy[3] - iqy[3]) / 2.0;

    char flag[n];
    double A[4], B[4];
    for (int i = 0; i < n; i++) {
        flag[i] = 0;
        if (intersect_with(0, X[i], Y[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(X[i]) - a - b * Y[i];
            Y_f1 = X[i];
            A[0] = X_f1.getRe().lower();
            A[1] = X_f1.getIm().lower();
            // We can safely replace the interval Y_f1 with its mid point
            A[2] = mid(Y_f1.getRe());
            A[3] = mid(Y_f1.getIm());
            B[0] = X_f1.getRe().upper();
            B[1] = X_f1.getIm().upper();
            B[2] = mid(Y_f1.getRe());
            B[3] = mid(Y_f1.getIm());
            if (intersectCubeRec(T_local, A, B)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                A[0] = X_f2.getRe().lower();
                A[1] = X_f2.getIm().lower();
                A[2] = Y_f2.getRe().lower();
                A[3] = Y_f2.getIm().lower();
                B[0] = X_f2.getRe().upper();
                B[1] = X_f2.getIm().upper();
                B[2] = Y_f2.getRe().upper();
                B[3] = Y_f2.getIm().upper();
                if (intersectCubeRec(T_local, A, B)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    A[0] = X_f3.getRe().lower();
                    A[1] = X_f3.getIm().lower();
                    A[2] = Y_f3.getRe().lower();
                    A[3] = Y_f3.getIm().lower();
                    B[0] = X_f3.getRe().upper();
                    B[1] = X_f3.getIm().upper();
                    B[2] = Y_f3.getRe().upper();
                    B[3] = Y_f3.getIm().upper();
                    if (intersectCubeRec(T_local, A, B)) {
                        X_f4 = square(X_f3) - a - b * Y_f3;
                        Y_f4 = X_f3;
                        A[0] = X_f4.getRe().lower();
                        A[1] = X_f4.getIm().lower();
                        A[2] = Y_f4.getRe().lower();
                        A[3] = Y_f4.getIm().lower();
                        B[0] = X_f4.getRe().upper();
                        B[1] = X_f4.getIm().upper();
                        B[2] = Y_f4.getRe().upper();
                        B[3] = Y_f4.getIm().upper();
                        if (intersectCubeRec(T_local, A, B)) {
                            flag[i] = 1;
                        }
                    }
                }
            }
        }
    }
    setFlagsVect(T_local, flag, 1);
    remove(T_local, 1);
    //
    // Compute Local Stable (end)
    //

    //
    // Compute 100000...
    //
    n = countCubes(T_f1);
    X.resize(n);
    Y.resize(n);
    cube_iter = 0;
    if (getFirstCube(T_f1)) {
        do {
            // X
            Re = Interval(T_f1.center[0] - T_f1.radius[0], T_f1.center[0] + T_f1.radius[0]);
            Im = Interval(T_f1.center[1] - T_f1.radius[1], T_f1.center[1] + T_f1.radius[1]);
            X[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(T_f1.center[2] - T_f1.radius[2], T_f1.center[2] + T_f1.radius[2]);
            Im = Interval(T_f1.center[3] - T_f1.radius[3], T_f1.center[3] + T_f1.radius[3]);
            Y[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(T_f1));
    }

    char flag_f1[n];
    for (int i = 0; i < n; i++) {
        flag_f1[i] = 0;
        if (intersect_with(1, X[i], Y[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_f1 = square(X[i]) - a - b * Y[i];
            Y_f1 = X[i];
            A[0] = X_f1.getRe().lower();
            A[1] = X_f1.getIm().lower();
            A[2] = mid(Y_f1.getRe());
            A[3] = mid(Y_f1.getIm());;
            B[0] = X_f1.getRe().upper();
            B[1] = X_f1.getIm().upper();
            B[2] = mid(Y_f1.getRe());
            B[3] = mid(Y_f1.getIm());
            if (intersectCubeRec(T_local, A, B)) {
                X_f2 = square(X_f1) - a - b * Y_f1;
                Y_f2 = X_f1;
                A[0] = X_f2.getRe().lower();
                A[1] = X_f2.getIm().lower();
                A[2] = Y_f2.getRe().lower();
                A[3] = Y_f2.getIm().lower();
                B[0] = X_f2.getRe().upper();
                B[1] = X_f2.getIm().upper();
                B[2] = Y_f2.getRe().upper();
                B[3] = Y_f2.getIm().upper();
                if (intersectCubeRec(T_local, A, B)) {
                    X_f3 = square(X_f2) - a - b * Y_f2;
                    Y_f3 = X_f2;
                    A[0] = X_f3.getRe().lower();
                    A[1] = X_f3.getIm().lower();
                    A[2] = Y_f3.getRe().lower();
                    A[3] = Y_f3.getIm().lower();
                    B[0] = X_f3.getRe().upper();
                    B[1] = X_f3.getIm().upper();
                    B[2] = Y_f3.getRe().upper();
                    B[3] = Y_f3.getIm().upper();
                    if (intersectCubeRec(T_local, A, B)) {
                        flag_f1[i] = 1;
                    }
                }
            }
        }
    }
    unsetFlagsAll(T_f1, 1);
    setFlagsVect(T_f1, flag_f1, 1);
    remove(T_f1, 1);


    // Prepare vector X and Y
    n = countCubes(T);
    X.resize(n);
    Y.resize(n);
    cube_iter = 0;
    if (getFirstCube(T)) {
        do {
            // X
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            X[cube_iter] = CpxInterval(Re, Im);
            // Y
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            Y[cube_iter] = CpxInterval(Re, Im);
            cube_iter++;
        } while (getNextCube(T));
    }

    // Evaluate the radius of the intersection of B_3 and f(B_2)
    double max_radius =  0;
    double max_PY3 = -1000;
    double min_QY3 = +1000;
    CpxInterval tmp_V;
    Interval tmp_s, tmp_S, tmp_t, tmp_T, tmp_R;
    for (int i = 0; i < n; i++) {
        if (intersect_with(3, X[i], Y[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            X_b1 = Y[i];
            if (!zero_in(b.getRe())) {
                Y_b1 = (square(Y[i]) - X[i] - a) / b;
            } else {
                Y_b1 = CpxInterval(Interval(-8, 8), Interval(-8, 8));
            }
            Interval Re_0 = Interval(Y_b1.getRe().lower(), mid(Y_b1.getRe()));
            Interval Re_1 = Interval(mid(Y_b1.getRe()), Y_b1.getRe().upper());
            Interval Im_0 = Interval(Y_b1.getIm().lower(), mid(Y_b1.getIm()));
            Interval Im_1 = Interval(mid(Y_b1.getIm()), Y_b1.getIm().upper());

            if (intersect_with(2, X_b1, CpxInterval(Re_0, Im_0), CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby,  maxPx, maxPy, minQx, minQy) ||
                intersect_with(2, X_b1, CpxInterval(Re_0, Im_1), CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby,  maxPx, maxPy, minQx, minQy) ||
                intersect_with(2, X_b1, CpxInterval(Re_1, Im_0), CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby,  maxPx, maxPy, minQx, minQy) ||
                intersect_with(2, X_b1, CpxInterval(Re_1, Im_1), CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby,  maxPx, maxPy, minQx, minQy)) { 
                if (zero_in(igx[3] - X[i])) {
                    max_radius = 10;
                    max_PY3 = +1000;
                    min_QY3 = -1000;
                } else {
                    tmp_V = Y[i] - X[i] * (igy[3] - Y[i]) / (igx[3] - X[i]);
                    tmp_s = tmp_V.getRe() - iay[3] * CY;
                    tmp_t = tmp_V.getIm();
                    tmp_S = iay[3] * RY;
                    tmp_T = iby[3] * RY;
                    tmp_R = (square(tmp_s) / square(tmp_S) + square(tmp_t) / square(tmp_T));
                    max_radius = max2(max_radius, tmp_R.upper());
                    max_PY3 = max2(max_PY3, tmp_V.getRe().upper());
                    min_QY3 = min2(min_QY3, tmp_V.getRe().lower());
                }
            }
        }
    }

    //
    // Compute 3100000...
    //
    char flag2[n];
    for (int i = 0; i < n; i++) {
        flag2[i] = 0;
        if (intersect_with(3, X[i], Y[i], CX, CY, RX, RY,
                           ifx, ify, igx, igy, iax, iay, ibx, iby,  
                           maxPx, maxPy, minQx, minQy)) {
            tmp_V = Y[i] - X[i] * (igy[3] - Y[i]) / (igx[3] - X[i]);
            tmp_s = tmp_V.getRe() - iay[3] * CY;
            tmp_t = tmp_V.getIm();
            tmp_S = iay[3] * RY;
            tmp_T = iby[3] * RY;
            tmp_R = square(tmp_s) / square(tmp_S) + square(tmp_t) / square(tmp_T);
            if ((zero_in(igx[3] - X[i])) || 
                ((tmp_R.lower() <= max_radius) && 
                 (tmp_V.getRe().lower() <= max_PY3) && 
                 (tmp_V.getRe().upper() >= min_QY3))) { 
                X_f1 = square(X[i]) - a - b * Y[i];
                Y_f1 = X[i];
                A[0] = X_f1.getRe().lower();
                A[1] = X_f1.getIm().lower();
                A[2] = mid(Y_f1.getRe());
                A[3] = mid(Y_f1.getIm());;
                B[0] = X_f1.getRe().upper();
                B[1] = X_f1.getIm().upper();
                B[2] = mid(Y_f1.getRe());
                B[3] = mid(Y_f1.getIm());
                if ((intersect_with(1, X_f1, Y_f1, CX, CY, RX, RY, 
                                   ifx, ify, igx, igy, iax, iay, ibx, iby,  
                                   maxPx, maxPy, minQx, minQy)) && 
                    (intersectCubeRec(T_f1, A, B))) {
                    X_f2 = square(X_f1) - a - b * Y_f1;
                    Y_f2 = X_f1;
                    A[0] = X_f2.getRe().lower();
                    A[1] = X_f2.getIm().lower();
                    A[2] = Y_f2.getRe().lower();
                    A[3] = Y_f2.getIm().lower();
                    B[0] = X_f2.getRe().upper();
                    B[1] = X_f2.getIm().upper();
                    B[2] = Y_f2.getRe().upper();
                    B[3] = Y_f2.getIm().upper();
                    if (intersectCubeRec(T_local, A, B)) {
                        X_f3 = square(X_f2) - a - b * Y_f2;
                        Y_f3 = X_f2;
                        A[0] = X_f3.getRe().lower();
                        A[1] = X_f3.getIm().lower();
                        A[2] = Y_f3.getRe().lower();
                        A[3] = Y_f3.getIm().lower();
                        B[0] = X_f3.getRe().upper();
                        B[1] = X_f3.getIm().upper();
                        B[2] = Y_f3.getRe().upper();
                        B[3] = Y_f3.getIm().upper();
                        if (intersectCubeRec(T_local, A, B)) {
                            flag2[i] = 1;
                        }
                    }
                }
            }
        }
    }
    unsetFlagsAll(T, 1);
    setFlagsVect(T, flag2, 1);
    remove(T, 1);
}

int checkTinCan(Tree &T, const CpxInterval Vs, const CpxInterval a, const CpxInterval b,
                const double fx[nData][nBoxes], const double fy[nData][nBoxes], 
                const double gx[nData][nBoxes], const double gy[nData][nBoxes],                         
                const double ax[nData][nBoxes], const double ay[nData][nBoxes], 
                const double bx[nData][nBoxes], const double by[nData][nBoxes], 
                const double px[nData][nBoxes], const double py[nData][nBoxes],
                const double qx[nData][nBoxes], const double qy[nData][nBoxes],
                const double Px[nData][nBoxes], const double Py[nData][nBoxes], 
                const double Qx[nData][nBoxes], const double Qy[nData][nBoxes], 
                const bool verbose)
{

    if (verbose) {
        cout << endl << "New checkTinCan check starts" << endl;
        cout << "a =" << a << endl;
        cout << "b =" << b << endl;
    }

    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    const CpxInterval fx0 (ifx[0]);
    const CpxInterval fy0 (ify[0]);
    const CpxInterval gx0 (igx[0]);
    const CpxInterval gy0 (igy[0]);
    const CpxInterval fx3 (ifx[3]);
    const CpxInterval fy3 (ify[3]);
    const CpxInterval gx3 (igx[3]);
    const CpxInterval gy3 (igy[3]);
    const Interval CX = (ipx[0] + iqx[3]) / 2.0;
    const Interval RX = (ipx[0] - iqx[3]) / 2.0;
    const Interval CY = (ipy[3] + iqy[3]) / 2.0;
    const Interval RY = (ipy[3] - iqy[3]) / 2.0;

    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
    }

    bool Numerical_Check_E = false;
    int maxDepth = getHeight(T) + 4;
    while (getHeight(T) < maxDepth) {
        const int to_be_kept = 1;
        CpxInterval x, y, tmp;
        CpxInterval u, v;
        Interval Re, Im;
        unsetFlagsAll(T, to_be_kept);
        getFirstCube(T);
        do {
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            x = CpxInterval(Re, Im);
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            y = CpxInterval(Re, Im);
            //euc2proj(fx0, fy0, gx0, gy0, x, y, u, v);
            if (zero_in(df2(a, b, fx0, fy0, gx0, gy0, fx3, fy3, x, y))) {
                if (intersect_with(0, x, y, CX, CY, RX, RY, 
                                   ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                   maxPx, maxPy, minQx, minQy)) {
                    tmp = x;
                    x = square(x) - a - b * y;
                    y = tmp;
                    if (intersect_with(2, x, y, CX, CY, RX, RY, 
                                       ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                       maxPx, maxPy, minQx, minQy)) {
                        tmp = x;
                        x = square(x) - a - b * y;
                        y = tmp;
                        euc2proj(fx3, fy3, gx3, gy3, x, y, u, v);
                        if (overlap(u, Vs)) {
                            setFlag(T.currentCube, to_be_kept);
                        }
                    }
                }
            }
        } while (getNextCube(T));
        //remove(T, to_be_kept);
        //if (getHeight(T) == 0) {
        if (countFlags(T, to_be_kept) == 0) {
            Numerical_Check_E = true;
            break;
        } else {
            if (verbose) {cout << "Depth " << getHeight(T) << ": " 
                               << countCubes(T) << " cubes remaining." << endl;}
        }
        subdivide(T);
    }
    if (Numerical_Check_E) {
        return 0;
    } else {
        return 1;
    }
}

void interpolation(const int source_0, const int source_1, const int target, const double t, 
                   const double re_a[nData], const double re_b[nData],
                   const double fx[nData][nBoxes], const double fy[nData][nBoxes], 
                   const double gx[nData][nBoxes], const double gy[nData][nBoxes],                         
                   const double ax[nData][nBoxes], const double ay[nData][nBoxes], 
                   const double bx[nData][nBoxes], const double by[nData][nBoxes], 
                   const double px[nData][nBoxes], const double py[nData][nBoxes],
                   const double qx[nData][nBoxes], const double qy[nData][nBoxes],
                   const double Px[nData][nBoxes], const double Py[nData][nBoxes], 
                   const double Qx[nData][nBoxes], const double Qy[nData][nBoxes], 
                   double t_re_a[nData], double t_re_b[nData],
                   double t_fx[nData][nBoxes], double t_fy[nData][nBoxes], 
                   double t_gx[nData][nBoxes], double t_gy[nData][nBoxes],                         
                   double t_ax[nData][nBoxes], double t_ay[nData][nBoxes], 
                   double t_bx[nData][nBoxes], double t_by[nData][nBoxes], 
                   double t_px[nData][nBoxes], double t_py[nData][nBoxes],
                   double t_qx[nData][nBoxes], double t_qy[nData][nBoxes],
                   double t_Px[nData][nBoxes], double t_Py[nData][nBoxes], 
                   double t_Qx[nData][nBoxes], double t_Qy[nData][nBoxes]) 
{
    t_re_a[target] = linear_interpolation(t, re_a[source_0], re_a[source_1]);
    t_re_b[target] = linear_interpolation(t, re_b[source_0], re_b[source_1]);

    for (int box = 0; box < nBoxes; box++) {
        t_fx[target][box] = linear_interpolation(t, fx[source_0][box], fx[source_1][box]);
        t_fy[target][box] = linear_interpolation(t, fy[source_0][box], fy[source_1][box]);
        t_gx[target][box] = linear_interpolation(t, gx[source_0][box], gx[source_1][box]);
        t_gy[target][box] = linear_interpolation(t, gy[source_0][box], gy[source_1][box]);
        t_ax[target][box] = linear_interpolation(t, ax[source_0][box], ax[source_1][box]);
        t_ay[target][box] = linear_interpolation(t, ay[source_0][box], ay[source_1][box]);
        t_bx[target][box] = linear_interpolation(t, bx[source_0][box], bx[source_1][box]);
        t_by[target][box] = linear_interpolation(t, by[source_0][box], by[source_1][box]);
        t_px[target][box] = linear_interpolation(t, px[source_0][box], px[source_1][box]);
        t_py[target][box] = linear_interpolation(t, py[source_0][box], py[source_1][box]);
        t_qx[target][box] = linear_interpolation(t, qx[source_0][box], qx[source_1][box]);
        t_qy[target][box] = linear_interpolation(t, qy[source_0][box], qy[source_1][box]);
        t_Px[target][box] = linear_interpolation(t, Px[source_0][box], Px[source_1][box]);
        t_Py[target][box] = linear_interpolation(t, Py[source_0][box], Py[source_1][box]);
        t_Qx[target][box] = linear_interpolation(t, Qx[source_0][box], Qx[source_1][box]);
        t_Qy[target][box] = linear_interpolation(t, Qy[source_0][box], Qy[source_1][box]);
    }
}

void compute_circle_coordinate(const int a_num, int& re_a_num, int& im_a_num, SDirection& subdiv_dir) {
    const int radius = 20;
    int a = 0;
    re_a_num = -radius;
    im_a_num = 0;

    for (int i = 0; i < 2 * radius; i++) {
        if (((re_a_num + 1) * (re_a_num + 1) + im_a_num * im_a_num) >= radius * radius) {
            subdiv_dir = Right;
            re_a_num++;
        } else {
            subdiv_dir = Up;
            im_a_num++;
        }
        if (a == a_num) {return;}
        a++;
    }

    for (int i = 2 * radius; i < 4 * radius; i++) {
        if ((re_a_num * re_a_num + (im_a_num - 1) * (im_a_num - 1)) >= radius * radius) {
            subdiv_dir = Down;
            im_a_num -= 1;
        } else {
            subdiv_dir = Right;
            re_a_num++;
        }
        if (a == a_num) {return;}
        a++;
    }
}

int main(int argc, char * argv [])
{
    const int dim = 4;       // The dimension of M

    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double re_a[nData], re_b[nData];
    double cut_Px2[nData];

    //char treeFileName[256];
    string inputFileName[nData];

    int b_num, a_num, maxDepth, re_a_subdiv, re_b_subdiv;
    //double re_V_size, im_V_size;


    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    if (argc < 6) {
        cout << "  usage: check_E b_num a_num maxDepth re_a_subdiv re_b_subdiv" << endl;
        cout << "     eg: ./check_E 0950 20 44" << endl;
        cout << "  b_num \\in [0, 1999]" << std::endl;
        cout << "  a_num \\in [1, 400] for the right boundary" << std::endl;
        return 1;
    } else {
        b_num = atoi(argv[optind + 0]);
        a_num = atoi(argv[optind + 1]);
        maxDepth = atoi(argv[optind + 2]);
        re_a_subdiv = atoi(argv[optind + 3]);
        re_b_subdiv = atoi(argv[optind + 4]);
        //re_V_size = atof(argv[optind + 5]);
        //im_V_size = atof(argv[optind + 6]);
    }

    SDirection subdiv_dir;
    int re_a_num;   // from -20 to 20
    int im_a_num;   // from 0 to 20
    const int im_a_num_max = 20;

    compute_circle_coordinate(a_num, re_a_num, im_a_num, subdiv_dir);
    ostringstream s;

    if (subdiv_dir == Right) {
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 0 << "-" << setw(2) << setfill('0') << re_a_num + 19 << ".dat";
        inputFileName[0] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 1 << "-" << setw(2) << setfill('0') << re_a_num + 19 << ".dat";
        inputFileName[1] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 0 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[2] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 1 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[3] = s.str(); s.str("");
    } else { // Up or Down
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 0 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[0] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 1 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[1] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 0 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[2] = s.str(); s.str("");
        s << "../data/positive/" <<  setw(4) << setfill('0') << b_num + 1 << "-" << setw(2) << setfill('0') << re_a_num + 20 << ".dat";
        inputFileName[3] = s.str(); s.str("");
    }

    if (verbose) {
        cout << inputFileName[0] << endl;
        cout << inputFileName[1] << endl;
        cout << inputFileName[2] << endl;
        cout << inputFileName[3] << endl;
    }

    // Read the data files
    for (int i = 0; i < nData; i++) {
        input_data_positive(inputFileName[i],
                            re_a[i], re_b[i],
                            tx[i], ty[i], ax[i], ay[i], bx[i], by[i], 
                            Px[i], Py[i], Qx[i], Qy[i], cut_Px2[i]);
    }

    // Parameter Setting
    Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    Interval Im_a;
    const int b_num_max = 1000;
    const double radius_initial = 0.1;
    const double radius_variation = 0;
    double radius_inf = radius_initial + radius_variation * double(b_num    ) / double(b_num_max);
    double radius_sup = radius_initial + radius_variation * double(b_num + 1) / double(b_num_max);
    if (verbose) {cout << "TinCan Radius = [" << radius_inf << ", " << radius_sup << "]" <<endl;}
    if (subdiv_dir == Right) {
        Im_a = Interval(radius_inf * double(im_a_num) / double(im_a_num_max), 
                        radius_sup * double(im_a_num) / double(im_a_num_max));
    } else if (subdiv_dir == Up) {
        Im_a = Interval(radius_inf * double(im_a_num - 1) / double(im_a_num_max), 
                        radius_sup * double(im_a_num    ) / double(im_a_num_max));
    } else { // Down
        Im_a = Interval(radius_inf * double(im_a_num    ) / double(im_a_num_max), 
                        radius_sup * double(im_a_num + 1) / double(im_a_num_max));
    }
    Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    Interval Im_b (0, 0);

    CpxInterval a (Re_a, Im_a);
    CpxInterval b (Re_b, Im_b);

    if (verbose) {cout << "a = " << a << ", b = " << b << endl;}

    for (int i = 0; i < nData; i++) {
        // compute the focuses in R^2 and the intervals in C
        compute_focuses(tx[i], ty[i], fx[i], fy[i], gx[i], gy[i], px[i], py[i], qx[i], qy[i]);

        // Adjust Px Py Qx Qy
        adjust_pq(px[i], py[i], qx[i], qy[i], Px[i], Py[i], Qx[i], Qy[i]);
    }

    double center[dim];
    double radius[dim];
    center[0] = 0;
    center[1] = 0;
    center[2] = 0;
    center[3] = 0;
    radius[0] = 8;
    radius[1] = 8;
    radius[2] = 8;
    radius[3] = 8;

    Tree unstable       = Tree(center, radius, dim);
    Tree unstable_b1    = Tree(center, radius, dim);
    Tree unstable_b2    = Tree(center, radius, dim);
    Tree unstable_b3    = Tree(center, radius, dim);
    Tree unstable_b4    = Tree(center, radius, dim);
    Tree stable         = Tree(center, radius, dim);
    Tree stable_local   = Tree(center, radius, dim);
    Tree stable_f1      = Tree(center, radius, dim);

    //
    // Main Part
    //

    // Set-oriented computation of the stable manifold
    while (getHeight(stable_local) < maxDepth) {
        subdivide(stable);
        subdivide(stable_local);
        subdivide(stable_f1);
        if (verbose) {cout << "W^s: detph " << getHeight(stable) << ": ";}
        
        // Compute the stable manifold
        computeStable(stable, stable_local, stable_f1, a, b, 
                      fx, fy, gx, gy, 
                      ax, ay, bx, by, 
                      px, py, qx, qy, 
                      Px, Py, Qx, Qy);
        if (getHeight(stable) == 0) {
            // The stable manifold 31000 is empty
            if (verbose) {cout << "W^s 31000.. is empty" << endl;}
            return 0;
        }
        if (verbose) {
            cout << "#cubes in stable_local = " << countCubes(stable_local)
                 << ", stable310 = " << countCubes(stable) 
                 << ", stable_f1 = " << countCubes(stable_f1) << endl;
        }
    }

    CpxInterval Vs;
    computeURegion(stable, fx, fy, Vs);
    if (verbose) {cout << "Stable U = " << Vs << endl;}

    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    const CpxInterval fx0 (ifx[0]);
    const CpxInterval fy0 (ify[0]);
    const CpxInterval gx0 (igx[0]);
    const CpxInterval gy0 (igy[0]);
    const CpxInterval fx3 (ifx[3]);
    const CpxInterval fy3 (ify[3]);
    const CpxInterval gx3 (igx[3]);
    const CpxInterval gy3 (igy[3]);
    const Interval CX = (ipx[0] + iqx[3]) / 2.0;
    const Interval RX = (ipx[0] - iqx[3]) / 2.0;
    const Interval CY = (ipy[3] + iqy[3]) / 2.0;
    const Interval RY = (ipy[3] - iqy[3]) / 2.0;

    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
    }

    // Set-oriented computation of the unstable manifold
    while (getHeight(unstable) < maxDepth + 16) {
        subdivide(unstable);
        subdivide(unstable_b1);
        subdivide(unstable_b2);
        subdivide(unstable_b3);
        subdivide(unstable_b4);
        if (verbose) {cout << "W^u: depth " << getHeight(unstable);}
        if (verbose) {cout << ", W^u_local: depth " << getHeight(unstable) << endl;}
        
        // Compute the unstable Manifold
        computeUnstable(unstable, unstable_b1, unstable_b2, unstable_b3, unstable_b4, a, b, 
                        fx, fy, gx, gy, 
                        ax, ay, bx, by, 
                        px, py, qx, qy, 
                        Px, Py, Qx, Qy);
        if (getHeight(unstable) == 0) {return 0;}
        if (verbose) {
            cout << "      unstable: depth = " << getHeight(unstable) << ", cubes = " << countCubes(unstable) << endl;
            cout << "   unstable_b1: depth = " << getHeight(unstable_b1) << ", cubes = " << countCubes(unstable_b1) << endl;
            cout << "   unstable_b2: depth = " << getHeight(unstable_b2) << ", cubes = " << countCubes(unstable_b2) << endl;
            cout << "   unstable_b3: depth = " << getHeight(unstable_b3) << ", cubes = " << countCubes(unstable_b3) << endl;
            cout << "   unstable_b4: depth = " << getHeight(unstable_b4) << ", cubes = " << countCubes(unstable_b4) << endl;
        }

        //
        //
        //
        const int to_be_kept = 1;
        CpxInterval x, y, tmp;
        CpxInterval u, v;
        Interval Re, Im;
        unsetFlagsAll(unstable, to_be_kept);
        getFirstCube(unstable);
        do {
            Re = Interval(unstable.center[0] - unstable.radius[0], unstable.center[0] + unstable.radius[0]);
            Im = Interval(unstable.center[1] - unstable.radius[1], unstable.center[1] + unstable.radius[1]);
            x = CpxInterval(Re, Im);
            Re = Interval(unstable.center[2] - unstable.radius[2], unstable.center[2] + unstable.radius[2]);
            Im = Interval(unstable.center[3] - unstable.radius[3], unstable.center[3] + unstable.radius[3]);
            y = CpxInterval(Re, Im);
            //euc2proj(fx0, fy0, gx0, gy0, x, y, u, v);
            if (zero_in(df2(a, b, fx0, fy0, gx0, gy0, fx3, fy3, x, y))) {
                if (intersect_with(0, x, y, CX, CY, RX, RY, 
                                   ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                   maxPx, maxPy, minQx, minQy)) {
                    tmp = x;
                    x = square(x) - a - b * y;
                    y = tmp;
                    if (intersect_with(2, x, y, CX, CY, RX, RY, 
                                       ifx, ify, igx, igy, iax, iay, ibx, iby, 
                                       maxPx, maxPy, minQx, minQy)) {
                        tmp = x;
                        x = square(x) - a - b * y;
                        y = tmp;
                        euc2proj(fx3, fy3, gx3, gy3, x, y, u, v);
                        if (overlap(u, Vs)) {
                            setFlag(unstable.currentCube, to_be_kept);
                        }
                    }
                }
            }
        } while (getNextCube(unstable));
        remove(unstable, to_be_kept);
        //
        //
        //
        if (getHeight(unstable) == 0) {
            if (verbose) {cout << "OK." << endl;}
            return 0;
        }
    }

    // Variables for subdivided small paramter boxes (with s_ and t_, t_ is for temporal ones)
    double t_re_a[nData], t_re_b[nData];
    double t_fx[nData][nBoxes], t_fy[nData][nBoxes];
    double t_gx[nData][nBoxes], t_gy[nData][nBoxes];
    double t_px[nData][nBoxes], t_qx[nData][nBoxes];
    double t_py[nData][nBoxes], t_qy[nData][nBoxes];
    double t_ax[nData][nBoxes], t_ay[nData][nBoxes];
    double t_bx[nData][nBoxes], t_by[nData][nBoxes];
    double t_Px[nData][nBoxes], t_Py[nData][nBoxes];
    double t_Qx[nData][nBoxes], t_Qy[nData][nBoxes];

    double s_re_a[nData], s_re_b[nData];
    double s_fx[nData][nBoxes], s_fy[nData][nBoxes];
    double s_gx[nData][nBoxes], s_gy[nData][nBoxes];
    double s_px[nData][nBoxes], s_qx[nData][nBoxes];
    double s_py[nData][nBoxes], s_qy[nData][nBoxes];
    double s_ax[nData][nBoxes], s_ay[nData][nBoxes];
    double s_bx[nData][nBoxes], s_by[nData][nBoxes];
    double s_Px[nData][nBoxes], s_Py[nData][nBoxes];
    double s_Qx[nData][nBoxes], s_Qy[nData][nBoxes];
    CpxInterval s_a, s_b;

    double t;
    int return_flag = 0;
    if (subdiv_dir == Right) {
        for (int iter_b = 0; iter_b < re_b_subdiv; iter_b++) {
            for (int iter_a = 0; iter_a < re_a_subdiv; iter_a++) {
                //if (verbose) {cout << endl << "iter_b = " << iter_b << ", iter_a = " << iter_a << endl << endl;}
                // Horizontal (a-axis) interpolation (bottom)
                t = double(iter_a) / double(re_a_subdiv);
                interpolation(0, 2, 0, t, 
                              re_a, re_b, 
                              fx, fy, gx, gy, px, py, qx, qy, 
                              ax, ay, bx, by, Px, Py, Qx, Qy,
                              t_re_a, t_re_b, 
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy, 
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy);
                t = double(iter_a + 1) / double(re_a_subdiv);
                interpolation(0, 2, 2, t, 
                              re_a, re_b, 
                              fx, fy, gx, gy, px, py, qx, qy,
                              ax, ay, bx, by, Px, Py, Qx, Qy,
                              t_re_a, t_re_b, 
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy, 
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy);
                
                // Horizontal (a-axis) interpolation (top)
                t = double(iter_a) / double(re_a_subdiv);
                interpolation(1, 3, 1, t, 
                              re_a, re_b, 
                              fx, fy, gx, gy, px, py, qx, qy,
                              ax, ay, bx, by, Px, Py, Qx, Qy,
                              t_re_a, t_re_b, 
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy, 
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy);
                t = double(iter_a + 1) / double(re_a_subdiv);
                interpolation(1, 3, 3, t, 
                              re_a, re_b, 
                              fx, fy, gx, gy, px, py, qx, qy,
                              ax, ay, bx, by, Px, Py, Qx, Qy,
                              t_re_a, t_re_b,
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy,
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy);
                
                // Vertical (b-axis) interpolation 
                t = double(iter_b) / double(re_b_subdiv);
                interpolation(0, 1, 0, t, 
                              t_re_a, t_re_b, 
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy, 
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy,
                              s_re_a, s_re_b,
                              s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                              s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
                interpolation(2, 3, 2, t, 
                              t_re_a, t_re_b,
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy,
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy,
                              s_re_a, s_re_b,
                              s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                              s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
                t = double(iter_b + 1) / double(re_b_subdiv);
                interpolation(0, 1, 1, t, 
                              t_re_a, t_re_b,
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy,
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy,
                              s_re_a, s_re_b,
                              s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                              s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
                interpolation(2, 3, 3, t, 
                              t_re_a, t_re_b,
                              t_fx, t_fy, t_gx, t_gy, t_px, t_py, t_qx, t_qy,
                              t_ax, t_ay, t_bx, t_by, t_Px, t_Py, t_Qx, t_Qy,
                              s_re_a, s_re_b,
                              s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                              s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);

                Re_a = hull4(s_re_a[0], s_re_a[1], s_re_a[2], s_re_a[3]);
                double a_im_0 = a.getIm().lower();
                double a_im_r = a.getIm().upper() - a.getIm().lower();
                Im_a = Interval(a_im_0 + a_im_r * double(iter_b + 0) / double(re_b_subdiv), 
                                a_im_0 + a_im_r * double(iter_b + 1) / double(re_b_subdiv));
                s_a = CpxInterval(Re_a, Im_a);
                Re_b = hull4(s_re_b[0], s_re_b[1], s_re_b[2], s_re_b[3]);
                Im_b = Interval(0, 0);
                s_b = CpxInterval(Re_b, Im_b);

                return_flag += checkTinCan(unstable, Vs, s_a, s_b, 
                                           s_fx, s_fy, s_gx, s_gy, s_ax, s_ay, s_bx, s_by, 
                                           s_px, s_py, s_qx, s_qy, s_Px, s_Py, s_Qx, s_Qy, verbose);
                if (!(verbose) && (return_flag != 0)) {
                    return 1;
                }
            }
        }
    } else {
        for (int iter_b = 0; iter_b < re_b_subdiv; iter_b++) {
            t = double(iter_b) / double(re_b_subdiv);
            interpolation(0, 1, 0, t, 
                          re_a, re_b, 
                          fx, fy, gx, gy, px, py, qx, qy, 
                          ax, ay, bx, by, Px, Py, Qx, Qy,
                          s_re_a, s_re_b,
                          s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                          s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
            interpolation(0, 1, 2, t, 
                          re_a, re_b, 
                          fx, fy, gx, gy, px, py, qx, qy, 
                          ax, ay, bx, by, Px, Py, Qx, Qy,
                          s_re_a, s_re_b,
                          s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                          s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
            t = double(iter_b + 1) / double(re_b_subdiv);
            interpolation(0, 1, 1, t, 
                          re_a, re_b,
                          fx, fy, gx, gy, px, py, qx, qy,
                          ax, ay, bx, by, Px, Py, Qx, Qy,
                          s_re_a, s_re_b,
                          s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                          s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
            interpolation(0, 1, 3, t, 
                          re_a, re_b,
                          fx, fy, gx, gy, px, py, qx, qy,
                          ax, ay, bx, by, Px, Py, Qx, Qy,
                          s_re_a, s_re_b,
                          s_fx, s_fy, s_gx, s_gy, s_px, s_py, s_qx, s_qy,
                          s_ax, s_ay, s_bx, s_by, s_Px, s_Py, s_Qx, s_Qy);
            
            Re_a = Interval(min2(s_re_a[0], s_re_a[1]), max2(s_re_a[0], s_re_a[1]));
            double a_im_0 = a.getIm().lower();
            double a_im_r = a.getIm().upper() - a.getIm().lower();
            Im_a = Interval(a_im_0 + a_im_r * double(iter_b + 0) / double(re_b_subdiv), 
                            a_im_0 + a_im_r * double(iter_b + 1) / double(re_b_subdiv));
            s_a = CpxInterval(Re_a, Im_a);
            Re_b = Interval(min2(s_re_b[0], s_re_b[1]), max2(s_re_b[0], s_re_b[1]));
            Im_b = Interval(0, 0);
            s_b = CpxInterval(Re_b, Im_b);

            return_flag += checkTinCan(unstable, Vs, s_a, s_b, 
                                       s_fx, s_fy, s_gx, s_gy, s_ax, s_ay, s_bx, s_by, 
                                       s_px, s_py, s_qx, s_qy, s_Px, s_Py, s_Qx, s_Qy, verbose);
            if (!(verbose) && (return_flag != 0)) {
                return 1;
            }
        }
    }

    if (return_flag != 0) {
        if (verbose) { 
            cout <<  setw(4) << setfill('0') << b_num << "-" << 
                setw(3) << setfill('0') << a_num << ": Fails!" << endl;
        }
        return return_flag;
    } else {
        if (verbose) {
            cout <<  setw(4) << setfill('0') << b_num << "-" <<  
                setw(3) << setfill('0') << a_num << ": OK." << endl;
        }
        return 0;
    }
}
