#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>

static const int nBoxes = 4; // The number of boxes
static const int nData  = 4; // The number of input data files

#include "locuslib.hpp"

int main(int argc, char * argv [])
{
    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double Px0[nData], Qx0[nData], Px2[nData], Qx2[nData];
    double PX[nData], PY[nData], QX[nData], QY[nData];
    double re_a[nData], re_b[nData];
    double im_a_inf, im_a_sup;
    double cut_Px2[nData];

    string inputFileName[nData];
    int n_points;

    bool CMC = true;
    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    inputFileName[0] = argv[optind + 0];
    inputFileName[1] = argv[optind + 1];
    inputFileName[2] = argv[optind + 2];
    inputFileName[3] = argv[optind + 3];
    im_a_inf = atof(argv[optind + 4]);
    im_a_sup = atof(argv[optind + 5]);
    n_points = atoi(argv[optind + 6]);

    // transitions to check CMC
    const int n_transition = 7;
    pair<int, int> transitions[n_transition];
    transitions[0] = make_pair(0, 0);
    transitions[1] = make_pair(0, 2);
    transitions[2] = make_pair(0, 3);
    transitions[3] = make_pair(1, 0);
    transitions[4] = make_pair(2, 2);
    transitions[5] = make_pair(2, 3);
    transitions[6] = make_pair(3, 1);
    
    // input the data
    for (int n = 0; n < nData; n++) {
        input_data_positive(inputFileName[n],
                            re_a[n], re_b[n],
                            tx[n], ty[n], ax[n], ay[n], bx[n], by[n], Px[n], Py[n], Qx[n], Qy[n], cut_Px2[n]);
    }

    // Parameter Setting
    Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    Interval Im_a (im_a_inf, im_a_sup);
    Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    Interval Im_b (0, 0);
    CpxInterval a (Re_a, Im_a);
    CpxInterval b (Re_b, Im_b);
    if (verbose) {cout << "a = " << a << ", b = " << b << endl;}

    for (int n = 0; n < nData; n++) {
        // compute the focuses in R^2 and the intervals in C
        compute_focuses(tx[n], ty[n], fx[n], fy[n], gx[n], gy[n], px[n], py[n], qx[n], qy[n]);

        // Adjust Px Py Qx Qy
        adjust_pq(px[n], py[n], qx[n], qy[n], Px[n], Py[n], Qx[n], Qy[n]);

        // Treatment for special transitions
        Px0[n] = Px[n][0];
        Qx0[n] = Qx[n][0];
        Px2[n] = Px[n][2];
        Qx2[n] = Qx[n][2];
    }

    vector< complex<double> > z[nData];
    vector< complex<double> > w[nData];
    vector< complex<double> > Z_point[nData];
    vector< complex<double> > W_point[nData];
    
    for (int n = 0; n < nData; n++) {
        z[n].resize(n_points, 0);
        w[n].resize(n_points, 0);
        Z_point[n].resize(n_points * n_points, 0);
        W_point[n].resize(n_points * n_points, 0);
    }
    
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }

    for (int trans = 0; trans < n_transition; trans++) {
        int error_count = 0;
        int domain = transitions[trans].first;
        int image = transitions[trans].second;
        if (verbose) {cout << "Transition from [" << domain << "] to [" << image << "] ... ";}

        for (int n = 0; n < nData; n++) {
            if (domain == 0 && image == 2) {Px[n][0] = - 0.1;} 
            if (domain == 0 && image == 0) {Qx[n][0] = - 0.1;}
            if (domain == 2 && image == 2) {Px[n][2] = cut_Px2[n];}

            // Define the base ellipse
            PX[n] = px[n][0] * ax[n][domain];
            QX[n] = qx[n][3] * ax[n][domain];
            PY[n] = py[n][3] * ay[n][domain];
            QY[n] = qy[n][3] * ay[n][domain];

            // Distribute points on the ellipse boundary
            define_ellipse_boundaries(ax[n][domain], bx[n][domain], Px[n][domain], PX[n], Qx[n][domain], QX[n], z[n]);
            define_ellipse_boundaries(ay[n][domain], by[n][domain], Py[n][domain], PY[n], Qy[n][domain], QY[n], w[n]);
            
            // define_domain_points();
            define_domain_points(domain, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
        }

        // Restore the original vaules of Px[0], Qx[0], Px[2], Qx[2]
        // which has benn modified for checking CMC wrt special transitions.
        for (int n = 0; n < nData; n++) {
            Px[n][0] = Px0[n];
            Qx[n][0] = Qx0[n];
            Px[n][2] = Px2[n];
            Qx[n][2] = Qx2[n];
        }
        
        Interval Re, Im;
        CpxInterval Z, W, ZZ, WW;
        int j, k, j_end, k_end;
        int dl, dr, ul, ur;
        Interval s, t, S, T;
        CpxInterval zz, ww;
        Interval rz, rw;

        for (j = 0; j < n_points; j++) {
            if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
            for (k = 0; k < n_points; k++) {
                if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }

                dl = j * n_points + k;
                dr = j_end * n_points + k;
                ul = j * n_points + k_end;
                ur = j_end * n_points + k_end;

                // Compute Z
                Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                   min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                   min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                   min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                              max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                   max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                   max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                   max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                   min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                   min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                   min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                              max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                   max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                   max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                   max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                Z = CpxInterval(Re, Im);

                // Compute W
                Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                   min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                   min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                   min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                              max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                   max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                   max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                   max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                   min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                   min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                   min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                              max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                   max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                   max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                   max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                W = CpxInterval(Re, Im);

                // apply Henon map
                ZZ = square(Z) - a - b * W;
                WW = Z;

                // Compute projective coordinates (zz)
                zz = ZZ - WW * (ifx[image] - ZZ) / (ify[image] - WW);

                // Compute r
                s = zz.getRe() - (iax[image] * (ipx[0] + iqx[3]) / Interval(2.0));
                t = zz.getIm();
                S = iax[image] * (ipx[0] - iqx[3]) / Interval(2.0);
                T = ibx[image] * (ipx[0] - iqx[3]) / Interval(2.0);
                rz = square(s) / square(S) + square(t) / square(T);

                if ((max4(Px[0][image], Px[1][image], Px[2][image], Px[3][image]) >= zz.getRe().lower()) &&
                    (min4(Qx[0][image], Qx[1][image], Qx[2][image], Qx[3][image]) <= zz.getRe().upper()) && 
                    (rz.lower() <= 1)) { 
                    error_count++;
                    //return 1;
                } 
            }
        }
        if (error_count) {
            CMC = false;
            if (verbose) {
                cout << error_count << " errors." << endl;
            } else {
                return 1;
            }
        } else {
            if (verbose) {cout << endl;}
        }
    }

    return 0;
}
