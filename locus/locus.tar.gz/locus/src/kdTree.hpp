static const int treeMaxDepth = 256;

class Cube {
public:
    Cube();
    byte flags;
    Cube* child_L;
    Cube* child_R;
};

inline Cube::Cube() : flags(0), child_L(NULL), child_R(NULL) {}

inline bool isLeaf(const Cube *cube) 
{
    if (cube != NULL) {
        if (cube->child_L || cube->child_R) return false;
    }
    return true;
}

inline void deleteCubeRec(Cube **p) 
{
    if (*p != NULL) {
        deleteCubeRec(&((*p)->child_L));
        deleteCubeRec(&((*p)->child_R));
        delete (*p);
        *p = 0;
    }
}

inline int subdivide(Cube *cube) 
{
    if (isLeaf(cube)) {
        cube->child_L = new Cube();
        cube->child_R = new Cube();
        return 1;
    }
    return 0;
}

inline void setFlag(Cube *cube, byte flag) 
{
	if (cube != NULL) cube->flags |= flag;
}

inline void unsetFlag(Cube *cube, byte flag) 
{
	if (cube != NULL) cube->flags &= ~flag;
}

class AmbientCube {
public:
    AmbientCube(double *c, double *r, byte d);
    int dimension;
    double *center;
    double *radius;
};

AmbientCube::AmbientCube(double *c, double *r, byte d)
{
    dimension = d;
    center = new double[d];
    radius = new double[d];
    for (int i = 0; i < d; i++) {
        center[i] = c[i];
        radius[i] = r[i];
    }
}

class Tree {
public:
    Tree(double *c, double *r, byte dim);
    AmbientCube bound;
    Cube *rootCube;
    Cube *currentCube;
    double *center, *radius;
    double *cStack, *rStack;
    Cube **cubeStack;
    unsigned int *branchStack;
    unsigned long depth;
    unsigned long height;
    byte *sd;
};

Tree::Tree(double *c, double *r, byte dim) : bound(c, r, dim)
{
    rootCube = new Cube();
    currentCube = rootCube;
    center = new double[dim];
    radius = new double[dim];
    for (int i = 0; i < dim; i++) {
        center[i] = bound.center[i];
        radius[i] = bound.radius[i];
    }
    cStack = new double[treeMaxDepth];
    rStack = new double[treeMaxDepth];
    cubeStack = new Cube*[treeMaxDepth];
    branchStack = new unsigned int[treeMaxDepth];
    sd = new byte[treeMaxDepth + 1];
    for (int i = 0; i < treeMaxDepth + 1; i++) {
        sd[i] = i % dim;
    }
    depth = 0;
    height = 0;
}

inline int getHeight(const Tree &T) 
{
    return T.height;
}

inline void reset(Tree &T) 
{
    T.currentCube = T.rootCube;
    for (int i = 0; i < T.bound.dimension; i++) {
        T.center[i] = T.bound.center[i];
        T.radius[i] = T.bound.radius[i];
    }
    T.depth = 0;
}

inline int up(Tree &T) 
{
    if (T.depth == 0) {
        return 0;
    } else {
        T.depth--;
        T.currentCube = T.cubeStack[T.depth];
        T.center[T.sd[T.depth]] = T.cStack[T.depth];
        T.radius[T.sd[T.depth]] = T.rStack[T.depth];
        return 1;
    }
}

inline int downLeft(Tree &T) 
{ 
    if (T.currentCube->child_L != NULL) {
        unsigned int sd = T.sd[T.depth];
        T.cStack[T.depth] = T.center[sd];
        T.rStack[T.depth] = T.radius[sd];
        T.cubeStack[T.depth] = T.currentCube;
        T.radius[sd] /= 2;
        T.center[sd] -= T.radius[sd];
        T.currentCube = T.currentCube->child_L;
        T.branchStack[T.depth] = 0;
        T.depth++;
        return 1;
    } else return 0;
}

inline int downRight(Tree &T) 
{
    if (T.currentCube->child_R != NULL) {
        unsigned int sd = T.sd[T.depth];
        T.cStack[T.depth] = T.center[sd];
        T.rStack[T.depth] = T.radius[sd];
        T.cubeStack[T.depth] = T.currentCube;
        T.radius[sd] /= 2;
        T.center[sd] += T.radius[sd];
        T.currentCube = T.currentCube->child_R;
        T.branchStack[T.depth] = 1;
        T.depth++;
        return 1;
    } else return 0;
}

inline int getNextBranch(Tree &T) 
{
    int down = 0;
    do {
        if (!up(T)) {
            return 0;
        }
        if (T.branchStack[T.depth] == 0) {
            down = downRight(T);
        }
    } while (!down);
    return 1;
}

inline int getFirstCube(Tree &T) 
{
    reset(T);
    while (T.depth != T.height)
        if (!(downLeft(T) || downRight(T)))
            if (!getNextBranch(T)) return 0;
    return T.depth == T.height;
}

inline int getNextCube(Tree &T) 
{
    if (!getNextBranch(T)) {
        return 0;
    }
    while (T.depth != T.height) {
        if (!(downLeft(T) || downRight(T))) {
            if (!getNextBranch(T)) {
                return 0;
            }
        }
    }
    return T.depth == T.height;
}

int countCubes(Tree &T) 
{
    int n = 0;
    if (getFirstCube(T)) 
        do {
            n++;
        } while (getNextCube(T));
    return n;
}

int getCubeDepth(const Cube *cube) 
{
    int depth_L, depth_R;
    if (cube != NULL) {
        depth_L = getCubeDepth(cube->child_L) + 1;
        depth_R = getCubeDepth(cube->child_R) + 1;
        return max2(depth_L, depth_R);
    }
    return -1;
}

int remove(Cube *cube, const byte flag) 
{
    if (cube->child_L) {
        if (remove(cube->child_L, flag)) {
            deleteCubeRec(&(cube->child_L));
        }
        if (isLeaf(cube)) {
            cube->flags &= ~flag;
        }
    }
    
    if (cube->child_R) {
        if (remove(cube->child_R, flag)) {
            deleteCubeRec(&(cube->child_R));
        }
        if (isLeaf(cube)) {
            cube->flags &= ~flag;
        }
    }
    
    return (isLeaf(cube) && !((cube->flags & flag) == flag));
}

void remove(Tree &T, const byte flag) 
{
    remove(T.rootCube, flag);
    T.height = getCubeDepth(T.rootCube);
}

void print(Tree &T, double *cubes) 
{
    int dim = T.bound.dimension;
    int j = 0;
    if (getFirstCube(T)) do {
            for (int i = 0; i < dim; i++) cubes[j*(2*dim+2) + i] = T.center[i];
            for (int i = 0; i < dim; i++) cubes[j*(2*dim+2) + dim + i] = T.radius[i];
            cubes[j * (2 * dim + 2) + 2 * dim] = T.currentCube->flags;
            j++;
        } while (getNextCube(T));
}

inline void setFlagRecIter(Tree &T, const double *a, const double *b, const byte flag, char *found)
{
    if (isLeaf(T.currentCube)) {
        setFlag(T.currentCube, flag);
        *found = 1;
        return;
    }

    const int dir = T.sd[T.depth];
    if (interval_intersect(T.center[dir] - T.radius[dir], T.center[dir], a[dir], b[dir])) {
        if (downLeft(T)) {
            setFlagRecIter(T, a, b, flag, found);
            up(T);
        }
    }
    if (interval_intersect(T.center[dir], T.center[dir] + T.radius[dir], a[dir], b[dir])) {
        if (downRight(T)) {
            setFlagRecIter(T, a, b, flag, found);
            up(T);
        }
    }
    return;
}

inline void setFlagRec(Tree &T, const double *a, const double *b, const byte flag, char *found)
{
    reset(T);
    setFlagRecIter(T, a, b, flag, found);
}

inline void setFlagRecIter(Tree &T, const double *a, const double *b, const byte flag)
{
    if (isLeaf(T.currentCube)) {
        setFlag(T.currentCube, flag);
        return;
    }

    const int dir = T.sd[T.depth];
    if (interval_intersect(T.center[dir] - T.radius[dir], T.center[dir], a[dir], b[dir])) {
        if (downLeft(T)) {
            setFlagRecIter(T, a, b, flag);
            up(T);
        }
    }
    if (interval_intersect(T.center[dir], T.center[dir] + T.radius[dir], a[dir], b[dir])) {
        if (downRight(T)) {
            setFlagRecIter(T, a, b, flag);
            up(T);
        }
    }
    return;
}

inline void setFlagRec(Tree &T, const double *a, const double *b, const byte flag)
{
    reset(T);
    setFlagRecIter(T, a, b, flag);
}

inline bool intersectCubeRecIter(Tree &T, const double *a, const double *b) 
{
    if (T.depth == T.height) {
        return true;
    }
    int i = T.sd[T.depth];
    if (interval_intersect(T.center[i] - T.radius[i], T.center[i], a[i], b[i])) {
        if (downLeft(T)) {
            if (intersectCubeRecIter(T, a, b) == true) {
                return true;
            } else {
                up(T);
            }
        }
    }
    if (interval_intersect(T.center[i], T.center[i] + T.radius[i], a[i], b[i])) {
        if (downRight(T)) {
            if (intersectCubeRecIter(T, a, b) == true) {
                return true;
            } else {
                up(T);
            }
        }
    }
    return false;
}

inline bool intersectCubeRec(Tree &T, const double *a, const double *b) 
{
    reset(T);
    return intersectCubeRecIter(T, a, b);
}

void subdivide(Tree &T) 
{
    if (getFirstCube(T)) {
        do {
            subdivide(T.currentCube);
        } while (getNextCube(T));
    }
    T.height++;
}

inline void unsetFlagsAll(Tree &T, const byte flag)
{
    if (getFirstCube(T)) {
        do {
            unsetFlag(T.currentCube, flag);
        } while (getNextCube(T));
    }
}

inline void setFlagsVect(Tree &T, const char *v, const byte flag)
{
    int i = 0;
    if (getFirstCube(T)) 
        do {
            if (v[i]) {
                setFlag(T.currentCube, flag);
            } else {
                unsetFlag(T.currentCube, flag);
            }
            i++;
        } while (getNextCube(T));
}

inline int countFlags(Tree &T, const byte flag)
{
    int ans = 0;
    if (getFirstCube(T)) 
        do {
            if (T.currentCube->flags & flag) {
                ans++;
            } 
        } while (getNextCube(T));
    return ans;
}
