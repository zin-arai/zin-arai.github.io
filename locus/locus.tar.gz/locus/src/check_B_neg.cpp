#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>

static const int nBoxes = 5; // The number of boxes
static const int nData  = 4; // The number of input data files

#include "locuslib.hpp"

void apply_henon_map_cubical(const vector<CpxInterval>& Z, const vector<CpxInterval>& W, 
                             vector<CpxInterval>& ZZ, vector<CpxInterval>& WW,
                             const CpxInterval a, const CpxInterval b) 
{
    for (vector<CpxInterval>::size_type i = 0; i != Z.size(); i++) {
        ZZ[i] = square(Z[i]) - a - b * W[i];
        WW[i] = CpxInterval(mid(Z[i].getRe()), mid(Z[i].getIm()));
    }
}

inline void map(int n, CpxInterval a, CpxInterval b, double *pR, double *infv, double *supv)
{
    vector<CpxInterval> Z (n);
    vector<CpxInterval> W (n);
    vector<CpxInterval> ZZ (n);
    vector<CpxInterval> WW (n);

    Interval Z_Re, Z_Im, W_Re, W_Im;

    for (int i = 0; i < n; i++) {
        Z_Re = Interval(*(pR + i*10 + 0) - *(pR + i*10 + 4), *(pR + i*10 + 0) + *(pR + i*10 + 4));
        Z_Im = Interval(*(pR + i*10 + 1) - *(pR + i*10 + 5), *(pR + i*10 + 1) + *(pR + i*10 + 5));
        W_Re = Interval(*(pR + i*10 + 2) - *(pR + i*10 + 6), *(pR + i*10 + 2) + *(pR + i*10 + 6));
        W_Im = Interval(*(pR + i*10 + 3) - *(pR + i*10 + 7), *(pR + i*10 + 3) + *(pR + i*10 + 7));
        Z[i] = CpxInterval(Z_Re, Z_Im);
        W[i] = CpxInterval(W_Re, W_Im);
    }

    apply_henon_map_cubical(Z, W, ZZ, WW, a, b);

    for (int i = 0; i < n; i++) {
        *(infv + i*4 + 0) = ZZ[i].getRe().lower();
        *(infv + i*4 + 1) = ZZ[i].getIm().lower(); 
        *(infv + i*4 + 2) = WW[i].getRe().lower(); 
        *(infv + i*4 + 3) = WW[i].getIm().lower();

        *(supv + i*4 + 0) = ZZ[i].getRe().upper();
        *(supv + i*4 + 1) = ZZ[i].getIm().upper();
        *(supv + i*4 + 2) = WW[i].getRe().upper();
        *(supv + i*4 + 3) = WW[i].getIm().upper();
    }
}

int computeInvSet(Tree &T, CpxInterval a, CpxInterval b, bool exhausted)
{
    int n, last_n, i, dim;
    double *infv, *supv, *pR;
    char *domain;

    dim = T.bound.dimension;
    n = countCubes(T);
    pR = (double *) malloc(sizeof(double) * (2 * dim + 2) * n);
    domain = (char *) malloc(sizeof(char) * n);
    infv = (double *) malloc(sizeof(double) * dim * n);
    supv = (double *) malloc(sizeof(double) * dim * n);

    do {
        last_n = n;
        for (i = 0; i < n; i++) {*(domain + i) = 0;}
        print(T, pR);
        map(n, a, b, pR, infv, supv);
        // Set the flag "1" to the i-th cube if this cube is in the image.
        // Set domain[i] = 1 if the image of the i-th cube intersects the tree.
        unsetFlagsAll(T, 3);
        for (i = 0; i < n; i++) {
            setFlagRec(T, infv+dim*i, supv+dim*i, 1, domain + i);
        }
        // remove non-invariant cubes
        setFlagsVect(T, domain ,2);
        remove(T, 3);
        n = countCubes(T);
    } while ((n != last_n) && (exhausted));

    free(domain);
    free(infv);
    free(supv);
    free(pR);
    return n;
}

void compute_transition(const double fx[nData][nBoxes], const double fy[nData][nBoxes], 
                        const double gx[nData][nBoxes], const double gy[nData][nBoxes],                         
                        const double ax[nData][nBoxes], const double ay[nData][nBoxes], 
                        const double bx[nData][nBoxes], const double by[nData][nBoxes], 
                        const double px[nData][nBoxes], const double py[nData][nBoxes],
                        const double qx[nData][nBoxes], const double qy[nData][nBoxes],
                        const double Px[nData][nBoxes], const double Py[nData][nBoxes], 
                        const double Qx[nData][nBoxes], const double Qy[nData][nBoxes], 
                        const CpxInterval a, const CpxInterval b,
                        const vector<CpxInterval> Z, const vector<CpxInterval> W,
                        vector< vector<bool> > & intersect,
                        vector< vector<bool> > & contained,
                        vector< vector<bool> > & image_intersect)
{
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes];
    Interval iax[nBoxes], ibx[nBoxes], iay[nBoxes], iby[nBoxes];
    Interval ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];

    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }

    Interval s, t, S, T;
    CpxInterval zz, ww, ZZ, WW;
    Interval rz, rw;

    double minPx[nBoxes], minPy[nBoxes], minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes], maxQx[nBoxes], maxQy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minPx[box] = min4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        minPy[box] = min4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
        maxQx[box] = max4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        maxQy[box] = max4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
    }

    for (vector<CpxInterval>::size_type i = 0; i != Z.size(); i++) {

        // Compute the image
        ZZ = square(Z[i]) - a - b * W[i];
        WW = Z[i];

        for (int box = 0; box < 5; box++) {
            // Compute zz
            zz = Z[i] - W[i] * (ifx[box] - Z[i]) / (ify[box] - W[i]);
            // Compute r
            s = zz.getRe() - (iax[box] * (ipx[0] + iqx[4]) / Interval(2.0));
            t = zz.getIm();
            S = iax[box] * (ipx[0] - iqx[4]) / Interval(2.0);
            T = ibx[box] * (ipx[0] - iqx[4]) / Interval(2.0);
            rz = square(s) / square(S) + square(t) / square(T);

            // Compute ww
            ww = W[i] - Z[i] * (igy[box] - W[i]) / (igx[box] - Z[i]);
            // Compute r
            s = ww.getRe() - (iay[box] * (ipy[4] + iqy[4]) / Interval(2.0));
            t = ww.getIm();
            S = iay[box] * (ipy[4] - iqy[4]) / Interval(2.0);
            T = iby[box] * (ipy[4] - iqy[4]) / Interval(2.0);
            rw = square(s) / square(S) + square(t) / square(T);

            //
            // Intersect with B[box]?
            //
            if (// Z direction
                (maxPx[box] >= zz.getRe().lower()) &&
                (minQx[box] <= zz.getRe().upper()) && 
                (rz.lower() <= 1) &&
                // W direction
                (maxPy[box] >= ww.getRe().lower()) &&
                (minQy[box] <= ww.getRe().upper()) && 
                (rw.lower() <= 1)) { 
                intersect[box][i] = 1;
                //
                // Contained in B[box]?
                //
                if (// Z direction
                    (minPx[box] >= zz.getRe().upper()) &&
                    (maxQx[box] <= zz.getRe().lower()) && 
                    (rz.upper() <= 1) &&
                    // W direction
                    (minPy[box] >= ww.getRe().upper()) &&
                    (maxQy[box] <= ww.getRe().lower()) && 
                    (rw.upper() <= 1)) { 
                    contained[box][i] = 1;
                }
            }

            // Compute zz
            zz = ZZ - WW * (ifx[box] - ZZ) / (ify[box] - WW);
            // Compute r
            s = zz.getRe() - (iax[box] * (ipx[0] + iqx[4]) / Interval(2.0));
            t = zz.getIm();
            S = iax[box] * (ipx[0] - iqx[4]) / Interval(2.0);
            T = ibx[box] * (ipx[0] - iqx[4]) / Interval(2.0);
            rz = square(s) / square(S) + square(t) / square(T);

            // Compute ww
            ww = WW - ZZ * (igy[box] - WW) / (igx[box] - ZZ);
            // Compute r
            s = ww.getRe() - (iay[box] * (ipy[4] + iqy[4]) / Interval(2.0));
            t = ww.getIm();
            S = iay[box] * (ipy[4] - iqy[4]) / Interval(2.0);
            T = iby[box] * (ipy[4] - iqy[4]) / Interval(2.0);
            rw = square(s) / square(S) + square(t) / square(T);

            // intersect with
            if (// Z direction
                (maxPx[box] >= zz.getRe().lower()) &&
                (minQx[box] <= zz.getRe().upper()) && 
                (rz.lower() <= 1) &&
                // W direction
                (maxPy[box] >= ww.getRe().lower()) &&
                (minQy[box] <= ww.getRe().upper()) && 
                (rw.lower() <= 1)) { 
                image_intersect[box][i] = 1;
            }
        }
    }

}

int main(int argc, char * argv [])
{
    const int dim = 4;       // The dimension of M

    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double re_a[nData], re_b[nData];
    double im_a_inf, im_a_sup;

    string inputFileName[nData];
    unsigned int maxDepth;

    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    inputFileName[0] = argv[optind + 0];
    inputFileName[1] = argv[optind + 1];
    inputFileName[2] = argv[optind + 2];
    inputFileName[3] = argv[optind + 3];
    im_a_inf = atof(argv[optind + 4]);
    im_a_sup = atof(argv[optind + 5]);
    maxDepth = atoi(argv[optind + 6]);
    
    // input the data
    for (int n = 0; n < nData; n++) {
        input_data_negative(inputFileName[n],
                            re_a[n], re_b[n],
                            tx[n], ty[n], ax[n], ay[n], bx[n], by[n], Px[n], Py[n], Qx[n], Qy[n]);
    }

    // Parameter Setting
    Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    Interval Im_a (im_a_inf, im_a_sup);
    Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    Interval Im_b (0, 0);
    CpxInterval a (Re_a, Im_a);
    CpxInterval b (Re_b, Im_b);
    if (verbose) {cout << "a = " << a << ", b = " << b << endl;}

    for (int i = 0; i < nData; i++) {
        // compute the focuses in R^2 and the intervals in C
        compute_focuses(tx[i], ty[i], fx[i], fy[i], gx[i], gy[i], px[i], py[i], qx[i], qy[i]);

        // Adjust Px Py Qx Qy
        adjust_pq(px[i], py[i], qx[i], qy[i], Px[i], Py[i], Qx[i], Qy[i]);
    }
    
    double center[2 * dim];
    double radius[2 * dim];
    center[0] = 0;
    center[1] = 0;
    center[2] = 0;
    center[3] = 0;
    radius[0] = 4;
    radius[1] = 4;
    radius[2] = 4;
    radius[3] = 4;

    Tree T = Tree(center, radius, dim);

    // mian routine
    bool exhausted = false;
    while (T.height < maxDepth)
    {
        subdivide(T);
        if (T.height == maxDepth) {
            exhausted = true;
        }
        computeInvSet(T, a, b, exhausted);
    }
    int n = countCubes(T);

    // Main Routine
    vector< vector<bool> > intersect(nBoxes, vector<bool>(n));
    vector< vector<bool> > contained(nBoxes, vector<bool>(n));
    vector< vector<bool> > image_intersect(nBoxes, vector<bool>(n));

    // Prepare vector Z and W
    vector<CpxInterval> Z (n);
    vector<CpxInterval> W (n);
    Interval Re, Im;
    int cube_counter = 0;
    if (getFirstCube(T)) {
        do {
            // Z
            Re = Interval(T.center[0] - T.radius[0], T.center[0] + T.radius[0]);
            Im = Interval(T.center[1] - T.radius[1], T.center[1] + T.radius[1]);
            Z[cube_counter] = CpxInterval(Re, Im);
            // W
            Re = Interval(T.center[2] - T.radius[2], T.center[2] + T.radius[2]);
            Im = Interval(T.center[3] - T.radius[3], T.center[3] + T.radius[3]);
            W[cube_counter] = CpxInterval(Re, Im);
            cube_counter++;
        } while (getNextCube(T));
    }

    compute_transition(fx, fy, gx, gy,
                       ax, ay, bx, by,
                       px, py, qx, qy,
                       Px, Py, Qx, Qy,
                       a, b, Z, W, intersect, contained, image_intersect);

    int failure_count = 0;

    getFirstCube(T);
    for (int cube = 0; cube < n; cube++) {
        //
        // B0
        //
        if (intersect[0][cube]) {
            // Numerical Check B' (i)
            if (intersect[1][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: (0,1)" << endl;
                } 
            }
            if (intersect[3][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: Transition (0,3)" << endl;
                } 
            }
            if (intersect[4][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: Transition (0,4)" << endl;
                } 
            }

            // Numerical Check B' (ii)
            if ((image_intersect[1][cube]) || (image_intersect[3][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (ii) Fails on B0." << endl;
                } 
            }

            // Numerical Check B' (v)
            if (!(contained[2][cube]) && (image_intersect[4][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (v) Fails." << endl;
                }
            }
        }

        //
        // B1
        //
        if (intersect[1][cube]) {
            // Numerical Check B' (i)
            if (intersect[2][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: (1,2)" << endl;
                } 
            }
            if (intersect[4][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: Transition (1,4)" << endl;
                } 
            }

            // Numerical Check B' (ii)
            if ((image_intersect[1][cube]) || (image_intersect[3][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (ii) Fails on B1." << endl;
                } 
            }

            // Numerical Check B' (vi)
            if (!(contained[3][cube]) && (image_intersect[4][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (vi) Fails." << endl;;
                }
            }
        }

        //
        // B2
        //
        if (intersect[2][cube]) {
            // Numerical Check B' (i)
            if (intersect[3][cube]) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (i) Fails: (2,3)" << endl;
                } 
            }

            // Numerical Check B' (iii)
            if ((image_intersect[0][cube]) || (image_intersect[1][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (iii) Fails on B2." << endl;
                } 
            }

            // Numerical Check B' (vii)
            if ((!contained[0][cube]) && (!contained[4][cube]) && (image_intersect[2][cube] || image_intersect[3][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (vii) Fails! " << endl;;
                } 
            }
        }

        //
        // B3
        //
        if (intersect[3][cube]) {
            // Numerical Check B' (iii)
            if ((image_intersect[0][cube]) || (image_intersect[1][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (iii) Fails on B3." << endl;
                } 
            }
            // Numerical Check B' (viii)
            if ((!contained[1][cube]) && (!contained[4][cube]) && (image_intersect[2][cube] || image_intersect[3][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (viii) Fails! " << endl;
                } 
            }
        }

        //
        // B4
        //
        if (intersect[4][cube]) {
            // Numerical Check B' (iv)
            if ((image_intersect[0][cube]) || (image_intersect[2][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (iv) Fails." << endl;
                } 
            }

            // Numerical Check B' (ix)
            if ((!contained[2][cube]) && (!contained[3][cube]) && (image_intersect[4][cube])) {
                failure_count++;
                if (verbose) {
                    cerr << "Numerical Check B' (ix) Fails! " << endl;;
                } 
            }
        }
        getNextCube(T);
    }

    if (verbose) {
        if (failure_count) {
            cout << "Fails on " << failure_count << " boxes!" << endl;
        } else {
            cout << "OK!" << endl;
        }
    }

    if (failure_count == 0) {
        return 0;
    } else {
        return 1;
    }
}
