function omega = solid_angle_triangle(a, b, c)

determ = sum([b(2)*c(3) - b(3)*c(2); 
              b(3)*c(1) - b(1)*c(3); 
              b(1)*c(2) - b(2)*c(1)] .* a);

al = norm(a);
bl = norm(b);
cl = norm(c);
 
div = al * bl * cl + a' * b * cl + c' * a * bl + b' * c *al;

omega = 2 * atan2(determ, div);
