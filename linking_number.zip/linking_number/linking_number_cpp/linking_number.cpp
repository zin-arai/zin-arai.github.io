#include <iostream>
#include <iomanip>
#include <random>
#include <vector>
#include <boost/numeric/interval.hpp>

using namespace std;
using namespace boost::numeric;
using namespace boost::numeric::interval_lib;

typedef interval<double> Interval;
const Interval interval_pi = Interval(3.1415926535896, 3.1415926535898);

// I/O Operator
std::ostream& operator << (std::ostream& out, const Interval& x)
{
    //cout.setf(std::ios_base::scientific, std::ios_base::floatfield);
    out << setprecision(20) << "[" << x.lower() << ", " << x.upper() << "]";
    return out;
}

class Vect3 {
public:
    // Constructors
    Vect3();
    Vect3(double x, double y, double z);
    Vect3(const Vect3& other);

    // Substitution Operartors
    Vect3& operator =  (const Vect3& rhs);
    Vect3& operator += (const Vect3& rhs);
    Vect3& operator -= (const Vect3& rhs);

    // Comparison Operators
    bool operator == (const Vect3& rhs);
    bool operator != (const Vect3& rhs);

    // Accessors
    double x() const;
    double y() const;
    double z() const;
    
private:
    double x_;
    double y_;
    double z_;
};

// Constructors
inline Vect3::Vect3() : x_(0.0), y_(0.0), z_(0.0) {}
inline Vect3::Vect3(double x, double y, double z) : x_(x), y_(y), z_(z) {}
inline Vect3::Vect3(const Vect3& other) : x_(other.x_), y_(other.y_), z_(other.z_) {}

// Substitution Operators
inline Vect3& Vect3::operator = (const Vect3& rhs)
{
    x_ = rhs.x_;
    y_ = rhs.y_;
    z_ = rhs.z_;
    return *this;
}

inline Vect3& Vect3::operator += (const Vect3& rhs)
{
    x_ += rhs.x_;
    y_ += rhs.y_;
    z_ += rhs.z_;
    return *this;
}

inline Vect3& Vect3::operator -= (const Vect3& rhs)
{
    x_ -= rhs.x_;
    y_ -= rhs.y_;
    z_ -= rhs.z_;
    return *this;
}

// Comparison Operators
inline bool Vect3::operator == (const Vect3& rhs)
{
    using namespace compare::set;
    return ((x_ == rhs.x_) && (y_ == rhs.y_) && (z_ == rhs.z_));
}

inline bool Vect3::operator != (const Vect3& rhs)
{
    using namespace compare::set;
    return ((x_ != rhs.x_) || (y_ != rhs.y_) || (z_ != rhs.z_));
}

// Arithmetic Operators
inline const Vect3 operator - (const Vect3& rhs)
{
    Vect3 ans;
    ans -= rhs;
    return ans;
}

inline const Vect3 operator + (const Vect3& lhs, const Vect3& rhs)
{
    Vect3 ans(lhs);
    ans += rhs;
    return ans;
}

inline const Vect3 operator - (const Vect3& lhs, const Vect3& rhs)
{
    Vect3 ans(lhs);
    ans -= rhs;
    return ans;
}

// Accessors
inline double Vect3::x() const {return x_;};
inline double Vect3::y() const {return y_;};
inline double Vect3::z() const {return z_;};

// I/O Operator
std::ostream& operator << (std::ostream& out, const Vect3& v)
{
    out << "(" << v.x() << ", " << v.y() << ", " << v.z() << ")";
    return out;
}

class IVect3 {
public:
    // Constructors
    IVect3();
    IVect3(double x, double y, double z);
    IVect3(Interval x, Interval y, Interval z);
    IVect3(const Vect3& v);
    IVect3(const IVect3& other);

    // Substitution Operartors
    IVect3& operator =  (const IVect3& rhs);
    IVect3& operator += (const IVect3& rhs);
    IVect3& operator -= (const IVect3& rhs);

    // Comparison Operators
    bool operator == (const IVect3& rhs);
    bool operator != (const IVect3& rhs);

    // Accessors
    Interval x() const;
    Interval y() const;
    Interval z() const;
    
private:
    Interval x_;
    Interval y_;
    Interval z_;
};

// Constructors
inline IVect3::IVect3() : x_(Interval(0.0)), y_(Interval(0.0)), z_(Interval(0.0)) {}
inline IVect3::IVect3(double x, double y, double z) : x_(Interval(x)), y_(Interval(y)), z_(Interval(z)) {}
inline IVect3::IVect3(Interval x, Interval y, Interval z) : x_(x), y_(y), z_(z) {}
inline IVect3::IVect3(const Vect3& v) : x_(Interval(v.x())), y_(Interval(v.y())), z_(Interval(v.z())) {}
inline IVect3::IVect3(const IVect3& other) : x_(other.x_), y_(other.y_), z_(other.z_) {}

// Substitution Operators
inline IVect3& IVect3::operator = (const IVect3& rhs)
{
    x_ = rhs.x_;
    y_ = rhs.y_;
    z_ = rhs.z_;
    return *this;
}

inline IVect3& IVect3::operator += (const IVect3& rhs)
{
    x_ += rhs.x_;
    y_ += rhs.y_;
    z_ += rhs.z_;
    return *this;
}

inline IVect3& IVect3::operator -= (const IVect3& rhs)
{
    x_ -= rhs.x_;
    y_ -= rhs.y_;
    z_ -= rhs.z_;
    return *this;
}

// Comparison Operators
inline bool IVect3::operator == (const IVect3& rhs)
{
    using namespace compare::set;
    return ((x_ == rhs.x_) && (y_ == rhs.y_) && (z_ == rhs.z_));
}

inline bool IVect3::operator != (const IVect3& rhs)
{
    using namespace compare::set;
    return ((x_ != rhs.x_) || (y_ != rhs.y_) || (z_ != rhs.z_));
}

// Arithmetic Operators
inline const IVect3 operator - (const IVect3& rhs)
{
    IVect3 ans;
    ans -= rhs;
    return ans;
}

inline const IVect3 operator + (const IVect3& lhs, const IVect3& rhs)
{
    IVect3 ans(lhs);
    ans += rhs;
    return ans;
}

inline const IVect3 operator - (const IVect3& lhs, const IVect3& rhs)
{
    IVect3 ans(lhs);
    ans -= rhs;
    return ans;
}

// Accessors
inline Interval IVect3::x() const {return x_;};
inline Interval IVect3::y() const {return y_;};
inline Interval IVect3::z() const {return z_;};

// I/O Operator
std::ostream& operator << (std::ostream& out, const IVect3& v)
{
    out << "(" << v.x() << ", " << v.y() << ", " << v.z() << ")";
    return out;
}

Interval atan_taylor(const Interval x)
{
    Interval ans(0);
    Interval tmp, x2;
    
    x2 = -x * x;
    tmp = x;
    for (int m = 0; m < 20; m++) {
        int n = 2 * m + 1;
        ans += tmp / double(n);
        tmp *= x2;
    }

    return ans;
}

Interval atan_taylor_slow(const Interval x)
{
    Interval ansinf(0), anssup(0);
    Interval x2, tmp;
    
    // Lower bound
    x2 = -x.lower() * x.lower();
    tmp = Interval(x.lower());
    for (int m = 0; m < 20; m++) {
        int n = 2 * m + 1;
        ansinf += tmp / double(n);
        tmp *= x2;
    }
    
    // Upper bound
    x2 = -x.upper() * x.upper();
    tmp = Interval(x.upper());
    for (int m = 0; m < 20; m++) {
        int n = 2 * m + 1;
        anssup += tmp / double(n);
        tmp *= x2;
    }

    return Interval(ansinf.lower(), anssup.upper());
}

Interval atan_double_rigorous(const double x)
{
    Interval X(x);
    if (x >= (sqrt(2.0) + 1)) {
        return  (interval_pi * 0.5) - atan_taylor(1.0/X);
    } else if (x >=  (sqrt(2.0) - 1)) {
        return  (interval_pi * 0.25) + atan_taylor((X - 1.0)/(X + 1.0));
    } else if (x >= (-sqrt(2.0) + 1)) {
        return atan_taylor(X);
    } else if (x >= (-sqrt(2.0) - 1)) {
        return -(interval_pi * 0.25) + atan_taylor((1.0 + X)/(1.0 - X));
    } else {
        return -(interval_pi * 0.5) - atan_taylor(1.0/X);
    }
}

Interval atan_rigorous(const Interval x)
{
    Interval ansinf, anssup;
    ansinf = atan_double_rigorous(x.lower());
    anssup = atan_double_rigorous(x.upper());
    return Interval(ansinf.lower(), anssup.upper());
}

Interval atan2_rigorous(const Interval y, const Interval x)
{
    Interval ans;
    if (zero_in(x) && zero_in(y)) {
        cerr << "Error0: atan2 can not computed." << endl;
        cerr << "x: " << x.lower() << ", " << x.upper() << endl;
        cerr << "y: " << y.lower() << ", " << y.upper() << endl;
    }

    if (!zero_in(x)) {
        if (x.lower() > 0) {
            ans = atan_rigorous(y / x);
        } else if (y.lower() > 0) {
            ans = atan_rigorous(y / x) + interval_pi;
        } else if (y.upper() < 0) {
            ans = atan_rigorous(y / x) - interval_pi;
        } else {
            cerr << "Error1: atan2 can not computed." << endl;
            cerr << "x: " << x.lower() << ", " << x.upper() << endl;
            cerr << "y: " << y.lower() << ", " << y.upper() << endl;
        }
    } else if (y.lower() > 0) {
        ans = - atan_rigorous(x / y) + (interval_pi * 0.5);
    } else {
        ans = - atan_rigorous(x / y) - (interval_pi * 0.5);
    }
    return ans;
}

Interval solid_angle_triangle(const IVect3 a, const IVect3 b, const IVect3 c)
{
    
    Interval determ =
        a.x() * (b.y() * c.z() - b.z() * c.y()) +
        a.y() * (b.z() * c.x() - b.x() * c.z()) +
        a.z() * (b.x() * c.y() - b.y() * c.x());

    Interval al = sqrt(a.x() * a.x() + a.y() * a.y() + a.z() * a.z());
    Interval bl = sqrt(b.x() * b.x() + b.y() * b.y() + b.z() * b.z());
    Interval cl = sqrt(c.x() * c.x() + c.y() * c.y() + c.z() * c.z());

    Interval div = al * bl * cl +
        (a.x() * b.x() + a.y() * b.y() + a.z() * b.z()) * cl +
        (c.x() * a.x() + c.y() * a.y() + c.z() * a.z()) * bl +
        (b.x() * c.x() + b.y() * c.y() + b.z() * c.z()) * al;

    return 2.0 * atan2_rigorous(determ, div);
}

Interval solid_angle_quadrilateral(const IVect3 a, const IVect3 b, const IVect3 c, const IVect3 d) {
    return solid_angle_triangle(a, b, c) + solid_angle_triangle(c, d, a);
}

Vect3 rand_Vect3() {
    random_device rnd;
    mt19937 mt(rnd());
    uniform_real_distribution<double> distribution(-1.0, 1.0);
    return Vect3(distribution(mt), distribution(mt), distribution(mt));
}

int main()
{
    vector<Vect3> t0, t1;

    // A random link
    int n0 = 1000;
    int n1 = 1000;
    for (size_t i = 0; i < n0; i++) {
        t0.push_back(rand_Vect3());
    }

    for (size_t i = 0; i < n1; i++) {
        t1.push_back(rand_Vect3());
    }

    // The Hopf lilnk
    /*
    t0.push_back(Vect3(1,0,0));
    t0.push_back(Vect3(1,1,0));
    t0.push_back(Vect3(0,1,0));
    t0.push_back(Vect3(-1,1,0));
    t0.push_back(Vect3(-1,0,0));
    t0.push_back(Vect3(-1,-1,0));
    t0.push_back(Vect3(0,-1,0));
    t0.push_back(Vect3(1,-1,0));

    t1.push_back(Vect3(0,0,0));
    t1.push_back(Vect3(0,0,1));
    t1.push_back(Vect3(1,0,1));
    t1.push_back(Vect3(2,0,1));
    t1.push_back(Vect3(2,0,0));
    t1.push_back(Vect3(2,0,-1));
    t1.push_back(Vect3(1,0,-1));
    t1.push_back(Vect3(0,0,-1));
    */
    
    // The initial point = the terminal point
    t0.push_back(t0[0]);
    t1.push_back(t1[0]);

    // The main routine
    Interval ans(0);
    IVect3 a, b, c, d;
    for (size_t i = 0; i < t0.size() - 1; i++) {
        for (size_t j = 0; j < t1.size() - 1; j++) {
            a = IVect3(t1[j]     - t0[i]);
            b = IVect3(t1[j]     - t0[i + 1]);
            c = IVect3(t1[j + 1] - t0[i + 1]);
            d = IVect3(t1[j + 1] - t0[i]);
            ans += solid_angle_quadrilateral(a, b, c, d);
        }
    }
    ans /= (4.0 * interval_pi);

    // Output the result
    cout << ans << endl;
    
    return 0;
}
