#include <iostream>
#include <iomanip>
#include <random>
#include <vector>

using namespace std;

class Vect3 {
public:
    // Constructors
    Vect3();
    Vect3(double x, double y, double z);
    Vect3(const Vect3& other);

    // Substitution Operartors
    Vect3& operator =  (const Vect3& rhs);
    Vect3& operator += (const Vect3& rhs);
    Vect3& operator -= (const Vect3& rhs);

    // Comparison Operators
    bool operator == (const Vect3& rhs);
    bool operator != (const Vect3& rhs);

    // Accessors
    double x() const;
    double y() const;
    double z() const;
    
private:
    double x_;
    double y_;
    double z_;
};

// Constructors
Vect3::Vect3() : x_(0.0), y_(0.0), z_(0.0) {}
Vect3::Vect3(double x, double y, double z) : x_(x), y_(y), z_(z) {}
Vect3::Vect3(const Vect3& other) : x_(other.x_), y_(other.y_), z_(other.z_) {}

// Substitution Operators
Vect3& Vect3::operator = (const Vect3& rhs)
{
    x_ = rhs.x_;
    y_ = rhs.y_;
    z_ = rhs.z_;
    return *this;
}

Vect3& Vect3::operator += (const Vect3& rhs)
{
    x_ += rhs.x_;
    y_ += rhs.y_;
    z_ += rhs.z_;
    return *this;
}

Vect3& Vect3::operator -= (const Vect3& rhs)
{
    x_ -= rhs.x_;
    y_ -= rhs.y_;
    z_ -= rhs.z_;
    return *this;
}

// Comparison Operators
bool Vect3::operator == (const Vect3& rhs)
{
    //using namespace compare::set;
    return ((x_ == rhs.x_) && (y_ == rhs.y_) && (z_ == rhs.z_));
}

bool Vect3::operator != (const Vect3& rhs)
{
    //using namespace compare::set;
    return ((x_ != rhs.x_) || (y_ != rhs.y_) || (z_ != rhs.z_));
}

// Arithmetic Operators
const Vect3 operator - (const Vect3& rhs)
{
    Vect3 ans;
    ans -= rhs;
    return ans;
}

const Vect3 operator + (const Vect3& lhs, const Vect3& rhs)
{
    Vect3 ans(lhs);
    ans += rhs;
    return ans;
}

const Vect3 operator - (const Vect3& lhs, const Vect3& rhs)
{
    Vect3 ans(lhs);
    ans -= rhs;
    return ans;
}

// Accessors
double Vect3::x() const {return x_;};
double Vect3::y() const {return y_;};
double Vect3::z() const {return z_;};

// I/O Operator
std::ostream& operator << (std::ostream& out, const Vect3& v)
{
    out << "(" << v.x() << ", " << v.y() << ", " << v.z() << ")";
    return out;
}

double solid_angle_triangle(const Vect3 a, const Vect3 b, const Vect3 c)
{
    
    double determ =
        a.x() * (b.y() * c.z() - b.z() * c.y()) +
        a.y() * (b.z() * c.x() - b.x() * c.z()) +
        a.z() * (b.x() * c.y() - b.y() * c.x());

    double al = sqrt(a.x() * a.x() + a.y() * a.y() + a.z() * a.z());
    double bl = sqrt(b.x() * b.x() + b.y() * b.y() + b.z() * b.z());
    double cl = sqrt(c.x() * c.x() + c.y() * c.y() + c.z() * c.z());

    double div = al * bl * cl +
        (a.x() * b.x() + a.y() * b.y() + a.z() * b.z()) * cl +
        (c.x() * a.x() + c.y() * a.y() + c.z() * a.z()) * bl +
        (b.x() * c.x() + b.y() * c.y() + b.z() * c.z()) * al;

    return 2.0 * atan2(determ, div);
}

double solid_angle_quadrilateral(const Vect3 a, const Vect3 b, const Vect3 c, const Vect3 d) {
    return solid_angle_triangle(a, b, c) + solid_angle_triangle(c, d, a);
}

Vect3 rand_Vect3() {
    random_device rnd;
    mt19937 mt(rnd());
    uniform_real_distribution<double> distribution(-1.0, 1.0);
    return Vect3(distribution(mt), distribution(mt), distribution(mt));
}

int main()
{
    vector<Vect3> t0, t1;
    
    // A random link
    int n0 = 10000;
    int n1 = 1000;

    for (size_t i = 0; i < n0; i++) {
        t0.push_back(rand_Vect3());
    }

    for (size_t i = 0; i < n1; i++) {
        t1.push_back(rand_Vect3());
    }

    // The Hopf lilnk
    /*
    t0.push_back(Vect3(1,0,0));
    t0.push_back(Vect3(1,1,0));
    t0.push_back(Vect3(0,1,0));
    t0.push_back(Vect3(-1,1,0));
    t0.push_back(Vect3(-1,0,0));
    t0.push_back(Vect3(-1,-1,0));
    t0.push_back(Vect3(0,-1,0));
    t0.push_back(Vect3(1,-1,0));

    t1.push_back(Vect3(0,0,0));
    t1.push_back(Vect3(0,0,1));
    t1.push_back(Vect3(1,0,1));
    t1.push_back(Vect3(2,0,1));
    t1.push_back(Vect3(2,0,0));
    t1.push_back(Vect3(2,0,-1));
    t1.push_back(Vect3(1,0,-1));
    t1.push_back(Vect3(0,0,-1));
    */
    
    // The initial point = the terminal point
    t0.push_back(t0[0]);
    t1.push_back(t1[0]);

    // The main routine
    double ans(0);
    Vect3 a, b, c, d;
    for (size_t i = 0; i < t0.size() - 1; i++) {
        for (size_t j = 0; j < t1.size() - 1; j++) {
            a = t1[j]     - t0[i];
            b = t1[j]     - t0[i + 1];
            c = t1[j + 1] - t0[i + 1];
            d = t1[j + 1] - t0[i];
            ans += solid_angle_quadrilateral(a, b, c, d);
        }
    }
    const double Pi = 3.14159265358;
    ans /= (4.0 * Pi);

    // Output the result
    cout << setprecision(20) << ans << endl;
    
    return 0;
}
