kv - C++ numerical verification libraries by kashi

http://verifiedby.me/kv/

Masahide Kashiwagi  kashi@waseda.jp

This software is released under the MIT License, see LICENSE.txt.
