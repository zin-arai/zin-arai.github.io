load curve1.mat;
gamma1 = coords;
load curve2.mat;
gamma2 = coords;
linking_number(gamma1, gamma2)

