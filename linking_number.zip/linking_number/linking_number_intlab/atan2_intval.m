function T = atan2_intval(Y, X)

if length(X) ~= length(Y)
    error('The length of vectors Y and X should be equal.')
end

L = length(X);
T = intval(zeros(length(X)));

for k = 1:L
    x = X(k);
    y = Y(k);
    if in(0, x) & in(0, y)
        error('arc-tangent can not computed.')
    end
    
    if ~in(0, x)
        if x > 0
            T(k) = atan(y / x);
        elseif y > 0
            T(k) = atan(y / x) + pi;
        elseif y < 0
            T(k) = atan(y / x) - pi; 
        else 
            error('arc-tangent can not computed.')
        end
    elseif Y > 0
        T(k) = - atan(x / y) + pi/2;
    else Y < 0
        T(k) = - atan(x / y) - pi/2; 
    end
end