function BEZ = bezier(TT, CPS)
BEZ = CPS*bernstein(length(CPS(1,:))-1, TT);
