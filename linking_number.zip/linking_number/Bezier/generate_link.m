% The number of knots and number of control points for knots;
n = 2;
np = [100; 150];
color_0 = [0, 0, 1]; % blue
color_1 = [1, 0, 0]; % red
colors = [color_0; color_1];
divn = 32; % the number of segments between two control points


set(0, 'defaultAxesFontSize', 10, 'defaultTextFontSize', 10);

%figure( 'InvertHardcopy', 'off', 'Color', [1 1 1], 'Position', [2 300 440 320]);
figure
xlabel({'x'}, 'FontName','Times New Roman');
ylabel({'y'}, 'FontName','Times New Roman');
zlabel({'z'}, 'FontName','Times New Roman');
view([-36 30]);
box('on');
hold('all');

for curve = 1:n
    pts = rand(3, np(curve));
    cps = find_c2_closed_bezier3(pts);
    nn = length(cps) + 1;
    tl = 0:1/divn:1;
    step = length(tl);
    tt = zeros(1, step * (nn - 1));
    coords = zeros(3, step * (nn - 1));
    thrpoint = pts;
    
    for m = 1:nn-1
        coords(:,step*(m-1)+1:step*m)=bezier(tl,cps{m});
    end;

    filename = sprintf('curve%d.mat', curve);
    save(filename, 'coords');
    % Plot the curve
    %gr1 = plot3(coords(1,:),coords(2,:),coords(3,:), 'LineWidth',1.3, 'DisplayName', 'Result Curve', 'Color', blue);
    plot3(coords(1,:), coords(2,:), coords(3,:), 'LineWidth', 0.5, 'Color', colors(curve, :));
    % Plot the control points
    %gr2 = plot3(pts(1,:), pts(2,:), pts(3,:),'DisplayName','Through Point', 'MarkerFaceColor',col2, 'MarkerEdgeColor',col2, 'Marker','o', 'LineStyle','none', 'Color', red);
end

axis equal;
set(gca, 'PlotBoxAspectRatioMode', 'manual', 'DataAspectRatio', [1 1 1]);
