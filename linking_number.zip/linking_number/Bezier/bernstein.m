function BE = bernstein(NN, TT)
onest = ones(1, length(TT));
II = [0:NN]' * onest;
BI = diag(rot90(pascal(NN + 1))) * onest;
TT = ones(NN + 1, 1)*TT;

BE = (1 - TT) .^ (NN - II) .* BI .* (TT .^ II);
