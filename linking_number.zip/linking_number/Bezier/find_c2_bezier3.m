function cps = find_c2_bezier3(pts)

sz = size(pts);

dim = sz(1);
cnum = sz(2) - 1;
unnum = 2*cnum*dim;

% Equation
eql = zeros(unnum);
eqr = zeros(unnum,1);

qq = reshape([1:unnum],dim,2*cnum);
qa = qq(:,1:2:end);
qb = qq(:,2:2:end);

% Initial Point
for dg=1:dim
    eql(dg, qa(dg,1)) = -2;
    eql(dg, qb(dg,1)) = 1;
end;
eqr(1:dim) = -pts(:,1);

% Intermediate Points
for ii=1:cnum-1
    jj = (2*ii-1)*dim;
    
    for dg=1:dim
        % C1 condition
        eql(jj+dg, qb(dg,ii)) = 1;
        eql(jj+dg, qa(dg,ii+1)) = 1;
        
        % C2 condition
        eql(jj+dg+dim, qa(dg,ii)) = 1;
        eql(jj+dg+dim, qb(dg,ii)) = -2;
        eql(jj+dg+dim, qa(dg,ii+1)) = 2;
        eql(jj+dg+dim, qb(dg,ii+1)) = -1;
    end;
    eqr(jj+[1:2*dim]) = [2*pts(:,ii+1);zeros(dim,1)];
end;

% Terminal Point
for dg=1:dim
    eql((2*cnum-1)*dim+dg, qa(dg,end)) = 1;
    eql((2*cnum-1)*dim+dg, qb(dg,end)) = -2;
end;
eqr(end-dim+1:end) = -pts(:,end);

% Solve the Equation
cps0 = eql\eqr;
cps0 = reshape(cps0,dim,numel(cps0)/dim);

% Convert to Control Points
cps = cell(1,cnum);
for ii=1:cnum
    cps{ii} = [pts(:,ii), cps0(:,2*(ii-1)+[1:2]), pts(:,ii+1)];
end;
