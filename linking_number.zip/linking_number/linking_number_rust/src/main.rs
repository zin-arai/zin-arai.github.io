use rand::Rng;
use std::ops::Sub;
const PI: f64 = 3.141592653589793;

#[derive(Debug, Copy, Clone)]
struct Vec3 {
    x: f64,
    y: f64,
    z: f64,
}

impl Vec3 {
    fn new(x: f64, y: f64, z: f64) -> Vec3 {
        Vec3 { x: x, y: y, z: z }
    }
}

impl Sub for Vec3 {
    type Output = Vec3;
    fn sub(self, other: Vec3) -> Vec3 {
        Vec3 {
            x: self.x - other.x,
            y: self.y - other.y,
            z: self.z - other.z,
        }
    }
}

fn solid_angle_triangle(a: &Vec3, b: &Vec3, c: &Vec3) -> f64 {
    let determ: f64 = a.x * (b.y * c.z - b.z * c.y)
        + a.y * (b.z * c.x - b.x * c.z)
        + a.z * (b.x * c.y - b.y * c.x);

    let al: f64 = num::Float::sqrt(a.x * a.x + a.y * a.y + a.z * a.z);
    let bl: f64 = num::Float::sqrt(b.x * b.x + b.y * b.y + b.z * b.z);
    let cl: f64 = num::Float::sqrt(c.x * c.x + c.y * c.y + c.z * c.z);

    let div: f64 = al * bl * cl
        + (a.x * b.x + a.y * b.y + a.z * b.z) * cl
        + (c.x * a.x + c.y * a.y + c.z * a.z) * bl
        + (b.x * c.x + b.y * c.y + b.z * c.z) * al;

    2.0 * num::Float::atan2(determ, div)
}

fn rand_vec3() -> Vec3 {
    let mut rng = rand::thread_rng();
    Vec3::new(
        rng.gen_range(-1.0, 1.0),
        rng.gen_range(-1.0, 1.0),
        rng.gen_range(-1.0, 1.0),
    )
}

fn main() {
    const N0: usize = 10000;
    const N1: usize = 1000;

    let mut t0: [Vec3; N0 + 1] = [Vec3::new(0.0, 0.0, 0.0); N0 + 1];
    let mut t1: [Vec3; N1 + 1] = [Vec3::new(0.0, 0.0, 0.0); N1 + 1];

    for i in 0..N0 {
        t0[i] = rand_vec3();
    }
    for i in 0..N1 {
        t1[i] = rand_vec3();
    }
    t0[N0] = t0[0];
    t1[N1] = t1[0];

    let mut n: f64 = 0.0;
    for i in 0..N0 {
        for j in 0..N1 {
            let a = t1[j] - t0[i];
            let b = t1[j] - t0[i + 1];
            let c = t1[j + 1] - t0[i + 1];
            let d = t1[j + 1] - t0[i];
            n += solid_angle_triangle(&a, &b, &c);
            n += solid_angle_triangle(&c, &d, &a);
        }
    }

    println!("{}\n", n / (4.0 * PI));
}
