function omega = solid_angle_triangle(a, b, c)

determ = det([a, b, c]);

al = norm(a);
bl = norm(b);
cl = norm(c);
 
div = al*bl*cl + dot(a,b)*cl + dot(a,c)*bl + dot(b,c)*al;
at = atan2(determ, div);

% If det > 0 and div < 0 arctan2 returns < 0, so add pi.
%if at < 0
%    at = at + pi
%end

omega = 2 * at;
