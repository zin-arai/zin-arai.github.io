function theta = intv_atan2(y, x)

if ~in(0, x) 
    if x > 0
        theta = atan(y/x);
    elseif y >= 0
        theta = atan(-y/-x) + pi;
    else 
        theta = atan(-y/-x) - pi; 
    end
elseif ~in(0, y)



else
    error('Either x or y should be nonzero!')
end