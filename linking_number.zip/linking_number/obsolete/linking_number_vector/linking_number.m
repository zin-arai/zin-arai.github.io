function n = linking_number(gamma0, gamma1);

n = intval(0);

length_0 = size(gamma0, 2);
length_1 = size(gamma1, 2);

m = (length_0 - 1) * (length_1 - 1);

a = zeros(3, m);
b = zeros(3, m);
c = zeros(3, m);
d = zeros(3, m);

ind = 1;
for i = 1:length_0 - 1
    for j = 1:length_1 - 1
        a(:, ind) = gamma1(:, j) - gamma0(:, i);
        b(:, ind) = gamma1(:, j) - gamma0(:, i + 1);
        c(:, ind) = gamma1(:, j + 1) - gamma0(:, i + 1);
        d(:, ind) = gamma1(:, j + 1) - gamma0(:, i);
        ind = ind + 1;
    end
    j = length_1;
    a(:, ind) = gamma1(:, j) - gamma0(:, i);
    b(:, ind) = gamma1(:, j) - gamma0(:, i + 1);
    c(:, ind) = gamma1(:, 1) - gamma0(:, i + 1);
    d(:, ind) = gamma1(:, 1) - gamma0(:, i);
    ind = ind + 1;
end
i = length_0;
for j = 1:length_1 - 1
    a(:, ind) = gamma1(:, j) - gamma0(:, i);
    b(:, ind) = gamma1(:, j) - gamma0(:, 1);
    c(:, ind) = gamma1(:, j + 1) - gamma0(:, 1);
    d(:, ind) = gamma1(:, j + 1) - gamma0(:, i);
    ind = ind + 1;
end
j = length_1;
a(:, ind) = gamma1(:, j) - gamma0(:, i);
b(:, ind) = gamma1(:, j) - gamma0(:, 1);
c(:, ind) = gamma1(:, 1) - gamma0(:, 1);
d(:, ind) = gamma1(:, 1) - gamma0(:, i);
a = intval(a);
b = intval(b);
c = intval(c);
d = intval(d);

        n = n + solid_angle_quadrilateral(a, b, c, d);


n = n / (4 * midrad(pi, 1e-14));

