using ValidatedNumerics
using LinearAlgebra

function solid_angle_triangle(a, b, c)
    determ = (b[2]*c[3] - b[3]*c[2]) * a[1] + (b[3]*c[1] - b[1]*c[3]) * a[2] + (b[1]*c[2] - b[2]*c[1]) * a[3]
    al = norm(a)
    bl = norm(b)
    cl = norm(c)
    ab = a[1] * b[1] + a[2] * b[2] + a[3] * b[3]
    bc = b[1] * c[1] + b[2] * c[2] + b[3] * c[3]
    ca = c[1] * a[1] + c[2] * a[2] + c[3] * a[3]
    div = al * bl * cl + ab * cl + ca * bl + bc * al
    return 2 * atan(determ, div)
end

function solid_angle_quadrilateral(a, b, c, d)
    return solid_angle_triangle(a, b, c) + solid_angle_triangle(c, d, a)
end

function linking_number(gamma0, gamma1)

    l0 = size(gamma0, 2)
    l1 = size(gamma1, 2)
    n = 0.0

    for i = 1:l0
        for j = 1:l1
            a = gamma1[:, j]              - gamma0[:, i];
            b = gamma1[:, j]              - gamma0[:, mod(i, l0) + 1];
            c = gamma1[:, mod(j, l1) + 1] - gamma0[:, mod(i, l0) + 1];
            d = gamma1[:, mod(j, l1) + 1] - gamma0[:, i];
            n = n + solid_angle_quadrilateral(a, b, c, d);
        end
    end

    return n / 4π
end

function linking_number_interval(gamma0, gamma1)

    G0 = Array{ValidatedNumerics.Interval{Float64}}(undef, size(gamma0))
    G1 = Array{ValidatedNumerics.Interval{Float64}}(undef, size(gamma1))

    for i = 1:size(gamma0, 1)
        for j = 1:size(gamma0, 2)
            G0[i, j] = @interval(gamma0[i, j])
        end
    end

    for i = 1:size(gamma1, 1)
        for j = 1:size(gamma1, 2)
            G1[i, j] = @interval(gamma1[i, j])
        end
    end

    return linking_number(G0, G1)
end
