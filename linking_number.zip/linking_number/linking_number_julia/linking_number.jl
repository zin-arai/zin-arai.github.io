using IntervalArithmetic
using LinearAlgebra

function solid_angle_triangle(a, b, c)
    determ = (b[2]*c[3] - b[3]*c[2]) * a[1] + (b[3]*c[1] - b[1]*c[3]) * a[2] + (b[1]*c[2] - b[2]*c[1]) * a[3] #determ = dot(cross(b, c), a) # slower
    al = sqrt(a[1]^2 + a[2]^2 + a[3]^2) #norm(a)
    bl = sqrt(b[1]^2 + b[2]^2 + b[3]^2) #norm(b)
    cl = sqrt(c[1]^2 + c[2]^2 + c[3]^2) #norm(c)
    ab = a[1] * b[1] + a[2] * b[2] + a[3] * b[3] #dot(a, b)
    bc = b[1] * c[1] + b[2] * c[2] + b[3] * c[3] #dot(b, c)
    ca = c[1] * a[1] + c[2] * a[2] + c[3] * a[3] #dot(c, a)
    div = al * bl * cl + ab * cl + ca * bl + bc * al
    return 2.0 * atan(determ, div)
end

function linking_number_loop(g00, g01, g10, g11)
    a = @. g10 - g00
    b = @. g10 - g01
    c = @. g11 - g01
    d = @. g11 - g00
    return solid_angle_triangle(a, b, c) + solid_angle_triangle(c, d, a)
end

function linking_number(gamma0, gamma1)

    l0 = size(gamma0, 2)
    l1 = size(gamma1, 2)
    n = zero(typeof(gamma0[1,1]))

    gamma0 = hcat(gamma0, gamma0[:,1])
    gamma1 = hcat(gamma1, gamma1[:,1])

    for i in 1:l0
        g00 = @view gamma0[:, i]
        g01 = @view gamma0[:, i + 1]
        for j = 1:l1
            g10 = @view gamma1[:, j]
            g11 = @view gamma1[:, j + 1]
            n += linking_number_loop(g00, g01, g10, g11);
        end
    end

    return n / 4π
end

function linking_number_interval(gamma0, gamma1)

    G0 = Array{Interval{Float64}}(undef, size(gamma0))
    G1 = Array{Interval{Float64}}(undef, size(gamma1))

    for i = 1:size(gamma0, 1)
        for j = 1:size(gamma0, 2)
            G0[i, j] = @interval(gamma0[i, j])
        end
    end

    for i = 1:size(gamma1, 1)
        for j = 1:size(gamma1, 2)
            G1[i, j] = @interval(gamma1[i, j])
        end
    end

    return linking_number(G0, G1)
end
