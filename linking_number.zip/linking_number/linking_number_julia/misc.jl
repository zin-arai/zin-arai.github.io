function zero_in(I)
    return (I.lo <= 0) & (I.hi >= 0)
end

function atan2_interval(y, x)

    if zero_in(x) & zero_in(y)
        error("arc-tangent can not computed.")
    end

    if !zero_in(x)
        if x > 0
            T = atan(y / x);
        elseif y > 0
            T = atan(y / x) + π
        elseif y < 0
            T = atan(y / x) - π
        else
            error("arc-tangent can not computed.")
        end
    elseif y > 0
        T = - atan(x / y) + π/2
    else y < 0
        T = - atan(x / y) - π/2
    end
    return T
end
