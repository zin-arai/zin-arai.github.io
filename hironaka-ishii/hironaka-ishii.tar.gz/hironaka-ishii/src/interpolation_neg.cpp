#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

static const int nBoxes = 5; // The number of boxes
static const int nData  = 4; // The number of input data files
#include "locuslib.hpp"

using namespace std;

int main(int argc, char * argv [])
{
    double tx_0[20], ty_0[20];
    double ax_0[5], ay_0[5];
    double bx_0[5], by_0[5];
    double Px_0[5], Py_0[5];
    double Qx_0[5], Qy_0[5];
    double tx_1[20], ty_1[20];
    double ax_1[5], ay_1[5];
    double bx_1[5], by_1[5];
    double Px_1[5], Py_1[5];
    double Qx_1[5], Qy_1[5];
    double a_0, b_0;
    double a_1, b_1;

    string outputFileName, inputFileName_0, inputFileName_1;

    // usage: interpolation t outputfile infile_0 infile_1
    const double t = atof(argv[1]);
    outputFileName = argv[2];
    inputFileName_0 = argv[3];
    inputFileName_1 = argv[4];

    // input the sixteen points in the trellis in R^2
    input_data_negative(inputFileName_0, 
                        a_0, b_0,
                        tx_0, ty_0, ax_0, ay_0, bx_0, by_0, Px_0, Py_0, Qx_0, Qy_0);

    // input the sixteen points in the trellis in R^2
    input_data_negative(inputFileName_1, 
                        a_1, b_1,
                        tx_1, ty_1, ax_1, ay_1, bx_1, by_1, Px_1, Py_1, Qx_1, Qy_1);

    ofstream outputFile(outputFileName.c_str());

    // output the interpolated data
    outputFile << "a = " << linear_interpolation(t, a_0, a_1) << endl;
    outputFile << "b = " << linear_interpolation(t, b_0, b_1) << endl;

    for (int i = 0; i < 8; i++) { 
        outputFile << "tx[" << i << "] = " << linear_interpolation(t, tx_0[i], tx_1[i]) << endl 
                   << "ty[" << i << "] = " << linear_interpolation(t, ty_0[i], ty_1[i]) << endl;
    }
    outputFile << "tx[8] = tx[2]" << endl;
    outputFile << "ty[8] = ty[2]" << endl;
    outputFile << "tx[9] = tx[3]" << endl;
    outputFile << "ty[9] = ty[3]" << endl;
    for (int i = 10; i < 12; i++) { 
        outputFile << "tx[" << i << "] = " << linear_interpolation(t, tx_0[i], tx_1[i]) << endl 
                   << "ty[" << i << "] = " << linear_interpolation(t, ty_0[i], ty_1[i]) << endl;
    }
    outputFile << "tx[12] = tx[6]" << endl;
    outputFile << "ty[12] = ty[6]" << endl;
    outputFile << "tx[13] = tx[7]" << endl;
    outputFile << "ty[13] = ty[7]" << endl;
    for (int i = 14; i < 16; i++) { 
        outputFile << "tx[" << i << "] = " << linear_interpolation(t, tx_0[i], tx_1[i]) << endl 
                   << "ty[" << i << "] = " << linear_interpolation(t, ty_0[i], ty_1[i]) << endl;
    }
    outputFile << "tx[16] = tx[10]" << endl;
    outputFile << "ty[16] = ty[10]" << endl;
    outputFile << "tx[17] = tx[15]" << endl;
    outputFile << "ty[17] = ty[15]" << endl;
    for (int i = 18; i < 20; i++) { 
        outputFile << "tx[" << i << "] = " << linear_interpolation(t, tx_0[i], tx_1[i]) << endl 
                   << "ty[" << i << "] = " << linear_interpolation(t, ty_0[i], ty_1[i]) << endl;
    }
    for (int i = 0; i < 5; i++) {
        outputFile << "ax[" << i << "] = " << linear_interpolation(t, ax_0[i], ax_1[i]) << endl;
    }
    for (int i = 0; i < 5; i++) {
        outputFile << "ay[" << i << "] = " << linear_interpolation(t, ay_0[i], ay_1[i]) << endl;
    }
    for (int i = 0; i < 5; i++) {
        outputFile << "bx[" << i << "] = " << linear_interpolation(t, bx_0[i], bx_1[i]) << endl;
    }
    for (int i = 0; i < 5; i++) {
        outputFile << "by[" << i << "] = " << linear_interpolation(t, by_0[i], by_1[i]) << endl;
    }
    for (int i = 0; i < 5; i++) { 
        outputFile << "Px[" << i << "]-" << "px[" << i << "] = " << linear_interpolation(t, Px_0[i], Px_1[i]) << endl
                   << "Qx[" << i << "]-" << "qx[" << i << "] = " << linear_interpolation(t, Qx_0[i], Qx_1[i]) << endl
                   << "Py[" << i << "]-" << "py[" << i << "] = " << linear_interpolation(t, Py_0[i], Py_1[i]) << endl
                   << "Qy[" << i << "]-" << "qy[" << i << "] = " << linear_interpolation(t, Qy_0[i], Qy_1[i]) << endl;
    }
    
    outputFile.close();
}
