#ifndef ZA_COMPLEX_INTERVAL
#define ZA_COMPLEX_INTERVAL

#include <iostream>
#include <complex>
#include "interval.hpp"

template <class I>
class ComplexInterval {
public:
    /// Constructor
    ComplexInterval();
    ComplexInterval(I re);
    ComplexInterval(I re, I im);
    ComplexInterval(const ComplexInterval& other);

    /// Substitution Operartors
    ComplexInterval& operator =  (const ComplexInterval& rhs);
    ComplexInterval& operator += (const ComplexInterval& rhs);
    ComplexInterval& operator -= (const ComplexInterval& rhs);
    ComplexInterval& operator *= (const ComplexInterval& rhs);
    ComplexInterval& operator /= (const ComplexInterval& rhs);

    ComplexInterval& operator += (const I& rhs);
    ComplexInterval& operator -= (const I& rhs);
    ComplexInterval& operator *= (const I& rhs);
    ComplexInterval& operator /= (const I& rhs);

    ComplexInterval& operator += (const double& rhs);
    ComplexInterval& operator -= (const double& rhs);
    ComplexInterval& operator *= (const double& rhs);
    ComplexInterval& operator /= (const double& rhs);

    /// Comparison Operators
    bool operator == (const ComplexInterval& rhs);
    bool operator != (const ComplexInterval& rhs);

    /// Accessors
    I getRe() const;
    I getIm() const;
    I cpxNorm() const;
    ComplexInterval center() const;

private:
    /// the real part
    I re_; 
    /// the imaginary part
    I im_; 
};

/// Constructors
template <class I> 
ComplexInterval<I>::ComplexInterval() : re_(I(0)), im_(I(0)) {}

template <class I> 
ComplexInterval<I>::ComplexInterval(I re) : re_(re), im_(I(0)) {}

template <class I> 
ComplexInterval<I>::ComplexInterval(I re, I im) : re_(re), im_(im) {}

template <class I>  
ComplexInterval<I>::ComplexInterval(const ComplexInterval<I>& other) : re_(other.re_), im_(other.im_) {}

/// Substitution Operators
template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator = (const ComplexInterval<I>& rhs)
{
    re_ = rhs.re_;
    im_ = rhs.im_;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator += (const ComplexInterval<I>& rhs)
{
    re_ += rhs.re_;
    im_ += rhs.im_;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator -= (const ComplexInterval<I>& rhs)
{
    re_ -= rhs.re_;
    im_ -= rhs.im_;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator *= (const ComplexInterval<I>& rhs)
{
    I tmp;
    tmp = re_ * rhs.re_ - im_ * rhs.im_;
    im_ = re_ * rhs.im_ + im_ * rhs.re_;
    re_ = tmp;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator /= (const ComplexInterval<I>& rhs)
{
    I rhsModulus, tmp;
    //rhsModulus = rhs.re_ * rhs.re_ + rhs.im_ * rhs.im_;
    rhsModulus = square(rhs.re_) + square(rhs.im_);
    /*
    I m1, m2, m3, m4, m;
    m1 = rhs.re_.upper() * rhs.re_.upper() + square(rhs.im_);
    m2 = rhs.re_.lower() * rhs.re_.lower() + square(rhs.im_);
    m3 = square(rhs.re_) + rhs.im_.upper() * rhs.im_.upper();
    m4 = square(rhs.re_) + rhs.im_.lower() * rhs.im_.lower();
    rhsModulus = I(min2(min2(m1.lower(), m2.lower()), min2(m3.lower(), m4.lower())), 
                   max2(max2(m1.upper(), m2.upper()), max2(m3.upper(), m4.upper())));
    */

    if (rhsModulus.lower() * rhsModulus.upper() <= 0) {
        std::cout << "Zero Division: " << rhs << ", Modulus = " << rhsModulus << std::endl;
    }
    tmp =   re_ * rhs.re_ + im_ * rhs.im_;
    im_ = - re_ * rhs.im_ + im_ * rhs.re_;
    re_ = tmp;
    re_ /= rhsModulus;
    im_ /= rhsModulus;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator += (const I& rhs)
{
    re_ += rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator -= (const I& rhs)
{
    re_ -= rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator *= (const I& rhs)
{
    re_ = re_ * rhs;
    im_ = im_ * rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator /= (const I& rhs)
{
    re_ /= rhs;
    im_ /= rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator += (const double& rhs)
{
    re_ += rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator -= (const double& rhs)
{
    re_ -= rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator *= (const double& rhs)
{
    re_ = re_ * rhs;
    im_ = im_ * rhs;
    return *this;
}

template <class I>  
ComplexInterval<I>& ComplexInterval<I>::operator /= (const double& rhs)
{
    re_ /= rhs;
    im_ /= rhs;
    return *this;
}

/// Comparison Operators
template <class I>  
bool ComplexInterval<I>::operator == (const ComplexInterval<I>& rhs)
{
    //using namespace compare::set;
    return ((re_ == rhs.re_) && (im_ == rhs.im_));
}

template <class I>  
bool ComplexInterval<I>::operator != (const ComplexInterval<I>& rhs)
{
    //using namespace compare::set;
    return ((re_ != rhs.re_) || (im_ != rhs.im_));
}

//
// Arithmetic Operators
//
template <class I>  
const ComplexInterval<I> operator - (const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans;
    ans -= rhs;
    return ans;
}

// "+"
template <class I>  
const ComplexInterval<I> operator + (const ComplexInterval<I>& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans += rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator + (const ComplexInterval<I>& lhs, 
                                     const I& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans += rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator + (const I& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans += rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator + (const ComplexInterval<I>& lhs, 
                                     const double& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans += rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator + (const double& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans += rhs;
    return ans;
}

// "-"
template <class I>  
const ComplexInterval<I> operator - (const ComplexInterval<I>& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans -= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator - (const ComplexInterval<I>& lhs, 
                                     const I& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans -= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator - (const I& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans -= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator - (const ComplexInterval<I>& lhs, 
                                     const double& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans -= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator - (const double& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans -= rhs;
    return ans;
}

// "*"
template <class I>  
const ComplexInterval<I> operator * (const ComplexInterval<I>& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans *= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator * (const ComplexInterval<I>& lhs, 
                                     const I& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans *= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator * (const I& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans *= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator * (const double& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(rhs);
    ans *= lhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator * (const ComplexInterval<I>& lhs, 
                                     const double& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans *= rhs;
    return ans;
}

// "/"
template <class I>  
const ComplexInterval<I> operator / (const ComplexInterval<I>& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans /= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator / (const ComplexInterval<I>& lhs, 
                                     const I& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans /= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator / (const I& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans /= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator / (const ComplexInterval<I>& lhs, 
                                     const double& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans /= rhs;
    return ans;
}

template <class I>  
const ComplexInterval<I> operator / (const double& lhs, 
                                     const ComplexInterval<I>& rhs)
{
    ComplexInterval<I> ans(lhs);
    ans /= rhs;
    return ans;
}

// Other functions
template <class I> 
ComplexInterval<I> square(const ComplexInterval<I>& rhs)
{
    I re, im;
    re = square(rhs.getRe()) - square(rhs.getIm());
    im = 2.0 * rhs.getRe() * rhs.getIm();
    ComplexInterval<I> ans(re, im);
    return ans;
}

template <class I> 
ComplexInterval<I> pow(const ComplexInterval<I>& rhs, const int n)
{
    I re(1), im;
    ComplexInterval<I> ans(re, im);
    for (int i = 0; i < n; i++) {
        //ans = ans * rhs;
        ans *= rhs;
    }
    return ans;
}

template <class I> 
I modulus_square(const ComplexInterval<I>& rhs)
{
    return square(rhs.getRe()) + square(rhs.getIm());
}

/// Accessors
template <class I> 
I ComplexInterval<I>::getRe() const {return re_;};

template <class I> 
I ComplexInterval<I>::getIm() const {return im_;};

template <class I> 
I ComplexInterval<I>::cpxNorm() const {
    I x = re_ * re_ + im_ * im_;
    if (x.lower() < 0.) x = I(0, x.upper());
    return sqrt(x);
};

template <class I> 
ComplexInterval<I> ComplexInterval<I>::center() const {
    return ComplexInterval<I>(mid(re_), mid(im_));
};

template <class I> 
ComplexInterval<I> intersect(ComplexInterval<I> u, ComplexInterval<I> v) {
    return ComplexInterval<I>(intersect(u.getRe(), v.getRe()), intersect(u.getIm(), v.getIm()));
};

/// I/O Operators
//template <class T, class P> 
//std::ostream& operator << (std::ostream& out, const interval<T, P>& x)
//{
//    out << "[" << x.lower() << ", " << x.upper() << "]";
//    return out;
//}

template <class I> 
std::ostream& operator << (std::ostream& out, const ComplexInterval<I>& z)
{
    I re = z.getRe(); 
    I im = z.getIm(); 
    out << re << " + " << im << "i";
    return out;
}

/// Set theoretic operations
template <class I> 
bool subset(const ComplexInterval<I>& x, const ComplexInterval<I>& y)
{
    return (subset(x.getRe(), y.getRe()) && subset(x.getIm(), y.getIm()));
}

template <class I> 
bool proper_subset(const ComplexInterval<I>& x, const ComplexInterval<I>& y)
{
    return (proper_subset(x.getRe(), y.getRe()) && proper_subset(x.getIm(), y.getIm()));
}

template <class I> 
bool overlap(const ComplexInterval<I>& x, const ComplexInterval<I>& y)
{
    return (overlap(x.getRe(), y.getRe()) && overlap(x.getIm(), y.getIm()));
}

template <class I> 
bool zero_in(const ComplexInterval<I>& x)
{
    return (zero_in(x.getRe()) && zero_in(x.getIm()));
}

#endif // ZA_COMPLEX_INTERVAL
