#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>
#include <cstdlib>
#include <climits>
#include <getopt.h>

#define max2(x, y) ((x) > (y) ? (x) : (y))
#define min2(x, y) ((x) < (y) ? (x) : (y))
#define interval_intersect(a, b, c, d)  !(((b) < (c)) || ((a) > (d)))

typedef unsigned char byte;
using namespace std;
#include "kdTree.hpp"
#include "ComplexInterval.hpp"
typedef interval Interval;
typedef ComplexInterval< Interval > CpxInterval;

const Interval entire(-INFINITY, INFINITY);
const CpxInterval entire_C(entire, entire);

typedef interval Interval;
Interval square(const Interval& x)
{
    if ((x.lower() >= 0) || (x.upper() <= 0)) {
        return x * x;
    } else {
        const Interval l(x.lower(), 0);
        const Interval r(0, x.upper());
        return interval::hull(l * l, r * r);
    }
}

inline double min3(const double a, const double b, const double c) 
{
    return min2(min2(a, b), c);
}

inline double max3(const double a, const double b, const double c) 
{
    return max2(max2(a, b), c);
}

inline double min4(const double a, const double b, const double c, const double d)
{
    return min2(min2(a, b), min2(c, d));
}

inline double max4(const double a, const double b, const double c, const double d) 
{
    return max2(max2(a, b), max2(c, d));
}

inline Interval hull4(const Interval a, const Interval b, const Interval c, const Interval d) 
{
    return interval::hull(interval::hull(a, b), interval::hull(c, d));
}

inline double linear_interpolation(double t, const double v_0, const double v_1) 
{
    return v_0 + t * (v_1 - v_0);
}

//double mid(const Interval I)
//{
//    return (I.lower() + I.upper()) * 0.5;
//}

void midrad(const CpxInterval I, CpxInterval& c, CpxInterval& r)
{
    c = CpxInterval((Interval(I.getRe().lower()) + Interval(I.getRe().upper())) * 0.5,
                    (Interval(I.getIm().lower()) + Interval(I.getIm().upper())) * 0.5);
    r = I - c;
    return;
}

double c_rand(double lower, double upper)
{
    return (upper - lower) * (double(rand()) / double(RAND_MAX)) + lower;
}

template <class I>
class Matrix {
public:
    Matrix(I p, I q, I r, I s);
    Matrix(const Matrix& other);
    I p_; // top-left
    I q_; // top-right
    I r_; // bottom-left
    I s_; // bottom-right
};

template <class I> inline
Matrix<I>::Matrix(I p, I q, I r, I s) : p_(p), q_(q), r_(r), s_(s) {}

template <class I> inline
Matrix<I>::Matrix(const Matrix<I>& other) : p_(other.p_), q_(other.q_), r_(other.r_), s_(other.s_) {}

template <class I> inline
std::ostream& operator << (std::ostream& out, const Matrix<I>& M)
{
    out << "p = " << M.p_ << endl;
    out << "q = " << M.q_ << endl;
    out << "r = " << M.r_ << endl;
    out << "s = " << M.s_ << endl;
    return out;
}

template <class I>
class RVector {
public:
    RVector(I a, I b);
    RVector(const RVector& other);
    I a_;
    I b_;
};

template <class I> inline
RVector<I>::RVector(I a, I b) : a_(a), b_(b) {}

template <class I> inline
RVector<I>::RVector(const RVector<I>& other) : a_(other.a_), b_(other.b_) {}

template <class I>
class CVector {
public:
    CVector();
    CVector(I a, I b);
    CVector(const CVector& other);
    I get1st() const;
    I get2nd() const;
    I a_;
    I b_;
};

template <class I> inline
CVector<I>::CVector() : a_(0), b_(0) {}

template <class I> inline
CVector<I>::CVector(I a, I b) : a_(a), b_(b) {}

template <class I> inline
CVector<I>::CVector(const CVector<I>& other) : a_(other.a_), b_(other.b_) {}

template <class I> inline
I CVector<I>::get1st() const {return a_;};

template <class I> inline
I CVector<I>::get2nd() const {return b_;};

template <class I> inline 
Matrix<I> product(const Matrix<I>& M, const Matrix<I>& N)
{
    I p, q, r, s;
    p = M.p_ * N.p_ + M.q_ * N.r_;
    q = M.p_ * N.q_ + M.q_ * N.s_;
    r = M.r_ * N.p_ + M.s_ * N.r_;
    s = M.r_ * N.q_ + M.s_ * N.s_;
    return Matrix<I>(p, q, r, s);
}

template <class I> inline 
RVector<I> product(const RVector<I>& v, const Matrix<I>& M)
{
    I A, B;
    A = v.a_ * M.p_ + v.b_ * M.r_;
    B = v.a_ * M.q_ + v.b_ * M.s_;
    return RVector<I>(A, B);
}

template <class I> inline 
CVector<I> product(const Matrix<I>& M, const CVector<I>& v)
{
    I A, B;
    A = M.p_ * v.a_ + M.q_ * v.b_;
    B = M.r_ * v.a_ + M.s_ * v.b_;
    return CVector<I>(A, B);
}

template <class I> inline 
I product(const RVector<I>& v, const CVector<I>& w)
{
    return v.a_ * w.a_ + v.b_ * w.b_;
}

double tang(double b)
{
    double b0, b1, a0, a1;
    if      (b < -0.90) {b0 = -1.00; a0 =  6.20; b1 = -0.90; a1 =  5.60;} 
    else if (b < -0.80) {b0 = -0.90; a0 =  5.60; b1 = -0.80; a1 =  5.04;} 
    else if (b < -0.70) {b0 = -0.80; a0 =  5.04; b1 = -0.70; a1 =  4.52;} 
    else if (b < -0.60) {b0 = -0.70; a0 =  4.52; b1 = -0.60; a1 =  4.04;} 
    else if (b < -0.50) {b0 = -0.60; a0 =  4.04; b1 = -0.50; a1 =  3.61;}
    else if (b < -0.40) {b0 = -0.50; a0 =  3.61; b1 = -0.40; a1 =  3.21;} 
    else if (b < -0.30) {b0 = -0.40; a0 =  3.21; b1 = -0.30; a1 =  2.85;} 
    else if (b < -0.20) {b0 = -0.30; a0 =  2.85; b1 = -0.20; a1 =  2.53;} 
    else if (b < -0.10) {b0 = -0.20; a0 =  2.53; b1 = -0.10; a1 =  2.25;} 
    else if (b <  0.00) {b0 = -0.10; a0 =  2.25; b1 =  0.00; a1 =  2.00;} 
    else if (b <  0.10) {b0 =  0.00; a0 =  2.00; b1 =  0.10; a1 =  2.21;} 
    else if (b <  0.20) {b0 =  0.10; a0 =  2.21; b1 =  0.20; a1 =  2.45;} 
    else if (b <  0.30) {b0 =  0.20; a0 =  2.45; b1 =  0.30; a1 =  2.72;} 
    else if (b <  0.40) {b0 =  0.30; a0 =  2.72; b1 =  0.40; a1 =  3.03;} 
    else if (b <  0.50) {b0 =  0.40; a0 =  3.03; b1 =  0.50; a1 =  3.37;} 
    else if (b <  0.60) {b0 =  0.50; a0 =  3.37; b1 =  0.60; a1 =  3.76;}
    else if (b <  0.70) {b0 =  0.60; a0 =  3.76; b1 =  0.70; a1 =  4.18;} 
    else if (b <  0.80) {b0 =  0.70; a0 =  4.18; b1 =  0.80; a1 =  4.65;} 
    else if (b <  0.90) {b0 =  0.80; a0 =  4.65; b1 =  0.90; a1 =  5.15;} 
    else                {b0 =  0.90; a0 =  5.15; b1 =  1.00; a1 =  5.70;}

    return a0 + (b - b0) / (b1 - b0) * (a1 - a0);
}

void input_data_positive(const string inputFileName, 
                         double& a, double& b, 
                         double* tx, double* ty, 
                         double* ax, double* ay, 
                         double* bx, double* by, 
                         double* Px, double* Py, 
                         double* Qx, double* Qy,
                         double& cut_Px2)
{
    ifstream inputFile(inputFileName.c_str());
    string tmp;

    inputFile >> tmp >> tmp >> a;
    inputFile >> tmp >> tmp >> b; 
    for (int i = 0; i < 16; i++) {
        inputFile >> tmp >> tmp >> tx[i];
        inputFile >> tmp >> tmp >> ty[i];
    }
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> ax[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> ay[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> bx[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> by[i];}
    for (int i = 0; i <  4; i++) {
        inputFile >> tmp >> tmp >> Px[i];
        inputFile >> tmp >> tmp >> Qx[i];
        inputFile >> tmp >> tmp >> Py[i];
        inputFile >> tmp >> tmp >> Qy[i];
    }
    inputFile >> tmp >> tmp >> cut_Px2; 
    
    double tx7_adjust, tx9_adjust, ty7_adjust, ty9_adjust, ty2_adjust;
    double ty3_adjust, tx13_adjust, tx5_adjust, tx15_adjust, ty10_adjust;
    inputFile >> tmp >> tmp >> tx7_adjust; 
    inputFile >> tmp >> tmp >> tx9_adjust; 
    inputFile >> tmp >> tmp >> ty7_adjust; 
    inputFile >> tmp >> tmp >> ty9_adjust; 
    inputFile >> tmp >> tmp >> ty2_adjust; 
    inputFile >> tmp >> tmp >> ty3_adjust; 
    inputFile >> tmp >> tmp >> tx13_adjust; 
    inputFile >> tmp >> tmp >> tx5_adjust; 
    inputFile >> tmp >> tmp >> tx15_adjust;
    inputFile >> tmp >> tmp >> ty10_adjust;

    tx[7] += tx7_adjust; 
    tx[9] += tx9_adjust; 
    ty[7] += ty7_adjust; 
    ty[9] += ty9_adjust; 
    ty[2] += ty2_adjust; 
    ty[3] += ty3_adjust; 
    tx[13] += tx13_adjust; 
    tx[5] += tx5_adjust; 
    tx[15] += tx15_adjust;
    ty[10] += ty10_adjust;

    inputFile.close();
}

void input_data_negative(const string inputFileName, 
                double& a, double& b, 
                double* tx, double* ty, 
                double* ax, double* ay, 
                double* bx, double* by, 
                double* Px, double* Py, 
                double* Qx, double* Qy)
{
    ifstream inputFile(inputFileName.c_str());
    string tmp;

    inputFile >> tmp >> tmp >> a;
    inputFile >> tmp >> tmp >> b; 

    // 0 - 7
    for (int i = 0; i < 8; i++) {
        inputFile >> tmp >> tmp >> tx[i];
        inputFile >> tmp >> tmp >> ty[i];
    }

    // 8, 9
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    tx[8] = tx[2];
    ty[8] = ty[2];
    tx[9] = tx[3];
    ty[9] = ty[3];

    // 10, 11
    inputFile >> tmp >> tmp >> tx[10];
    inputFile >> tmp >> tmp >> ty[10];
    inputFile >> tmp >> tmp >> tx[11];
    inputFile >> tmp >> tmp >> ty[11];

    // 12, 13
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    tx[12] = tx[6];
    ty[12] = ty[6];
    tx[13] = tx[7];
    ty[13] = ty[7];

    // 14, 15
    inputFile >> tmp >> tmp >> tx[14];
    inputFile >> tmp >> tmp >> ty[14];
    inputFile >> tmp >> tmp >> tx[15];
    inputFile >> tmp >> tmp >> ty[15];

    // 16, 17
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    inputFile >> tmp >> tmp >> tmp;
    tx[16] = tx[10];
    ty[16] = ty[10];
    tx[17] = tx[15];
    ty[17] = ty[15];

    // 18, 19
    inputFile >> tmp >> tmp >> tx[18];
    inputFile >> tmp >> tmp >> ty[18];
    inputFile >> tmp >> tmp >> tx[19];
    inputFile >> tmp >> tmp >> ty[19];

    for (int i = 0; i <  5; i++) {inputFile >> tmp >> tmp >> ax[i];}
    for (int i = 0; i <  5; i++) {inputFile >> tmp >> tmp >> ay[i];}
    for (int i = 0; i <  5; i++) {inputFile >> tmp >> tmp >> bx[i];}
    for (int i = 0; i <  5; i++) {inputFile >> tmp >> tmp >> by[i];}
    for (int i = 0; i <  5; i++) {
        inputFile >> tmp >> tmp >> Px[i];
        inputFile >> tmp >> tmp >> Qx[i];
        inputFile >> tmp >> tmp >> Py[i];
        inputFile >> tmp >> tmp >> Qy[i];
    }

    inputFile.close();
}

void apply_henon_map(const vector<CpxInterval>& Z, const vector<CpxInterval>& W, 
                     vector<CpxInterval>& ZZ, vector<CpxInterval>& WW,
                     const CpxInterval a, const CpxInterval b) 
{
    for (vector<CpxInterval>::size_type i = 0; i != Z.size(); i++) {
        ZZ[i] = square(Z[i]) - a - b * W[i];
        WW[i] = Z[i];
    }
}

template <class I> inline 
Matrix<I> Df(I b, I x) 
{
    return Matrix<I>(I(2) * x, -b, I(1), I(0));
}

void compute_focuses(const double* tx, const double* ty, 
                      double* fx, double* fy,
                      double* gx, double* gy,
                      double* px, double* py,
                      double* qx, double* qy)
{
    for (int i = 0; i < nBoxes; i++) {
        fx[i]=(tx[0+4*i]*(ty[1+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[2+4*i])
               -tx[2+4*i]*(tx[1+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[2+4*i])
               +(ty[2+4*i]-ty[0+4*i])*(tx[1+4*i]-tx[0+4*i])*(tx[3+4*i]-tx[2+4*i]))/
            ((ty[1+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[2+4*i])
             -(ty[3+4*i]-ty[2+4*i])*(tx[1+4*i]-tx[0+4*i]));

        fy[i]=(ty[0+4*i]*(tx[1+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[2+4*i])
               -ty[2+4*i]*(ty[1+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[2+4*i])
               +(tx[2+4*i]-tx[0+4*i])*(ty[1+4*i]-ty[0+4*i])*(ty[3+4*i]-ty[2+4*i]))/
            ((tx[1+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[2+4*i])
             -(tx[3+4*i]-tx[2+4*i])*(ty[1+4*i]-ty[0+4*i]));

        gx[i]=(tx[0+4*i]*(ty[2+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[1+4*i])
               -tx[1+4*i]*(tx[2+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[1+4*i])
               +(ty[1+4*i]-ty[0+4*i])*(tx[2+4*i]-tx[0+4*i])*(tx[3+4*i]-tx[1+4*i]))/
            ((ty[2+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[1+4*i])
             -(ty[3+4*i]-ty[1+4*i])*(tx[2+4*i]-tx[0+4*i]));

        gy[i]=(ty[0+4*i]*(tx[2+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[1+4*i])
               -ty[1+4*i]*(ty[2+4*i]-ty[0+4*i])*(tx[3+4*i]-tx[1+4*i])
               +(tx[1+4*i]-tx[0+4*i])*(ty[2+4*i]-ty[0+4*i])*(ty[3+4*i]-ty[1+4*i]))/
            ((tx[2+4*i]-tx[0+4*i])*(ty[3+4*i]-ty[1+4*i])
             -(tx[3+4*i]-tx[1+4*i])*(ty[2+4*i]-ty[0+4*i]));

        px[i] = tx[0+4*i] - ty[0+4*i] * (tx[1+4*i] - tx[0+4*i]) / (ty[1+4*i] - ty[0+4*i]);
        qx[i] = tx[2+4*i] - ty[2+4*i] * (tx[3+4*i] - tx[2+4*i]) / (ty[3+4*i] - ty[2+4*i]);
        py[i] = ty[0+4*i] - tx[0+4*i] * (ty[2+4*i] - ty[0+4*i]) / (tx[2+4*i] - tx[0+4*i]);
        qy[i] = ty[1+4*i] - tx[1+4*i] * (ty[3+4*i] - ty[1+4*i]) / (tx[3+4*i] - tx[1+4*i]);
    }
}

void adjust_pq(const double* px, const double* py, 
               const double* qx, const double* qy,
               double* Px, double* Py, 
               double* Qx, double* Qy)
{
    for (int i = 0; i < nBoxes; i++) {
        Px[i] += px[i];
        Qx[i] += qx[i];
        Py[i] += py[i];
        Qy[i] += qy[i];
    }
}

void define_ellipse_boundaries(const double a, const double b, 
                               const double p, const double P,
                               const double q, const double Q, 
                               vector< complex<double> >& z)
{
    // n = number of points on the boundary, should be a multiple of 8
    int n = z.size(); 
    double Re, Im;
    double step = 4.0 / n;
    
    for(int j = 0; j < n; j++) {
        if (j < n / 4) {
            // the top boundary (from left to right)
            // j \in [0, n/4]
            Re = j * (p - q) * step + q;
            Im = sqrt((P - Q) * (P - Q) / 4 - (Re - (P + Q) / 2) * (Re - (P + Q) / 2)) * b / a;
        } else if (j < n / 2) {
            // vertical edge on the right hand side  (Re = p, from top to bottom)
            // j \in [n/4, n/2]
            Re = p;
            Im = - (j - n * 3 / 8) 
                * sqrt((P - Q) * (P - Q) / 4 - (Re - (P + Q) / 2) * (Re - (P + Q) / 2)) * b / a * 2 * step;
        } else if (j < n * 3 / 4) {
            // the bottom boundary (from right to left)
            // j \in [n/2, n*3/4]
            Re = - (j - n / 2) * (p - q) * step + p;
            Im = - sqrt((P - Q) * (P - Q) / 4 - (Re - (P + Q) / 2) * (Re - (P + Q) / 2)) * b / a;
        } else {
            // vertical edge on the left hand side (Re = q, from bottom to top)
            // j \in [n*3/4, n]
            Re = q;
            Im = (j - n * 7 / 8) * sqrt((P - Q) * (P - Q) / 4 - (Re - (P + Q) / 2) * (Re - (P + Q) / 2)) * b / a * 2 * step;
        }
        z[j] = complex<double>(Re, Im);
    }
}

void define_domain_points(const int domain, 
                          const double* fx, const double* fy, 
                          const double* gx, const double* gy,
                          const vector< complex<double> >& z, 
                          const vector< complex<double> >& w,
                          vector< complex<double> >& Z, 
                          vector< complex<double> >& W)
{
    int number_of_points = z.size();

    for (int j = 0; j < number_of_points; j++) {
        for (int k = 0; k < number_of_points; k++) {
            Z[j * number_of_points + k] = (fy[domain] * z[j] / (fx[domain] - z[j]) + w[k]) * gx[domain] * (fx[domain] - z[j]) / (fy[domain] * gx[domain] - (fx[domain] - z[j]) * (gy[domain] - w[k]));
            W[j * number_of_points + k] = (gx[domain] * w[k] / (gy[domain] - w[k]) + z[j]) * fy[domain] * (gy[domain] - w[k]) / (gx[domain] * fy[domain] - (gy[domain] - w[k]) * (fx[domain] - z[j]));
        }
    }
}

complex<double> square(const complex<double>& z)
{
    return z * z;
}

double square(const double z)
{
    return z * z;
}

void proj2euc(const CpxInterval fx, const CpxInterval fy, const CpxInterval gx, const CpxInterval gy,
              CpxInterval &x, CpxInterval &y, const CpxInterval u, const CpxInterval v)
{
    CpxInterval x_, y_;
    CpxInterval denom = gx * fy - (u - fx) * (v - gy);
    x_ = gx * (fy * u + fx * v - u * v) / denom;
    y_ = fy * (gx * v + gy * u - u * v) / denom;

    // Mean value version
    CpxInterval uc, ur;
    CpxInterval vc, vr;
    midrad(u, uc, ur);
    midrad(v, vc, vr);
    CpxInterval denomc = gx * fy - (uc - fx) * (vc - gy);
    CpxInterval tmpx = fy * u + fx * v - u * v;
    CpxInterval tmpy = gy * u + gx * v - u * v;

    x = gx * (fy * uc + fx * vc - uc * vc) / denomc +
        (gx * (v - gy) * tmpx / square(denom) + gx * (fy - v) / denom) * ur +
        (gx * (u - fx) * tmpx / square(denom) + gx * (fx - u) / denom) * vr;
    y = fy * (gx * vc + gy * uc - uc * vc) / denomc +
        (fy * (v - gy) * tmpy / square(denom) + fy * (gy - v) / denom) * ur +
        (fy * (u - fx) * tmpy / square(denom) + fy * (gx - u) / denom) * vr;

    // Take the intersection
    x = CpxInterval(Interval(max(x_.getRe().lower(), x.getRe().lower()), min(x_.getRe().upper(), x.getRe().upper())),
                    Interval(max(x_.getIm().lower(), x.getIm().lower()), min(x_.getIm().upper(), x.getIm().upper())));
    y = CpxInterval(Interval(max(y_.getRe().lower(), y.getRe().lower()), min(y_.getRe().upper(), y.getRe().upper())),
                    Interval(max(y_.getIm().lower(), y.getIm().lower()), min(y_.getIm().upper(), y.getIm().upper())));
}

/*
template <class I>
void proj2euc(const I fx, const I fy, const I gx, const I gy, I &x, I &y, const I u, const I v)
{
    I denom = gx * fy - (u - fx) * (v - gy);
    x = gx * (fy * u + fx * v - u * v) / denom;
    y = fy * (gx * v + gy * u - u * v) / denom;
}
*/

void euc2proj(const CpxInterval fx, const CpxInterval fy, const CpxInterval gx, const CpxInterval gy,
              const CpxInterval x, const CpxInterval y, CpxInterval &u, CpxInterval &v)
{
    CpxInterval u_, v_;
    u_ = x - y * (x - fx) / (y - fy);
    v_ = y - x * (y - gy) / (x - gx);

    // Mean value form version
    CpxInterval xc, xr;
    CpxInterval yc, yr;
    midrad(x, xc, xr);
    midrad(y, yc, yr);
    u = xc - yc * (xc - fx) / (yc - fy) + (fy / (fy - y)) * xr + (fy * (x - fx) / square(fy - y)) * yr;
    v = yc - xc * (yc - gy) / (xc - gx) + (gx * (y - gy) / square(x - gx)) * xr + (gx / (gx - x)) * yr;

    // Take the intersection
    u = CpxInterval(Interval(max(u_.getRe().lower(), u.getRe().lower()), min(u_.getRe().upper(), u.getRe().upper())),
                    Interval(max(u_.getIm().lower(), u.getIm().lower()), min(u_.getIm().upper(), u.getIm().upper())));
    v = CpxInterval(Interval(max(v_.getRe().lower(), v.getRe().lower()), min(v_.getRe().upper(), v.getRe().upper())),
                    Interval(max(v_.getIm().lower(), v.getIm().lower()), min(v_.getIm().upper(), v.getIm().upper())));

}

/*
template <class I>
void euc2proj(const I fx, const I fy, const I gx, const I gy, const I x, const I y, I &u, I &v)
{
    u = x - y * (x - fx) / (y - fy);
    v = y - x * (y - gy) / (x - gx);
}
*/

template <class I>
RVector<I> dxy_euc2proj_u(const I fx, const I fy, const I x, const I y)
{
    I du_dx, du_dy;
    du_dx = I(1) - y / (y - fy);
    du_dy = fy * (x - fx) / (square(y - fy));
    return RVector<I>(du_dx, du_dy);
}

template <class I>
RVector<I> dxy_euc2proj_u_wo_denom(const I fx, const I fy, const I x, const I y)
{
    I du_dx, du_dy;
    du_dx = -y + fy;
    du_dy =  x - fx;
    return RVector<I>(du_dx, du_dy);
}

/*
template <class I>
Matrix<I> ddxy_euc2proj_u(const I fx, const I fy, const I x, const I y)
{
    I tmp = fy / square(y - fy);
    return Matrix<I>(I(0), tmp, tmp, I(2) * tmp * (fx - x) / (y - fy));
}
*/

template <class I>
CVector<I> du_proj2euc_xy(const I fx, const I fy, const I gx, const I gy, const I u, const I v)
{
    I denom = gx * fy - (u - fx) * (v - gy);
    denom = square(denom);
    I dx_du = fy *    gx    * (fy * gx - gx * v + fx * (v - gy)) / denom;
    I dy_du = fy * (gy - v) * (fy * gx - gx * v + fx * (v - gy)) / denom;
    return CVector<I>(dx_du, dy_du);
}

template <class I>
CVector<I> du_proj2euc_xy_wo_denom(const I fx, const I fy, const I gx, const I gy, const I u, const I v)
{
    I dx_du = gx;
    I dy_du = gy - v;
    return CVector<I>(dx_du, dy_du);
}

/*
template <class I>
CVector<I> ddu_proj2euc_xy(const I fx, const I fy, const I gx, const I gy, const I u, const I v)
{
    I denom = gx * fy - (u - fx) * (v - gy);
    denom = denom * square(denom);
    I dx_dudu = (I(2) * fy * gx * (gy - v) * (-(fy * gx) + fx * (gy - v) + gx * v)) / denom;
    I dy_dudu = (I(-2) * fy * square(gy - v) * (fy * gx - gx * v + fx * (v - gy))) / denom;
    return CVector<I>(dx_dudu, dy_dudu);
}
*/

inline bool intersect_with(const int box, const CpxInterval X, const CpxInterval Y, 
                           const Interval CX, const Interval CY,
                           const Interval RX, const Interval RY,
                           const Interval ifx[nBoxes], const Interval ify[nBoxes], 
                           const Interval igx[nBoxes], const Interval igy[nBoxes], 
                           const Interval iax[nBoxes], const Interval iay[nBoxes], 
                           const Interval ibx[nBoxes], const Interval iby[nBoxes], 
                           const double Px[nBoxes], const double Py[nBoxes], 
                           const double Qx[nBoxes], const double Qy[nBoxes])
{
    CpxInterval U, V; // Projective Coordinates
    Interval s, t, S, T;
    Interval rU, rV;

    if (!overlap(X.getRe(), Interval(-8, 8)) || 
        !overlap(X.getIm(), Interval(-8, 8)) ||
        !overlap(Y.getRe(), Interval(-8, 8)) ||
        !overlap(Y.getIm(), Interval(-8, 8))) {
        return false;
    }

    if (zero_in(ify[box] - Y)) {
        if (zero_in(igx[box] - X)) {
            return true;
        }
        // Compute V
        V = Y - X * (igy[box] - Y) / (igx[box] - X);
        // Compute r
        s = V.getRe() - iay[box] * CY;
        t = V.getIm();
        S = iay[box] * RY;
        T = iby[box] * RY;
        rV = square(s) / square(S) + square(t) / square(T);
        
        // intersect with
        if (// W direction
            (Py[box] >= V.getRe().lower()) &&
            (Qy[box] <= V.getRe().upper()) && 
            (rV.lower() <= 1)) {
            return true;
        } else {
            return false;
        }
    }

    if (zero_in(igx[box] - X)) {
        // Compute U
        U = X - Y * (ifx[box] - X) / (ify[box] - Y);
        // Compute r
        s = U.getRe() - iax[box] * CX;
        t = U.getIm();
        S = iax[box] * RX;
        T = ibx[box] * RX;
        rU = square(s) / square(S) + square(t) / square(T);
        
        // intersect with
        if (// Z direction
            (Px[box] >= U.getRe().lower()) &&
            (Qx[box] <= U.getRe().upper()) && 
            (rU.lower() <= 1)) {
            return true;
        } else {
            return false;
        }
    }

    // Compute U
    U = X - Y * (ifx[box] - X) / (ify[box] - Y);
    // Compute r
    s = U.getRe() - iax[box] * CX;
    t = U.getIm();
    S = iax[box] * RX;
    T = ibx[box] * RX;
    rU = square(s) / square(S) + square(t) / square(T);
    
    // Compute V
    V = Y - X * (igy[box] - Y) / (igx[box] - X);
    // Compute r
    s = V.getRe() - iay[box] * CY;
    t = V.getIm();
    S = iay[box] * RY;
    T = iby[box] * RY;
    rV = square(s) / square(S) + square(t) / square(T);
    
    // intersect with
    if (// Z direction
        (Px[box] >= U.getRe().lower()) &&
        (Qx[box] <= U.getRe().upper()) && 
        (rU.lower() <= 1) &&
        // W direction
        (Py[box] >= V.getRe().lower()) &&
        (Qy[box] <= V.getRe().upper()) && 
        (rV.lower() <= 1)
        ) {
        return true;
    } else {
        return false;
    }
}

inline bool contained_in(const int box, const CpxInterval X, const CpxInterval Y, 
                         const Interval CX, const Interval CY,
                         const Interval RX, const Interval RY,
                         const Interval ifx[nBoxes], const Interval ify[nBoxes], 
                         const Interval igx[nBoxes], const Interval igy[nBoxes], 
                         const Interval iax[nBoxes], const Interval iay[nBoxes], 
                         const Interval ibx[nBoxes], const Interval iby[nBoxes], 
                         const double Px[nBoxes], const double Py[nBoxes], 
                         const double Qx[nBoxes], const double Qy[nBoxes])
{
    Interval s, t, S, T;
    CpxInterval U, V; // Projective Coordinates
    Interval rU, rV;

    if (zero_in(ify[box] - Y) || zero_in(igx[box] - X)) {
        return false;
    }

    // Compute U
    U = X - Y * (ifx[box] - X) / (ify[box] - Y);
    // Compute r
    s = U.getRe() - iax[box] * CX;
    t = U.getIm();
    S = iax[box] * RX;
    T = ibx[box] * RX;
    rU = square(s) / square(S) + square(t) / square(T);
    
    // Compute V
    V = Y - X * (igy[box] - Y) / (igx[box] - X);
    // Compute r
    s = V.getRe() - iay[box] * CY;
    t = V.getIm();
    S = iay[box] * RY;
    T = iby[box] * RY;
    rV = square(s) / square(S) + square(t) / square(T);
    
    // contained in
    if (// Z direction
        (Px[box] > U.getRe().upper()) &&
        (Qx[box] < U.getRe().lower()) && 
        (rU.upper() < 1) &&
        // W direction
        (Py[box] > V.getRe().upper()) &&
        (Qy[box] < V.getRe().lower()) && 
        (rV.upper() < 1)
        ) {
        return true;
    } else {
        return false;
    }
}
/*
template <class T> 
T dF(const T a, const T b, 
     const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
     const T x0, const T y0) 
{
    T ans, u, v, x1, y1, x2, y2, tmp;
    euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    // 1st
    tmp = x0;
    x1 = square(x0) - a - b * y0;
    y1 = tmp;
    // 2nd
    tmp = x1;
    x2 = square(x1) - a - b * y1;
    y2 = tmp;
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x2, y2);

    return product(De2p, product(D1, product(D0, Dp2e)));
}
*/

template <class T> 
T f2(const T a, const T b, 
     const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
     const T u, const T v) 
{
    T ans, x, y, tmp;
    proj2euc(fx, fy, gx, gy, x, y, u, v);
    // 1st
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 2nd
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    euc2proj(fx, fy, gx, gy, x, y, ans, tmp);
    return ans;
}

template <class T> 
T df2(const T a, const T b, 
      const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
      const T x0, const T y0) 
{
    T ans, tmp;
    // 1st
    tmp = x0;
    const T x1 = square(x0) - a - b * y0;
    const T y1 = tmp;
    // 2nd
    tmp = x1;
    const T x2 = square(x1) - a - b * y1;
    const T y2 = tmp;
    T u, v;
    euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x2, y2);

    return product(De2p, product(D1, product(D0, Dp2e)));
}

template <class T> 
T df2_wo_denom(const T a, const T b, 
      const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
      const T x0, const T y0) 
{
    T ans, tmp;
    // 1st
    tmp = x0;
    const T x1 = square(x0) - a - b * y0;
    const T y1 = tmp;
    // 2nd
    tmp = x1;
    const T x2 = square(x1) - a - b * y1;
    const T y2 = tmp;
    T u, v;
    try {
        euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    }
    catch (...) {
        return entire_C;
    }
    CVector<T> Dp2e = du_proj2euc_xy_wo_denom(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    RVector<T> De2p = dxy_euc2proj_u_wo_denom(FX, FY, x2, y2);

    return product(De2p, product(D1, product(D0, Dp2e)));
}

/*
template <class T> 
T ddf2(const T a, const T b, 
       const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
       const T u, const T v) 
{
    T ans, x0, y0, x1, y1, x2, y2, tmp;
    proj2euc(fx, fy, gx, gy, x0, y0, u, v);
    // 1st
    tmp = x0;
    x1 = square(x0) - a - b * y0;
    y1 = tmp;
    // 2nd
    tmp = x1;
    x2 = square(x1) - a - b * y1;
    y2 = tmp;
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x2, y2);

    CVector<T> D0Dp2e   = product(D0, Dp2e);
    CVector<T> D1D0Dp2e = product(D1, D0Dp2e);
    
    T dx0_du = Dp2e.get1st();
    T dx1_du = D0Dp2e.get1st();
    T dx2_du = D1D0Dp2e.get1st();
    T dy2_du = D1D0Dp2e.get2nd();

    CVector<T> DDp2e = ddu_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  DD0   = Matrix<T>(T(2) * dx0_du, T(0), T(0), T(0));
    Matrix<T>  DD1   = Matrix<T>(T(2) * dx1_du, T(0), T(0), T(0));
    RVector<T> DDe2p = product(RVector<T>(dx2_du, dy2_du), ddxy_euc2proj_u(FX, FY, x2, y2));

    return product(DDe2p, product(D1, product(D0, Dp2e)))
        +  product(De2p, product(DD1, product(D0, Dp2e)))
        +  product(De2p, product(D1, product(DD0, Dp2e)))
        +  product(De2p, product(D1, product(D0, DDp2e)));
}
*/

template <class T> 
T f3(const T a, const T b, 
     const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
     const T u, const T v) 
{
    T ans, x, y, tmp;
    proj2euc(fx, fy, gx, gy, x, y, u, v);
    // 1st
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 2nd
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 3rd
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    euc2proj(fx, fy, gx, gy, x, y, ans, tmp);
    return ans;
}

template <class T> 
T df3(const T a, const T b, 
      const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
      const T x0, const T y0) 
{
    T ans, tmp;
    // 1st
    tmp = x0;
    const T x1 = square(x0) - a - b * y0;
    const T y1 = tmp;
    // 2nd
    tmp = x1;
    const T x2 = square(x1) - a - b * y1;
    const T y2 = tmp;
    // 3rd
    tmp = x2;
    const T x3 = square(x2) - a - b * y2;
    const T y3 = tmp;
    T u, v;
    euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    Matrix<T>  D2   = Df(b, x2);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x3, y3);

    return product(De2p, product(D2, product(D1, product(D0, Dp2e))));
}

/*
template <class T> 
T ddf3(const T a, const T b, 
       const T fx, const T fy, const T gx, const T gy, const T FX, const T FY,
       const T u, const T v) 
{
    T ans, x0, y0, x1, y1, x2, y2, x3, y3, tmp;
    proj2euc(fx, fy, gx, gy, x0, y0, u, v);
    // 1st
    tmp = x0;
    x1 = square(x0) - a - b * y0;
    y1 = tmp;
    // 2nd
    tmp = x1;
    x2 = square(x1) - a - b * y1;
    y2 = tmp;
    // 3rd
    tmp = x2;
    x3 = square(x2) - a - b * y2;
    y3 = tmp;
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    Matrix<T>  D2   = Df(b, x2);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x3, y3);

    CVector<T> D0Dp2e     = product(D0, Dp2e);
    CVector<T> D1D0Dp2e   = product(D1, D0Dp2e);
    CVector<T> D2D1D0Dp2e = product(D2, D1D0Dp2e);
    
    T dx0_du = Dp2e.get1st();
    T dx1_du = D0Dp2e.get1st();
    T dx2_du = D1D0Dp2e.get1st();
    T dx3_du = D2D1D0Dp2e.get1st();
    T dy3_du = D2D1D0Dp2e.get2nd();

    CVector<T> DDp2e = ddu_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  DD0   = Matrix<T>(T(2) * dx0_du, T(0), T(0), T(0));
    Matrix<T>  DD1   = Matrix<T>(T(2) * dx1_du, T(0), T(0), T(0));
    Matrix<T>  DD2   = Matrix<T>(T(2) * dx2_du, T(0), T(0), T(0));
    RVector<T> DDe2p = product(RVector<T>(dx3_du, dy3_du), ddxy_euc2proj_u(FX, FY, x3, y3));

    return product(DDe2p, product(D2, product(D1, product(D0, Dp2e)))) 
         + product(De2p, product(DD2, product(D1, product(D0, Dp2e)))) 
         + product(De2p, product(D2, product(DD1, product(D0, Dp2e)))) 
         + product(De2p, product(D2, product(D1, product(DD0, Dp2e)))) 
         + product(De2p, product(D2, product(D1, product(D0, DDp2e)))); 
}
*/

template <class T> 
T f4(const T a, const T b, 
     const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
     const T u, const T v) 
{
    T ans, x, y, tmp;
    proj2euc(fx, fy, gx, gy, x, y, u, v);
    // 1st
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 2nd
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 3rd
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    // 4th
    tmp = x;
    x = square(x) - a - b * y;
    y = tmp;
    euc2proj(fx, fy, gx, gy, x, y, ans, tmp);
    return ans;
}

CpxInterval df4(const CpxInterval a, const CpxInterval b, 
    const CpxInterval fx, const CpxInterval fy, 
    const CpxInterval gx, const CpxInterval gy, 
    const CpxInterval FX, const CpxInterval FY, 
    const CpxInterval x0, const CpxInterval y0) 
{
    CpxInterval ans, tmp;
    // 1st
    const CpxInterval x1 = square(x0) - a - b * y0;
    const CpxInterval y1 = x0;
    // 2nd
    const CpxInterval x2 = square(x1) - a - b * y1;
    const CpxInterval y2 = x1;
    // 3rd
    const CpxInterval x3 = square(x2) - a - b * y2;
    const CpxInterval y3 = x2;
    // 4th
    const CpxInterval x4 = square(x3) - a - b * y3;
    const CpxInterval y4 = x3;
    CpxInterval u, v;
    try {
        euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    }
    catch (...) {
        return entire_C;
    }
    CVector<CpxInterval> Dp2e (CpxInterval(0), CpxInterval(0));
    try {
        Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    }
    catch (...) {
        return entire_C;
    }
    Matrix<CpxInterval>  D0   = Df(b, x0);
    Matrix<CpxInterval>  D1   = Df(b, x1);
    Matrix<CpxInterval>  D2   = Df(b, x2);
    Matrix<CpxInterval>  D3   = Df(b, x3);
    RVector<CpxInterval> De2p (CpxInterval(0), CpxInterval(0));
    try {
        De2p = dxy_euc2proj_u(FX, FY, x4, y4);
    }
    catch (...) {
        return entire_C;
    }

    return product(De2p, product(D3, product(D2, product(D1, product(D0, Dp2e)))));
}

CpxInterval df4_wo_denom(const CpxInterval a, const CpxInterval b, 
    const CpxInterval fx, const CpxInterval fy, 
    const CpxInterval gx, const CpxInterval gy, 
    const CpxInterval FX, const CpxInterval FY, 
    const CpxInterval x0, const CpxInterval y0) 
{


    CpxInterval ans, tmp;
    // 1st
    CpxInterval x1 = square(x0) - a - b * y0;
    CpxInterval y1 = x0;
    // 2nd
    CpxInterval x2 = square(x1) - a - b * y1;
    CpxInterval y2 = x1;
    // 3rd
    CpxInterval x3 = square(x2) - a - b * y2;
    CpxInterval y3 = x2;
    // 4th
    CpxInterval x4 = square(x3) - a - b * y3;
    CpxInterval y4 = x3;


    // try mid rad
    CpxInterval x_ = x0.center();
    CpxInterval y_ = y0.center();
    CpxInterval a_ = a.center();
    CpxInterval b_ = b.center();

    const double rad_ar = rad(a.getRe());
    const double rad_ai = rad(a.getIm());
    const double rad_br = rad(b.getRe());
    const double rad_bi = rad(b.getIm());
    const double rad_xr = rad(x0.getRe());
    const double rad_xi = rad(x0.getIm());
    const double rad_yr = rad(y0.getRe());
    const double rad_yi = rad(y0.getIm());
    
    /*
    CpxInterval D_m11; // = 2.0 * x;
    CpxInterval D_m12; // = -a;
    CpxInterval D_m13;// = -y;
    CpxInterval D_m14(1);
    CpxInterval D_m21(1);
    CpxInterval D_m22(0);
    */
    Interval du_dxr, du_dxi, du_dyr, du_dyi, du_dar, du_dai, du_dbr, du_dbi;
    Interval dv_dxr, dv_dxi, dv_dyr, dv_dyi, dv_dar, dv_dai, dv_dbr, dv_dbi;

    CpxInterval D11(1);
    CpxInterval D12(0);
    CpxInterval D13(0);
    CpxInterval D14(0);
    CpxInterval D21(0);
    CpxInterval D22(1);
    CpxInterval D23(0);
    CpxInterval D24(0);
    CpxInterval T11(0);
    CpxInterval T12(0);
    CpxInterval T13(0);
    CpxInterval T14(0);

    const CpxInterval Im(Interval(0), Interval(1));

    CpxInterval x(x0);
    CpxInterval y(y0);
    CpxInterval U, V;

    for (int iteration = 0; iteration < 4; iteration++) {
        T11 = D11;
        T12 = D12;
        T13 = D13;
        T14 = D14;
        D11 = 2*x*D11 - b*D21;
        D12 = 2*x*D12 - b*D22;
        D13 = 2*x*D13 - b*D23 - 1;
        D14 = 2*x*D14 - b*D24 - y;
        D21 = T11;
        D22 = T12;
        D23 = T13;
        D24 = T14;
        du_dxr = D11.getRe();
        dv_dxr = D11.getIm();
        du_dyr = D12.getRe();
        dv_dyr = D12.getIm();
        du_dar = D13.getRe();
        dv_dar = D13.getIm();
        du_dbr = D14.getRe();
        dv_dbr = D14.getIm();
        U = (abs(du_dar)*rad_ar + abs(-dv_dar)*rad_ai + abs(du_dbr)*rad_br + abs(-dv_dbr)*rad_bi + abs(du_dxr)*rad_xr + abs(-dv_dxr)*rad_xi + abs(du_dyr)*rad_yr + abs(-dv_dyr)*rad_yi) * interval(-1.0, 1.0);
        V = (abs(dv_dar)*rad_ar + abs( du_dar)*rad_ai + abs(dv_dbr)*rad_br + abs( du_dbr)*rad_bi + abs(dv_dxr)*rad_xr + abs( du_dxr)*rad_xi + abs(dv_dyr)*rad_yr + abs( du_dyr)*rad_yi) * interval(-1.0, 1.0);

        // center value
        tmp = x_;
        x_ = x_ * x_ - a_ - b_ * y_;
        y_ = tmp;

        // mean value form
        tmp = x;
        x = intersect(x_ + U + V * Im, x * x - a - b*y);
        y = tmp;

        if (iteration == 0) {
            x1 = intersect(x1, x);
            y1 = intersect(y1, y);
        } else if (iteration == 1) {
            x2 = intersect(x2, x);
            y2 = intersect(y2, y);
        } else if (iteration == 2) {
            x3 = intersect(x3, x);
            y3 = intersect(y3, y);
        } else if (iteration == 3) {
            x4 = intersect(x4, x);
            y4 = intersect(y4, y);
        }
    }

    CpxInterval u, v;
    try {
        euc2proj(fx, fy, gx, gy, x0, y0, u, v);
    }
    catch (...) {
        return entire_C;
    }
    CVector<CpxInterval> Dp2e = du_proj2euc_xy_wo_denom(fx, fy, gx, gy, u, v);
    Matrix<CpxInterval>  D0   = Df(b, x0);
    Matrix<CpxInterval>  D1   = Df(b, x1);
    Matrix<CpxInterval>  D2   = Df(b, x2);
    Matrix<CpxInterval>  D3   = Df(b, x3);
    RVector<CpxInterval> De2p = dxy_euc2proj_u_wo_denom(FX, FY, x4, y4);
    
    return product(De2p, product(D3, product(D2, product(D1, product(D0, Dp2e)))));
}

/*
template <class T> 
T ddf4(const T a, const T b, 
       const T fx, const T fy, const T gx, const T gy, const T FX, const T FY, 
       const T u, const T v) 
{
    T ans, x0, y0, x1, y1, x2, y2, x3, y3, x4, y4, tmp;
    proj2euc(fx, fy, gx, gy, x0, y0, u, v);
    // 1st
    tmp = x0;
    x1 = square(x0) - a - b * y0;
    y1 = tmp;
    // 2nd
    tmp = x1;
    x2 = square(x1) - a - b * y1;
    y2 = tmp;
    // 3rd
    tmp = x2;
    x3 = square(x2) - a - b * y2;
    y3 = tmp;
    // 4th
    tmp = x3;
    x4 = square(x3) - a - b * y3;
    y4 = tmp;
    CVector<T> Dp2e = du_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  D0   = Df(b, x0);
    Matrix<T>  D1   = Df(b, x1);
    Matrix<T>  D2   = Df(b, x2);
    Matrix<T>  D3   = Df(b, x3);
    RVector<T> De2p = dxy_euc2proj_u(FX, FY, x4, y4);

    CVector<T> D0Dp2e       = product(D0, Dp2e);
    CVector<T> D1D0Dp2e     = product(D1, D0Dp2e);
    CVector<T> D2D1D0Dp2e   = product(D2, D1D0Dp2e);
    CVector<T> D3D2D1D0Dp2e = product(D3, D2D1D0Dp2e);
    
    T dx0_du = Dp2e.get1st();
    T dx1_du = D0Dp2e.get1st();
    T dx2_du = D1D0Dp2e.get1st();
    T dx3_du = D2D1D0Dp2e.get1st();
    T dx4_du = D3D2D1D0Dp2e.get1st();
    T dy4_du = D3D2D1D0Dp2e.get2nd();

    CVector<T> DDp2e = ddu_proj2euc_xy(fx, fy, gx, gy, u, v);
    Matrix<T>  DD0   = Matrix<T>(T(2) * dx0_du, T(0), T(0), T(0));
    Matrix<T>  DD1   = Matrix<T>(T(2) * dx1_du, T(0), T(0), T(0));
    Matrix<T>  DD2   = Matrix<T>(T(2) * dx2_du, T(0), T(0), T(0));
    Matrix<T>  DD3   = Matrix<T>(T(2) * dx3_du, T(0), T(0), T(0));
    RVector<T> DDe2p = product(RVector<T>(dx4_du, dy4_du), ddxy_euc2proj_u(FX, FY, x4, y4));

    return product(DDe2p, product(D3, product(D2, product(D1, product(D0, Dp2e)))))
         + product(De2p, product(DD3, product(D2, product(D1, product(D0, Dp2e)))))
         + product(De2p, product(D3, product(DD2, product(D1, product(D0, Dp2e)))))
         + product(De2p, product(D3, product(D2, product(DD1, product(D0, Dp2e)))))
         + product(De2p, product(D3, product(D2, product(D1, product(DD0, Dp2e)))))
         + product(De2p, product(D3, product(D2, product(D1, product(D0, DDp2e)))));
}
*/
