#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>

static const int nBoxes = 4; // The number of boxes
static const int nData  = 4; // The number of input data files
#include "locuslib.hpp"

using namespace std;

void input_data(const string inputFileName, 
                double& a, double& b, 
                double* tx, double* ty, 
                double* ax, double* ay, 
                double* bx, double* by, 
                double* Px, double* Py, 
                double* Qx, double* Qy,
                double& cut_Px2, 
                double& tx7_adjust, double& tx9_adjust, double& ty7_adjust, double& ty9_adjust, 
                double& ty2_adjust, double& ty3_adjust, double& tx13_adjust, double& tx5_adjust, double& tx15_adjust, double& ty10_adjust)
{
    ifstream inputFile(inputFileName.c_str());
    string tmp;


    inputFile >> tmp >> tmp >> a;
    inputFile >> tmp >> tmp >> b;
    for (int i = 0; i < 16; i++) {
        inputFile >> tmp >> tmp >> tx[i];
        inputFile >> tmp >> tmp >> ty[i];
    }
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> ax[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> ay[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> bx[i];}
    for (int i = 0; i <  4; i++) {inputFile >> tmp >> tmp >> by[i];}
    for (int i = 0; i <  4; i++) {
        inputFile >> tmp >> tmp >> Px[i];
        inputFile >> tmp >> tmp >> Qx[i];
        inputFile >> tmp >> tmp >> Py[i];
        inputFile >> tmp >> tmp >> Qy[i];
    }
    inputFile >> tmp >> tmp >> cut_Px2; 
    inputFile >> tmp >> tmp >> tx7_adjust;
    inputFile >> tmp >> tmp >> tx9_adjust;
    inputFile >> tmp >> tmp >> ty7_adjust;
    inputFile >> tmp >> tmp >> ty9_adjust;
    inputFile >> tmp >> tmp >> ty2_adjust; 
    inputFile >> tmp >> tmp >> ty3_adjust; 
    inputFile >> tmp >> tmp >> tx13_adjust; 
    inputFile >> tmp >> tmp >> tx5_adjust; 
    inputFile >> tmp >> tmp >> tx15_adjust; 
    inputFile >> tmp >> tmp >> ty10_adjust; 
    
    inputFile.close();
}

int main(int argc, char * argv [])
{
    double tx_0[16], ty_0[16];
    double ax_0[4], ay_0[4];
    double bx_0[4], by_0[4];
    double Px_0[4], Py_0[4];
    double Qx_0[4], Qy_0[4];
    double tx_1[16], ty_1[16];
    double ax_1[4], ay_1[4];
    double bx_1[4], by_1[4];
    double Px_1[4], Py_1[4];
    double Qx_1[4], Qy_1[4];
    double a_0, b_0;
    double a_1, b_1;
    double cut_Px2_0;
    double cut_Px2_1;
    double tx7_adjust_0, tx9_adjust_0, ty7_adjust_0, ty9_adjust_0;
    double tx7_adjust_1, tx9_adjust_1, ty7_adjust_1, ty9_adjust_1;
    double ty2_adjust_0, ty3_adjust_0, tx13_adjust_0, tx5_adjust_0, tx15_adjust_0, ty10_adjust_0;
    double ty2_adjust_1, ty3_adjust_1, tx13_adjust_1, tx5_adjust_1, tx15_adjust_1, ty10_adjust_1;

    string outputFileName, inputFileName_0, inputFileName_1;

    // usage: interpolation t outputfile infile_0 infile_1
    const double t = atof(argv[1]);
    outputFileName = argv[2];
    inputFileName_0 = argv[3];
    inputFileName_1 = argv[4];

    // input the sixteen points in the trellis in R^2
    input_data(inputFileName_0, 
               a_0, b_0,
               tx_0, ty_0, ax_0, ay_0, bx_0, by_0, Px_0, Py_0, Qx_0, Qy_0, cut_Px2_0, 
               tx7_adjust_0, tx9_adjust_0, ty7_adjust_0, ty9_adjust_0, 
               ty2_adjust_0, ty3_adjust_0, tx13_adjust_0, tx5_adjust_0, tx15_adjust_0, ty10_adjust_0);

    // input the sixteen points in the trellis in R^2
    input_data(inputFileName_1, 
               a_1, b_1,
               tx_1, ty_1, ax_1, ay_1, bx_1, by_1, Px_1, Py_1, Qx_1, Qy_1, cut_Px2_1,
               tx7_adjust_1, tx9_adjust_1, ty7_adjust_1, ty9_adjust_1,
               ty2_adjust_1, ty3_adjust_1, tx13_adjust_1, tx5_adjust_1, tx15_adjust_1, ty10_adjust_1);


    ofstream outputFile(outputFileName.c_str());

    // output the interpolated data
    outputFile << "a = " << linear_interpolation(t, a_0, a_1) << endl;
    outputFile << "b = " << linear_interpolation(t, b_0, b_1) << endl;

    for (int i = 0; i < 16; i++) { 
        outputFile << "tx[" << i << "] = " << linear_interpolation(t, tx_0[i], tx_1[i]) << endl 
                   << "ty[" << i << "] = " << linear_interpolation(t, ty_0[i], ty_1[i]) << endl;
    }
    for (int i = 0; i < 4; i++) {
        outputFile << "ax[" << i << "] = " << linear_interpolation(t, ax_0[i], ax_1[i]) << endl;
    }
    for (int i = 0; i < 4; i++) {
        outputFile << "ay[" << i << "] = " << linear_interpolation(t, ay_0[i], ay_1[i]) << endl;
    }
    for (int i = 0; i < 4; i++) {
        outputFile << "bx[" << i << "] = " << linear_interpolation(t, bx_0[i], bx_1[i]) << endl;
    }
    for (int i = 0; i < 4; i++) {
        outputFile << "by[" << i << "] = " << linear_interpolation(t, by_0[i], by_1[i]) << endl;
    }
    for (int i = 0; i < 4; i++) { 
        outputFile << "Px[" << i << "]-" << "px[" << i << "] = " << linear_interpolation(t, Px_0[i], Px_1[i]) << endl
                   << "Qx[" << i << "]-" << "qx[" << i << "] = " << linear_interpolation(t, Qx_0[i], Qx_1[i]) << endl
                   << "Py[" << i << "]-" << "py[" << i << "] = " << linear_interpolation(t, Py_0[i], Py_1[i]) << endl
                   << "Qy[" << i << "]-" << "qy[" << i << "] = " << linear_interpolation(t, Qy_0[i], Qy_1[i]) << endl;
    }
    outputFile << "cut_Px2 = " << linear_interpolation(t, cut_Px2_0, cut_Px2_1) << endl;
    outputFile << "tx[7]_adjust = " << linear_interpolation(t, tx7_adjust_0, tx7_adjust_1) << endl;
    outputFile << "tx[9]_adjust = " << linear_interpolation(t, tx9_adjust_0, tx9_adjust_1) << endl;
    outputFile << "ty[7]_adjust = " << linear_interpolation(t, ty7_adjust_0, ty7_adjust_1) << endl;
    outputFile << "ty[9]_adjust = " << linear_interpolation(t, ty9_adjust_0, ty9_adjust_1) << endl;
    outputFile << "ty[2]_adjust = " << linear_interpolation(t, ty2_adjust_0, ty2_adjust_1) << endl;
    outputFile << "ty[3]_adjust = " << linear_interpolation(t, ty3_adjust_0, ty3_adjust_1) << endl;
    outputFile << "tx[13]_adjust = " << linear_interpolation(t, tx13_adjust_0, tx13_adjust_1) << endl;
    outputFile << "tx[5]_adjust = " << linear_interpolation(t, tx5_adjust_0, tx5_adjust_1) << endl;
    outputFile << "tx[15]_adjust = " << linear_interpolation(t, tx15_adjust_0, tx15_adjust_1) << endl;
    outputFile << "ty[10]_adjust = " << linear_interpolation(t, ty10_adjust_0, ty10_adjust_1) << endl;
    
    outputFile.close();
}
