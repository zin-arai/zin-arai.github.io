#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>

static const int nBoxes = 7; // The number of boxes: 0-3 for original AI paper, 4-6 for Hironaka's paper
static const int nBoxesOriginal = 4; // The number of boxes for original AI paper
static const int nData  = 4; // The number of input data files

#include "locuslib.hpp"

double estimate_intersection(const int n_points, const double fx, const double fy, const vector< complex<double> > zs, const vector< complex<double> > ws) {
    double ans = -65535.0;
    Interval Re, Im;
    CpxInterval Z, W;
    int j, k, j_end, k_end;
    int dl, dr, ul, ur;
    for (j = 0; j < n_points; j++) {
        if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
        for (k = 0; k < n_points; k++) {
            if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
            dl = j * n_points + k;
            dr = j_end * n_points + k;
            ul = j * n_points + k_end;
            ur = j_end * n_points + k_end;
            
            //cout << "ws[dl] = " << ws[dl] << endl;
            //cout << "ws[dr] = " << ws[dr] << endl;

            Re = Interval(min4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()), max4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()));
            Im = Interval(min4(zs[dl].imag(), zs[dr].imag(), zs[ul].imag(), zs[ur].imag()), max4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()));
            Z = CpxInterval(Re, Im);
            Re = Interval(min4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()), max4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()));
            Im = Interval(min4(ws[dl].imag(), ws[dr].imag(), ws[ul].imag(), ws[ur].imag()), max4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()));
            W = CpxInterval(Re, Im);

            // Compute projective coordinates (zz)
            if (zero_in(fy - W)) {
                ans = 65535.0;
            } else {
                ans = max(ans, ((Z - W * (fx - Z) / (fy - W)).getRe()).upper());
            }
        }
    }
    return ans;
}

int main(int argc, char * argv [])
{
    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double Px0[nData], Qx0[nData], Px2[nData], Qx2[nData];
    double PX[nData], PY[nData], QX[nData], QY[nData];
    double re_a[nData], re_b[nData];
    double im_a_inf, im_a_sup;
    double cut_Px2[nData];

    string inputFileName[nData];
    int n_points;

    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    const int P03 = 4;
    const int P12 = 5;
    const int P23 = 6;

    inputFileName[0] = argv[optind + 0];
    inputFileName[1] = argv[optind + 1];
    inputFileName[2] = argv[optind + 2];
    inputFileName[3] = argv[optind + 3];
    //im_a_inf = atof(argv[optind + 4]);
    //im_a_sup = atof(argv[optind + 5]);
    n_points = atoi(argv[optind + 4]);

    // transitions to check CMC
    const int n_transition = 3;
    pair<int, int> transitions[n_transition];
    transitions[0] = make_pair(P03, P12);
    transitions[1] = make_pair(P12, P03);
    transitions[2] = make_pair(P23, P12);
    
    // input the data
    for (int n = 0; n < nData; n++) {
        input_data_positive(inputFileName[n],
                            re_a[n], re_b[n],
                            tx[n], ty[n], ax[n], ay[n], bx[n], by[n], Px[n], Py[n], Qx[n], Qy[n], cut_Px2[n]);
    }

    // Parameter Setting
    Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    Interval Im_a (0, 0);
    Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    Interval Im_b (0, 0);
    CpxInterval a (Re_a, Im_a);
    CpxInterval b (Re_b, Im_b);
    if (verbose) {cout << "a = " << a << ", b = " << b << ", n_points = " << n_points << endl;}

    for (int n = 0; n < nData; n++) {
        // compute the focuses in R^2 and the intervals in C
        compute_focuses(tx[n], ty[n], fx[n], fy[n], gx[n], gy[n], px[n], py[n], qx[n], qy[n]);

        // Adjust Px Py Qx Qy
        adjust_pq(px[n], py[n], qx[n], qy[n], Px[n], Py[n], Qx[n], Qy[n]);
    }
    
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxesOriginal; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }

    ifx[P03] = ifx[0]; ify[P03] = ify[0]; igx[P03] = igx[0]; igy[P03] = igy[0];
    iax[P03] = iax[0]; iay[P03] = iay[0]; ibx[P03] = ibx[0]; iby[P03] = iby[0];
    ipx[P03] = ipx[0]; ipy[P03] = ipy[0]; iqx[P03] = iqx[0]; iqy[P03] = iqy[0];

    ifx[P12] = ifx[1]; ify[P12] = ify[1]; igx[P12] = igx[1]; igy[P12] = igy[1];
    iax[P12] = iax[1]; iay[P12] = iay[1]; ibx[P12] = ibx[1]; iby[P12] = iby[1];
    ipx[P12] = ipx[1]; ipy[P12] = ipy[1]; iqx[P12] = iqx[1]; iqy[P12] = iqy[1];

    ifx[P23] = ifx[2]; ify[P23] = ify[2]; igx[P23] = igx[2]; igy[P23] = igy[2];
    iax[P23] = iax[2]; iay[P23] = iay[2]; ibx[P23] = ibx[2]; iby[P23] = iby[2];
    ipx[P23] = ipx[2]; ipy[P23] = ipy[2]; iqx[P23] = iqx[2]; iqy[P23] = iqy[2];

    const double margin_03_Qx = -0.00001;
    const double margin_03_Px =  0.00001;
    const double margin_12_Qx = -0.00001;
    const double margin_12_Px =  0.00001;
    const double margin_23_Qx = -0.1;
    const double margin_23_Px =  0.00001;

    // P03
    for (int n = 0; n < nData; n++) {
        // Define the base ellipse
        PX[n] = px[n][0] * ax[n][0];
        QX[n] = qx[n][3] * ax[n][0];
        PY[n] = py[n][3] * ay[n][0];
        QY[n] = qy[n][3] * ay[n][0];

        vector< complex<double> > zb(n_points);
        vector< complex<double> > wb(n_points);
        vector< complex<double> > z_(n_points * n_points);
        vector< complex<double> > w_(n_points * n_points);

        define_ellipse_boundaries(ax[n][3], bx[n][3], Px[n][3], PX[n], Qx[n][3], QX[n], zb);
        define_ellipse_boundaries(ay[n][3], by[n][3], Py[n][3], PY[n], Qy[n][3], QY[n], wb);
        define_domain_points(3, fx[n], fy[n], gx[n], gy[n], zb, wb, z_, w_);

        ax[n][P03] = ax[n][0];
        bx[n][P03] = bx[n][0];
        Px[n][P03] = estimate_intersection(n_points, fx[n][0], fy[n][0], z_, w_) + margin_03_Px;
        Qx[n][P03] = Qx[n][0] + margin_03_Qx;
        ay[n][P03] = ay[n][0];
        by[n][P03] = by[n][0];
        Py[n][P03] = Py[n][0];
        Qy[n][P03] = Qy[n][0];
        fx[n][P03] = fx[n][0];
        fy[n][P03] = fy[n][0];
        gx[n][P03] = gx[n][0];
        gy[n][P03] = gy[n][0];
    }
    
    // P12
    for (int n = 0; n < nData; n++) {
        // Define the base ellipse
        PX[n] = px[n][0] * ax[n][0];
        QX[n] = qx[n][3] * ax[n][0];
        PY[n] = py[n][3] * ay[n][0];
        QY[n] = qy[n][3] * ay[n][0];
        
        vector< complex<double> > zb(n_points);
        vector< complex<double> > wb(n_points);
        vector< complex<double> > z_(n_points * n_points);
        vector< complex<double> > w_(n_points * n_points);

        define_ellipse_boundaries(ax[n][2], bx[n][2], Px[n][2], PX[n], Qx[n][2], QX[n], zb);
        define_ellipse_boundaries(ay[n][2], by[n][2], Py[n][2], PY[n], Qy[n][2], QY[n], wb);
        define_domain_points(2, fx[n], fy[n], gx[n], gy[n], zb, wb, z_, w_);

        ax[n][P12] = ax[n][1];
        bx[n][P12] = bx[n][1];
        Px[n][P12] = estimate_intersection(n_points, fx[n][1], fy[n][1], z_, w_) + margin_12_Px;
        Qx[n][P12] = Qx[n][1] + margin_12_Qx;
        ay[n][P12] = ay[n][1];
        by[n][P12] = by[n][1];
        Py[n][P12] = Py[n][1];
        Qy[n][P12] = Qy[n][1];
        fx[n][P12] = fx[n][1];
        fy[n][P12] = fy[n][1];
        gx[n][P12] = gx[n][1];
        gy[n][P12] = gy[n][1];
    }

    // P23
    for (int n = 0; n < nData; n++) {
        // Define the base ellipse
        PX[n] = px[n][0] * ax[n][0];
        QX[n] = qx[n][3] * ax[n][0];
        PY[n] = py[n][3] * ay[n][0];
        QY[n] = qy[n][3] * ay[n][0];
        
        vector< complex<double> > zb(n_points);
        vector< complex<double> > wb(n_points);
        vector< complex<double> > z_(n_points * n_points);
        vector< complex<double> > w_(n_points * n_points);

        define_ellipse_boundaries(ax[n][3], bx[n][3], Px[n][3], PX[n], Qx[n][3], QX[n], zb);
        define_ellipse_boundaries(ay[n][3], by[n][3], Py[n][3], PY[n], Qy[n][3], QY[n], wb);
        define_domain_points(3, fx[n], fy[n], gx[n], gy[n], zb, wb, z_, w_);

        ax[n][P23] = ax[n][2];
        bx[n][P23] = bx[n][2];
        Px[n][P23] = estimate_intersection(n_points, fx[n][2], fy[n][2], z_, w_) + margin_23_Px;
        Qx[n][P23] = Qx[n][2] + margin_23_Qx;
        ay[n][P23] = ay[n][2];
        by[n][P23] = by[n][2];
        Py[n][P23] = Py[n][2];
        Qy[n][P23] = Qy[n][2];
        fx[n][P23] = fx[n][2];
        fy[n][P23] = fy[n][2];
        gx[n][P23] = gx[n][2];
        gy[n][P23] = gy[n][2];
    }
    
    if (verbose) {
        cout << "Qx[ 0 ] = " << Qx[0][ 0 ] << endl;
        cout << "Qx[P03] = " << Qx[0][P03] << endl;
        cout << "Px[P03] = " << Px[0][P03] << endl;
        cout << "Px[ 0 ] = " << Px[0][ 0 ] << endl;
        
        cout << "Qx[ 1 ] = " << Qx[0][ 1 ] << endl;
        cout << "Qx[P12] = " << Qx[0][P12] << endl;
        cout << "Px[P12] = " << Px[0][P12] << endl;
        cout << "Px[ 1 ] = " << Px[0][ 1 ] << endl;
        
        cout << "Qx[ 2 ] = " << Qx[0][ 2 ] << endl;
        cout << "Qx[P23] = " << Qx[0][P23] << endl;
        cout << "Px[P23] = " << Px[0][P23] << endl;
        cout << "Px[ 2 ] = " << Px[0][ 2 ] << endl;
    }
    
    for (int n = 0; n < nData; n++) {
        if (Px[n][P03] > Px[n][0]) {
            cout << "P03 boundary error" << endl;
            return 1;
        }
        if (Px[n][P12] > Px[n][1]) {
            cout << "P12 boundary error" << endl;
            return 1;
        }
        if (Px[n][P23] > Px[n][2]) {
            cout << "P23 boundary error" << endl;
            return 1;
        }
    }

    vector< complex<double> > z[nData];
    vector< complex<double> > w[nData];
    vector< complex<double> > Z_point[nData];
    vector< complex<double> > W_point[nData];
    
    for (int n = 0; n < nData; n++) {
        z[n].resize(n_points, 0);
        w[n].resize(n_points, 0);
        Z_point[n].resize(n_points * n_points, 0);
        W_point[n].resize(n_points * n_points, 0);
    }
    
    // Check BCC
    int error_count = 0;
    for (int trans = 0; trans < n_transition; trans++) {
        int domain = transitions[trans].first;
        int image = transitions[trans].second;
        if (verbose) {cout << "Transition from [" << domain << "] to [" << image << "] ... ";}

        Interval Re, Im;
        CpxInterval Z, W, ZZ, WW;
        int j, k, j_end, k_end;
        int dl, dr, ul, ur;
        Interval s, t, S, T;
        CpxInterval zz, ww;
        Interval rz, rw;

        for (int n = 0; n < nData; n++) {
            PX[n] = px[n][0] * ax[n][domain];
            QX[n] = qx[n][3] * ax[n][domain];
            PY[n] = py[n][3] * ay[n][domain];
            QY[n] = qy[n][3] * ay[n][domain];
            define_ellipse_boundaries(ax[n][domain], bx[n][domain], Px[n][domain], PX[n], Qx[n][domain], QX[n], z[n]);
            define_ellipse_boundaries(ay[n][domain], by[n][domain], Py[n][domain], PY[n], Qy[n][domain], QY[n], w[n]);
            define_domain_points(domain, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
        }

        for (j = 0; j < n_points; j++) {
            if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
            for (k = 0; k < n_points; k++) {
                if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }

                dl = j * n_points + k;
                dr = j_end * n_points + k;
                ul = j * n_points + k_end;
                ur = j_end * n_points + k_end;
                
                // Compute Z
                Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                   min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                   min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                   min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                              max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                   max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                   max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                   max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                   min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                   min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                   min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                              max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                   max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                   max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                   max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                Z = CpxInterval(Re, Im);

                // Compute W
                Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                   min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                   min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                   min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                              max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                   max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                   max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                   max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                   min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                   min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                   min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                              max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                   max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                   max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                   max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                W = CpxInterval(Re, Im);

                // apply the Hénon map
                ZZ = square(Z) - a - b * W;
                WW = Z;
                
                // BCC forward
                // Compute projective coordinates (zz)
                if (zero_in(ify[image] - WW)) {
                    if (verbose) {cout << "Zero div error! (forward)" << endl;}
                    error_count++;
                } else {
                    zz = ZZ - WW * (ifx[image] - ZZ) / (ify[image] - WW);
                    
                    // Compute r
                    s = zz.getRe() - (iax[image] * (ipx[0] + iqx[3]) / Interval(2.0));
                    t = zz.getIm();
                    S = iax[image] * (ipx[0] - iqx[3]) / Interval(2.0);
                    T = ibx[image] * (ipx[0] - iqx[3]) / Interval(2.0);
                    rz = square(s) / square(S) + square(t) / square(T);
                    
                    if ((max4(Px[0][image], Px[1][image], Px[2][image], Px[3][image]) >= zz.getRe().lower()) &&
                    (min4(Qx[0][image], Qx[1][image], Qx[2][image], Qx[3][image]) <= zz.getRe().upper()) && 
                    (rz.lower() <= 1)) { 
                        // if (verbose) {cout << "Transition from [" << domain << "] to [" << image << "] ... ";}
                        // if (verbose) {cout << "CMC error! (forward)";}
                        // if (verbose) {cout << ": x = " << j << "/" << n_points << ", ";}
                        // if (verbose) {cout << ": y = " << k << "/" << n_points << endl;}
                        error_count++;
                        //return 1;
                    } 
                }

                // BCC backward
                // Compute projective coordinates (zz)
                if (zero_in(igx[image] - ZZ)) {
                    if (verbose) {cout << "Zero div error! (backward)" << endl;}
                    cout << "ZZ = " << ZZ << endl;
                    cout << "igx = " << igx[image] << ", image = " << image << endl;
                    error_count++;
                } else {
                    ww = WW - ZZ * (igy[image] - WW) / (igx[image] - ZZ);
                    
                    // Compute r
                    s = ww.getRe() - (iay[image] * (ipy[3] + iqy[3]) / Interval(2.0));
                    t = ww.getIm();
                    S = iay[image] * (ipy[3] - iqy[3]) / Interval(2.0);
                    T = iby[image] * (ipy[3] - iqy[3]) / Interval(2.0);
                    rw = square(s) / square(S) + square(t) / square(T);
                    
                    if ((max4(Py[0][image], Py[1][image], Py[2][image], Py[3][image]) <= ww.getRe().upper()) && 
                    (min4(Qy[0][image], Qy[1][image], Qy[2][image], Qy[3][image]) >= ww.getRe().lower()) && 
                    (rw.upper() >= 1)) {
                        // if (verbose) {cout << "Transition from [" << domain << "] to [" << image << "] ... ";}
                        // if (verbose) {cout << "CMC error! (backward)";}
                        // if (verbose) {cout << ": x = " << j << "/" << n_points << ", ";}
                        // if (verbose) {cout << ": y = " << k << "/" << n_points << endl;}
                        error_count++;
                        //return 1;
                    }
                }
            }
        }

        if (error_count) {
            if (verbose) {cout << error_count << " errors." << endl;}
            return error_count;
        } else {
            if (verbose) {cout << endl;}
        }
    }

    return 0;
}
