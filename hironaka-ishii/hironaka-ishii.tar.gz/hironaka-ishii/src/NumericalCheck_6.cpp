#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <complex>
#include <fenv.h>
#include <string.h>

static const int nBoxes = 5;
static const int nData  = 4; // The number of input data files

#include "locuslib.hpp"

void define_disk(const double a, const double b, const double r, vector< complex<double> >& z)
{
    // n = number of points on the boundary
    int n = z.size(); 
    for(int i = 0; i < n; i++) {
        z[i] = complex<double>(r*cos(2*M_PI*i/n), r*sin(2*M_PI*i/n));
    }
}

void define_P(const double p2x, const double p2y, const double s2, const double c,
    const vector< complex<double> >& x_, const vector< complex<double> >& y_, vector< complex<double> >& x, vector< complex<double> >& y)
{
    const int nx = x_.size();
    const int ny = y_.size();

    for (int ix = 0; ix < nx; ix++) {
        for (int iy = 0; iy < ny; iy++) {
            x[ix * ny + iy] = x_[ix] + p2x + s2 * (y_[iy] - p2y);
            y[ix * ny + iy] = y_[iy] + c;
        }
    }
}

double estimate_intersection(const int n_points, const double fx, const double fy, const vector< complex<double> > zs, const vector< complex<double> > ws) {
    double ans = -65535.0;
    Interval Re, Im;
    CpxInterval Z, W;
    int j, k, j_end, k_end;
    int dl, dr, ul, ur;
    for (j = 0; j < n_points; j++) {
        if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
        for (k = 0; k < n_points; k++) {
            if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
            dl = j * n_points + k;
            dr = j_end * n_points + k;
            ul = j * n_points + k_end;
            ur = j_end * n_points + k_end;
            
            //cout << "ws[dl] = " << ws[dl] << endl;
            //cout << "ws[dr] = " << ws[dr] << endl;

            Re = Interval(min4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()), max4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()));
            Im = Interval(min4(zs[dl].imag(), zs[dr].imag(), zs[ul].imag(), zs[ur].imag()), max4(zs[dl].real(), zs[dr].real(), zs[ul].real(), zs[ur].real()));
            Z = CpxInterval(Re, Im);
            Re = Interval(min4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()), max4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()));
            Im = Interval(min4(ws[dl].imag(), ws[dr].imag(), ws[ul].imag(), ws[ur].imag()), max4(ws[dl].real(), ws[dr].real(), ws[ul].real(), ws[ur].real()));
            W = CpxInterval(Re, Im);

            // Compute projective coordinates (zz)
            if (zero_in(fy - W)) {
                ans = 65535.0;
            } else {
                ans = max(ans, ((Z - W * (fx - Z) / (fy - W)).getRe()).upper());
            }
        }
    }
    return ans;
}

int main(int argc, char * argv [])
{
    double tx[nData][nBoxes * 4];
    double ty[nData][nBoxes * 4];
    double fx[nData][nBoxes], fy[nData][nBoxes];
    double gx[nData][nBoxes], gy[nData][nBoxes];
    double px[nData][nBoxes], qx[nData][nBoxes];
    double py[nData][nBoxes], qy[nData][nBoxes];
    double ax[nData][nBoxes], ay[nData][nBoxes];
    double bx[nData][nBoxes], by[nData][nBoxes];
    double Px[nData][nBoxes], Py[nData][nBoxes];
    double Qx[nData][nBoxes], Qy[nData][nBoxes];
    double Px0[nData], Qx0[nData], Px2[nData], Qx2[nData];
    double PX[nData], PY[nData], QX[nData], QY[nData];
    double re_a[nData], re_b[nData];
    double im_a_inf, im_a_sup;
    double cut_Px2[nData];

    string inputFileName[nData];
    int n_points;

    bool verbose = false;
    int result;
    while ((result = getopt(argc, argv, "v")) != -1) {
        switch (result) {
        case 'v':
            verbose = true;
            break;
        case '?':
            cout << "Unknown Option" << endl;
            return 1;
        }
    }

    inputFileName[0] = argv[optind + 0];
    inputFileName[1] = argv[optind + 1];
    inputFileName[2] = argv[optind + 2];
    inputFileName[3] = argv[optind + 3];
    //im_a_inf = atof(argv[optind + 4]);
    //im_a_sup = atof(argv[optind + 5]);
    n_points = 256;

    // input the data
    for (int n = 0; n < nData; n++) {
        input_data_negative(inputFileName[n],
                            re_a[n], re_b[n],
                            tx[n], ty[n], ax[n], ay[n], bx[n], by[n], Px[n], Py[n], Qx[n], Qy[n]);
    }

    // Parameter Setting
    Interval Re_a = hull4(re_a[0], re_a[1], re_a[2], re_a[3]);
    Interval Im_a (0, 0);
    Interval Re_b = hull4(re_b[0], re_b[1], re_b[2], re_b[3]);
    Interval Im_b (0, 0);
    CpxInterval a (Re_a, Im_a);
    CpxInterval b (Re_b, Im_b);
    if (verbose) {cout << "a = " << a << ", b = " << b << ", n_points = " << n_points << endl;}

    for (int n = 0; n < nData; n++) {
        // compute the focuses in R^2 and the intervals in C
        compute_focuses(tx[n], ty[n], fx[n], fy[n], gx[n], gy[n], px[n], py[n], qx[n], qy[n]);

        // Adjust Px Py Qx Qy
        adjust_pq(px[n], py[n], qx[n], qy[n], Px[n], Py[n], Qx[n], Qy[n]);
    }
    
    Interval ifx[nBoxes], ify[nBoxes], igx[nBoxes], igy[nBoxes], iax[nBoxes], ibx[nBoxes];
    Interval iay[nBoxes], iby[nBoxes], ipx[nBoxes], iqx[nBoxes], ipy[nBoxes], iqy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        ifx[box] = hull4(fx[0][box], fx[1][box], fx[2][box], fx[3][box]);
        ify[box] = hull4(fy[0][box], fy[1][box], fy[2][box], fy[3][box]);
        igx[box] = hull4(gx[0][box], gx[1][box], gx[2][box], gx[3][box]);
        igy[box] = hull4(gy[0][box], gy[1][box], gy[2][box], gy[3][box]);
        iax[box] = hull4(ax[0][box], ax[1][box], ax[2][box], ax[3][box]);
        iay[box] = hull4(ay[0][box], ay[1][box], ay[2][box], ay[3][box]);
        ibx[box] = hull4(bx[0][box], bx[1][box], bx[2][box], bx[3][box]);
        iby[box] = hull4(by[0][box], by[1][box], by[2][box], by[3][box]);
        ipx[box] = hull4(px[0][box], px[1][box], px[2][box], px[3][box]);
        ipy[box] = hull4(py[0][box], py[1][box], py[2][box], py[3][box]);
        iqx[box] = hull4(qx[0][box], qx[1][box], qx[2][box], qx[3][box]);
        iqy[box] = hull4(qy[0][box], qy[1][box], qy[2][box], qy[3][box]);
    }
    
    vector< complex<double> > z[nData];
    vector< complex<double> > w[nData];
    vector< complex<double> > Z_point[nData];
    vector< complex<double> > W_point[nData];
    
    for (int n = 0; n < nData; n++) {
        z[n].resize(n_points, 0);
        w[n].resize(n_points, 0);
        Z_point[n].resize(n_points * n_points, 0);
        W_point[n].resize(n_points * n_points, 0);
    }

    // Compute r3
    double ymin =  65536.0;
    double ymax = -65536.0;

    Interval Re, Im;
    CpxInterval Z, W;

    for (int box = 0; box < nBoxes; box++) {
        if ((box == 2) || (box == 3) || (box == 4)) {
            for (int n = 0; n < nData; n++) {
                PX[n] = px[n][0] * ax[n][box];
                QX[n] = qx[n][4] * ax[n][box];
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ax[n][box], bx[n][box], Px[n][box], PX[n], Qx[n][box], QX[n], z[n]);
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
                define_domain_points(box, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
                
                int j, k, j_end, k_end;
                int dl, dr, ul, ur;

                for (j = 0; j < n_points; j++) {
                    if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
                    for (k = 0; k < n_points; k++) {
                        if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
        
                        dl = j * n_points + k;
                        dr = j_end * n_points + k;
                        ul = j * n_points + k_end;
                        ur = j_end * n_points + k_end;
                        
                        // Compute Z
                        Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                                      max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                        Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                                      max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                        Z = CpxInterval(Re, Im);
        
                        // Compute W
                        Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                                      max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                        Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                                      max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                        W = CpxInterval(Re, Im);

                        if (zero_in(Z.getIm()) && zero_in(W.getIm())) {
                            ymax = max(ymax, W.getRe().upper());
                            ymin = min(ymin, W.getRe().lower());
                        }
                    }
                }
            }
        }
    }

    Interval I3(ymin, ymax);
    double y3 = mid(I3);
    double r3 = rad(I3);
    
    if (verbose) {
        cout << "I3 = " << I3 << endl;
        cout << "y3 = " << y3 << endl;
        cout << "r3 = " << r3 << endl;
    }

    // Estimate horizontal slope
    double slope_max = -65536.0;
    Interval tmp;

    for (int box = 0; box < nBoxes; box++) {
        if ((box == 2) || (box == 3) || (box == 4)) {
            if (verbose) {
                cout << "igx = " << igx[box] << endl;
                cout << "igy = " << igy[box] << endl;
            }
            for (int n = 0; n < nData; n++) {
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
            }
            for (int i = 0; i < n_points; i++) {
                tmp = hull4(w[0][i].imag(), w[1][i].imag(), w[2][i].imag(), w[3][i].imag());
                if (zero_in(tmp)) {
                    tmp = hull4(w[0][i].real(), w[1][i].real(), w[2][i].real(), w[3][i].real());
                    slope_max = max(slope_max, abs(((tmp - igy[box])/(-igx[box])).upper()));
                }
            }
        }
    }
    
    if (verbose) {
        cout << "slope_max = " << slope_max << endl;
    }

    // Compute p3 and its stable eigenvalue
    double A = mid(a.getRe());
    double B = mid(b.getRe());
    double p3x = (1 + B - sqrt((1 + B) * (1 + B) + 4 * A)) / 2;
    double p3y = p3x;
    if (verbose) {
        cout << "p3x = " << p3x << endl;
        cout << "p3y = " << p3y << endl;
    }
    double s3 = 0;
    double u = s3;
    double v = 1;
    double U;
    double V;
    const int nite = 16;

    if (B == 0.0) {
        s3 = 0.0;
    } else {
        for (int i = 0; i < nite; i ++) {
            U = v;
            V = (-u + 2 * p3x * v)/B;
            u = U / V;
            v = 1.0;
        }
        s3 = u;
    }
    if (verbose) {
        cout << "s3 = " << s3 << endl;
    }
    
    // (u, v) is set to the orthonormal to (s3, 1)
    u =   1/(1 + s3*s3);
    v = -s3/(1 + s3*s3);

    // Estimate the distance to p2 stable direction
    double dist_min = 65536.0;
    for (int box = 0; box < nBoxes; box++) {
        if ((box == 2) || (box == 3) || (box == 4)) {
            for (int n = 0; n < nData; n++) {
                PX[n] = px[n][0] * ax[n][box];
                QX[n] = qx[n][4] * ax[n][box];
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ax[n][box], bx[n][box], Px[n][box], PX[n], Qx[n][box], QX[n], z[n]);
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
                define_domain_points(box, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
                
                int j, k, j_end, k_end;
                int dl, dr, ul, ur;

                for (j = 0; j < n_points; j++) {
                    if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
                    if ((box == 2) && (j < n_points * 3 / 4)) {continue;}
                    if ((box == 3) && (j < n_points * 3 / 4)) {continue;}
                    if ((box == 4) && (j < n_points * 1 / 4)) {continue;}
                    if ((box == 4) && (j > n_points * 1 / 2)) {continue;}
                    for (k = 0; k < n_points; k++) {
                        if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
        
                        dl = j * n_points + k;
                        dr = j_end * n_points + k;
                        ul = j * n_points + k_end;
                        ur = j_end * n_points + k_end;
                        
                        // Compute Z
                        Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                                      max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                        Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                                      max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                        Z = CpxInterval(Re, Im);
        
                        // Compute W
                        Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                                      max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                        Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                                      max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                        W = CpxInterval(Re, Im);

                        if (zero_in(Z.getIm()) && zero_in(W.getIm())) {
                            dist_min = min(dist_min, abs((u * (Z.getRe() - p3x) + v * (W.getRe() - p3y)).lower()));
                        }
                    }
                }
            }
        }
    }
    if (verbose) {
        cout << "dist_min = " << dist_min << endl;
    } // delta_min is the maximum of delta

    // Define delta
    double delta3 = dist_min;
    
    // Define R2
    double R3 = r3;
    double step_size = 0.001;
    while (slope_max > (R3 * R3 - r3 * r3) /(delta3 * delta3 + abs(s3) * (R3 * R3 - r3 * r3))) {
        R3 = R3 + step_size;
    }

    if (verbose) {
        cout << "R3 = " << R3 << endl;
    }

    // CMC
    const int npts_disk_x = 128;
    const int npts_disk_y = 512;

    vector< complex<double> > x_;
    vector< complex<double> > y_;
    x_.resize(npts_disk_x, 0);
    y_.resize(npts_disk_y, 0);
    define_disk(1.0, 1.0, delta3, x_);
    define_disk(1.0, 1.0, R3, y_);

    vector< complex<double> > x;
    vector< complex<double> > y;
    x.resize(npts_disk_x * npts_disk_y, 0);
    y.resize(npts_disk_x * npts_disk_y, 0);

    define_P(p3x, p3y, s3, y3, x_, y_, x, y);
    
    int ix, iy, ix_end, iy_end;
    int dl, dr, ul, ur;
    CpxInterval X, Y, X_, Y_;
    int error_count_for_1 = 0;
    int error_count_bak_1 = 0;
    for (ix = 0; ix < npts_disk_x; ix++) {
        if (ix + 1 == npts_disk_x) { ix_end = 0; } else { ix_end = ix + 1; }
        for (iy = 0; iy < npts_disk_y; iy++) {
            if (iy + 1 == npts_disk_y) { iy_end = 0; } else { iy_end = iy + 1; }
            
            dl = ix     * npts_disk_x + iy;
            dr = ix_end * npts_disk_x + iy;
            ul = ix     * npts_disk_x + iy_end;
            ur = ix_end * npts_disk_x + iy_end;
            
            // Compute X
            Re = Interval(min4(x[dl].real(), x[dr].real(), x[ul].real(), x[ur].real()), max4(x[dl].real(), x[dr].real(), x[ul].real(), x[ur].real()));
            Im = Interval(min4(x[dl].imag(), x[dr].imag(), x[ul].imag(), x[ur].imag()), max4(x[dl].imag(), x[dr].imag(), x[ul].imag(), x[ur].imag()));
            X = CpxInterval(Re, Im);
            
            // Compute Y
            Re = Interval(min4(y[dl].real(), y[dr].real(), y[ul].real(), y[ur].real()), max4(y[dl].real(), y[dr].real(), y[ul].real(), y[ur].real()));
            Im = Interval(min4(y[dl].imag(), y[dr].imag(), y[ul].imag(), y[ur].imag()), max4(y[dl].imag(), y[dr].imag(), y[ul].imag(), y[ur].imag()));
            Y = CpxInterval(Re, Im);
            
            // apply the Hénon map
            X_ = square(X) - a - b * Y;
            Y_ = X;
                
            if ((X_ - (p3x + (Y_ - p3y) * s3)).cpxNorm() < delta3) {
                error_count_for_1++;
            }

            if ((Y_ - y3).cpxNorm() > R3) {
                error_count_bak_1++;
            }
        }
    }

    if (verbose) {
        cout << "6 (1) Forward  CMC: " << error_count_for_1 << "/" << npts_disk_x * npts_disk_y << " errors." << endl;
        cout << "6 (1) Backward CMC: " << error_count_bak_1 << "/" << npts_disk_x * npts_disk_y << " errors." << endl;
    }
    
    //
    // (2)
    //

    const Interval CX = (ipx[0] + iqx[4]) / 2.0;
    const Interval RX = (ipx[0] - iqx[4]) / 2.0;
    const Interval CY = (ipy[4] + iqy[4]) / 2.0;
    const Interval RY = (ipy[4] - iqy[4]) / 2.0;
    double minQx[nBoxes], minQy[nBoxes];
    double maxPx[nBoxes], maxPy[nBoxes];
    for (int box = 0; box < nBoxes; box++) {
        minQx[box] = min4(Qx[0][box], Qx[1][box], Qx[2][box], Qx[3][box]);
        minQy[box] = min4(Qy[0][box], Qy[1][box], Qy[2][box], Qy[3][box]);
        maxPx[box] = max4(Px[0][box], Px[1][box], Px[2][box], Px[3][box]);
        maxPy[box] = max4(Py[0][box], Py[1][box], Py[2][box], Py[3][box]);
    }

    int npts_stable = 100000;
    if (B > -0.025) { npts_stable *= 100; }
    const double length_stable = 0.01;
    const int max_iteration = 10;
    const int min_points_in_the_domain = 8;
    vector< double > xs;
    vector< double > ys;
    xs.resize(npts_stable, 0);
    ys.resize(npts_stable, 0);

    for (int i = 0; i < npts_stable; i++){
        xs[i] = p3x + s3 * length_stable * i / npts_stable;
        ys[i] = p3y +      length_stable * i / npts_stable;
    }

    double tmp_;
    int i_ini, i_mid, i_end;
    double x_ini, y_ini, x_mid, y_mid, x_end, y_end;
    for (int ite = 0; ite < max_iteration; ite++) {
        for (int i = 0; i < npts_stable; i++){
            tmp_ = ys[i];
            ys[i] = (ys[i]*ys[i] - A - xs[i]) / B;
            xs[i] = tmp_;
        }

        bool in_the_domain = false;
        i_ini = 0;
        i_end = 0;
        for (int i = 0; i < npts_stable; i++) {
            // cout << ite << ":" << i << endl;
            // cout << xs[i] << endl;
            // cout << ys[i] << endl;
            X = CpxInterval(xs[i]);
            Y = CpxInterval(ys[i]);
            if (contained_in(1, X, Y, CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby, maxPx, maxPy, minQx, minQy) && contained_in(3, X, Y, CX, CY, RX, RY, ifx, ify, igx, igy, iax, iay, ibx, iby, maxPx, maxPy, minQx, minQy)) {
                if (!in_the_domain) {
                    i_ini = i;
                    x_ini = xs[i];
                    y_ini = ys[i];
                    in_the_domain = true;
                }
            } else {
                if (in_the_domain) {
                    i_end = i;
                    x_end = xs[i];
                    y_end = ys[i];
                    in_the_domain = false;
                }
            }
        }
        if (i_end - i_ini > min_points_in_the_domain) {
            if (verbose) {cout << "iteration = " << ite << endl;}
            break;
        }
    }

    if (i_end - i_ini < min_points_in_the_domain) {
        cout << "ERROR" << endl; 
        return 1;
    }

    // X = x^2 - A - By 
    // Y = x
    // x = Y
    // y = (Y^2 - A - X) / B
    
    i_mid = int((i_ini + i_end) / 2);
    x_mid = xs[i_mid];
    y_mid = ys[i_mid];
    double s1 = (x_ini - x_end) / (y_ini - y_end);
    double p1x = x_mid;
    double p1y = y_mid;
    if (verbose) {cout << "i_ini = " << i_ini << endl;}
    if (verbose) {cout << "x_ini = " << x_ini << endl;}
    if (verbose) {cout << "y_ini = " << y_ini << endl;}
    if (verbose) {cout << "i_end = " << i_end << endl;}
    if (verbose) {cout << "x_end = " << x_end << endl;}
    if (verbose) {cout << "y_end = " << y_end << endl;}
    if (verbose) {cout << "p1x = " << p1x << endl;}
    if (verbose) {cout << "p1y = " << p1y << endl;}
    if (verbose) {cout << "s1 = " << s1 << endl;}

    // Compute r1
    ymin =  65536.0;
    ymax = -65536.0;

    for (int box = 0; box < nBoxes; box++) {
        if ((box == 1) || (box == 3)) {
            for (int n = 0; n < nData; n++) {
                PX[n] = px[n][0] * ax[n][box];
                QX[n] = qx[n][4] * ax[n][box];
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ax[n][box], bx[n][box], Px[n][box], PX[n], Qx[n][box], QX[n], z[n]);
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
                define_domain_points(box, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
                
                int j, k, j_end, k_end;
                int dl, dr, ul, ur;

                for (j = 0; j < n_points; j++) {
                    if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
                    for (k = 0; k < n_points; k++) {
                        if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
        
                        dl = j * n_points + k;
                        dr = j_end * n_points + k;
                        ul = j * n_points + k_end;
                        ur = j_end * n_points + k_end;
                        
                        // Compute Z
                        Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                                      max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                        Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                                      max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                        Z = CpxInterval(Re, Im);
        
                        // Compute W
                        Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                                      max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                        Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                                      max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                        W = CpxInterval(Re, Im);

                        if (zero_in(Z.getIm()) && zero_in(W.getIm())) {
                            ymax = max(ymax, W.getRe().upper());
                            ymin = min(ymin, W.getRe().lower());
                        }
                    }
                }
            }
        }
    }

    Interval I1(ymin, ymax);
    double y1 = mid(I1);
    double r1 = rad(I1);
    
    if (verbose) {
        cout << "I1 = " << I1 << endl;
        cout << "y1 = " << y1 << endl;
        cout << "r1 = " << r1 << endl;
    }

    // Estimate horizontal slope
    slope_max = -65536.0;

    for (int box = 0; box < nBoxes; box++) {
        if ((box == 1) || (box == 3)) {
            // if (verbose) {
            //     cout << "igx = " << igx[box] << endl;
            //     cout << "igy = " << igy[box] << endl;
            // }
            for (int n = 0; n < nData; n++) {
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
            }
            for (int i = 0; i < n_points; i++) {
                tmp = hull4(w[0][i].imag(), w[1][i].imag(), w[2][i].imag(), w[3][i].imag());
                if (zero_in(tmp)) {
                    tmp = hull4(w[0][i].real(), w[1][i].real(), w[2][i].real(), w[3][i].real());
                    slope_max = max(slope_max, abs(((tmp - igy[box])/(-igx[box])).upper()));
                }
            }
        }
    }
    
    if (verbose) {
        cout << "slope_max = " << slope_max << endl;
    }

    // (u, v) is set to the orthonormal to (s1, 1)
    u =   1/(1 + s1*s1);
    v = -s1/(1 + s1*s1);

    // Estimate the distance to p2 stable direction
    dist_min = 65536.0;
    for (int box = 0; box < nBoxes; box++) {
        if ((box == 1) || (box == 3)) {
            for (int n = 0; n < nData; n++) {
                PX[n] = px[n][0] * ax[n][box];
                QX[n] = qx[n][4] * ax[n][box];
                PY[n] = py[n][4] * ay[n][box];
                QY[n] = qy[n][4] * ay[n][box];
                define_ellipse_boundaries(ax[n][box], bx[n][box], Px[n][box], PX[n], Qx[n][box], QX[n], z[n]);
                define_ellipse_boundaries(ay[n][box], by[n][box], Py[n][box], PY[n], Qy[n][box], QY[n], w[n]);
                define_domain_points(box, fx[n], fy[n], gx[n], gy[n], z[n], w[n], Z_point[n], W_point[n]);
                
                int j, k, j_end, k_end;
                int dl, dr, ul, ur;

                for (j = 0; j < n_points; j++) {
                    if (j + 1 == n_points) { j_end = 0; } else { j_end = j + 1; }
                    if ((box == 2) && (j < n_points * 3 / 4)) {continue;}
                    if ((box == 3) && (j < n_points * 3 / 4)) {continue;}
                    if ((box == 4) && (j < n_points * 1 / 4)) {continue;}
                    if ((box == 4) && (j > n_points * 1 / 2)) {continue;}
                    for (k = 0; k < n_points; k++) {
                        if (k + 1 == n_points) { k_end = 0; } else { k_end = k + 1; }
        
                        dl = j * n_points + k;
                        dr = j_end * n_points + k;
                        ul = j * n_points + k_end;
                        ur = j_end * n_points + k_end;
                        
                        // Compute Z
                        Re = Interval(min4(min4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           min4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           min4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           min4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())),
                                      max4(max4(Z_point[0][dl].real(), Z_point[0][dr].real(), Z_point[0][ul].real(), Z_point[0][ur].real()),
                                           max4(Z_point[1][dl].real(), Z_point[1][dr].real(), Z_point[1][ul].real(), Z_point[1][ur].real()),
                                           max4(Z_point[2][dl].real(), Z_point[2][dr].real(), Z_point[2][ul].real(), Z_point[2][ur].real()),
                                           max4(Z_point[3][dl].real(), Z_point[3][dr].real(), Z_point[3][ul].real(), Z_point[3][ur].real())));
                        Im = Interval(min4(min4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           min4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           min4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           min4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())),
                                      max4(max4(Z_point[0][dl].imag(), Z_point[0][dr].imag(), Z_point[0][ul].imag(), Z_point[0][ur].imag()),
                                           max4(Z_point[1][dl].imag(), Z_point[1][dr].imag(), Z_point[1][ul].imag(), Z_point[1][ur].imag()),
                                           max4(Z_point[2][dl].imag(), Z_point[2][dr].imag(), Z_point[2][ul].imag(), Z_point[2][ur].imag()),
                                           max4(Z_point[3][dl].imag(), Z_point[3][dr].imag(), Z_point[3][ul].imag(), Z_point[3][ur].imag())));
                        Z = CpxInterval(Re, Im);
        
                        // Compute W
                        Re = Interval(min4(min4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           min4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           min4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           min4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())),
                                      max4(max4(W_point[0][dl].real(), W_point[0][dr].real(), W_point[0][ul].real(), W_point[0][ur].real()),
                                           max4(W_point[1][dl].real(), W_point[1][dr].real(), W_point[1][ul].real(), W_point[1][ur].real()),
                                           max4(W_point[2][dl].real(), W_point[2][dr].real(), W_point[2][ul].real(), W_point[2][ur].real()),
                                           max4(W_point[3][dl].real(), W_point[3][dr].real(), W_point[3][ul].real(), W_point[3][ur].real())));
                        Im = Interval(min4(min4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           min4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           min4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           min4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())),
                                      max4(max4(W_point[0][dl].imag(), W_point[0][dr].imag(), W_point[0][ul].imag(), W_point[0][ur].imag()),
                                           max4(W_point[1][dl].imag(), W_point[1][dr].imag(), W_point[1][ul].imag(), W_point[1][ur].imag()),
                                           max4(W_point[2][dl].imag(), W_point[2][dr].imag(), W_point[2][ul].imag(), W_point[2][ur].imag()),
                                           max4(W_point[3][dl].imag(), W_point[3][dr].imag(), W_point[3][ul].imag(), W_point[3][ur].imag())));
                        W = CpxInterval(Re, Im);

                        if (zero_in(Z.getIm()) && zero_in(W.getIm())) {
                            dist_min = min(dist_min, abs((u * (Z.getRe() - p1x) + v * (W.getRe() - p1y)).lower()));
                        }
                    }
                }
            }
        }
    }
    if (verbose) {
        cout << "dist_min = " << dist_min << endl;
    } // delta_min is the maximum of delta

    // Define delta
    double delta1 = dist_min;
    
    // Define R2
    double R1 = r1;
    while (slope_max > (R1 * R1 - r1 * r1) /(delta1 * delta1 + abs(s1) * (R1 * R1 - r1 * r1))) {
        R1 = R1 + step_size;
    }

    if (verbose) {
        cout << "R1 = " << R1 << endl;
    }

    // CMC
    x_.resize(npts_disk_x, 0);
    y_.resize(npts_disk_y, 0);
    define_disk(1.0, 1.0, delta1, x_);
    define_disk(1.0, 1.0, R1, y_);

    x.resize(npts_disk_x * npts_disk_y, 0);
    y.resize(npts_disk_x * npts_disk_y, 0);

    define_P(p1x, p1y, s1, y1, x_, y_, x, y);
    
    int error_count_for_2 = 0;
    int error_count_bak_2 = 0;
    for (ix = 0; ix < npts_disk_x; ix++) {
        if (ix + 1 == npts_disk_x) { ix_end = 0; } else { ix_end = ix + 1; }
        for (iy = 0; iy < npts_disk_y; iy++) {
            if (iy + 1 == npts_disk_y) { iy_end = 0; } else { iy_end = iy + 1; }
            
            dl = ix     * npts_disk_x + iy;
            dr = ix_end * npts_disk_x + iy;
            ul = ix     * npts_disk_x + iy_end;
            ur = ix_end * npts_disk_x + iy_end;
            
            // Compute X
            Re = Interval(min4(x[dl].real(), x[dr].real(), x[ul].real(), x[ur].real()), max4(x[dl].real(), x[dr].real(), x[ul].real(), x[ur].real()));
            Im = Interval(min4(x[dl].imag(), x[dr].imag(), x[ul].imag(), x[ur].imag()), max4(x[dl].imag(), x[dr].imag(), x[ul].imag(), x[ur].imag()));
            X = CpxInterval(Re, Im);
            
            // Compute Y
            Re = Interval(min4(y[dl].real(), y[dr].real(), y[ul].real(), y[ur].real()), max4(y[dl].real(), y[dr].real(), y[ul].real(), y[ur].real()));
            Im = Interval(min4(y[dl].imag(), y[dr].imag(), y[ul].imag(), y[ur].imag()), max4(y[dl].imag(), y[dr].imag(), y[ul].imag(), y[ur].imag()));
            Y = CpxInterval(Re, Im);
            
            // apply the Hénon map
            X_ = square(X) - a - b * Y;
            Y_ = X;
                
            if ((X_ - (p3x + (Y_ - p3y) * s3)).cpxNorm() < delta3) {
                error_count_for_2++;
            }

            if ((Y_ - y3).cpxNorm() > R3) {
                error_count_bak_2++;
            }
        }
    }

    if (verbose) {
        cout << "6 (2) Forward  CMC: " << error_count_for_1 << "/" << npts_disk_x * npts_disk_y << " errors." << endl;
        cout << "6 (2) Backward CMC: " << error_count_bak_1 << "/" << npts_disk_x * npts_disk_y << " errors." << endl;
    }

    return error_count_for_1 + error_count_bak_1 + error_count_for_2 + error_count_bak_2;
}
