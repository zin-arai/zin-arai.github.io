#!/usr/bin/env python3
import sys, shutil, subprocess

argvs = sys.argv
argc = len(argvs)

if argc == 1:
    process_number = 0
    max_process = 1
elif argc == 3:
    process_number = int(argvs[1])
    max_process = int(argvs[2])
else:
    print("Usage: ./run_pp.py [process_number max_process]")
    
for b_num in range(0, 8193):
    if (b_num % max_process) == process_number:
        print("b_num = " + str(b_num) + "\n")
        subprocess.call(['../bin/NumericalCheck_pp', str(b_num)])
