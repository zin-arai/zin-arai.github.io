#!/usr/bin/env python3
import sys, shutil, subprocess
import math

argvs = sys.argv
argc = len(argvs)

if argc == 1:
    process_number = 0
    max_process = 1
elif argc == 3:
    process_number = int(argvs[1])
    max_process = int(argvs[2])

b_num_min = 0
b_num_max = 2000
a_num_min = 50
a_num_max = 150
npoints_ini = 64
npoints_max = 65536

for b_num in range(b_num_min, b_num_max):
    if (b_num % max_process) == process_number:
        for a_num in range(a_num_min, a_num_max):
            file0 = "../data/positive/{:04}".format(b_num + 0) + "-" + "{:03}".format(a_num + 0) + ".dat"
            file1 = "../data/positive/{:04}".format(b_num + 0) + "-" + "{:03}".format(a_num + 1) + ".dat"
            file2 = "../data/positive/{:04}".format(b_num + 1) + "-" + "{:03}".format(a_num + 0) + ".dat"
            file3 = "../data/positive/{:04}".format(b_num + 1) + "-" + "{:03}".format(a_num + 1) + ".dat"
            CMC = False
            print("b_num = " + str(b_num) + ", a_num = " + str(a_num) + ": ")
            npoints = npoints_ini
            # Check CMC for the forward iteration of the Henon
            while npoints <= npoints_max:
                result = subprocess.call(['../bin/NumericalCheck_1', file0, file1, file2, file3, str(npoints)])
                if (result == 0):
                    print("CMC OK." + "\n")
                    CMC = True
                    break
                else:
                    print("\n" + "Subdivision Refined to " + str(npoints * 2) + "... ")
                    npoints = npoints * 2
            # Exit if CMC is not satisfied
            if (not CMC):
                print("Error: b_num = " + str(b_num) + ", a_num = " + str(a_num) + "\n")
                exit() 
