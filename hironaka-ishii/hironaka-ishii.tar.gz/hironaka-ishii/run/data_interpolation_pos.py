#!/usr/bin/env python3
import sys, shutil, subprocess, random

print("Interpolating horizontally...")

a_seq = [2.00, 2.21, 2.45, 2.72, 3.03, 3.37, 3.76, 4.18, 4.65, 5.15, 5.70]
t_step = 0.01

for b_num in range(0, 9):
    filename_left   = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
    filename_center = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
    filename_right  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
    for j in range(50, 151):
        filename = "../data/positive/{:04}".format(b_num * 200) + "-" + "{:03}".format(j) + ".dat"
        if j == 0:
            subprocess.call(['cp', filename_left, filename])
        elif (0 < j) & (j < 100):
            t = t_step * j
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left, filename_center])
        elif j == 100:
            subprocess.call(['cp', filename_center, filename])
        elif (100 < j) & (j < 200):
            t = t_step * (j - 100)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_center, filename_right])
        else:
            subprocess.call(['cp', filename_right, filename])

for b_num in range(9, 11):
    filename_left1  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] - 0.1) * 100))) + ".dat"
    filename_left2  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] -0.05) * 100))) + ".dat"
    filename_center = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.0) * 100))) + ".dat"
    filename_right  = "../data/positive_distinguished/crossed{:03}".format(b_num * 10) + "-" + "{:03}".format(int(round((a_seq[b_num] + 0.1) * 100))) + ".dat"
    for j in range(50, 151):
        filename = "../data/positive/{:04}".format(b_num * 200) + "-" + "{:03}".format(j) + ".dat"
        if j == 0:
            subprocess.call(['cp', filename_left1, filename])
        elif (0 < j) & (j < 50):
            t = 2 * t_step * j
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left1, filename_left2])
        elif j == 50:
            subprocess.call(['cp', filename_left2, filename])
        elif (50 < j) & (j < 100):
            t = 2 * t_step * (j - 50)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_left2, filename_center])
        elif j == 100:
            subprocess.call(['cp', filename_center, filename])
        elif (100 < j) & (j < 200):
            t = t_step * (j - 100)
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_center, filename_right])
        else:
            subprocess.call(['cp', filename_right, filename])

print("Interpolating vertically...")

for b_base in [000, 200, 400, 600, 800, 1000, 1200, 1400, 1600, 1800]:
    for i in range(50, 151):
        t = i / 200.0
        print("Generating " + str(b_base + i))
        for j in range(50, 151):
            filename_d = "../data/positive/{:04}".format(b_base      ) + "-" + "{:03}".format(j) + ".dat"
            filename_u = "../data/positive/{:04}".format(b_base + 200) + "-" + "{:03}".format(j) + ".dat"
            filename   = "../data/positive/{:04}".format(b_base + i  ) + "-" + "{:03}".format(j) + ".dat"
            subprocess.call(['../bin/interpolation_pos', str(t), filename, filename_d, filename_u])
