#ifndef _Rectangle_h
#define _Rectangle_h

#include <stdio.h>
#include "Vec.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
  int dim;
  double *c, *r;
} Rectangle;

Rectangle *RectangleNew(double *c, double *r, unsigned char dim) {
  Rectangle *rec;
  NEW(rec, Rectangle*, 1);
  rec->dim = dim;
  NEW(rec->c, double*, dim);
  NEW(rec->r, double*, dim);
  VecCopy(c, rec->c, dim);
  VecCopy(r, rec->r, dim);

  return rec;
}

void RectangleFree(Rectangle **rec) {
  if (*rec) {
    free((*rec)->r);
    free((*rec)->c);
    free(*rec);
    *rec = 0;
  }
}

int RectangleContains(Rectangle *rect, double *x) {
  int i, in = 1;
  for (i=0; in && i<rect->dim; i++) 
    in = (fabs(x[i] - rect->c[i]) <= rect->r[i]);
  return in;
}

void RectangleSave(FILE *out, Rectangle *r) {
  fprintf(out, "Rectangle at %p:\n", r);
  if (r) {  
    fprintf(out, "  dim = %d\n", r->dim);
    fprintf(out, "  center = "); VecPrint(out, r->c, r->dim);
    fprintf(out, "  radius = "); VecPrint(out, r->r, r->dim);
  }
}
  
Rectangle *RectangleLoad(FILE *in) {
  int dim;
  double *c, *r;
  Rectangle *rect;

  fscanf(in, "Rectangle at %p:\n", &rect);
  if (rect) {
    fscanf(in, "  dim = %d\n", &dim);
    fscanf(in, "  center = "); c = VecRead(in, dim);
    fscanf(in, "  radius = "); r = VecRead(in, dim);
    rect = RectangleNew(c, r, dim);
    free(c);
    free(r);
  }
  return rect;
}
    

#ifdef __cplusplus
}
#endif


#endif
