/*
 * Copyright (c) 1998,99 Oliver Junge, for details see COPYING
 * 
 * Iter.h   
 *
 */

#ifndef _Iter_h
#define _Iter_h

#include "Tree.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {

  Tree *tree;                 /* tree of boxes */
  Tree *searchTree;           /* copy of tree for searching */

} Iter;

/* creates and returns a new iter structure */
Iter *IterNew(Rectangle *Q) {

  Iter *iter;
  NEW(iter, Iter*, 1);
  iter->tree = TreeNew(Q);
  iter->searchTree = TreeCopy(iter->tree);

  return iter;
}

/* deletes **iter and set *iter=0 */
void IterFree(Iter **iter) {
  if (*iter) {
    TreeFree(&((*iter)->searchTree));
    TreeFree(&((*iter)->tree));
    free(*iter);
    *iter = 0;
  }
}

/* saves the iter structure including the tree ti file out */
void IterSave(FILE *out, Iter *iter) {
  if (iter) {
    TreeSave(out, iter->tree);
  }
}

#ifdef __cplusplus
}
#endif

#endif
