#ifndef _Box_h
#define _Box_h

#include <stdio.h>
#include <assert.h>
#include "SparseVector.h"

#ifdef __cplusplus
extern "C" {
#endif

struct Box {
    byte sd;         /* coordinate in which box is/will be subdivided */
    byte flags;      /* space for various flags */    
    byte color;      /* the color of that box */
    Box *child[2];   /* pointer to the children */
    int no;            /* number, needed for measure computation */
};

/* creates and returns new box */
Box *BoxNew(void) {
	Box *box;
	NEW(box, Box*, 1);
	box->sd = 0;
	box->flags = 0;
        box->color = 1;
	box->child[0] = 0;
	box->child[1] = 0;
	box->no = -1;
	return box;
}

/* deletes box *box and all children, sets *b=0  */
void BoxFree(Box **box) {
    if (*box) {
        BoxFree(&((*box)->child[0]));
        BoxFree(&((*box)->child[1]));
        free(*box);
        *box = 0;
    }
}

/* returns the number of children */
unsigned int BoxNoOfChildren(Box *box) {
	if (box) {
		if (box->child[0] && box->child[1]) return 2;
		if (box->child[0] || box->child[1]) return 1;
	}
	return 0; /* if b==0, it has no children, too */
}

/* subdivides box, stores sd in their children */
int BoxSubdivide(Box *box, unsigned char sd) {
	if (BoxNoOfChildren(box)==0) {
		box->child[0] = BoxNew();
		box->child[1] = BoxNew();
		box->sd = sd;
		return 1;
	}
	fprintf(stderr, "warning: libgaio: BoxSubdivide(): box is no leaf.\n");
	return 0;
}

/* unsubdivides box */
int BoxUnsubdivide(Box *box) {
	if (BoxNoOfChildren(box)!=0) {
		BoxFree(&(box->child[0]));
		BoxFree(&(box->child[1]));
		return 1;
	}
	return 0;
}

/* flag handling functions */
void BoxSetFlag(Box *box, byte flag) {
	if (box) box->flags |= flag;
}

void BoxUnsetFlag(Box *box, byte flag) {
	if (box) box->flags &= ~flag;
}

void BoxChangeFlag(Box *box, byte from, byte to) {
	if (box) {
		if (box->flags & from) {
			box->flags &= ~from;
			box->flags |= to;
		}
	}
}

byte BoxGetFlags(Box *box) {
	if (box)
		return box->flags;
	else {
		fprintf(stderr, "error: libgaio: BoxGetFlags called with invalid argument.");
		return 0;
	}
}

/* returns the relative depth of the box: 
   -1, if it has no children (a "leaf"); 
   -2, if it is parent of a leaf; 
    0, otherwise */
int BoxDepth(Box *box) {
	if (box) {
		if (BoxNoOfChildren(box)==0) return -1;
		if (BoxNoOfChildren(box->child[0])==0 &&
			    BoxNoOfChildren(box->child[1])==0) return -2;
	}
	return 0;
}

/* saves the box to the stream out */
void BoxSave(FILE *out, Box *box) {
	if (box) {
                fwrite((void *)&box->color, 1, 1, out);
		fwrite((void *)&box->sd, 1, 1, out);
		fwrite((void *)&box->flags, 1, 1, out);
	}
	else
	    fprintf(out, "%c", 0);
	return;
}

/* loads a box from the stream in */
Box *BoxLoad(FILE *in) {
	int C;
	Box *box;

	C = fgetc(in);
	if (C==EOF || C==0) return 0;

	box = BoxNew();
	fread((void *)&box->sd, 1, 1, in);
	fread((void *)&box->flags, 1, 1, in);

	return box;
}

#ifdef __cplusplus
}
#endif

#endif
