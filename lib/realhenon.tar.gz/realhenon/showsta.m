!date
load data/param_stack;
param_stack = sortrows(param_stack, 1);
dmin = min(param_stack(:,2)); dmax = max(param_stack(:,2));

total_area = 0;
disp('Remaining cubes in the parameter space:')
for i = dmin:dmax
  no = find(param_stack(:,2)==i);
  lno(i) = length(no);
  area(i) = lno(i) / 2^(i);
  if length(no) ~= 0
    disp(sprintf('param_depth %2d: %6d cubes,   area: %12.9f%%',i ,lno(i),100*area(i)));
  end
  total_area = total_area + area(i);
end

disp(sprintf('         TOTAL: %6d cubes,   area: %12.9f%%',length(param_stack),100*total_area));

for i = dmin:dmax
  no = find(param_stack(:,2)==i);
end
