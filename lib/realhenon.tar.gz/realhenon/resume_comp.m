function resume_comp(resume_time)

%%% tree for TM
center = [0;0;0;0];
radius = [8;8;1;1];
tree = Tree(center,radius);

phase_sd = tree.sd;
phase_sd( 1) = 0; phase_sd( 2) = 1;
phase_sd( 3) = 0; phase_sd( 4) = 1;
phase_sd( 5) = 0; phase_sd( 6) = 1;
phase_sd( 7) = 0; phase_sd( 8) = 1;
phase_sd( 9) = 0; phase_sd(10) = 1;
phase_sd(11) = 0; phase_sd(12) = 1;
tree.sd = phase_sd;

param_center = [4;0];
param_radius = [8;1];
param_tree = Tree(param_center,param_radius);
hyp_tree = Tree(param_center,param_radius);
param_sd = param_tree.sd;
param_sd(1) = 0; param_sd(2) = 0; param_sd(3) = 0;

filename = sprintf('snapshots/param_stack_%.8d.mat', resume_time)
eval(sprintf('load %s;',filename));

filename = sprintf('snapshots/remaining_%.8d.tree', resume_time);
param_tree = Tree(filename);
param_tree.sd = param_sd;

filename = sprintf('snapshots/hyperbolic_%.8d.tree', resume_time);
hyp_tree = Tree(filename)
hyp_tree.sd = param_sd;

main_routine(param_tree, hyp_tree, param_stack, phase_sd, resume_time);
