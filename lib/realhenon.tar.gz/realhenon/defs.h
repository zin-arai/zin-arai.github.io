#ifndef _defs_h
#define _defs_h

#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include <math.h>
#include <string.h>

#define max(x,y) ((x) > (y) ? (x) : (y))
#define min(x,y) ((x) < (y) ? (x) : (y))
#define mymax(x,y) ((x) > (y) ? (x) : (y))
#define mymin(x,y) ((x) < (y) ? (x) : (y))

#define SQMAX(x, y) (max(((x)*(x)),((y)*(y))))
#define SQMIN(x, y) (min(((x)*(x)),((y)*(y))))
#define IPMAX(a, b, c, d) (max(max(((a)*(c)), ((b)*(d))), max(((a)*(d)), ((b)*(c)))))
#define IPMIN(a, b, c, d) (min(min(((a)*(c)), ((b)*(d))), min(((a)*(d)), ((b)*(c)))))

#define interval_intersect(a, b, c, d)  !(((b) < (c)) || ((a) > (d)))

#define NEW(ptr, type, nr) (ptr = (type) calloc((size_t) (nr), sizeof(*ptr)))
#define FREE(ptr)  free(ptr)

typedef unsigned char byte;

#endif
