%% tree initialization
tree = Tree([0;0;0;0],[8;8;1;1]);

%% parameter setting
param_inf = [5.4; 1.0];
param_sup = [5.4; 1.0];

%% subdivision direction
% 0: x-axis
% 1: y-axis
% 2: v-axis (v: tangent vector along x)
% 2: w-axis (w: tangent vector along y)
sd = tree.sd;
sd( 1) = 0; sd( 2) = 1;
sd( 3) = 0; sd( 4) = 1;
sd( 5) = 0; sd( 6) = 1;
sd( 7) = 0; sd( 8) = 1;
sd( 9) = 0; sd(10) = 1;
sd(11) = 0; sd(12) = 1;
tree.sd = sd;

%% run the main routine
hyp_realhenon(tree,param_inf,param_sup);
