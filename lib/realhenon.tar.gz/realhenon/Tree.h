#ifndef _Tree_h
#define _Tree_h

#define SD_MAX 500 /* we allow max. 500 sd's in each coordinate */
#define DEPTH_MAX(d) ((d)*SD_MAX) 
#define DEPTH(tree, depth) (depth < 0 ? BoxDepth(tree->box) : tree->depth)

#include "Box.h"
#include "Rectangle.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    Rectangle *Q;               /* region of interest in phase space */
    Box *root;                  /* root of the tree */
    unsigned int *refcount;     /* reference count for the root box */
    Box *box;                   /* current box */
    double *c, *r;              /* center and radius of the current box */
    double *cStack, *rStack;    /* stacks for c and r */
    Box **boxStack;             /* stack for current box */
    unsigned int *branchStack;  /* stack for last visited branch in the tree */
    unsigned long depth;        /* current depth, i.e. depth of *box */
    byte *sd;                   /* array of bisection directions */
} Tree;

/* sets box=root and c and r to the values of the root box */
void TreeReset(Tree *tree) {
    assert(tree);

    tree->box = tree->root;
    VecCopy(tree->Q->c, tree->c, tree->Q->dim);
    VecCopy(tree->Q->r, tree->r, tree->Q->dim);
    tree->depth = 0;
}

/* creates and returns a new tree */
Tree *TreeNew(Rectangle *Q) {

    unsigned int i, dim;
    Tree *tree;

    assert(Q);
    dim = Q->dim;
    NEW(tree, Tree*, 1);
    tree->Q = RectangleNew(Q->c, Q->r, dim);
    tree->root = BoxNew();
    NEW(tree->refcount, unsigned int*, 1);
    *(tree->refcount) = 1;
    NEW(tree->c, double*, dim);
    NEW(tree->r, double*, dim);
    NEW(tree->cStack, double*, DEPTH_MAX(dim));
    NEW(tree->rStack, double*, DEPTH_MAX(dim));
    NEW(tree->boxStack, Box**, DEPTH_MAX(dim));
    NEW(tree->branchStack, unsigned int *, DEPTH_MAX(dim));
    NEW(tree->sd, byte*, DEPTH_MAX(dim)+1);
    for (i=0; i<DEPTH_MAX(dim)+1; i++) tree->sd[i] = i % dim;
    TreeReset(tree);

    return tree;
}

/* deletes the tree *tree and sets *tree=0 */
void TreeFree(Tree **tree) {
    if (*tree) {
        free((*tree)->branchStack);
        free((*tree)->boxStack);
        free((*tree)->rStack);
        free((*tree)->cStack);
        free((*tree)->r);
        free((*tree)->c);
        *((*tree)->refcount) -= 1;
        if (*((*tree)->refcount)==0) {
            BoxFree(&((*tree)->root));
            RectangleFree(&((*tree)->Q));
            free((*tree)->sd);
        }
        free(*tree);
        *tree = 0;
    }
}


/* creates and returns a copy of tree, sharing the boxtree at root */
Tree *TreeCopy(Tree *tree) {
    Tree *copy;

    assert(tree);

    NEW(copy, Tree*, 1);
    copy->Q = tree->Q;
    copy->root = tree->root;
    *(tree->refcount) += 1;
    copy->refcount = tree->refcount;
    NEW(copy->c, double*, tree->Q->dim);
    NEW(copy->r, double*, tree->Q->dim);
    NEW(copy->cStack, double*, DEPTH_MAX(tree->Q->dim));
    NEW(copy->rStack, double*, DEPTH_MAX(tree->Q->dim));
    NEW(copy->boxStack, Box**, DEPTH_MAX(tree->Q->dim));
    NEW(copy->branchStack, unsigned int*, DEPTH_MAX(tree->Q->dim));
    copy->sd = tree->sd;
    TreeReset(copy);

    return copy;
}

/* goes to child i of box, computing the new c, r and depth */
inline int TreeDown(Tree *tree, unsigned int i) {
    if (tree->box->child[i]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        if (i==0) {
            tree->c[sd] -= tree->r[sd];
            tree->box = tree->box->child[0];
        } else {
            tree->c[sd] += tree->r[sd];
            tree->box = tree->box->child[1];
        }
        tree->branchStack[tree->depth] = i;
        tree->depth++;

        return 1;
    } else
        return 0;
}

/* goes to the parent of box, computing the corresponding values of c, r and depth */
inline int TreeUp(Tree *tree) {
    if (tree->depth==0) return 0;
    tree->depth--;
    tree->box = tree->boxStack[tree->depth];
    tree->c[tree->box->sd] = tree->cStack[tree->depth];
    tree->r[tree->box->sd] = tree->rStack[tree->depth];

    return 1;
}

// Zin ARAI
inline int TreeDownLeft(Tree *tree) { 
    if (tree->box->child[0]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] -= tree->r[sd];
        tree->box = tree->box->child[0];
        tree->branchStack[tree->depth] = 0;
        tree->depth++;
        return 1;
    } else return 0;
}

// Zin ARAI
inline int TreeDownRight(Tree *tree) {
    if (tree->box->child[1]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] += tree->r[sd];
        tree->box = tree->box->child[1];
        tree->branchStack[tree->depth] = 1;
        tree->depth++;
        return 1;
    } else return 0;
}

/* goes to the next branch */
int TreeNextBranch(Tree *tree) {
    int down = 0;

    do {
        if (!TreeUp(tree)) return 0;
        if (tree->branchStack[tree->depth]==0)
            down = TreeDownRight(tree);
    } while (!down);

    return 1;
}

/* first part of iterator over the boxes of a certain depth */
int TreeFirstBox(Tree *tree, int depth) {

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    TreeReset(tree);

    while (DEPTH(tree, depth)!=depth)
        if (!(TreeDownLeft(tree) || TreeDownRight(tree)))
            if (!TreeNextBranch(tree)) return 0;

    return DEPTH(tree, depth)==depth;
}

/* second part of this iterator */
int TreeNextBox(Tree *tree, int depth) {

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (!TreeNextBranch(tree)) return 0;

    while (DEPTH(tree, depth)!=depth)
        if (!(TreeDownLeft(tree) || TreeDownRight(tree)))
            if (!TreeNextBranch(tree)) return 0;

    return DEPTH(tree, depth)==depth;
}

/* inserts a box on depth 'depth' into the tree which contains x (if
   possible at all), returning
   1, if successful;
   0, if box has already been there;
   -1, if x is not contained in the root box,
   a inserted box gets the flag 'flag0', a found box the flag flag1.
*/
int TreeInsert(Tree *tree, double *x, int depth, byte flag0, byte flag1) {

    assert(tree);
    assert(depth==-1 || depth<=DEPTH_MAX(tree->Q->dim));

    if (RectangleContains(tree->Q, x)) {
        int inserted = 0;
        TreeReset(tree);
        while (DEPTH(tree, depth)!=depth) {
            int i;
            if (!tree->box->child[0] && !tree->box->child[1])
                tree->box->sd = tree->sd[tree->depth];
            i = ((tree->c)[tree->box->sd] < x[tree->box->sd]);
            if (!TreeDown(tree, i)) {
                tree->box->child[i] = BoxNew();
                BoxSetFlag(tree->box->child[i], flag0);
                TreeDown(tree, i);
                inserted = 1;
            } else {
                BoxSetFlag(tree->box, flag1);
            }
        }
        return inserted;
    }
    return -1;
}

/* subdivides all leaves which have their flag 'flag' set in the next coordinate direction, returns the number of subdivided boxes*/
int TreeSubdivide(Tree *tree, byte flag) {
    int no = 0;

    assert(tree);

    if (TreeFirstBox(tree, -1)) do {
            if (tree->box->flags & flag) {
                BoxSubdivide(tree->box, tree->sd[tree->depth]);
                no++;
            }
        } while (TreeNextBox(tree, -1));

    return no;
}

/* unsubdivides all leaves which have their flag 'flag' set returns the number of unsubdivided boxes*/
int TreeUnsubdivide(Tree *tree, byte flag) {
    int no = 0;

    assert(tree);

    if (TreeFirstBox(tree, -2)) do {
            if (tree->box->flags & flag) {
                BoxUnsubdivide(tree->box);
                no++;
            }
        } while (TreeNextBox(tree, -2));

    return no;
}

/* removes all boxes which don't have their flag 'flag' set */
int TreeRemove(Box *box, byte flag) {
    int i;

    for (i=0; i<2; i++) {
        if (box->child[i]) {
            if (TreeRemove(box->child[i], flag))
                BoxFree(&(box->child[i]));
            if (BoxNoOfChildren(box)==0)
                box->flags &= ~flag;
        }
    }

    return (BoxNoOfChildren(box)==0 && !((box->flags & flag)==flag));
}

/* deletes the depth 'depth' and all deeper depths */
void TreeDeleteDepth(Tree *tree, int depth) {
    if (depth==0) {
        BoxFree(&(tree->root->child[0]));
        BoxFree(&(tree->root->child[1]));
    } else
        if (TreeFirstBox(tree, depth-1)) do {
                BoxFree(&(tree->box->child[0]));
                BoxFree(&(tree->box->child[1]));
            } while (TreeNextBox(tree, depth-1));
}

/* sets the flag 'flag' of all boxes on depth (choice==0) or of those for which choice[box->no]==1 */
void TreeSetFlags(Tree *tree, int depth, char *choice, byte flag) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxSetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
}

/* unsets the flag 'flag' of all boxes on 'depth' (choice==0) or of those for which choice[box->no]==1*/
void TreeUnsetFlags(Tree *tree, int depth, char *choice, byte flag) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxUnsetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
}

/* changes the flags of all boxes on 'depth' (choice==0) or of those for which choice[box->no]==1*/
void TreeChangeFlags(Tree *tree, int depth, char *choice, byte from, byte to) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxChangeFlag(tree->box, from, to);
        } while (TreeNextBox(tree, depth));
}

/* sets the values of the array 'flags' according to flags of all boxes on 'depth' */
void TreeGetFlags(Tree *tree, int depth, byte *flags) {
    int no =0;

    if (TreeFirstBox(tree, depth)) do
                                       flags[no++] = BoxGetFlags(tree->box);
        while (TreeNextBox(tree, depth));
}

/* returns the number of boxes in the tree which starts at box */
int TreeCount(Box *box) {
    int no0, no1;
    if (box) {
        no0 = TreeCount(box->child[0]);
        no1 = TreeCount(box->child[1]);
        return (no0 + no1 + 1);
    } else
        return 0;
}

/* returns the number of boxes on depth 'depth' and enumerates the boxes */
int TreeCountDepth(Tree *tree, int depth) {
    int no = 0;

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (TreeFirstBox(tree, depth)) do {
            tree->box->no = no++;
        } while (TreeNextBox(tree, depth));

    return no;
}

/* returns the depth of the tree starting at box 'box' */
int TreeDepth(Box *box) {
    int l, r;
    if (box) {
        l = TreeDepth(box->child[0]) + 1;
        r = TreeDepth(box->child[1]) + 1;
        return mymax(l, r);
    }
    return -1;
}

/* prints all boxes on depth 'depth' in ASCII format */
void TreePrint(FILE *out, Tree *tree, int depth) {
    unsigned long i;

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (TreeFirstBox(tree, depth)) do {
            for (i=0; i<tree->Q->dim; i++) fprintf(out,"%g ",tree->c[i]);
            for (i=0; i<tree->Q->dim; i++) fprintf(out,"%g ",tree->r[i]);
            fprintf(out,"%u", tree->box->flags);
            fprintf(out, "\n");
        } while (TreeNextBox(tree, depth));
}

void TreePrintToMatrix(Tree *tree, int depth, double *boxes) {
    int dim, i, j = 0;

    assert(tree);
    dim = tree->Q->dim;
    assert(depth==-1 || depth <= DEPTH_MAX(dim));

    if (TreeFirstBox(tree, depth)) do {
            for (i=0; i<dim; i++) boxes[j*(2*dim+2) + i] = tree->c[i];
            for (i=0; i<dim; i++) boxes[j*(2*dim+2) + dim + i] = tree->r[i];
            boxes[j*(2*dim+2) + 2*dim] = tree->box->flags;
            j++;
        } while (TreeNextBox(tree, depth));

}

/* saves the boxes in the subtree starting at box */
void TreeSaveBox(FILE *out, Box *box) {
    BoxSave(out, box);
    if (box) {
        TreeSaveBox(out, box->child[0]);
        TreeSaveBox(out, box->child[1]);
    }
}

/* saves the tree to stream out */
void TreeSave(FILE *out, Tree *tree) {
    fprintf(out, "Tree at %p:\n", tree);
    if (tree) {
        float one = 1;
        RectangleSave(out, tree->Q);
        fprintf(out, "  no of boxes = %d\n", TreeCount(tree->root));
        TreeSaveBox(out, tree->root);
    }
}

/* loads a subtree starting at box from stream in */
Box *TreeLoadBox(FILE *in) {
    Box *box;
    box = BoxLoad(in);
    if (box) {
        box->child[0] = TreeLoadBox(in);
        box->child[1] = TreeLoadBox(in);
    }
    return box;
}

/* loads a tree from stream in */
Tree *TreeLoad(FILE *in) {
    Rectangle *Q;
    Tree *tree;
    int n;
    float one;
    if (!fscanf(in, "Tree at %p:\n", &tree)) return 0;
    if (tree) {
        if (!(Q = RectangleLoad(in))) return 0;
        if (!fscanf(in, "  no of boxes = %d\n", &n)) return 0;
        if (!(tree = TreeNew(Q))) return 0;
        if (!(tree->root = TreeLoadBox(in))) return 0;

        /* reconstructing the sd vector */
        TreeReset(tree);
        do {
            tree->sd[tree->depth] = tree->box->sd;
        } while(TreeDownLeft(tree) || TreeDownRight(tree));

        RectangleFree(&Q);
    }
    return tree;
}


inline void TreeSetFlagRec(Tree *tree, double *a, double *b, byte flag, char *found)
{
    int i;

    if (!(tree->box->child[0]) && !(tree->box->child[1])) {
        BoxSetFlag(tree->box, flag);
        *found = 1;
        return;
    }

    i = tree->box->sd;
    if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
        if (TreeDownLeft(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
        if (TreeDownRight(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    return;
}

inline void TreeSearchBoxRec(Tree *tree, double *a, double *b, int depth, SparseVector *nos) {
  int i;

  if (depth==DEPTH(tree, depth)) {
    SparseVectorAddEntry(nos, tree->box->no, 1.0);
    return;
  }
  i = tree->box->sd;
  if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
    if (TreeDownLeft(tree)) {
      TreeSearchBoxRec(tree, a, b, depth, nos);
      TreeUp(tree);
    }
  }
  if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
    if (TreeDownRight(tree)) {
      TreeSearchBoxRec(tree, a, b, depth, nos);
      TreeUp(tree);
    }
  }
}

inline bool TreeIntersectBoxRec(Tree *tree, double *a, double *b, int depth) {
  int i;

  if (depth==DEPTH(tree, depth)) {
      return true;
  }
  i = tree->box->sd;
  if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
      if (TreeDownLeft(tree)) {
          if (TreeIntersectBoxRec(tree, a, b, depth) == true) {
              return true;
          } else {
              TreeUp(tree);
          }
      }
  }
  if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
      if (TreeDownRight(tree)) {
          if (TreeIntersectBoxRec(tree, a, b, depth) == true) {
              return true;
          } else {
              TreeUp(tree);
          }
      }
  }
  return false;
}
    
void TreeSubdivideAll(Tree *tree) 
{
    if (TreeFirstBox(tree, -1)) {
        do {
            BoxSubdivide(tree->box, tree->sd[tree->depth]);
        } while (TreeNextBox(tree, -1));
    }
}

void TreeSetFlagsAll(Tree *tree, int depth, byte flag)
{
    if (TreeFirstBox(tree, depth)) {
        do {
            BoxSetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
    }
}

void TreeUnsetFlagsAll(Tree *tree, int depth, byte flag)
{
    if (TreeFirstBox(tree, depth)) {
        do {
            BoxUnsetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
    }
}

void TreeSetFlagsVect(Tree *tree, int depth, char *vect, byte flag)
{
    int i = 0;
    if (TreeFirstBox(tree, depth)) do {
        if (vect[i]) {
            BoxSetFlag(tree->box, flag);
        } else {
            BoxUnsetFlag(tree->box, flag);
        }
        i++;
    } while (TreeNextBox(tree, depth));
}

#ifdef __cplusplus
}
#endif

#endif
