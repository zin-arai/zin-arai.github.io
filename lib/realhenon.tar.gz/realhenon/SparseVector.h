#ifndef _SparseVector_h
#define _SparseVector_h

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int dim;              /* dimension of the vector */
    int nz;               /* number of nonzeros of the vector */
    int size;             /* size of rows and entries */
    int *rows;
    double *entries;
} SparseVector;
  
SparseVector *SparseVectorNew(int dim, int size) {
  SparseVector *v;

  NEW(v, SparseVector*, 1);
  v->dim = dim;
  v->nz = 0;
  v->size = size;
  NEW(v->rows, int*, size);
  NEW(v->entries, double*, size);

  return v;
}

void SparseVectorFree(SparseVector **v) {
  if (*v) {
    free((*v)->entries);
    free((*v)->rows);
    free(*v);
    *v = 0;
  }
}

void SparseVectorAddEntry(SparseVector *v, int row, double entry) {
    if (v->nz >= v->size) {
        v->size *= 2;
        v->rows = (int*)realloc(v->rows, v->size*sizeof(int));
        v->entries = (double*)realloc(v->entries, v->size*sizeof(double));
    }
    v->rows[v->nz] = row;
    v->entries[v->nz] = entry;
    v->nz++;
}

#ifdef __cplusplus
}
#endif

#endif
