%%% tree for TM
center = [0;0;0;0];
radius = [8;8;1;1];
tree = Tree(center,radius);

phase_sd = tree.sd;
phase_sd( 1) = 0; phase_sd( 2) = 1;
phase_sd( 3) = 0; phase_sd( 4) = 1;
phase_sd( 5) = 0; phase_sd( 6) = 1;
phase_sd( 7) = 0; phase_sd( 8) = 1;
phase_sd( 9) = 0; phase_sd(10) = 1;
phase_sd(11) = 0; phase_sd(12) = 1;
tree.sd = phase_sd;

%%% tree for the parameter space
param_center = [4;0];
param_radius = [8;1];
param_tree = Tree(param_center,param_radius);
hyp_tree = Tree(param_center,param_radius);
param_sd = param_tree.sd;
param_sd(1) = 0; param_sd(2) = 0; param_sd(3) = 0;
param_tree.sd = param_sd;
hyp_tree.sd = param_sd;
clear param_sd;
param_tree.set_flags('all',1); param_tree.subdivide(1);
param_tree.set_flags('all',1); param_tree.subdivide(1);

% param_stack = [weight, param_depth, phase_depth, data_number, a, b]
param_stack = [1,2,0,0,-2,0;
               1,2,0,1, 2,0;
               1,2,0,2, 6,0;
               1,2,0,3,10,0];
filename = 'data/00000000.tree';
tree.save(filename); eval(sprintf('!gzip -1f %s',filename));
filename = 'data/00000001.tree';
tree.save(filename); eval(sprintf('!gzip -1f %s',filename));
filename = 'data/00000002.tree';
tree.save(filename); eval(sprintf('!gzip -1f %s',filename));
filename = 'data/00000003.tree';
tree.save(filename); eval(sprintf('!gzip -1f %s',filename));

resume_time = 0;
main_routine(param_tree, hyp_tree, param_stack, phase_sd, resume_time);
