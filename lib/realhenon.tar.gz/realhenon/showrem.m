% showhyp --> landscape --> print -deps2 -painter test.eps
param_tree = Tree('data/remaining.tree');
clf;
plotb(param_tree,-1,'g');
hold on;
xlabel('a','Rot',0,'FontName','Times','FontAngle','italic','FontSize',16);
ylabel('b','Rot',0,'FontName','Times','FontAngle','italic','FontSize',16);
h = gca;
set(h,'Fontname','Times','Fontsize',8)
set(h,'TickDir','out')
axis([-4 12 -1 1])
grid
