#include "interval.hpp"

extern "C" {
  void realhenon(int n, double *param_inf, double *param_sup,
                 double *pR, double *infv, double *supv);
}

extern "C" {
  void t_realhenon(int n, double *param_inf, double *param_sup,
                   double *pR, double *infv, double *supv);
}

void realhenon(int n, double *param_inf, double *param_sup,
               double *pR, double *infv, double *supv)
{
    int i;
    interval a, b, x, y, X, Y;

    // paramters
    a = interval(param_inf[0], param_sup[0]);
    b = interval(param_inf[1], param_sup[1]);

    for (i=0; i<n; i++) {
        // domain cube
        x = interval(*(pR + i*6 + 0) - *(pR + i*6 + 2), 
                     *(pR + i*6 + 0) + *(pR + i*6 + 2));
        y = interval(*(pR + i*6 + 1) - *(pR + i*6 + 3), 
                     *(pR + i*6 + 1) + *(pR + i*6 + 3));

        // Henon map
        X = a - x*x + b*y;
        Y = x;

        // image cube
        *(infv + i*2 + 0) = X.lower();
        *(infv + i*2 + 1) = Y.lower();
        *(supv + i*2 + 0) = X.upper();
        *(supv + i*2 + 1) = Y.upper();
    }
}

void t_realhenon(int n, double *param_inf, double *param_sup,
                 double *pR, double *infv, double *supv)
{
    int i;
    interval a, b;
    interval x, y, v, w, X, Y, V, W;

    // parameters
    a = interval(param_inf[0], param_sup[0]);
    b = interval(param_inf[1], param_sup[1]);

    for (i=0; i<n; i++) {
        // domian cube
        x = interval(*(pR + i*10 + 0) - *(pR + i*10 + 4), 
                     *(pR + i*10 + 0) + *(pR + i*10 + 4));
        y = interval(*(pR + i*10 + 1) - *(pR + i*10 + 5), 
                     *(pR + i*10 + 1) + *(pR + i*10 + 5));
        v = interval(*(pR + i*10 + 2) - *(pR + i*10 + 6), 
                     *(pR + i*10 + 2) + *(pR + i*10 + 6));
        w = interval(*(pR + i*10 + 3) - *(pR + i*10 + 7), 
                     *(pR + i*10 + 3) + *(pR + i*10 + 7));

        // Henon map on TM
        // Remark: We use the midpoint of x and v for the value of Y and W.
        // This can be justified only under the following assumptions:
        // 1. grid size of x direction is smaller than that of y direction.
        // 2. grid size of v direction is smaller than that of w direction.
        // 3. inclusion of the true image of the domain cube to the *interior*
        //    of the image cube is not required.
        // Otherwise, we must use "Y = x" and "W = v".
        X = a - x*x + b*y;
        Y = mid(x);
        V = -2*x*v + b*w;
        W = mid(v);

        // image cube
        *(infv + i*4 + 0) = X.lower();
        *(infv + i*4 + 1) = Y.lower();
        *(infv + i*4 + 2) = V.lower();
        *(infv + i*4 + 3) = W.lower();
        *(supv + i*4 + 0) = X.upper();
        *(supv + i*4 + 1) = Y.upper();
        *(supv + i*4 + 2) = V.upper();
        *(supv + i*4 + 3) = W.upper();
    }
}
