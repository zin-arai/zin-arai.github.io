% GAIO example script 
% computes the unstable manifold of an equilibrium 
% in the Lorenz system

lor = Model('lorenz');
lor.beta = 8/3;
lor.rho = 28;

rk = Integrator('RungeKutta4');
rk.model = lor;

dp = Integrator('DormandPrince853');
dp.model = lor;

edges = Points('Edges', lor.dim, 120);
center = Points('Center', lor.dim);
mc = Points('MonteCarlo', lor.dim, 50);

t = Tree(lor.dim, lor.center + [0.1 0.1 0.1]', lor.radius);
t.integrator = rk;
t.domain_points = edges;
t.image_points = center;

rk.tFinal = 0.2;
depth = 24;

no_of_steps = 100;
x0 = lor.fixed_point;
t.insert(x0, depth);
gum(t, depth, no_of_steps);

