% GAIO example script 
% computes the unstable manifold of an equilibrium 
% in the Lorenz system

lorenz = Model('lorenz');
lorenz.beta = 8/3;
lorenz.rho = 14;

rk = Integrator('RungeKutta4');
rk.model = lorenz;

dp = Integrator('DormandPrince853');
dp.model = lorenz;

edges = Points('Edges', lorenz.dim, 120);
center = Points('Center', lorenz.dim);
mc = Points('MonteCarlo', lorenz.dim, 50);

t = Tree(lorenz.dim, lorenz.center + [0.1 0.1 0.1]', lorenz.radius);
t.integrator = dp;
t.domain_points = edges;
t.image_points = center;

rk.tFinal = 0.2;
depth = 21;

no_of_steps = 100;
x0 = lorenz.fixed_point;
t.insert(x0, depth);
gum(t, depth, no_of_steps);

P = t.matrix(mc);
[v,l] = eigs(P,4);
b = t.boxes(-1);
I = find(max(diag(l))==diag(l));
p = v(:,I);
show3(b', 'r', 3, [1 2 3], 'r', 0.05, max(log(abs(p))+20,0));
