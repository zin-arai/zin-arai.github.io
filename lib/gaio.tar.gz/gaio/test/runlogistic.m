% GAIO example script
% computes the SRB measure of the logistic map

model = Model('logistic');

edges = Points('Edges', 1, 50);
center = Points('Center', 1);
mc = Points('MonteCarlo', 1, 200);

map = Integrator('Map');
map.model = model;

t = Tree(model.dim, model.center, model.radius);
t.integrator = map;
t.domain_points = edges;
t.image_points = center;

depth = 8;
to_be_subdivided = 8;
for i=1:depth,
 t.set_flags('all', to_be_subdivided);
 t.subdivide;
end

[m,l] = im(t, mc);





