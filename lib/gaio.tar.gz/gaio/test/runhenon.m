% GAIO example script 
% computes the relative global attractor for the henon map

addpath(strcat(getenv('GAIODIR'),'/matlab'))

henon = Model('henon');

map = Integrator('Map');
map.model = henon;

edges = Points('Edges', 2, 100);
center = Points('Center', 2, 1);

t = Tree([0.01 0.01], henon.radius);
t.integrator = map;
t.domain_points = edges;
t.image_points = center;

rga(t,12);

plotb(t);
