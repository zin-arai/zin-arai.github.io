% GAIO example script 
% computes all zeros of the Himmelblau function

addpath(strcat(getenv('GAIODIR'),'/matlab'))

m = Model('himmelblau');
i = Integrator('Newton');
i.model = m;

mc = Points('Grid', m.dim, 10);
c = Points('Center', m.dim);

t = Tree(m.center, m.radius);
t.integrator = i;
t.domain_points = mc;
t.image_points = c;

i.tFinal = 2;
rga(t, 10);

plotb(t);
