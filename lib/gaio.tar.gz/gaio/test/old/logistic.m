
model = Model('logistic');
edges = Points('Edges', 1, 50);
center = Points('Center', 1);
mc = Points('MonteCarlo', 1, 20);
map = Integrator('Map');
map.model = model;

t = Tree(model.dim, model.center, model.radius);
t.integrator = map;
t.domain_points = edges;
t.image_points = center;

subdivision(t,1);
depth = -1;
for i=31:30,
  aim(t, 'exhaustion');
  %subdivision(t,1);
  A = t.matrix('exhaustion', depth, 26);
  options.disp=0;
  [m,l]=eigs(A,1,options);
  m = abs(m)/norm(m,1);
  v = t.volume(depth);
  h = abs(m)./(2*v);
  b = t.boxes(depth);
  e = errlog(b,h);
  ph = projlog(b);
  pe = errlog(b,ph);
  perr_hm(i,:)=[size(b,2), sum(e), sum(pe), sum(e-pe)]
end

subdivision(t,8);

b=t.boxes(-1);