henon = Model("henon")
map = Integrator("Map")
map.model = henon
o=map.eval([1,1],10)
save(o,'o.dat')

lip = Points("Lipschitz", 2, "1")
edges = Points("Edges", 2,"25")
center = Points("Center", 2, "1")
grid = Points("Grid",2,"200")
mc = Points("MonteCarlo", 2, "20")

t = Tree(henon.dim, henon.center, henon.radius)
t.integrator = map
t.domain_points = edges
t.image_points = center

subdivision(t,8)

A = t.matrix(mc)

ea = array(A.equilibria(), 'i')-48
i = nonzero(ea)


G = A.graph()
