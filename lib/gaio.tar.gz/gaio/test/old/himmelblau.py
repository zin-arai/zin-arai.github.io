m = Model("himmelblau")
i = Integrator("Newton")
i.model = m

mc = Points("Grid", m.dim, "10")
c = Points("Center", m.dim, "1")

t = Tree(m.dim, m.center, m.radius)
t.integrator = i
t.domain_points = mc
t.image_points = c

i.tFinal = 2
subdivision(t, 10)

b = t.boxes(-1)
show2(b,0,1)
