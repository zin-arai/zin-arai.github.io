lorenz = Model("lorenz")
euler = Integrator("Euler")
mp = Integrator("MidpointRule")
rk = Integrator("RungeKutta4")
gauss6 = Integrator("Gauss6")
euler.model = lorenz
mp.model = lorenz
rk.model = lorenz
gauss6.model = lorenz

x0 = array([1.0, 1.0, 1.0])
mp.tFinal=0.01
mp.eval("e.dat", x0, 1)
euler.tFinal = 0.01
euler.eval("e.dat", x0, 1)
rk.tFinal = 0.01
rk.eval("e.dat", x0, 1)
gauss6.tFinal = 0.01
gauss6.eval("e.dat", x0, 1)

ad = Points("Adaptive", lorenz.dim, "1")
edges = Points("Edges", lorenz.dim,"73")
center = Points("Center", lorenz.dim, "1")
mc = Points("MonteCarlo", lorenz.dim, "20")
ad = Points("Adaptive", lorenz.dim, "20")

t = Tree(lorenz.dim, lorenz.center, lorenz.radius)
t.integrator = rk
t.domain_points = edges
t.image_points = center

rk.tFinal=0.2
depth=24
x = lorenz.fixed_point

t.insert(x,depth)
continuation(t,depth,10)

A=t.matrix(mc)
[l,v]=eigs(A)
t.color(colors(v))
t.save('test.g')

