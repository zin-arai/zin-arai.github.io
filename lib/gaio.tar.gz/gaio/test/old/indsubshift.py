def sd_scc1(tree, steps = 1):
  for i in range(0, steps):
    tree.set_flags("all", to_be_subdivided)
    tree.subdivide()
    tree.images()
    A = tree.images_to_matrix()
    G = A.graph()
    scc = G.strong_components()
    # flags = A.sinks(scc)
    flags = where(scc,'1','0').tostring()
    tree.set_flags(flags, hit)
    tree.remove()
    print 'step ' + `i` + ': ' + `tree.count(-1)` + ' boxes'

model = Model("ohenon")
map = Integrator("Map")
map.model = model
dom = Points("Grid", 2,"10000")
img = Points("Center", 2, "1")
mc = Points("MonteCarlo", 2, "10")
lip = Points('Lipschitz', 2)
vert = Points('Vertices', 2)
t = Tree(model.dim, model.center, model.radius)
t.integrator = map

# Grid coverings
t.domain_points = dom
t.image_points = img

sd_scc(t, dom, 16)

t.save('henon_16.g')
A=t.matrix(dom)
A.save('A_16.dat')

t = TreeLoad('henon_22.g')
A=SparseMatrixLoad('A_22.dat')
HA=IndSubshift(A)
print HA.dim
[l,v]=eigs(HA)
print l, log(l)

# Lipschitz coverings
t.domain_points = lip
t.image_points = vert

sd_scc1(t, 2)
flags=where(ones(t.count(-1)), '1', '0').tostring()
t.delete_images(flags)
t.images()
A=t.images_to_matrix()
HA=IndSubshift(A)
print HA.dim
[l,v]=eigs(HA)
print l, log(l)
