lorenz = Model("lorenz")
dp78 = Integrator("DormandPrince78")
dp853 = Integrator("DormandPrince853")
dp78.model = lorenz
dp853.model = lorenz

x0 = array([1.0, 1.0, 1.0])


y = dp78.eval("e.dat", x0, 1)
z = dp853.eval("e.dat", x0, 1)


