chua = Model('chua')
euler = Integrator('Euler')
mp = Integrator('MidpointRule')
rk = Integrator('RungeKutta4')
gauss6 = Integrator('Gauss6')
euler.model = chua
mp.model = chua
rk.model = chua
gauss6.model = chua

x0 = [1.0, 1.0, 1.0];
mp.tFinal=0.01
mp.eval(x0', 1)
euler.tFinal = 0.01
euler.eval(x0, 1)
rk.tFinal = 0.01
rk.eval(x0, 1)
gauss6.tFinal = 0.01
gauss6.eval(x0, 1)

ad = Points('Adaptive', chua.dim)
edges = Points('Edges', chua.dim, 73)
center = Points('Center', chua.dim)
mc = Points('MonteCarlo', chua.dim, 20)
ad = Points('Adaptive', chua.dim)

t = Tree(chua.center, chua.radius)
t.integrator = rk
t.domain_points = edges
t.image_points = center

rk.tFinal=0.2
depth=24
x = chua.fixed_point
t.insert(x,depth)
gum(t,depth,10)
A=t.matrix(mc)
[v, l]=eigs(A)
t.color(colors(v))
t.save('test.g')

