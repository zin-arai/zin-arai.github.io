
model = Model("logistic")
edges = Points("Edges", 1,"50")
center = Points("Center", 1, "1")
mc = Points("MonteCarlo", 1, "20")
map = Integrator("Map")
map.model = model

t = Tree(model.dim, model.center, model.radius)
t.integrator = map
t.domain_points = edges
t.image_points = center

subdivision(t,3)
subdivision(t,1)
A = t.matrix(16,-1,'exhaustion')
[l,v] = eigs(A)  
save(v,'v.dat')
save(t.boxes(-1),'b.dat')
#t.density(m,-1) 
