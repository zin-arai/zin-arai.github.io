c = Model("crtbp")

e = Integrator("Euler")
rk = Integrator("RungeKutta4")
dp  = Integrator("DormandPrince78")

e.model = c
smp.model = c
rk.model = c
dp.model = c

x0 = array(c.fixed_point,'d')

e.eval(x0, 1)
rk.eval(x0, 1)
dp.eval(x0, 1)
