henon = Model("henon")
henon.a = 1.3
map = Integrator("Map")
map.model = henon
edges = Points("Edges", 2,"10")
center = Points("Center", 2, "1")
mc = Points("MonteCarlo", 2, "200")
lip = Points("Lipschitz", 2)
vert = Points('Vertices', 2)
t = Tree(henon.dim, [0.01, 0.01], henon.radius)
t.integrator = map
t.domain_points = edges
t.image_points = center
depth=4

for i in range(0, depth):
    t.set_flags("all", to_be_subdivided)
    t.subdivide()

save(t.boxes(),'b.dat')

sd_adap(t,mc)
save(t.boxes(),'b.dat')

subdivision(t,4)
A = t.matrix(mc)
e = A.equilibria()
ea = array(e,'i')-48
nz = nonzero(ea)
G = A.graph()
sp = G.shortest_path(36,20)
save(t.boxes(),'b.dat')
