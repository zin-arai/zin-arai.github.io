#include <gaio/Model.h>
#include <gaio/Iter.h>
#include <gaio/Points.h>
#include <gaio/Measure.h>
#include <gaio/Newton.h>
#include <gaio/Node.h>
#include <gaio/Set.h>
#include <gaio/IndSubshift.h>
#include <gaio/GaussNewton.h>

char delim[80] = "________________________________________________________________________________";

void qr_test() {
  Matrix *A = 0, *Q = 0, *R = 0, *b = 0;

  printf("%s\nqr_test\n", delim);

  A = MatrixNew(3, 2);
  MatrixSetElement(A, 0, 0, 1);
  MatrixSetElement(A, 0, 1, 2);
  MatrixSetElement(A, 1, 0, 3);
  MatrixSetElement(A, 1, 1, 4);
  MatrixSetElement(A, 2, 0, 5);
  MatrixSetElement(A, 2, 1, 6);
  MatrixPrint(stdout, A);
  QR(A, &Q, &R);
  MatrixPrint(stdout, Q);
  MatrixPrint(stdout, R);

  b = MatrixNew(2, 1);
  MatrixSetElement(b, 0, 0, 1);
  MatrixSetElement(b, 1, 0, 2);
  MatrixPrint(stdout, b);
}

void f(double *x, double *u, double *y) {
  y[0] = x[0];
  y[1] = x[1];
  y[2] = x[0]*x[1] + 10;
}

void Df(double *x, double *u, double *Dfx) {
  Dfx[0] = 1;
  Dfx[1] = 0;
  Dfx[2] = x[1];
  Dfx[3] = 0;
  Dfx[4] = 1;
  Dfx[5] = x[0];
}


void gauss_newton_test() {
  
  GaussNewton *gn;
  double *x, *y, *u = 0;
  
  printf("%s\ngauss_newton_test\n", delim);

  gn = GaussNewtonNew(3, 2, f, Df);
  gn->iter_max = 100;
  GaussNewtonInfo(stdout, gn);
  
  NEW(x, 2);
  NEW(y, 2);
  
  x[0] = 0.1;
  x[1] = 0.1;

  GaussNewtonStep(gn, x, u, y);
  GaussNewtonSolve(gn, x, u, y);

  free(x);
  free(y);
}

main () {


  gauss_newton_test();
  
 


}


