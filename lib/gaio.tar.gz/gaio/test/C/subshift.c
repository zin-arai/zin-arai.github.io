#include <gaio/Model.h>
#include <gaio/Iter.h>
#include <gaio/Points.h>
#include <gaio/Measure.h>
#include <gaio/Newton.h>
#include <gaio/Node.h>
#include <gaio/Set.h>
#include <gaio/IndSubshift.h>

char delim[80] = "________________________________________________________________________________";

SparseMatrix *A;



void points_test() {
  int i, dim;
  Model *m = 0;
  Integrator *itgr = 0;  
  Rectangle *Q = 0;
  Iter  *t = 0;
  Points *mc = 0, *lip = 0, *ad = 0,*center = 0, *vert = 0, *edges = 0, *grid = 0;
  char flags[] = "all";

  m = ModelNew("ohenon");
  dim = *m->dim;
  ModelInfo(stdout, m);
/*   ModelInfo(stdout, m); */
  itgr =IntegratorNew("Map");
  IntegratorSetModel(itgr, m);
  Q = RectangleNew(m->c, m->r, dim);
  t = IterNew(Q);
  t->integrator = itgr;
  mc = PointsNew("MonteCarlo", dim, "20");
  lip = PointsNew("Lipschitz", dim, "20");
  ad = PointsNew("Adaptive", dim, "20");
  center = PointsNew("Center", dim, "20");
  vert = PointsNew("Vertices", dim, "20");
  edges = PointsNew("Edges", dim, "20");  
  grid = PointsNew("Grid", dim, "100");  
  t->domPoints = grid;
  t->imgPoints = center;
  IterInfo(stdout, t);
  for (i=0; i<18; i++) {
    TreeSetFlags(t->tree, -1, flags, SUBDIVIDE);
    TreeSubdivide(t->tree, SUBDIVIDE);
    IterMapAll(t, -1); 
    TreeRemove(t->tree->root, HIT);
    printf("n = %d\n", TreeCountDepth(t->tree, -1));
  }
  A = MonteCarloMatrix(t, -1, mc);
/*   SparseMatrixInfo(stdout, A); */

}

void set_test() {
  int r;
  Set *s;
  Stack *st;
  SetElement *n1, *n2, *n3;

  printf("%s\nset_test\n", delim);

  n1 = SetElementNew(1, 0, 0, 0);
  n2 = SetElementNew(2, 0, 0, 0);
  n3 = SetElementNew(30, 0, 0, 0);
  s = SetNew();
  SetInsert(s, n1);
  SetInsert(s, n2);
  SetInsert(s, n3);
  printf("s->no=%d\n", s->no_of_elements);

  n1 = SetContains(s, 30);
  printf("n1=%x\n", n1);

  st = SetToStack(s);
  StackInfo(stdout, st);
  
  SetElementFree(&n1);
  SetElementFree(&n2);
  SetFree(&s);
  
}

void node_test() {
  Node *n;

  printf("%s\nnode_test\n", delim);

  n = NodeNew(1);
  NodeInsert(n, 1);
  NodeInsert(n, 2);
  NodeInfo(stdout, 0, n);

}

void sofic_test() {
  int i;
  IndSubshift *s;
  char node[10], letters[10];

  printf("%s\nsofic_test\n", delim);

  A = SparseMatrixNew(10);
  s = IndSubshiftNew(A, letters);
  memset(node, 0, 10);
  for (i=0; i<10; i++) {
    int l = floor(drand48()*9);
    printf("%d ", l);
    node[l] = 1;
  } 
  IndSubshiftInsert(s, node);
  memset(node, 0, 10);
  for (i=0; i<10; i++) {
    int l = floor(drand48()*9);
    printf("%d ", l);
    node[l] = 1;
  } 
   IndSubshiftInsert(s, node);
  IndSubshiftInfo(stdout, s);

}


void IndSubshift_test() {
  char *letters;
  int i, nconv, nev = 1;
  SparseMatrix *HA;
  IndSubshift *s;
  FILE *is;
  static char *which = "LR";
  double *dr = 0, *di = 0, *w = 0;

  printf("%s\nIndSubshift_test\n", delim);

  is = fopen("A.dat", "w");

  NEW(letters, A->dim);
  for (i=0; i<A->dim/2; i++) letters[i] = 0;
  for (i=A->dim/2; i<A->dim; i++) letters[i] = 1;
  
  s = IndSubshiftNew(A, letters);
  HA = IndSubshiftGraph(s);
/*   SparseMatrixInfo(stdout, A); */
/*   SparseMatrixInfo(stdout, HA);  */
/*   SparseMatrixPrint(is, HA); */
/*   IndSubshiftInfo(stdout, s); */
  printf("dim_sub = %d, no_of_nodes = %d\n", HA->dim, _Node_no_of_nodes);

  nconv = ARPACK(HA, nev, which, &dr, &di, &w);

  printf("nconv = %d\n", nconv);
  printf(" l = %lg, log(l) = %lg\n", dr[0], log(dr[0]));
  
  fclose(is);
  free(letters);

}


main () {
  unsigned int flag, i;
  

/*   set_test(); */
/*   node_test(); */
/*   sofic_test(); */
  points_test(); 
  IndSubshift_test();

}


