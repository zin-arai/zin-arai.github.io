#include <iostream/iostream.h>

main() {
  int a;
  a=1;
cout << a;
}


