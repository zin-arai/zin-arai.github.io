#include <gaio/Model.h>
#include <gaio/Iter.h>
#include <gaio/Points.h>
#include <gaio/Measure.h>
#include <gaio/Newton.h>

char delim[80] = "________________________________________________________________________________";

SparseMatrix *A;


void points_test() {
  int i, dim;
  Model *m = 0;
  Integrator *itgr = 0;  
  Rectangle *Q = 0;
  Iter  *t = 0;
  Points *mc = 0, *lip = 0, *ad = 0,*center = 0, *vert = 0, *edges = 0;
  char flags[] = "all";

  m = ModelNew("henon");
  dim = *m->dim;
  ModelInfo(stdout, m);
  itgr =IntegratorNew("Map");
  IntegratorSetModel(itgr, m);
  Q = RectangleNew(m->c, m->r, dim);
  t = IterNew(Q);
  t->integrator = itgr;
  mc = PointsNew("MonteCarlo", dim, "20");
  lip = PointsNew("Lipschitz", dim, "20");
  ad = PointsNew("Adaptive", dim, "20");
  center = PointsNew("Center", dim, "20");
  vert = PointsNew("Vertices", dim, "20");
  edges = PointsNew("Edges", dim, "20");  
  t->domPoints = edges;
  t->imgPoints = center;
  IterInfo(stdout, t);
  for (i=0; i<16; i++) {
    TreeSetFlags(t->tree, -1, flags, SUBDIVIDE);
    TreeSubdivide(t->tree, SUBDIVIDE);
    IterMapAll(t, -1); 
    TreeRemove(t->tree->root, HIT);
    printf("n = %d\n", TreeCountDepth(t->tree, -1));
  }
  A = MonteCarloMatrix(t, -1, mc);
  /* SparseMatrixInfo(stdout, A); */

}

#include <gaio/Graph.h>

void ShortestPath_test() {

  double *nz, lnz, i, *p;
  char *e;
  Graph *G;

  printf("%s\nShortestPath_test\n", delim);

  NEW(nz, A->dim);
  lnz = 0;
  G = TransitionGraph(A);
  e = SparseMatrixEquilibria(A);
  for (i=0; i<=A->dim; i++) {
    if (e[(int)i]!='0') {
      nz[(int)lnz] = i;
      lnz++;
    }
  }
  VecPrint(stdout, nz, lnz);
  ShortestPath(G, nz[0], nz[2], p);
}


/* #include <LEDA/graph.h> */
/* #include <LEDA/graph_alg.h> */

/* void DIJKSTRA_test() { */
  
/*   node n0, n1; */
  
/*   GRAPH<int,double> G; */

/*   n0 = G.new_node(0); */
/*   n1 = G.new_node(1); */
/*   G.new_edge(n0, n1, 1); */

/*   node_array<edge> pred; */
/*   edge_array<double> c = G.edge_data(); */

/*   DIJKSTRA(G, n0, n1, c, pred); */

  
/* } */

  

main () {
  unsigned int flag, i;
  
  points_test(); 

  ShortestPath_test();

}


