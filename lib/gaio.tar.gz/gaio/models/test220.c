/* 
*
*  Test220 von Prof. Schittkowski
*
*/

#include <math.h>
#include <gaio/defs.h>

char *name = "Test220";
char *typ = "map";
int   dim  = 10;
int   paramDim = 0;
char *paramNames[];
double c[10] = { 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2, 0.2 };
double r[10] = { 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5 };
double tFinal = 1;

/* this is the "right hand side" of the system, i.e. a map, a vector field, ... */
void rhs(double *x, double *u, double *y) {
 int i,j;
 
 for( i=0;i<dim;i++ )
 { y[i] = dim;
   for( j=0;j<dim;j++ ) y[i] -= cos(x[j]);
   y[i] += (i+1)*(1.0-cos(x[i])) - sin(x[i]);
 }    
   
}

/* this is the derivative of rhs */
void drhs(double *x, double *u, double *D) {
 int i,j;
 
 for( i=0;i<dim;i++ )
 { for( j=0;j<dim;j++ )
   { if( i==j )
       D[j*dim+i] = sin(x[i]) + (i+1)*sin(x[i]) - cos(x[i]);
     else
       D[j*dim+i] = sin(x[j]);  
   }
 }   
}

/* this is a local Lipschitz estimate for rhs. The matrix L must be computed
   in such a way that |f(x)-f(y)| <= L |x-y| (componentwise) for all
   x,y \in B(c,r)={ z : |c-x| <= r } */
void lip(double *c, double *r, double *L) {}

/* the function fixed_point may be used to provide a fixed point of
   rhs ;-), i.e. computes a point such that rhs(x)=x or a zero of
   rhs or ... */
void fixed_point(double *x) {}


