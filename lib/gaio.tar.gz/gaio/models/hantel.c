/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "A simple Hamiltonian system";
char *typ = "ode";
int   dim  = 2;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = 1;
double c[2] = { 0.999, -0.001 };
double r[2] = { 1, 2 };
double tFinal = 0.05;

void rhs(double *x, double *u, double *y) {
  y[0] = x[1];
  y[1] = -4*mu*(x[0]*x[0] - 1)*x[0];
}

void fixed_point(double *x) {
  x[0] = 0;
  x[1] = 0;
}
