/* Copyright (c) 1998 Stefan Sertl, for details see COPYING */

#include <gaio/Matrix.h>

char *name = "three coupled flipflops";
char *typ = "map";
int   dim  = 12;
int   paramDim = 6;
char *paramNames[] = { "lambda", "v0", "v1", "v2", "g0", "g1" };
double lambda = 3.0, v0 = 1.0, v1= 2.0, v2 = 1.0, g0=0.01, g1=0.01;
double c[12] = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };
double r[12] = { 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2 };
double tFinal = 1;

static double v, g;
static double r0=60.0, rl=4.5e5, gminmos=1e-15, beta=8.5e-6, delta=2e-2;

static double ictrl(double a, double b) {
  if (b <= v)
    return 0.0;
  else if (b <= a+v)
    return beta*(b-v)*(b-v)*(1.0-delta*a);
  else
    return beta*a*(1.0+delta*a)*(2.0*(b-v)-a);
}

static void dictrl(double a, double b, double *dida, double *didb) {
  if (b <= v) {
    (*dida) = 0.0;
    (*didb) = 0.0;
  }
  else if (b <= a+v) {
    (*dida) = -delta*beta*(b-v)*(b-v);
    (*didb) = beta*2.0*(b-v)*(1.0-delta*a);
  }
  else {
    (*dida) = beta*((1.0+delta*a)*(2.0*(b-v)-a) +
           a*delta*(2.0*(b-v)-a)-a*(1.0+delta*a));
    (*didb) = beta*a*(1.0+delta*a)*2.0;
  }
}
   
static void inv(int ndim, int n, int m, int nm1, double *x, double lambda,
                double *f) {
  f[n] = f[n] + (lambda - x[n])/rl + (x[m]-x[n])/r0;
  f[m] = f[m] - x[m]*gminmos + (x[n]-x[m])/r0 - ictrl(x[n],x[nm1]);
}

static void dinv(int ndim, int n, int m, int nm1, double *x, double lambda,
		 double *dfdx) {
  double dida, didb;

  dictrl(x[n],x[nm1],&dida,&didb);

  dfdx[n+n*ndim] += -1.0/rl - 1.0/r0;
  dfdx[m+n*ndim] += 1.0/r0 - dida;
  dfdx[n+m*ndim] += 1.0/r0;
  dfdx[m+m*ndim] += -gminmos - 1.0/r0;
  dfdx[m+nm1*ndim] += -didb;
}

static void resstr(int ndim, int n, int m, double *x, double g,
                   double *f) {
  f[n] += g*(x[n]-x[m]);
  f[m] += g*(x[m]-x[n]);
}

static void dresstr(int ndim, int n, int m, double *x, double g,
		    double *dfdx) {

  dfdx[n+n*ndim] += g;
  dfdx[n+m*ndim] += -g;
  dfdx[m+n*ndim] += -g;
  dfdx[m+m*ndim] += g;
}

void rhs(double *x, double *u, double *y) {
  int i;

  for (i=0; i<dim; i++)
    y[i] = 0.0;

  v=v0;
  inv(dim, 0, 1, 2, x, lambda, y);
  inv(dim, 2, 3, 0, x, lambda, y);
  g=g0;
  resstr(dim, 2, 4, x, g, y);
  v=v1;
  inv(dim, 4, 5, 6, x, lambda, y);
  inv(dim, 6, 7, 4, x, lambda, y);
  g=g1;
  resstr(dim, 6, 8, x, g, y);
  v=v2;
  inv(dim, 8, 9, 10, x, lambda, y);
  inv(dim, 10, 11, 8, x, lambda, y);  
}

void drhs(double *x, double *u, double *Df) {
  v=v0;
  dinv(dim, 0, 1, 2, x, lambda, Df);
  dinv(dim, 2, 3, 0, x, lambda, Df);
  g=g0;
  dresstr(dim, 2, 4, x, g, Df);
  v=v1;
  dinv(dim, 4, 5, 6, x, lambda, Df);
  dinv(dim, 6, 7, 4, x, lambda, Df);
  g=g1;
  dresstr(dim, 6, 8, x, g, Df);
  v=v2;
  dinv(dim, 8, 9, 10, x, lambda, Df);
  dinv(dim, 10, 11, 8, x, lambda, Df);
}

