/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>
#include <gaio/defs.h>

char *name = "The Duffing oszillator";
char *typ = "map";
int   dim  = 2;
int   paramDim = 2;
char *paramNames[] = { "delta", "mu" , "h"};
double delta = 0.2, mu = 0.36, h = 0.05;
double c[2] = { 0, 0.3 };
double r[2] = { 1.5, 0.9 };
double tFinal = 1;

void duffing(double *x, double *y, double t) {
  y[0] = x[1];
  y[1] = -delta*x[1] + x[0] - x[0]*x[0]*x[0] + mu*cos(t);
}

void rkstep(double *x, double *y, double hd, double t) {
  int i;
  double z[2], k1[2], k2[2], k3[2], k4[2];
  duffing(x,k1,t);
  for (i=0; i<2; i++) z[i] = x[i] + hd/2*k1[i];
  duffing(z, k2, t+hd/2.0);
  for (i=0; i<2; i++) z[i] = x[i] + hd/2*k2[i];
  duffing(z, k3, t+hd/2.0);
  for (i=0; i<2; i++) z[i] = x[i] + hd*k3[i];
  duffing(z, k4, t+hd);
  for (i=0; i<2; i++) 
    y[i] = x[i] + (hd/6)*(k1[i] + 2*k2[i] + 2*k3[i] + k4[i]);
}

void rhs(double *x, double *u, double *y) {
  int i;
  double tmp[2], t = 0, hd = h*2*3.1415927;
  for (i=0; i<2; i++) tmp[i] = x[i];
  while ( t < 2*3.1415927   ) {
    rkstep(tmp, y, hd, t);
    t += hd;
    for (i=0; i<2; i++) tmp[i] = y[i];
  }
}
