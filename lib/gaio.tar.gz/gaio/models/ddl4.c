/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "Ding, Du and Li's example 4";
char *typ = "map";
int   dim  = 1;
int   paramDim = 0;
char *paramNames;
double c[1] = { 0.5 };
double r[1] = { 0.5 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
    if (x[0] < 1./3.) 
      y[0] = (2*x[0])/(1-x[0]);
    else
      y[0] = (1-x[0])/(2*x[0]);
}


