/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "2D linear map";
char *typ = "map";
int   dim  = 2;
int   paramDim = 2;
char *paramNames[] = { "a", "b" };
double a = 1.2, b = 0.2;
double c[2] = { 0, 0 };
double r[2] = { 2, 2 };
double tFinal = 1;

double rho = 0.3;

void rhs(double *x, double *u, double *y) {
  y[0] = cos(rho)*a*x[0] + sin(rho)*b*x[1];
  y[1] = -sin(rho)*a*x[0] + cos(rho)*b*x[1];
}

void fixed_point(double *x) {
  x[0] = 0;
  x[1] = 0;
}

