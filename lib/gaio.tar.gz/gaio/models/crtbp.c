/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

#define sqr(x) ((x)*(x))

char *name = "The circular restricted three body problem";
char *typ = "ode";
int   dim  = 6;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = 3.040423398444176e-06; /* mu for the system sun-earth/moon */
double c[6] = { 1.0028, 0, 0, 0, 0.18, 0 };
double r[6] = { 0.0140, 0.01, 0.002, 0.2, 0.2, 0.04 };
double tFinal = 3.0596820441054; /* the period of the Halo orbit */

void rhs(double *x, double *u, double *fx) {

  double s = x[1]*x[1] + x[2]*x[2];
  double c1 = (1-mu)/pow(sqrt((x[0]+mu)*(x[0]+mu) + s), 3.0);
  double c2 = mu/pow(sqrt((x[0]+mu-1)*(x[0]+mu-1) + s), 3.0);
  
  fx[0] = x[3];
  fx[1] = x[4];
  fx[2] = x[5];
  fx[3] =  2*x[4] + x[0] - (x[0]+mu)*c1 - (x[0]+mu-1)*c2;
  fx[4] = -2*x[3] + x[1] - x[1]*(c1+c2);
  fx[5] = -x[2]*(c1+c2);

}

#define DFX(i,j) Dfx[i + j*6]

void drhs(double *x , double *u, double *Dfx) {

  int i;

  double    s = sqr(x[1]) + sqr(x[2]);
  double  pn1 = s + sqr(-1 + x[0] + mu);
  double  pn2 = s + sqr(x[0] + mu);
  double   n1 = pow(pn1, -3.0/2.0);
  double   n2 = pow(pn2, -3.0/2.0);
  double   c1 = mu*n1;
  double   c2 = (1-mu)*n2;
  double dc1c = mu*(-3.0/2.0)*pow(pn1, -5.0/2.0)*2;
  double dc10 = dc1c*(x[0]+mu-1);
  double dc11 = dc1c*x[1];
  double dc12 = dc1c*x[2];
  double dc2c = (1-mu)*(-3.0/2.0)*pow(pn2, -5.0/2.0)*2;
  double dc20 = dc2c*(x[0]+mu);
  double dc21 = dc2c*x[1];
  double dc22 = dc2c*x[2];

  DFX(0,0) = 0; 
  DFX(1,0) = 0; 
  DFX(2,0) = 0;
  DFX(3,0) = 1 - ((x[0] + mu - 1)*dc10 + c1) - ((x[0] + mu)*dc20 + c2);
  DFX(4,0) = - x[1]*(dc10 + dc20);
  DFX(5,0) = - x[2]*(dc10 + dc20);
  
  DFX(0,1) = 0; 
  DFX(1,1) = 0; 
  DFX(2,1) = 0;
  DFX(3,1) = - (x[0]+mu-1)*dc11 - (x[0]+mu)*dc21;
  DFX(4,1) = 1 - (x[1]*(dc11 + dc21) + (c1+c2));
  DFX(5,1) = - x[2]*(dc11 + dc21);
  
  DFX(0,2) = 0; 
  DFX(1,2) = 0; 
  DFX(2,2) = 0;
  DFX(3,2) = - (x[0]+mu-1)*dc12 - (x[0]+mu)*dc22;
  DFX(4,2) = - x[1]*(dc12+dc22);
  DFX(5,2) = - (x[2]*(dc12+dc22) + (c1+c2));
  
  DFX(0,3) = 1;
  DFX(1,3) = 0;
  DFX(2,3) = 0;
  DFX(3,3) = 0;
  DFX(4,3) = -2;
  DFX(5,3) = 0;
  
  DFX(0,4) = 0;
  DFX(1,4) = 1;
  DFX(2,4) = 0;
  DFX(3,4) = 2;
  DFX(4,4) = 0;
  DFX(5,4) = 0;
  
  DFX(0,5) = 0;
  DFX(1,5) = 0;
  DFX(2,5) = 1;
  DFX(3,5) = 0;
  DFX(4,5) = 0;
  DFX(5,5) = 0;

}

/* one point on the Halo-orbit around L1 */
void fixed_point(double *x) {
  x[0] = 0.98883694630639;
  x[1] = 0.0;
  x[2] = 8.0215045472047e-04;
  x[3] = 0.0;
  x[4] = 8.9372363327736e-03;
  x[5] = 0.0;
}


  
