#include <math.h>
#include <gaio/defs.h>

char *name = "Competing species";
char *typ = "map";
int   dim  = 2;
int   paramDim = 3;
char *paramNames[] = { "T", "h", "mu" };
double c[2] = { 0.1, 0.1 };
double r[2] = { 0.5, 2 };
double tFinal = 1;
double T = -1;
double h = -0.001;
double mu = 0.1;
double k[4][2];
double tmp[1][2];

void species(double *x, double t, double *y) {
  y[0] = ( mu - exp( -(1+mu)*t ) * ( x[0]+x[1]) ) * x[0] - x[1];
  y[1] = ( mu - 1 - exp( -(1+mu)*t ) * ( x[1]+4*x[0]) ) * x[1];
}                                                             
                                                              
void fixed_point(double *x) {                                 
  x[0] = 0;                                                   
  x[1] = 0;                                                   
}                                                             
                                                              
                                                              
                                                              
void Step(double *x, double t, double *fx) {                  
                                                              
  int j;                                                      
  species(x, t, k[0]);                                        
  VecAdd(x, h/2, k[0], dim, tmp[0]);                          
                                                              
  species(tmp[0], t, k[1]);                                   
  VecAdd(x, h/2, k[1], dim, tmp[0]);                          
                                                              
  species(tmp[0], t, k[2]);                                   
  VecAdd(x, h, k[2], dim, tmp[0]);                            
                                                              
  species(tmp[0], t, k[3]);                                   
                                                              
  for (j=0; j < dim; j++)                                     
    fx[j] = x[j] + (h/6)*(  k[0][j] + 2*k[1][j] + 2*k[2][j] +   k[3][j]);
                                                              
}                                                             
                                                              
/* caution: the value of x is not preserved */                
void rhs(double *x, double *u, double *fx) {                  
  double t, h0;                                               
                                                              
  t = 0;                                                      
  h0 = h;                                                     
                                                              
  while (fabs(t) < fabs(T)) {                                 
    if ((t + h - T)*sign(h) > 0.0)                            
      h = T - t;                                              
    Step(x, t, fx);                                           
    VecCopy(fx, x, dim);                                      
    t += h;                                                   
  }                                                           
  h = h0;                                                     
}                                                             

