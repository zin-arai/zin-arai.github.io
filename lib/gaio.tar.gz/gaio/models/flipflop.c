#include <gaio/defs.h>

char *name = "flipflop";
char *typ = "map";
int   dim  = 4;
int   paramDim = 2;
char *paramNames[] = { "lambda", "v0" };
double lambda = 2.0, v0 = 1.0;
double c[4] = { 2, 2, 2, 2 };
double r[4] = { 2, 2, 2, 2 };
double tFinal = 1;

static double r0=60.0, rl=4.5e5, gminmos=1e-15, beta=8.5e-6, delta=2e-2;

static double ictrl(double a, double b) {
  if (b <= v0)
    return 0.0;
  else if (b <= a+v0)
    return beta*(b-v0)*(b-v0)*(1.0-delta*a);
  else
    return beta*a*(1.0+delta*a)*(2.0*(b-v0)-a);
}

static void dictrl(double a, double b, double *dida, double *didb) {
  if (b <= v0) {
    (*dida) = 0.0;
    (*didb) = 0.0;
  }
  else if (b <= a+v0) {
    (*dida) = -delta*beta*(b-v0)*(b-v0);
    (*didb) = beta*2.0*(b-v0)*(1.0-delta*a);
  }
  else {
    (*dida) = beta*((1.0+delta*a)*(2.0*(b-v0)-a) +
           a*delta*(2.0*(b-v0)-a)-a*(1.0+delta*a));
    (*didb) = beta*a*(1.0+delta*a)*2.0;
  }
}
   
static void inv(int ndim, int n, int m, int nm1, double *x, double lambda,
                double *f) {
  f[n] = f[n] + (lambda - x[n])/rl + (x[m]-x[n])/r0;
  f[m] = f[m] - x[m]*gminmos + (x[n]-x[m])/r0 - ictrl(x[n],x[nm1]);
}

static void dinv(int ndim, int n, int m, int nm1, double *x, double lambda,
		 double *dfdx) {
  double dida, didb;

  dictrl(x[n],x[nm1],&dida,&didb);

  dfdx[n+n*ndim] += -1.0/rl - 1.0/r0;
  dfdx[m+n*ndim] += 1.0/r0 - dida;
  dfdx[n+m*ndim] += 1.0/r0;
  dfdx[m+m*ndim] += -gminmos - 1.0/r0;
  dfdx[m+nm1*ndim] += -didb;
}

void rhs(double *x, double *u, double *y) {
  int i;

  for (i=0; i<dim; i++)
    y[i] = 0.0;

  inv(dim, 0, 1, 2, x, lambda, y);
  inv(dim, 2, 3, 0, x, lambda, y);
}

void drhs(double *x, double *u, double *Df) {
  dinv(dim, 0, 1, 2, x, lambda, Df);
  dinv(dim, 2, 3, 0, x, lambda, Df);
}


