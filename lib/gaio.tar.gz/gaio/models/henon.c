/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>
#define max(x,y) ((x)>(y) ? (x) : (y))

char *typ = "map";                 /* map, ode or newton (so far) */
char *name = "The Henon map";       /* a descriptive name */
int   dim  = 2;                     /* dimension of phase space */
int   uDim = 0;                     /* dim of control/perturbation space*/
int   paramDim = 2;                 /* number of free parameters */
char *paramNames[] = { "a", "b" };  /* their names */
double a = 1.3, b = 0.2;            /* their initial values */
double c[2] = { 0, 0 };             /* center of outer box */
double r[2] = { 3, 3 };             /* radius of outer box */
double tFinal = 1;                  /* integration time */

/* this is the "right hand side" of the system, i.e. a map, a vector field, ... */
void rhs(double *x, double *u, double *y) {
  y[0] = 1 - a*x[0]*x[0] + x[1]/5;
  y[1] = b*x[0]*5;
}

/* this is the derivative of rhs */
void drhs(double *x, double *u, double *D) {
  D[0] = -2*a*x[0];
  D[1] = 5*b;
  D[2] = 1.0/5.0;
  D[3] = 0.0;
}

/* this is a local Lipschitz estimate for rhs. The matrix L must be computed
   in such a way that |f(x)-f(y)| <= L |x-y| (componentwise) for all
   x,y \in B(c,r)={ z : |c-x| <= r } */
void lip(double *c, double *r, double *L) {
  L[0] = 2.0*fabs(a)*max(fabs(c[0] + r[0]), fabs(c[0] - r[0]));
  L[1] = 5.0*fabs(b);
  L[2] = 1.0/5.0;
  L[3] = 0.0;
}

/* the function fixed_point may be used to provide a fixed point of
   rhs ;-), i.e. computes a point such that rhs(x)=x or a zero of
   rhs or ... */
void fixed_point(double *x) {
  double t = (b-1)/(2*a);
  x[0] = t + sqrt(t*t + 1/a);
  x[1] = 5*b*x[0];
}

