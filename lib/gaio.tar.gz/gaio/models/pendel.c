/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "Pendel";
char *typ = "ode";
int   dim  = 2;
int   paramDim = 1;
char *paramNames[] = { "D" };
double  D = 0;
double c[2] = { 0, 1 };
double r[2] = { 3.2, 1.2 };
double tFinal = 0.001;

void rhs(double *x, double *u, double *y) {
  y[0] = x[1];
  y[1] = -sin(x[0])-D*x[1];
}

void fixed_point(double *x) {
  x[0] = 0;
  x[1] = 0;
}


  
