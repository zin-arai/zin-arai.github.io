/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The cat map";
char *typ = "map";
int   dim  = 2;
int   paramDim = 0;
char *paramNames;
double c[2] = { 0.5, 0.5 };
double r[2] = { 0.5, 0.5 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
  y[0] = fmod(2*x[0] + x[1], 1);
  y[1] = fmod(x[0] + x[1], 1);
}

void fixed_point(double *x) {
  x[0] = 0;
  x[1] = 0;
}

