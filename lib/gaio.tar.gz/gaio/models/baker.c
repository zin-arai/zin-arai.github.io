/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The baker's map";
char *typ = "map";
int   dim  = 2;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = 0.3;
double c[2] = { 0.5, 0.5 };
double r[2] = { 0.5, 0.5 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
  y[0] = (x[0] <= 0.5 ? 2*x[0] : 2*x[0]-1);
  y[1] = (x[0] <= 0.5 ? mu*x[1] : mu*x[1]+0.5);
}

