/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>
#include <gaio/defs.h>

char *name = "The inverse Henon map";
char *typ = "map";
int   dim  = 2;
int   paramDim = 2;
char *paramNames[] = { "a", "b" };
double a = 1.3, b = 0.2;
double c[2] = { 0, 0 };
double r[2] = { 3, 3 };
double tFinal = 1;

void rhs(double *y, double *u, double *x) {
  x[0] = y[1]/(5*b);
  x[1] = 5*(y[0] - 1 + a*x[0]*x[0]);
}

void fixed_point(double *x) {
  double t = (b-1)/(2*a);
  x[0] = t + sqrt(t*t + 1/a);
  x[1] = 5*b*x[0];
}

void lip(double *c, double *r, double *L) {
  L[0] = 0.0;
  L[1] = 5;
  L[2] = 1.0/(5.0*b);
  L[3] = 2.0*a/(5.0*b*b)*max(fabs(c[0] + r[0]), fabs(c[0] - r[0]));
}



