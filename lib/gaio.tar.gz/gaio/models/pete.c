/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The pete map, big attractor, small support";
char *typ = "map";
int   dim  = 2;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = 0.1415;
double c[2] = { 0, 0 };
double r[2] = { 0.3, 0.4 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
  double r = sqrt(x[0]*x[0] + x[1]*x[1]),
    t = atan(x[0]/x[1]),
    a = -mu + 0.7*pow(r,0.94) - 0.25*(cos(2*t))*(cos(2*t)),
    b = 0.1*cos(2*t);
  
  y[0] = cos(t)*(a + b);
  y[1] = sin(t)*(a - b);
}


