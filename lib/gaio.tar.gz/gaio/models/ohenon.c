/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *typ = "map";                
char *name = "The (original) Henon map";  
int   dim  = 2;                   
int   uDim = 0;                   
int   paramDim = 2;               
char *paramNames[] = { "a", "b" };  
double a = 1.4, b = 0.3;       
double c[2] = { 0, 0 };        
double r[2] = { 1.5, 1.5 };        
double tFinal = 1;             

void rhs(double *x, double *u, double *y) {
  y[0] = 1 - a*x[0]*x[0] + b*x[1];
  y[1] = x[0];
}

void drhs(double *x, double *u, double *L) {
  L[0] = -2*a*x[0];
  L[1] = 1;
  L[2] = b;
  L[3] = 0;
}

#define max(x,y) ((x) > (y) ? (x) : (y))

void lip(double *c, double *r, double *L) {
  L[0] = 2*fabs(a)*max(fabs(c[0]-r[0]), fabs(c[0]+r[0]));
  L[1] = 1;
  L[2] = fabs(b);
  L[3] = 0;
}

void fixed_point(double *x) {
  double l = (1-b)/(2*a);
  x[0] = -l + sqrt(l*l+1/a);
  x[1] = x[0];
}


