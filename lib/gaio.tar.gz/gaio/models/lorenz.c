/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The Lorenz system";
char *typ = "ode";
int   dim  = 3;
int   paramDim = 3;
char *paramNames[] = { "sigma", "rho", "beta" };
double  sigma = 10, rho = 28, beta = 0.4;
double c[3] = { 0, 0, 27 };
double r[3] = { 30, 30, 40 };
double tFinal = 0.2;

void rhs(double *x, double *u, double *y) {
  y[0] = sigma*(x[1]-x[0]);
  y[1] = rho*x[0] - x[1] - x[0]*x[2];
  y[2] = x[0]*x[1] - beta*x[2];
}

void drhs(double *x, double *u, double *D) {
  D[0] = -sigma;
  D[1] = rho - x[2];
  D[2] = x[1];
  D[3] = sigma;
  D[4] = -1;
  D[5] = x[0];
  D[6] = 0;
  D[7] = -x[0];
  D[8] = -beta;
}

void fixed_point(double *x) {
  x[0] = sqrt(beta*(rho-1));
  x[1] = x[0];
  x[2] = rho-1;
}


  
