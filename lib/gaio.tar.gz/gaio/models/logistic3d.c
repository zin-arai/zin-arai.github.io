/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>
#include <gaio/defs.h>

char *name = "The 3D logistic map";
char *typ = "map";
int   dim  = 3;
int   paramDim = 3;
char *paramNames[] = { "mu", "lambda", "g" };
double  mu = 1.2, lambda = 2.35, g = 0.1;
double c[3] = { 0.3, 1.0, 0.3 };
double r[3] = { 0.7, 1.0, 0.7 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
    y[0] = x[1]-mu*x[0];
    y[1] = lambda*x[1]*(1-x[0]);
    y[2] = x[0]-g*x[2];

}

void lip(double *c, double *r, double *L) {
    L[0] = 1.2;
    L[1] = max(2.35*fabs(c[0]+r[0]),2.35*fabs(c[0]-r[0]));
    L[2] = 1;
    L[3] = 1;
    L[4] = max(2.35*fabs(1-c[0]-r[0]),2.35*fabs(1-c[0]+r[0]));
    L[5] = 0;
    L[6] = 0;
    L[7] = 0;
    L[8] = 0.1;
}
 
  
