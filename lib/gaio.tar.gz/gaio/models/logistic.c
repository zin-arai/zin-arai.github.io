/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The logistic map";
char *typ = "map";
int   dim  = 1;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = 4.0;
double c[1] = { 0.5 };
double r[1] = { 0.5 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
  y[0] = mu*x[0]*(1-x[0]);
}

void fixed_point(double *x) {
  x[0] = 1-1/mu;
}

  
void lip(double *c, double *r, double *L) {
  if (c[0]<0.5)
    L[0] = fabs(mu*(1-2*(c[0]-r[0])));
  else
    L[0] = fabs(mu*(1-2*(c[0]+r[0])));
}
