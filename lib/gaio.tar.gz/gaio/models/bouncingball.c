/* Copyright (c) 1999 Gary Froyland, for details see COPYING */

#include <math.h>
#include <gaio/defs.h>

char *typ = "map";                 /* map, ode or newton (so far) */
char *name = "The bouncing ball map";       /* a descriptive name */
int   dim  = 2;                     /* dimension of phase space */
int   uDim = 0;                     /* dim of control/perturbation space*/
int   paramDim = 2;                 /* number of free parameters */
char *paramNames[] = { "alpha","gamm" };  /* their names */
double alpha = 0.8, gamm = 2*M_PI;       /* their initial values */
double c[2] = { M_PI,0 };             /* center of outer box */
double r[2] = { M_PI,15 };           /* radius of outer box */
double tFinal = 1;                  /* integration time */

/* this is the "right hand side" of the system, i.e. a map, a vector field, ... */
void rhs(double *x, double *u, double *y) {
  y[0] = fmod(x[0]+x[1]+8*M_PI,2*M_PI); 
  y[1] = alpha*x[1]-gamm*cos(x[0]+x[1]);
}

/* this is the derivative of rhs */
void drhs(double *x, double *u, double *D) {
  D[0] = 1.0;
  D[1] = 1.0;
  D[2] = gamm*sin(x[0]+x[1]);
  D[3] = alpha+gamm*sin(x[0]+x[1]);
}

/* this is a local Lipschitz estimate for rhs. The matrix L must be computed
   in such a way that |f(x)-f(y)| <= L |x-y| (componentwise) for all
   x,y \in B(c,r)={ z : |c-x| <= r } */
void lip(double *c, double *r, double *L) {
  L[0] = 1.0;
  L[1] = 1.0;
  L[2] = max(abs(gamm*sin(c[0]+c[1]+r[0]+r[1])),max(abs(gamm*sin(c[0]+c[1]-r[0]-r[1])),max(abs(gamm*sin(c[0]+c[1]+r[0]-r[1])),abs(gamm*sin(c[0]+c[1]-r[0]+r[1])))));
  L[3] = max(abs(alpha+gamm*sin(c[0]+c[1]+r[0]+r[1])),max(abs(alpha+gamm*sin(c[0]+c[1]-r[0]-r[1])),max(abs(alpha+gamm*sin(c[0]+c[1]+r[0]-r[1])),abs(alpha+gamm*sin(c[0]+c[1]-r[0]+r[1])))));
}

/*everything below here is garbage*/
/* the function fixed_point may be used to provide a fixed point of
   rhs ;-), i.e. computes a point such that rhs(x)=x or a zero of
   rhs or ... 
void fixed_point(double *x) {
  double t = (b-1)/(2*a);
  x[0] = t + sqrt(t*t + 1/a);
  x[1] = 5*b*x[0];
}
*/
