
#include <math.h>


char *name = "Chua's circuit";
char *typ = "ode";
int   dim  = 3;
int   paramDim = 2;
char *paramNames[] = { "a", "b" };
double a = 16, b = 33, m0 = -0.2, m1 = 0.01;
double c[3] = { 0, 0, 0 };
double r[3] = { 12, 2.5, 20 };
double tFinal = 0.5;

void rhs(double *x, double *u, double *y) {
  y[0] = a*(x[1] - m0*x[0] - m1*x[0]*x[0]*x[0]/3.0);
  y[1] = x[0]-x[1]+x[2]; 
  y[2] = -b*x[1];
}



















void fixed_point(double *x) {
  x[0] = sqrt(-3*m0/m1);
  x[1] = 0;
  x[2] = -x[0];
}


  
