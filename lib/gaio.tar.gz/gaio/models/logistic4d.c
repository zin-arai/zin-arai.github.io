/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "The 4D logistic map";
char *typ = "map";
int   dim  = 4;
int   paramDim = 4;
char *paramNames[] = { "lambda_0", "lambda_1", "lambda_2", "lambda_3" };
double  lambda_0 = 0.2, lambda_1 = 0.2, lambda_2 = 2, lambda_3 = 2;
double c[3] = { 0.3, 0.75, 0.3 };
double r[3] = { 0.7, 0.75, 0.7 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
    y[0] = x[1] - lambda_0*x[0];
    y[1] = lambda_1*x[1]*(1-x[0]);
    y[2] = x[3] - lambda_2*x[2];
    y[3] = x[0] - lambda_3*x[3];
}



  
