/* Copyright (c) 1998 Stefan Sertl, for details see COPYING */

char *name = "himmelblau";
char *typ = "new";
int   dim  = 2;
int   paramDim = 0;
char *paramNames;
double c[2] = { 0.0, 0.0 };
double r[2] = { 5.1, 5.1 };
double tFinal = 1;


void rhs(double *x, double *u, double *y) {
  y[0] = 2*(x[0]*x[0]+x[1]-11)*(2*x[0])+2*(x[0]+x[1]*x[1]-7);
  y[1] = 2*(x[0]*x[0]+x[1]-11) + 2*(x[0]+x[1]*x[1]-7)*(2*x[1]);
}

void drhs(double *x, double *u, double *Df) {
  Df[0] = 2*(2*x[0])*(2*x[0]) + 2*(x[0]*x[0]+x[1]-11)*2 + 2;
  Df[1] = 2*2*x[0] + 2*2*x[1];
  Df[2] = 2*2*x[0] + 2*2*x[1];
  Df[3] = 2 + 2*(2*x[1])*(2*x[1]) + 2*(x[0]+x[1]*x[1]-7)*2;
}
