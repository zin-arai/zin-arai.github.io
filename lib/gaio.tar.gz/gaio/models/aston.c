/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *name = "a map supposed by Philip Aston";
char *typ = "map";
int   dim  = 2;
int   paramDim = 1;
char *paramNames[] = { "mu" };
double mu = -0.478;
double c[2] = { 0, 0 };
double r[2] = { 2, 2 };
double tFinal = 1;

void rhs(double *x, double *u, double *y) {
    y[0] = ( -2.6 + 1.5*x[0]*x[0] + 0.7*x[0]*x[1])*x[0] -0.5*x[1];
    y[1] = (mu +0.4*x[1]*x[1]+0.5*x[0]*x[1])*x[1] + 0.3*x[0];
}


