/* Copyright (c) 1998 Oliver Junge, for details see COPYING */

#include <math.h>

char *typ = "map";                 /* map, ode or newton (so far) */
char *name = "The Shear map";       /* a descriptive name */
int   dim  = 2;                     /* dimension of phase space */
int   uDim = 0;                     /* dim of control/perturbation space*/
int   paramDim = 3;                 /* number of free parameters */
char *paramNames[] = { "alpha", "lu", "ls" };  /* their names */
double alpha = 0.5, lu = 2, ls = 0.3;            /* their initial values */
double c[2] = { 0, 0 };             /* center of outer box */
double r[2] = { 2, 4 };             /* radius of outer box */
double tFinal = 1;                  /* integration time */

double f(double x) {
  if (x<=1) return 0;
  return (x-1)*(x-1);
}
void rhs(double *x, double *u, double *y) {
  double c = alpha*f(lu*x[0] + ls*x[1]);
  y[0] = lu*x[0] - c; 
  y[1] = ls*x[1] + c; 
}


