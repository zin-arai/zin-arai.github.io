/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * VarEqn.c task for the integration of the variational equation
 *  
 */

#include <gaio/Task.h>

char *name = "VarEqn";

int dim(int dim) {
  return dim*(dim+1);
}

void f(Task *task, double *x, double *u, double *y) {
  int i, j, k, dim;
  double dy[MAXDIM*MAXDIM]; 

  dim = *task->model->dim;
  
  task->model->rhs(x, u, y);
  task->model->drhs(x, u, dy);

  for (i=0; i<dim; i++) 
    for (j=0; j<dim; j++) {
      y[dim + i + j*dim] = 0;
      for (k=0; k<dim; k++)
	y[dim + i + j*dim] += dy[i + k*dim]*x[dim + k + j*dim];
    }
}


