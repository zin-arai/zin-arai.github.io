/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 *
 */

#include <gaio/Task.h>

char *name = "plain";

int dim(int dim) {
  return dim;
}

void f(Task *task, double *x, double *u, double *y) {
  task->model->rhs(x, u, y);
}

void df(Task *task, double *x, double *u, double *y) {
  assert(task->model->drhs);

  task->model->drhs(x, u, y);
}

