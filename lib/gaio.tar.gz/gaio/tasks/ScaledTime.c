/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * ScaledTime.c   the task 
                            \dot x = f(x)/||f(x)||
			    \dot t = 1/||f(x)||
 *
 */

#include <gaio/Task.h>

char *name = "ScaledTime";

int Dim(int dim) {
  return dim+1;
}

void f(Task *task, double *x, double *u, double *y) {
  int i, dim = TaskDim(task);
  double norm = 0;

  task->model->rhs(x, u, y);
  for (i=0; i<dim-1; i++) norm += fabs(y[i]);
  for (i=0; i<dim-1; i++) y[i] /= norm;
  y[dim-1] = 1.0/norm;
}

void Df(Task *task, double *x, double *u, double *Dfx) {
  int i, j, k, dim = TaskDim(task)-1;
  double norm, fx[MAXDIM], Dfx_tmp;

  task->model->rhs(x, u, fx);
  norm = VecNorm(fx, dim);
  task->model->drhs(x, u, Dfx);
  for (i=0; i<dim; i++) {
    Dfx[i + dim*dim] = 0;
    for (k=0; k<dim; k++) 
      Dfx[i + dim*dim] += fx[k]*Dfx[k + i*dim];
  }
  for (i=0; i<dim; i++) {
    for (j=0; j<dim; j++) {
      Dfx[i + j*dim] /= norm;
      Dfx[i + j*dim] -= fx[i]*Dfx[j + dim*dim]/pow(norm, 3.0);
    }
  }  
  
}


