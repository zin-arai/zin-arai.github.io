/*
 * Copyright (c) 2001 Oliver Junge, for details see COPYING
 * 
 * Cost.c task for the integration of an additional cost function
 *  
 */

#include <gaio/Task.h>

char *name = "Cost";

int dim(int dim) {
  return (dim+1);
}

void f(Task *task, double *x, double *u, double *y) {
  int dim;

  if (task->model->cost==NULL) {
    fprintf(stderr, "Cost::f: error: model does not define a 'cost' function.\n");
    return;
  }

  dim = *task->model->dim;
  
  task->model->rhs(x, u, y);
  y[dim] = task->model->cost(x, u);

}


