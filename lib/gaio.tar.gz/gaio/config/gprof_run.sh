#! /usr/bin/env bash
if test -z $AUTO_DIR; then
    echo "Please set AUTO_DIR"
    exit 1
fi

if test -z "$OPT"; then 
    OPT="-pg -g";
fi
export OPT;
set -- `getopt "c" $*`
for x in $*; do
case "$x" in
  -c)
    cd $AUTO_DIR/src;
    make -e clean;
    ;;
  --)
    ;;
  *)
        exit 1
esac
done

cd $AUTO_DIR/src;
make -e;
cd ../demos/tim;
rm -f tim.exe;
make -e tim.exe;
cp r.tim.1 fort.2;
touch fort.3;
tim.exe;
gprof tim.exe | more;


