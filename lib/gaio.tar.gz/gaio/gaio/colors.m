function c = colors(v)
  
  eps = 1e-20/length(v);
  a = abs(v);
  mi = log(max(min(a), eps));
  ma = log(max(max(a), eps));
  a(find(a < eps)) = eps;
  h = floor(254*(log(a)-mi)/(ma-mi)+1);
  c = sprintf('%1c', h);
  
