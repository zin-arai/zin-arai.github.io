function l = length_of_path(A, path)
% LENGTH_OF_PATH - compute the length of a path
%   L = length_of_path(A, P) computes the length L of the path P
%   as determined by the transition matrix A
  
  l = 0;
  for i=1:length(path)-1
    l = l + (1-A(path(i+1), path(i)));
  end
  
