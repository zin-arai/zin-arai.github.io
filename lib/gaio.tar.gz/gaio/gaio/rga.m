function rga(tree, varargin)

% rga - relative global attractor.
%   rga(tree [, domain_points, image_points, integrator, no_of_steps]): 
%   subdivision algorithm for the computation of the relative global 
%   attractor. 
%   Defaults for the optional arguments are
%     domain_points = tree.domain_points,
%     image_points  = tree.image_points,
%     integrator    = tree.integrator, 
%     no_of_steps   = 1.

% Oliver Junge, 12.6.2000

d = tree.dim;
hit = 1;
to_be_subdivided = 8;
points_found = 0;

no_of_steps = 1;
integrator = Integrator(tree.integrator);
domain_points = Points(tree.domain_points);
image_points  = Points(tree.image_points);

for i=1:length(varargin),
 o = varargin{i};
 if isa(o, 'Points')
   if points_found==0
     domain_points = o;
     points_found = 1;
   else
     image_points = o;
   end
 elseif isa(o, 'Integrator')
   integrator = o
 elseif isnumeric(o)
   no_of_steps = o;
 end
end

for i=1:no_of_steps
  tree.set_flags('all', to_be_subdivided);
  tree.subdivide;
  b = tree.first_box(-1);
  while (~isempty(b))
    center = b(1:d);
    radius = b(d+1:2*d);
    p = domain_points.get(center, radius, integrator, radius);
    fp = integrator.map(p);
    ip = image_points.get(fp, radius, integrator, radius);
    tree.set_flags(ip, hit);
    b = tree.next_box(-1);
  end
  tree.remove(hit);
  disp(sprintf('step %d: %d boxes', i, tree.count(-1)));
end

