function p=show3(b, color, dim, which, edgecolor_in, alpha_in, p)

% SHOW3  plot box collection.
%   SHOW3(B) shows a plot of the box collection B.
%   
%   SHOW3(B, C) uses the color C (default is red).
%
%   SHOW3(B, C, DIM) assumes boxes of dimension DIM (default is 3).
%
%   SHOW3(B, C, DIM, WHICH), where WHICH is a 3-vector of integers
%   in the range 1..DIM, shows a projection onto the coordinates
%   specified in WHICH.
%
%   SHOW3(B, C, DIM, WHICH, EC), where EC is a color, uses EC as the
%   color of the edges of the boxes
%
%   SHOW3(B, C, DIM, WHICH, EC, ALPHA), where ALPHA is in [0,1], 
%   makes the boxes transparent with factor ALPHA
%
%   SHOW3(B, C, DIM, WHICH, EC, ALPHA, P), where P is a vector (length=
%   number of boxes) colores the boxes according to P
  

ix = 1;
iy = 2;
iz = 3;

d = 3
if nargin > 2 
  d = dim;
end

if nargin > 3,
  ix = which(1);
  iy = which(2);
  iz = which(3);
end

edgecolor = [0 0 0];
if nargin > 4
  edgecolor = edgecolor_in;
end

alpha = 1;
alpha_edge = 1;
if nargin > 5
  alpha = alpha_in;
  alpha_edge = 0;
end

col = color;
if nargin > 6
  pnorm = p/max(abs(p));
  col = pnorm(:)';
end

xmax = max(b(:,ix));
xmin = min(b(:,ix));
ymax = max(b(:,iy));
ymin = min(b(:,iy));
zmax = max(b(:,iz));
zmin = min(b(:,iz));

xr = b(1,ix+d);
yr = b(1,iy+d);
zr = b(1,iz+d);

%axis([xmin-xr-0.000,xmax+xr+0.000,ymin-yr-0.000,ymax+yr+0.000,zmin-zr-0.000,zmax+zr+0.000])
%hold on
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeColor',edgecolor);
set(p,'EdgeAlpha',alpha_edge);
set(p,'FaceAlpha',alpha);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeAlpha',alpha_edge);
set(p,'EdgeColor',edgecolor);
set(p,'FaceAlpha',alpha);
x=[b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeColor',edgecolor);
set(p,'EdgeAlpha',alpha_edge);
set(p,'FaceAlpha',alpha);
x=[b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeColor',edgecolor);
set(p,'EdgeAlpha',alpha_edge);
set(p,'FaceAlpha',alpha);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeColor',edgecolor);
set(p,'EdgeAlpha',alpha_edge);
set(p,'FaceAlpha',alpha);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d)];
p=patch(x',y',z',col);
set(p,'EdgeColor',edgecolor);
set(p,'EdgeAlpha',alpha_edge);
set(p,'FaceAlpha',alpha);
