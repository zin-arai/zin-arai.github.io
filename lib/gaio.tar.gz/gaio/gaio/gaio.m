% GAIO 2.2.2 (help gaio)
%
% GAIO is a toolbox for the set-oriented numerical analysis of
% dynamical systems. It provides data structures and algorithms
% for the computation of
%   - invariant sets (maximal invariant set, chain recurrent set,
%     periodic points, global attractor);
%   - invariant manifolds (stable/unstable manifold of an arbitrary
%     invariant set);
%   - invariant measures, almost invariant sets.
%
% Data structures/Objects
%   Model        - defines the 'right hand side' (map, vector field, etc.)
%   Integrator   - makes a discrete dynamical system out of a model
%   Points       - discretize the 'map a set'-task
%   Tree         - basic data structure for storing the set collections
%
% General algorithms
%   crs          - chain recurrent set
%   gum          - global unstable manifold
%   im           - invariant measure
%   mis          - maximal invariant set
%   pp           - periodic points
%   rga          - relative global attractor
%
% Miscellaneous
%   adj_matrix   - compute (geometric) adjacency matrix
%   dijkstra     - computes shortest path between two nodes in a directed
%                  weighted graph
%   fwd_inv_set  - computes the forward invariant set of a transition matrix
%   intorb       - compute piecewise cubical hermite interpolation of trajectory
%   bar3d        - bar plot of invariant measure
%   show2        - box (and measure) plot in 2D
%   show3        - box (and measure) plot in 3D
%
% Specialized algorithms
%   aim_hm       - adaptive computation of invariant measure subdividing
%                  regions with high mass first
%   aim_lip      - adaptive computation of invariant measure using a
%                  local error estimate based on Lipschitz constants
%   aim_cmp      - adaptive computation of invariant measure using a
%                  local error estimate based on comparing two approximations
% 
%
% Copyright (c) 2003 by djs� GmbH, Paderborn
%               http://www.djs2.de
