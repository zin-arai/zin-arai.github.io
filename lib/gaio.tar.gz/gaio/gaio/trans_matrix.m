function P = trans_matrix(tree, points, depth)

% TRANS_MATRIX(TREE, POINTS [, DEPTH])
%   computes the transition matrix on the given DEPTH
%   (default = -1) of the TREE, using the MonteCarlo 
%   method with the given POINTS

% Oliver Junge, 26.06.2001, Pasadena

if nargin < 3
  depth = -1;
end
  
d = tree.dim;
integrator = Integrator(tree.integrator);
nob = tree.count(depth);
ijs = zeros(nob, 3);
k = 1;
no = 1;
b = tree.first_box(depth);
while (~isempty(b))
  q = points.get(b(1:d), b(d+1:2*d));
  fpts = integrator.map(q);
  I = tree.search(fpts(1:2,:), depth);
  I = I(find(I>0));
  if (length(I) > 0)
    [I,J,S] = find(sparse(I, no, 1, nob, nob));
    if k+length(I) > length(ijs)
      ijs = realloc(ijs, [2*size(ijs,1), 3]);
    end
    ijs(k:k+length(I)-1,:) = [I J S];
  end
  k = k + length(I);
  b = tree.next_box(depth);
  fprintf('box no %d\r',no); 
  no = no + 1;
end
 
P = sparse(ijs(1:k-1,1), ijs(1:k-1,2), ijs(1:k-1,3), nob, nob);
cs = sum(P);
P = P*spdiags(1./cs', 0, nob, nob);



