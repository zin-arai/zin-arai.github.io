function [v,d] = seig(A, nev, which)
  
% SEIG computes a few eigenpairs of a sparse matrix using the ARPACKage
%   [V,D] = SEIG(A[,NEV, WHICH]) computes NEV eigenpairs of the
%   sparse matrix A. The parameter which determines which part of
%   the spectrum of A is approximated.
  
if ~issparse(A),
  error('first argument must be a sparse matrix.');
end

if nargin < 2,
  nev = 1;
end

if ~isnumeric(nev),
  error('second argument must be numeric.')
end

if nargin < 3,
  which = 'LX';
end

[v, d] = arpack(A, nev, which);

for i=1:size(v,2),
  v(:,i) = v(:,i)/norm(v(:,i), 1);
end

if nargout < 2,
  v = d;
end
