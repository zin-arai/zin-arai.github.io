function pp(tree, period, varargin)

% pp - periodic points.
%   pp(tree, period [, method, no_of_steps]): subdivision algorithm for the 
%   computation of the set of periodic points of a certain period. 
%   The optional parameter method specifies the way the transition 
%   matrix is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = tree.domain_points,
%     no_of_steps = 1.

% Oliver Junge, 12.6.2000

hit = 1;
to_be_subdivided = 8;

no_of_steps = 1;
points = Points(tree.domain_points);

for i=1:length(varargin),
 o = varargin{i};
 if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   points = o;
 elseif isnumeric(o)
   no_of_steps = o;
 end
end

for i=1:no_of_steps
  tree.set_flags('all', to_be_subdivided);
  tree.subdivide;
  A = tree.matrix(points);
  d = full(diag(A^period));
  d(find(d)) = 1;
  flags = sprintf('%1d', d);
  clear d;
  tree.set_flags(flags, hit);
  tree.remove(hit);
  disp(sprintf('step %d: %d boxes, depth = %d', i, tree.count(-1), tree.depth));
end
