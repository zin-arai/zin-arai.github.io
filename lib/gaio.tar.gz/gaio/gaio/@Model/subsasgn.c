/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Model.h>
#include <gaio/mxHandling.h>


void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Model *m;
  mxArray *ptr;
  double *pr;
  
  ptr = mxGetField(prhs[0], 0, "handle");
  m = (Model *)ptrFromMxArray(ptr);
  if (m==NULL) {mexPrintf("??? Model: model is empty.\n\n"); return;}
  
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  if (!strcmp(type,".")) {
    ptr = mxGetField(prhs[1], 0, "subs");
    attr = mxArrayToString(ptr);

    if (!strcmp(attr, "dim")) {
      pr = mxGetPr(prhs[2]);
      *(m->dim) = *pr;
    } else if (!strcmp(attr, "uDim")) {
      pr = mxGetPr(prhs[2]);
      *(m->uDim) = *pr;
    } else {
      int i;
      int counter = 0; 
      for (i=0; i < m->paramDim; i++)
	if (!strcmp(attr, m->paramNames[i])) {
	  pr = mxGetPr(prhs[2]);
          *(m->param[i]) = *pr;
	} else {
	  counter = counter+1;
	}
      if (counter == m->paramDim)
	mxErrMsgTxt("Model: unknown field");
    }
    
    mxFree(attr);
  }

  mxFree(type);

  plhs[0] = (mxArray*) prhs[0];

  return;
}


