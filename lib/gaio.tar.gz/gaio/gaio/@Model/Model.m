function m = Model(m_in)

% Model - load a model from a file.
%    m = Model(name) loads a model from file 'name.so' (see the reference 
%    manual for a description of how to write a new model).
%
%    NOTE: call delete(m); clear m; to delete the model from memory.
%
% Attributes
%    m.filename     filename as given for loading the model m
%    m.name         descriptive name of the model m
%    m.typ          type of the model m (i.e. map, ode, ...)
%    m.dim          dimension of state space
%    m.dim = d      sets dimension of state space to d
%    m.paramDim     number of "free" parameters 
%    m.tFinal       suggested integration time 
%    m.center       suggested center of outer box Q 
%    m.radius       suggested radius of outer box Q 
%    m.fixed_point  special point in the state space (e.g. equilibrium)
%
% Methods
%    m.rhs(X)	    evaluates the right hand side at the point X;
%    m.drhs(X)      evaluates the derivative of the right hand side 
%                   at the point X - not all models define this function;
%    m.lip(C, R)    returns a matrix L such that 
%                             |rhs(x) - rhs(y)| <= L|x-y| 
%                   (componentwise) for all x,y in B(c,r)={ x : |c-x| <= r }

% 2007 djs2 GmbH

if nargin == 0
  error('Too few input arguments: filename or handle expected.')
elseif isa(m_in, 'struct')
  m = m_in;
  m = class(m, 'Model');
elseif ischar(m_in)
  m.handle = load_model(m_in);
  m = class(m, 'Model');
else
  error('Input argument of wrong type: handle or string expected.');
end

