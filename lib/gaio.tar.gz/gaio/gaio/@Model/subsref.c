/*
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Model.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Model *m;
  mxArray *ptr;
  double *pr;
  int k;
    
  ptr = mxGetField(prhs[0], 0, "handle");
  m = (Model *)ptrFromMxArray(ptr);
  if (m==NULL) {mexPrintf("??? Model: model is empty.\n\n"); return;}
    
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  ptr = mxGetField(prhs[1], 0, "subs");
  attr = mxArrayToString(ptr);

  if (mxGetNumberOfElements(prhs[1])==1 && !strcmp(type,".")) {

    if (!strcmp(attr, "name")) {
      plhs[0] = mxCreateCharMatrixFromStrings(1, (const char**)&(m->name));
    } else if (!strcmp(attr, "filename")) {
      char *filename; 
      filename = (char *)&(m->filename);      
      plhs[0] = mxCreateCharMatrixFromStrings(1, (const char**)&(filename));
    } else if (!strcmp(attr, "typ")) {
      plhs[0] = mxCreateCharMatrixFromStrings(1, (const char**)&(m->typ));
    } else if (!strcmp(attr, "dim")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = *(m->dim);
    } else if (!strcmp(attr, "uDim")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = *(m->uDim);
    } else if (!strcmp(attr, "paramDim")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = m->paramDim;
    } else if (!strcmp(attr, "tFinal")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = m->tFinal;
    } else if (!strcmp(attr, "radius")) {
      plhs[0] = mxCreateDoubleMatrix(*(m->dim), 1, mxREAL);
      pr = mxGetPr(plhs[0]);
      for (k=0; k < *(m->dim); k++) pr[k] = m->r[k];
    } else if (!strcmp(attr, "center")) {
      plhs[0] = mxCreateDoubleMatrix(*(m->dim), 1, mxREAL);
      pr = mxGetPr(plhs[0]);
      for (k=0; k < *(m->dim); k++) pr[k] = m->c[k];
    } else if (!strcmp(attr, "fixed_point")) {
      plhs[0] = mxCreateDoubleMatrix(*(m->dim), 1, mxREAL);
      pr = mxGetPr(plhs[0]);
      if (!m->fixed_point)
      {mexPrintf("??? model does not define a fixed point\n\n"); return;}
      m->fixed_point(pr);
    } else if (!strcmp(attr, "info")) { /* info */
      plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
      pr = mxGetPr(plhs[0]);
      ModelInfo(stdout, m);
    } else { /* free parameters */
      int i;
      int counter=0;
      for (i=0; i<m->paramDim; i++)
	if (!strcmp(attr, m->paramNames[i])) {
	  plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
	  pr = mxGetPr(plhs[0]);
	  pr[0] = *(m->param[i]); 
	} else  {
        counter = counter +1;
        }
      if (counter == m->paramDim)
	{mexPrintf("??? Model: unknown field or method\n\n"); return;}
    }
  }

  /* methods */
  if (mxGetNumberOfElements(prhs[1])==2 && !strcmp(type,".")) {
    
    ptr = mxGetField(prhs[1], 1, "type");
    type = mxArrayToString(ptr);
    ptr = mxGetField(prhs[1], 1, "subs");
    
    if (!strcmp(attr, "rhs")) { 
      /* right hand side */
      int k, n, n1, dim = *(m->dim);
      double *u, *prl, *pr0;
      if (mxGetNumberOfElements(ptr)>1)
	{mexPrintf("??? Model.rhs: too many input arguments.\n\n"); return;}
      n = mxGetN(mxGetCell(ptr, 0));
      n1 = mxGetM(mxGetCell(ptr, 0));
      pr0 = mxGetPr(mxGetCell(ptr, 0));
      if (n1!=dim)
	{mexPrintf("??? Model.rhs: input matrix has wrong dimension.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(dim, n, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < n; k++) 
	m->rhs(pr0 + k*dim, u, prl + k*dim);
    } else if (!strcmp(attr, "cost")) { 
      int k, n, nu, n1, n1u, dim = *(m->dim), udim = *(m->uDim);
      double *prl, *pr0, *pru;
      if (mxGetNumberOfElements(ptr)<2)
	{mexPrintf("??? Model.cost: too few input arguments.\n\n"); return;}
      n = mxGetN(mxGetCell(ptr, 0));
      n1 = mxGetM(mxGetCell(ptr, 0));
      pr0 = mxGetPr(mxGetCell(ptr, 0));
      if (n1!=dim) {mexPrintf("??? Model.cost: space input matrix has wrong dimension.\n\n"); return;}
      nu = mxGetN(mxGetCell(ptr, 1));
      n1u = mxGetM(mxGetCell(ptr, 1));
      pru = mxGetPr(mxGetCell(ptr, 1));
      if (nu!=n) {mexPrintf("??? Model.cost: not enough control values.\n\n"); return;}
      if (n1u!=udim) {mexPrintf("??? Model.cost: control input matrix has wrong dimension.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < n; k++) 
	prl[k] = m->cost(pr0 + k*dim, pru + k*udim);
    } else if (!strcmp(attr, "drhs")) { 
      /* derivative of the right hand side */
      double *u;
      if (mxGetNumberOfElements(ptr)>1)
	{mexPrintf("??? Model.drhs: too many input arguments.\n\n"); return;}
      if (mxGetNumberOfElements(mxGetCell(ptr, 0)) != *(m->dim))
	{mexPrintf("??? Model.drhs: input vector has wrong dimension.\n\n"); return;}
      if (m->drhs==NULL)
	{mexPrintf("??? Model: model does not define drhs.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(*(m->dim), *(m->dim), mxREAL);
      m->drhs(mxGetPr(mxGetCell(ptr, 0)), u, mxGetPr(plhs[0]));
    } else if (!strcmp(attr, "lip")) { 
      /* Lipschitz estimate of the right hand side */
      double *u;
      if (mxGetNumberOfElements(ptr)!=2)
	{mexPrintf("??? Model.lip: usage: model.lip(center, radius).\n\n"); return;}
      if (mxGetNumberOfElements(mxGetCell(ptr, 0)) != *(m->dim))
	{mexPrintf("??? Model.lip: center has wrong dimension.\n\n"); return;}
      if (mxGetNumberOfElements(mxGetCell(ptr, 1)) != *(m->dim))
	{mexPrintf("??? Model.lip: radius has wrong dimension.\n\n"); return;}
      if (m->lip==NULL)
	{mexPrintf("??? Model: model does not define lip.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(*(m->dim), *(m->dim), mxREAL);
      m->lip(mxGetPr(mxGetCell(ptr, 0)), mxGetPr(mxGetCell(ptr, 1)), 
	     mxGetPr(plhs[0]));
    } else {
      {mexPrintf("??? Model: unknown method\n\n"); return;}
    }

  }

  mxFree(attr);
  mxFree(type);
  
  return;
}


