function noi = insert_intorb(tree, model, itgr, x0, depth)
  
  dim = model.dim;
  nosd = depth/dim;
  br = tree.radius./(2^nosd);
  hl = itgr.orbit(x0);
  dhl = diff(hl');
  vhl =  model.rhs(hl(2:dim+1,:));  
  rr = abs(dhl(:,2:dim+1))./(ones(length(dhl),1)*br);
  x = cumsum([1 ceil(max(rr'))]);
  [o,t] = intorb(hl(1,:), hl(2:dim+1,:), vhl, x);
  I = tree.insert(o, depth, 0, 0, t*(254/itgr.tFinal) + 1);
  noi = sum(I(find(I>0)));
 
