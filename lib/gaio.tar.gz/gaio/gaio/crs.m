function crs(tree, varargin)

% crs - chain recurrent set.
%   crs(tree [, method, no_of_steps]): subdivision algorithm for the 
%   computation of the chain recurrent set. The optional parameter
%   method specifies the way the transition matrix is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = tree.domain_points,
%     no_of_steps = 1.

% Oliver Junge, 12.6.2000
% oj 1.2.2005: removed Graph class, scc substituted

hit = 1;
to_be_subdivided = 8;

no_of_steps = 1;
points = Points(tree.domain_points);

for i=1:length(varargin),
 o = varargin{i};
if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   points = o;
 elseif isnumeric(o)
   no_of_steps = o;
 end
end

for i=1:no_of_steps
  tree.set_flags('all', to_be_subdivided);
  tree.subdivide;
  A = tree.matrix(points);
  sc = scc(A,A');
  sc(find(sc > -1)) = 1;
  sc(find(sc == -1)) = 0;
  flags = sprintf('%1d', sc);
  tree.set_flags(flags, hit);
  tree.remove(hit);
  disp(sprintf('step %d: %d boxes', i, tree.count(-1)));
end
