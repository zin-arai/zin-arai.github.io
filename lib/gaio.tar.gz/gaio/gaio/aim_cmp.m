function density = aim_cmp(tree, varargin)

% aim_cmp - adaptive computation of invariant measure.
%   aim_cmp(tree [, method, no_of_steps]): an adaptive subdivision algorithm
%   for the computation of invariant measures; refines the box collection
%   in regions with high estimated error of the invariant density h;
%   estimates the local error of h by comparing two different approximations.
%   The optional parameter 'method' specifies the way the transition matrix 
%   is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = 'exhaustion',
%     no_of_steps = 1.

% Oliver Junge, 12.6.2000

hit = 1;
to_be_subdivided = 8;
to_be_unsubdivided = 16;
dim = tree.dim;
options.disp = 0;

no_of_steps = 1;
method = 'exhaustion';

for i=1:length(varargin),
 o = varargin{i};
 if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   method = o;
 elseif isnumeric(o)
   no_of_steps = o;
 end
end
  
for i=1:no_of_steps,
  % compute invariant density on current collection
  A = tree.matrix(method, -1, 16);
  [m, eigenvalue] = eigs(A, 1, options);
  measure = abs(m)./norm(m, 1);
  v0 = tree.volume(-1);
  h0 = abs(measure)./v0;

  tree.set_flags('all', to_be_subdivided);
  tree.subdivide;

  % compute invariant density on refined collection
  A = tree.matrix(method, -1, 16);
  [m, eigenvalue] = eigs(A, 1, options);
  measure = abs(m)./norm(m, 1);
  v1 = tree.volume(-1);
  h1 = abs(measure)./v1;
 
  % estimate the local errors
  n = length(h0);
errors = (abs(h1(1:2:2*n) - h0).*v1(1:2:2*n) + abs(h1(2:2:2*n) - h0).*v1(2:2:2*n));
  mean_error = sum(errors)/n;

  % keep the subdivision only for boxes with high estimated local error
  d = zeros(1, n);
  d(find(errors < mean_error)) = 1;
  flags = sprintf('%1d', d);
  tree.set_flags(flags, to_be_unsubdivided, -2);
  tree.unsubdivide(to_be_unsubdivided);
  tree.unset_flags('all', to_be_unsubdivided);
  disp(sprintf('step %d: %d boxes, eig = %d, mean error = %d', i, tree.count(-1), eigenvalue, mean_error));
end

