 function h=plotplus(tree,p);

% plotbplus(TREE, P), where P is an nx1 vector (e.g. invariant density), 
% shows box coverings of the tree TREE on depth -1.
%


if isa(tree, 'Tree')

      depth = -1;
      dim = tree.dim;
    

  if  dim == 2
     h=showdim2plus(tree.boxes(depth)', p);
xlabel('x');
ylabel('y');
  elseif dim > 2
     h=showdim3plus(tree.boxes(depth)', p);
xlabel('x');
ylabel('y');
zlabel('z');
  end;

else error('Tree-object expected as first input argument.'); 
end;

%
% show 2D-Box-Coverings
%
% showdim2plus(b,p)
%
% p must be a nx1 vector (eg. invariant density)

function h=showdim2plus(b, p)

pnorm=p/max(abs(p));
col=pnorm';

x=[ b(:,1)-b(:,3) b(:,1)+b(:,3) b(:,1)+b(:,3) b(:,1)-b(:,3) ];
y=[ b(:,2)-b(:,4) b(:,2)-b(:,4) b(:,2)+b(:,4) b(:,2)+b(:,4) ];
h=patch(x',y',col);




%
% showdim3plus(b,p) show the global attractor using matlab's patches
%
% p should be an nx1 vector (eg. invariant density)

function h=showdim3plus(b,p)

color=ones(1,length(p),1);

pnorm=p/max(abs(p));

color(1,:,:)=[pnorm];

ix = 1;
iy = 2;
iz = 3;
d = 3;
xmax = max(b(:,ix));
xmin = min(b(:,ix));
ymax = max(b(:,iy));
ymin = min(b(:,iy));
zmax = max(b(:,iz));
zmin = min(b(:,iz));

xr = b(1,ix+d);
yr = b(1,iy+d);
zr = b(1,iz+d);

axis([xmin-xr-0.000,xmax+xr+0.000,ymin-yr-0.000,ymax+yr+0.000,zmin-zr-0.000,zmax+zr+0.000])
hold on
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
h=patch(x',y',z',color);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
h=patch(x',y',z',color);
x=[b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
h=patch(x',y',z',color);
x=[b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)-b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
h=patch(x',y',z',color);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d) b(:,iz)+b(:,iz+d)];
h=patch(x',y',z',color);
x=[b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y=[b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
z=[b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d) b(:,iz)-b(:,iz+d)];
h=patch(x',y',z',color);

