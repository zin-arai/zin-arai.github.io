function [d, pre] = bellman_ford(P, src)

% bellman_ford	shortest path.
%
%   bellman_ford(P, src) computes the lengths of the shortest paths from the
%   node src to all other nodes, regarding the sparse matrix A as a graph, 
%   where the entry (i,j) in A defines the weight of the edge j->i.
%
%   [d, pre] = bellman_ford(P, src) returns the lengths d together with 
%   the precessor node of each node on the shortest path for each node.
%
%   Copyright (c) 2004 by Oliver Junge 
