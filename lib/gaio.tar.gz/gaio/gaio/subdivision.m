function subdivision(t, n)

% subdivision(T) 
%   Performs a step of the subdivision algorithm for the
%   computation of the relative global attractor on the tree T.
%
% subdivision(T, N) 
%   Performs N steps of the subdivision algorithm for the
%   computation of the relative global attractor on the tree T.
%

hit = 1;
to_be_subdivided = 8;

if (nargin < 2)
  n = 1
end

for i=1:n
  t.set_flags('all', to_be_subdivided);
  t.subdivide;
  t.map_all;
  t.remove(hit);
  disp(sprintf('step %d: %d boxes', i, t.count(-1)));
end
