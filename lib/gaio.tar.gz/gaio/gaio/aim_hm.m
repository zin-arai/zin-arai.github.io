function m = aim(tree, varargin)

% aim - adaptive computation of invariant measure.
%   aim(tree [, method, no_of_steps]): an adaptive subdivision algorithm
%   for the computation of invariant measures; refines the box collection
%   in regions with high measure. 
%   The optional parameter 'method' specifies the way the transition matrix 
%   is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = tree.domain_points,
%     no_of_steps = 1.

% Oliver Junge, 12.6.2000

hit = 1;
to_be_subdivided = 8;

no_of_steps = 1;
method = Points(tree.domain_points);

for i=1:length(varargin),
 o = varargin{i};
 if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   method = o;
 elseif isnumeric(o)
   no_of_steps = o;
 end
end

for i=1:no_of_steps,
  options.disp = 0;
  A = tree.matrix(method, -1, 26);
  [m,l] = eigs(A, 1, options);
  m = abs(m)./norm(m,1);
  d = zeros(1, length(m));
  d(find(m > sum(m)/length(m))) = 1;
  flags = sprintf('%1d', d);
  tree.set_flags(flags, to_be_subdivided);
  r = zeros(1, length(m));
  r(find(log10(m) > (log10(max(m))-8))) = 1;
  flags = sprintf('%1d', r);
  tree.set_flags(flags, hit);
  tree.remove(hit);
  tree.subdivide;
  disp(sprintf('step %d: %d boxes, eig = %d', i, tree.count(-1), l));
end
