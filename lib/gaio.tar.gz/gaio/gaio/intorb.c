/* o = intorb(t, f, df, ndt) 

   t    times
   f    points
   df   vec field in f
   ndt  summed number of intermediate points 
*/

#include <math.h>
#include "mex.h"

#define MAXDIM 256

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  int l, k, i, dim, n;
  mxArray *ptr;
  double *pr0, *pr1, *pr2, *pr3, *pl0, *pl1, p[MAXDIM], xi, dxi;
  double x[4], a0[MAXDIM], a1[MAXDIM], a2[MAXDIM], a3[MAXDIM];
  
  dim = mxGetM(prhs[1]);
  n = mxGetN(prhs[1]);

  pr0 = mxGetPr(prhs[0]);
  pr1 = mxGetPr(prhs[1]);
  pr2 = mxGetPr(prhs[2]);
  pr3 = mxGetPr(prhs[3]);

  if (nlhs<2) {
    plhs[0] = mxCreateDoubleMatrix(dim, pr3[n-1], mxREAL);
    pl0 = mxGetPr(plhs[0]);
  } else if (nlhs==2) {
    plhs[0] = mxCreateDoubleMatrix(dim, pr3[n-1], mxREAL);
    pl0 = mxGetPr(plhs[0]);
    plhs[1] = mxCreateDoubleMatrix(1, pr3[n-1], mxREAL);
    pl1 = mxGetPr(plhs[0]);
  } else 
    mxErrMsg("Too many output arguments.");

  for (l=0; l<n-1; l++) {
    /* Hermite interpolation */
    x[0] = *(pr0 + l);
    x[1] = *(pr0 + l); 
    x[2] = *(pr0 + l+1);
    x[3] = *(pr0 + l+1); 
    for (i=0; i<dim; i++) {
      /* first column */
      a0[i] = *(pr1 + l*dim + i);
      a1[i] = *(pr1 + l*dim + i);
      a2[i] = *(pr1 + (l+1)*dim + i);
      a3[i] = *(pr1 + (l+1)*dim + i);
      /* second column */
      a3[i] = *(pr2 + (l+1)*dim + i);
      a2[i] = (a2[i] - a1[i])/(x[2]-x[1]);
      a1[i] = *(pr2 + l*dim + i);
      /*third column */
      a3[i] = (a3[i] - a2[i])/(x[3]-x[1]);
      a2[i] = (a2[i] - a1[i])/(x[2]-x[0]);
      /*forth column */
      a3[i] = (a3[i] - a2[i])/(x[3]-x[0]);
    }
    
    /* evaluation of the polynomial */
    dxi = (pr0[l+1] - pr0[l])/(pr3[l+1]-pr3[l]);
    xi = pr0[l];
    for (k=pr3[l]-1; k<pr3[l+1]; k++) {
      for (i=0; i<dim; i++) {
	*(pl0 + k*dim + i) = a0[i] + (xi - x[0])*(a1[i] 
				   + (xi - x[1])*(a2[i] + (xi - x[2])*a3[i]));
      }  
      xi += dxi;
    }
  }
  return;
}

