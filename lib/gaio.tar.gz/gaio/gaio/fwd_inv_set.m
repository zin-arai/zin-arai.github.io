function I = fwd_inv_set(P)

% FWD_INV_SET	forward invariant set.
%    FWD_INV_SET(P) computes the forward invariant set of the transition
%    matrix P as a vector of flags.
