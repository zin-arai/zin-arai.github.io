/*
 * Copyright (c) 2000 Oliver Junge, for details see COPYING
 * 
 * finder.c
 *
 *
 * T = finder(tree, depth, itgr, x, t_start)
 */

#include <math.h>
#include <gaio/Finder.h>
#include <gaio/Iter.h>

#include "mex.h"

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  mxArray *ptr;
  Iter *iter;
  Integrator *itgr;
  int dim, depth, m, n, k;
  double *prl = 0, dummy[MAXDIM], *pr0 = 0, t_start = 0;

  
  if (nrhs < 4) {
    {mexPrintf("??? not enough input parameters.\n\n"); return;}
  }
  if (nlhs > 1) {
    {mexPrintf("??? too many output parameters.\n\n"); return;}
  }

/*   printf("class = %s\n", mxGetClassName(prhs[0])); */
  if (strcmp(mxGetClassName(prhs[0]), "Tree"))
    {mexPrintf("??? Tree object expected as first input parameter.\n\n"); return;}

  ptr = mxGetField(prhs[0], 0, "handle");
  iter = *(Iter **)mxGetData(ptr);
  if (iter==NULL) {mexPrintf("??? Finder: tree is empty.\n\n"); return;}
  dim = iter->tree->Q->dim;

  depth = (int)*mxGetPr(prhs[1]);
/*   printf("depth = %d\n", depth); */

/*   printf("class = %s\n", mxGetClassName(prhs[2])); */
  if (strcmp(mxGetClassName(prhs[2]), "Integrator"))
    {mexPrintf("??? Integrator object expected as third input parameter.\n\n"); return;}

  ptr = mxGetField(prhs[2], 0, "handle");
  itgr = *(Integrator **)mxGetData(ptr);
  if (itgr==NULL) {mexPrintf("??? Finder: integrator is empty.\n\n"); return;}
  if (itgr->task==NULL) {mexPrintf("??? Finder: no model assigned to integrator.\n\n"); return;}

  n = mxGetN(prhs[3]);
  m = mxGetM(prhs[3]);
  if (m!=dim)
    {mexPrintf("??? Finder: 4th parameter has wrong dimension.\n\n"); return;}
  pr0 = mxGetPr(prhs[3]);

  if (nrhs>4) t_start = *(mxGetPr(prhs[4]));

/*   printf("n = %d\n", n); */
/*   VecPrint(stdout, pr0, dim); */
 
  plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL);
  prl = mxGetPr(plhs[0]);
  
  for (k=0; k < n; k++) {
    prl[k] = Finder(iter->tree, depth, itgr, t_start, pr0 + k*dim, dummy);
  }

  

  return;
}


