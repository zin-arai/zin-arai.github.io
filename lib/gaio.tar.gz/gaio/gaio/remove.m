function remove(tree, I)

% removes all leaves not listed (by number) in I

hit = 1;
fI = zeros(tree.count(-1),1);
fI(I) = 1;
tree.unset_flags('all', hit);
flags = sprintf('%1d', fI);
tree.set_flags(flags, hit);
tree.remove(hit);
