function [N, D] = chull(X)

% computes the convex hull of the set of points X in terms
% of the normals on the facets


dim = size(X,2);
mX = sum(X)/size(X,1);
C = convhulln(X);
N = zeros(size(C));
D = zeros(size(C,1),1);
for i=1:size(C,1),
  A = X(C(i,:),:);
  E = ones(dim,1)*X(C(i,1),:);
  n = null(A-E);
  d = X(C(i,1),:)*n;
  s = sign(d - mX*n);
  N(i,:) = s*n';
  D(i) = s*d;
end

