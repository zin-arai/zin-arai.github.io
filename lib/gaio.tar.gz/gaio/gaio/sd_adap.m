function sd_adap(t, p, n)

% sd_adap(T, P, N) 
%   Performs N steps of the "high mass" adaptive subdivision algorithm for the
%   computation of an invariant measure the tree T using the
%   testpoints P for the computation of the transition matrix.
%
%   default: N = 1.

hit = 1;
to_be_subdivided = 8;

if (nargin < 2)
  error('usage: sd_adap(tree, points [, no_of_steps])');
end

if (nargin < 3)
  n = 1;
end

for i=1:n
  A = t.matrix(p);
  [v,l] = seig(A);
  m = abs(v(:,1));
  d = zeros(1, length(m));
  d(find(m > sum(m)/length(m))) = 1;
  flags = num2str(d, '%1d');
  t.set_flags(flags, to_be_subdivided);
  r = zeros(1, length(m));
  r(find(log10(m) > (log10(max(m))-8))) = 1;
%  flags = num2str(r, '%1d');
  flags = sprintf('%1d', r);
  t.set_flags(flags, hit);
  t.remove(hit);
  t.subdivide;
  disp(sprintf('step %d: %d boxes, eig = %d', i, t.count(-1), l));
end
