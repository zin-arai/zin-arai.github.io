function L = lip_est(tree, center, h)
% LIP_EST - estimate the local Lipschitz constant of the invariant density
%   
  
dim = tree.dim;
L = zeros(length(center), 1);
box = tree.first_box(-1);
while (~isempty(box))
  no = box(2*dim+2);
  ngbs = tree.neighbours;
  if (dim==1)
     c = abs(center(:,ngbs)-center(:,no)*ones(1,length(ngbs)));
  else
    c = max(abs((center(:,ngbs)-center(:,no)*ones(1,length(ngbs)))));
  end
  L(no) = max(abs(h(ngbs)-h(no))./c');
  box = tree.next_box(-1);
end  
