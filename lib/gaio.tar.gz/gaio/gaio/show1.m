%
% show the measure in 1D
%
% show1(b,col)
%
function h=show1(b, col)
x=[b(:,1)-b(:,2) b(:,1)+b(:,2) b(:,1)+b(:,2) b(:,1)-b(:,2)];
y=[zeros(size(b,1),1) zeros(size(b,1),1) b(:,3) b(:,3)];
h=patch(x',y',col);
