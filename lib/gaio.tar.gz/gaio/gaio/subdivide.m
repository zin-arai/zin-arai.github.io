function subdivide(tree, I, depth)

% subdivides all leaves listed (by number) in I, but not more than
% up to the given depth - if specified

to_be_subdivided = 8;
fI = zeros(tree.count(-1),1);
fI(I) = 1;
tree.unset_flags('all', to_be_subdivided);
flags = sprintf('%1d', fI);
tree.set_flags(flags, to_be_subdivided);
tree.subdivide(to_be_subdivided);
if nargin > 2
  tree.delete(depth+1);
end
