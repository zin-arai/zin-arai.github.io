/* Noch bearbeiten.......*/

#include <math.h>
#include <gaio/Graph.h>
#include <gaio/SparseMatrix.h>

#include "mex.h"

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  int n, nz, *ptr, *ir, *jc;
  int dims[1];
  Graph *g = 0;
  double *pr;
  
  /* Check for proper number of arguments */
  
  if (nrhs > 1) {
    {mexPrintf("??? load_graph requires one input argument.\n\n"); return;}
  } else if (nlhs > 1) {
    {mexPrintf("??? load_graph requires one output argument.\n\n"); return;}
  }
  
  /* Create a matrix for the return argument */
  dims[0] = 1; 
  plhs[0] = mxCreateNumericArray(1, dims, mxINT32_CLASS, mxREAL);

  n = mxGetM(prhs[0]);
  nz = mxGetNzmax(prhs[0]);
  pr = mxGetPr(prhs[0]);
  ir = mxGetIr(prhs[0]);
  jc = mxGetJc(prhs[0]);

  ptr = (int *)mxGetData(plhs[0]);  
  ptr[0] = (int)TransitionGraphFromPtr(n, nz, ir, jc, pr);
  return;

}


