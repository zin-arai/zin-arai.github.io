function expand(tree, depth, which, flag_ins, flag_found)
% EXPAND - expand box collection
%   expand(tree, d, which, f0, f1) expands all boxes on depth
%   d with flags which set and sets the flags f0 in all inserted
%   boxes and the flag f1 in all found boxes

  d = tree.dim;
  none = 0;
  to_be_expanded = 4;
  
  integrator = Integrator(tree.integrator);
  domain_points = Points(tree.domain_points);
  image_points  = Points(tree.image_points);
  
  tree.change_flags('all', which, to_be_expanded);
  b = tree.first_box(depth);
  while (~isempty(b))
    center = b(1:d);
    radius = b(d+1:2*d);
    flags = b(2*d+1);
    if (bitand(flags, to_be_expanded))
      p = domain_points.get(center, radius, integrator);
      fp = integrator.map(p);
      ip = image_points.get(fp, radius, integrator);
      tree.insert(ip, depth, flag_ins, flag_found);
    end
    b = tree.next_box(depth);
  end
  tree.unset_flags('all', to_be_expanded);
