function fba_remove(tree, depth, lambda, y)


d = tree.dim;
none = 0;
hit = 1;
inserted = 2;
to_be_expanded = 4;
to_be_subdivided = 8;


integrator = Integrator(tree.integrator);

w=tree.get_flags('all', -1);
I=find(w==2);
J=find(w==0);

b=tree.boxes(-1);
k2=lambda^integrator.tFinal;

y = zeros(1, tree.count(-1));
for i=1:length(I)
     for j=1:length(J)
     if norm(b(1:d, I(i))-b(1:d, J(j)))<k2;
     y(I(i))=1;
     break;
     end;
     end;
end;

       
tree.change_flags(dec2bin(y)', inserted, hit , -1);
tree.remove(inserted);

%disp(sprintf('%d boxes', tree.count(-1))); 

 





