function v_new = realloc(v, size_new)
  
  v_new = zeros(size_new(1), size_new(2));
  v_new(1:size(v,1),1:size(v,2)) = v;
  
