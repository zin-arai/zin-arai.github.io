/* (c) 2004 Oliver Junge */

#include <math.h>
#include <mex.h>

struct GRAPH {
	int n;
	int *ep;
	int *edge;
	double *ew;
	};

void initialize_single_source(struct GRAPH graph, int sour, double *d, int *pre) {
  int i;
  for (i=0; i<graph.n; i++) {
    d[i] = 1e308;
    pre[i] = -1;
  }
  d[sour] = 0.0;
}

int bellman_ford(struct GRAPH graph, int sour, double *d, int *pre) { 

  int i, u, v;

  initialize_single_source(graph, sour, d, pre);  

  for (i=0; i<graph.n; i++) 
    for (u=0; u<graph.n; u++) 
      for (v=graph.ep[u]; v<graph.ep[u+1]; v++) 
        if ( d[graph.edge[v]] > d[u] + (graph.ew[v]) ) { 
          d[graph.edge[v]] = d[u] + graph.ew[v];
          pre[graph.edge[v]] = u;
        }
 
   for (u=0; u<graph.n; u++) 
     for (v=graph.ep[u]; v<graph.ep[u+1]; v++) 
       if ( d[graph.edge[v]] > d[u] + (graph.ew[v]) ) 
         return 0;

  return 1;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
  
  int i, e, sour, *pre;
  struct GRAPH graph,fgraph;
  double *pr, *d;
  
  if (nrhs < 2)
    {mexPrintf("??? usage: bellman_ford(matrix, source).\n\n"); return;}

  if (!mxIsSparse(prhs[0]))
    {mexPrintf("??? first parameter must be sparse.\n\n"); return;}

  graph.n = mxGetM(prhs[0]);
  graph.ep = mxGetJc(prhs[0]);
  graph.edge = mxGetIr(prhs[0]);
  graph.ew = mxGetPr(prhs[0]);

  sour = (int)*mxGetPr(prhs[1]) - 1;
  if (sour < 0 || sour >= graph.n)
    {mexPrintf("??? source node out of range.\n\n"); return;}
    
  if (!(d   = (double*)mxCalloc((unsigned)graph.n,sizeof(double))) ||
      !(pre= (int*)   mxCalloc((unsigned)graph.n,sizeof(int)))     )
   {mexPrintf("??? memory allocation error\n\n"); return;} 

  if (!bellman_ford(graph, sour, d, pre))
    {mexPrintf("??? negative weight cycle - no solution exists.\n\n"); return;}

  plhs[0] = mxCreateDoubleMatrix(1, graph.n, mxREAL);
  pr = mxGetPr(plhs[0]);
  for (i=0; i<graph.n; i++) pr[i] = ( d[i]==1e308 ? -1 : d[i]);
  if (nrhs > 1) {
    plhs[1] = mxCreateDoubleMatrix(1, graph.n, mxREAL);
    pr = mxGetPr(plhs[1]);
    for (i=0; i<graph.n; i++) pr[i] = pre[i]+1;
  }
  
  mxFree(d);
  mxFree(pre);

  return;
}
