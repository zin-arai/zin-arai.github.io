/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Integrator.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Integrator *i;
  mxArray *ptr;
  double *pr, *u = 0;
  
  
  ptr = mxGetField(prhs[0], 0, "handle");
  i = (Integrator *)ptrFromMxArray(ptr);
  if (i==NULL) {mexPrintf("??? Integrator: integrator is empty.\n\n"); return;}
  
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  ptr = mxGetField(prhs[1], 0, "subs");
  attr = mxArrayToString(ptr);

  /* attributes */
  if (mxGetNumberOfElements(prhs[1])==1 && !strcmp(type,".")) {

    if (!strcmp(attr, "filename")) {
      printf("%s\n", i->filename); fflush(stdout);
      plhs[0] = mxCreateString(i->filename);
    } else if (!strcmp(attr, "name")) {
      plhs[0] = mxCreateString(i->name);
    } else if (!strcmp(attr, "dim")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = TaskDim(i->task);
    } else if (!strcmp(attr, "tFinal")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->tFinal;
    } else if (!strcmp(attr, "h")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->h;
    } else if (!strcmp(attr, "h_min")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->h_min;
    } else if (!strcmp(attr, "h_max")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->h_max;
    } else if (!strcmp(attr, "eps")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->eps;
    } else if (!strcmp(attr, "model")) {
      mwSize dims[2] = {1,1};
      const char *field_names[] = {"handle"};
      if (i->task == NULL) {
	mexPrintf("??? Integrator.model: No model assigned.\n\n"); return;}
      plhs[0] = mxCreateStructArray(2, dims, 1, field_names);
      mxSetField(plhs[0], 0, "handle", ptrToMxArray(i->task->model));
    } else if (!strcmp(attr, "task")) {
      char *taskname;
      if (i->task == NULL) {
	{mexPrintf("??? Integrator.task: no task assigned.\n\n"); return;}
      } else { 
      taskname = (char *)(i->task->name);
      plhs[0] = mxCreateCharMatrixFromStrings(1,(const char**)&(taskname));
      }
    } else if (!strcmp(attr, "info")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      IntegratorInfo(stdout, i);
    } else if (!strcmp(attr, "count")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->count;
    } else if (!strcmp(attr, "steps_max")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = i->steps_max;
    } else {
      {mexPrintf("??? Integrator: unknown field or method.\n\n"); return;}
    }
  }
   
  /* methods */
  if (mxGetNumberOfElements(prhs[1])==2 && !strcmp(type,".")) {
    int dim, nargin;
    double *pr0, *pr1, *prl, *prl0, *prl1;
    
    ptr = mxGetField(prhs[1], 1, "subs");
    nargin = mxGetNumberOfElements(ptr);
    pr0 = mxGetPr(mxGetCell(ptr, 0));

    if (!mxIsNumeric(mxGetCell(ptr, 0))) 
      {mexPrintf("??? Integrator: matrix as first argument expected.\n\n"); return;}
    if (i->task==NULL) 
      {mexPrintf("??? Integrator: no model assigned.\n\n"); return;}
    dim = TaskDim(i->task);
    
    if (!strcmp(attr, "eval")) { /* eval */

      int n, m, length = 1, k;
      n = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.map: input matrix has wrong dimension.\n\n"); return;}
      if (mxGetNumberOfElements(ptr) == 2)
	length = (int)*mxGetPr(mxGetCell(ptr, 1)); 
      plhs[0] = mxCreateDoubleMatrix(dim, length+1, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < dim; k++) prl[k]= pr0[k];
      for (k=0; k < length; k++) 
	IntegratorMap(i, prl+k*dim, u, prl+(k+1)*dim);

    } else if (!strcmp(attr, "orbit")) { /* orbit */

      int n, m, length, j, k;
      double *y = 0, *t = 0, *u = 0;
      n = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.map: input matrix has wrong dimension.\n\n"); return;}
      IntegratorOrbit(i, pr0, u, &y, &t, &length);
      plhs[0] = mxCreateDoubleMatrix(dim+1, length, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < length; k++) {
	prl[k*(dim+1)] = t[k];
	for (j=1; j < dim+1; j++)
	  prl[k*(dim+1) + j] = y[k*dim + j-1];
      }
      free(y);
      free(t);

    } else if (!strcmp(attr, "uorbit")) { /* orbit */

      int length, j, k, n, m;
      double *y = 0, *t = 0;
      int uDim = *(i->task->model->uDim);
      int steps = ceil(i->tFinal/i->h);
      n = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.uorbit: input matrix has wrong dimension.\n\n"); return;}
      if (mxGetNumberOfElements(ptr) == 2) {
	n = mxGetN(mxGetCell(ptr, 1));
	m = mxGetM(mxGetCell(ptr, 1));
	printf("n = %d\n", n);
	printf("m = %d\n", m);
	printf("steps = %d\n", steps);
	if (m!=uDim) {mexPrintf("??? Integrator.uorbit: wrong uDim.\n\n"); return;}
	if (n < steps) 
	  {mexPrintf("??? Integrator.uorbit: too few control values.\n\n"); return;}
	u = mxGetPr(mxGetCell(ptr, 1));
      }
      IntegratorOrbit(i, pr0, u, &y, &t, &length);
      plhs[0] = mxCreateDoubleMatrix(dim+1, length, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < length; k++) {
	prl[k*(dim+1)] = t[k];
	for (j=1; j < dim+1; j++)
	  prl[k*(dim+1) + j] = y[k*dim + j-1];
      }
      free(y);
      free(t);

    } else if (!strcmp(attr, "finder")) { /* finder */

      int n, m, k;
      double *c, *r, dummy[MAXDIM];
      if (nargin < 3)
	{mexPrintf("??? not enough input arguments.\n\n"); return;}
      c = mxGetPr(mxGetCell(ptr, 1));
      VecPrint(stdout, c, dim);
      n = mxGetN(mxGetCell(ptr, 1));
      m = mxGetM(mxGetCell(ptr, 1));
      if (!(((m==dim) && (n==1)) || ((n==dim) && (m==1))))
	{mexPrintf("??? Integrator.finder: center of target box has wrong dimension.\n\n"); return;}
      r = mxGetPr(mxGetCell(ptr, 2));
      VecPrint(stdout, r, dim);
      n = mxGetN(mxGetCell(ptr, 2));
      m = mxGetM(mxGetCell(ptr, 2));
      if (!(((m==dim) && (n==1)) || ((n==dim) && (m==1))))
	{mexPrintf("??? Integrator.finder: radius of target box has wrong dimension.\n\n"); return;}
      n = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.finder: input matrix has wrong dimension.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(1, n, mxREAL);
      prl0 = mxGetPr(plhs[0]);
      for (k=0; k < n; k++) 
	IntegratorFinder(i, pr0 + k*dim, u, c, r, prl0 + k, dummy);

    } else if (!strcmp(attr, "map")) { /* map */
 
      int n, m, k;
      n = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.map: input matrix has wrong dimension.\n\n"); return;}
      plhs[0] = mxCreateDoubleMatrix(dim, n, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k=0; k < n; k++) 
	IntegratorMap(i, pr0 + k*dim, u, prl + k*dim);

    } else if (!strcmp(attr, "umap")) { /* umap */
 
      int n0, n1, m, k0, k1, j, ju;
      int uDim = *(i->task->model->uDim);
      int steps = ceil(i->tFinal/i->h);
      double *uv;
      NEW(uv, steps*uDim);

      n0 = mxGetN(mxGetCell(ptr, 0));
      m = mxGetM(mxGetCell(ptr, 0));
      if (m!=dim)
	{mexPrintf("??? Integrator.umap: input matrix has wrong dimension.\n\n"); return;}
      if (mxGetNumberOfElements(ptr) < 2) 
	{mexPrintf("??? Integrator.umap: control values missing.\n\n"); return;}
      n1 = mxGetN(mxGetCell(ptr, 1));
      m = mxGetM(mxGetCell(ptr, 1));
      if (m!=uDim) {mexPrintf("??? Integrator.umap: wrong uDim.\n\n"); return;}
      u = mxGetPr(mxGetCell(ptr, 1));
      /*      for (ju=0; ju<2*uDim; ju++) 
	      printf("u[%d] = %lg\n", ju, u[ju]); fflush(stdout);*/
      
      plhs[0] = mxCreateDoubleMatrix(dim, n0*n1, mxREAL);
      prl = mxGetPr(plhs[0]);
      for (k1=0; k1 < n1; k1++) {
	for (j=0; j < steps; j++) 
	  for (ju=0; ju< uDim; ju++)
	    uv[j*uDim + ju] = u[k1*uDim + ju];
	for (k0=0; k0 < n0; k0++) {
	  IntegratorMap(i, pr0 + k0*dim, uv, prl + k1*dim + k0*n1*dim);
	}
      }

      free(uv);
    } 
  }
  
  mxFree(attr);
  mxFree(type);

  return;
}

