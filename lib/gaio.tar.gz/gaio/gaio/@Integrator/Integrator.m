function i = Integrator(i_in)
%
% Integrator - load an integrator from a file.
%    i = Integrator(name) loads an integrator from the file 'name.so' 
%    (see the reference manual for a description of how to write your
%    own integrator).
%
%    NOTE: call delete(i); clear i; to delete the integrator from memory.
%
% Attributes
%    i.filename         filename as given for loading the integrator
%    i.name             descriptive name
%    i.dim              dimension of phase space
%    i.tFinal           integration time 
%    i.tFinal = t       sets integration time to t
%    i.h                stepsize
%    i.h = h            sets stepsize to h
%    i.model = m        assignes model m to the integrator
%    i.model            returns a handle to the assigned model (use Model(i.model) to generate a Model)
%    i.task = 't'       sets the integrators task to 't' (string)
%    i.task             name of the chosen task 
%    i.count            number of evaluations of the right hand side
%                       of the assigned model since loading the integrator 
%    i.count = c        sets i.count to c
%    For integrators with adaptive stepsize control:
%    i.h_min            minimal stepsize
%    i.h_min = h        sets minimal stepsize to h 
%    i.h_max            maximal stepsize
%    i.h_max = h        sets maximal stepsize to h 
%    i.eps              local error tolerance
%    i.eps = eps        sets local error tolerance to eps
%    i.steps_max        maximum number of allowed integration steps
%    i.steps_max = s    sets the maximum number of allowed integration steps
%
% Methods
%    i.eval(X)          returns the matrix [X, f(X)], where X is a point in 
%                       state space and f is the map defined by
%                       applying the integrator to its assigned model.        
%    i.eval(X, K)       returns the matrix [X, f(X), f^1(X), ..., f^K(X)], 
%                       where K is a positive integer. 
%    i.orbit(X)         computes f(X) and returns the orbit internally 
%                       produced by the integrator; the first row of the 
%                       returned matrix contains the intermediate times;
%    i.finder(X, C, R)  returns the first times for which the
%                       orbits starting in X enter the box B(C,R)
%    i.map(X)           for a vector X: returns f(X); 
%                       for a matrix X: returns [f(X(:,1)), ..., f(X(:,n))],
%                       where n ist number of columns of X.

% Oliver Junge, 3.4.2001

if nargin == 0
  error('Too few input arguments: filename or handle expected.')
elseif isa(i_in, 'struct')
  i = i_in;
  i = class(i, 'Integrator');
elseif ischar(i_in) 
  i.handle = load_integrator(i_in);
  i = class(i, 'Integrator');
else
  error('Input argument of wrong type: handle or string expected.');
end

