/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Model.h>
#include <gaio/Integrator.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr, *task;
  Integrator *intr;
  mxArray *ptr;
  double *pr;
  
  ptr = mxGetField(prhs[0], 0, "handle");
  intr = (Integrator *)ptrFromMxArray(ptr);
  if (intr==NULL) {mexPrintf("??? Integrator: integrator is empty.\n\n"); return;}
  
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  ptr = mxGetField(prhs[1], 0, "subs");
  attr = mxArrayToString(ptr);
  
  if (!strcmp(type,".")) {

    if (!strcmp(attr, "model")) {
      if (!strcmp(mxGetClassName(prhs[2]), "Model")) {
        Model *m; 
        ptr = mxGetField(prhs[2], 0, "handle");
        m = (Model *)ptrFromMxArray(ptr);
        if (m==NULL) 
          {mexPrintf("??? Integrator.model: model is empty.\n\n"); return;}
        IntegratorSetModel(intr, m); 
      } else { 
	    {mexPrintf("??? Integrator.model: right hand side must be a model object\n\n"); return;} 
      }
/*       IntegratorInfo(stdout, intr); */
    } else if (!strcmp(attr, "task")) {
      if (strcmp(mxGetClassName(prhs[2]), "char"))
	{mexPrintf("??? Integrator.task: character string expected.\n\n"); return;}
      task = mxArrayToString(prhs[2]);
      mexPrintf("%s\n", task); 
      IntegratorSetTask(intr, task);
      mxFree(task);
    } else if (!strcmp(attr, "tFinal")) {
      pr = mxGetPr(prhs[2]);
      intr->tFinal = *pr;
    } else if (!strcmp(attr, "h")) {
      pr = mxGetPr(prhs[2]);
      intr->h = *pr;
    } else if (!strcmp(attr, "h_min")) {
      pr = mxGetPr(prhs[2]);
      intr->h_min = *pr;
    } else if (!strcmp(attr, "h_max")) {
      pr = mxGetPr(prhs[2]);
      intr->h_max = *pr;
    } else if (!strcmp(attr, "eps")) {
      pr = mxGetPr(prhs[2]);
      intr->eps = *pr;
    } else if (!strcmp(attr, "count")) {
      pr = mxGetPr(prhs[2]);
      intr->count = *pr;
    } else if (!strcmp(attr, "steps_max")) {
      pr = mxGetPr(prhs[2]);
      intr->steps_max = *pr;
    } else
      {mexPrintf("??? Integrator: unknown attribute.\n\n"); return;}
  }

  mxFree(attr);
  mxFree(type);

  plhs[0] = (mxArray*) prhs[0];

  return;
}


