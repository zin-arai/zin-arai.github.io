/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Points.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *filename, *info;
  int dim, no;
  
  /* Check for proper number of arguments */

  if (nrhs < 2) {
    mexPrintf("??? two or three input arguments required.\n\n"); return;
  } 
  if (!mxIsChar(prhs[0])) {
    mexPrintf("??? filename expected as first argument.\n\n"); return;
  }
  
  filename = mxArrayToString(prhs[0]);
  dim = (int)*mxGetPr(prhs[1]);
  if (nrhs < 3) {
    info = (char *)mxMalloc(2);
    snprintf(info, 2, "%d", 1);
  } else {
    if (mxIsChar(prhs[2])) 
      info = mxArrayToString(prhs[2]);
    else if (mxIsDouble(prhs[2])) {
      info = (char *)mxMalloc(255);
      no = (int)*mxGetPr(prhs[2]);
      snprintf(info, 255, "%d", no);
    } else {
      mexPrintf("??? argument 3 is of wrong type.\n\n"); return;
    }
  }

  plhs[0] = ptrToMxArray(PointsNew(filename, dim, info));

  mxFree(filename);
  mxFree(info);

  return;
}


