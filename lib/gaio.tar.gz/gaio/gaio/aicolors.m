function c = aicolors(v)
  
  eps = 1e-20/length(v);
  a = abs(v);
  mi = log(max(min(a), eps));
  ma = log(max(max(a), eps));
  a(find(a < eps)) = eps;
  h = floor(127*(log(a)-mi)/(ma-mi)+1);
  i_pos = find(v > 0);
  h(i_pos) = h(i_pos) + 127;
  c = sprintf('%1c', h);
  
