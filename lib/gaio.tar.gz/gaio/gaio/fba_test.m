function fba(tree, y, depth, lambda, varargin)

% fba - fast basin of attraction. 
% fba(tree,y, depth,lambda,[,domain_points,image_points,integrator,no_of_steps]):
% 
%   continuation algorithm for the computation of the fast basin of attraction 
%   of a given box collection with respect to lambda. 
%   Precondition: the tree must at least contain one box which has its second
%   flag (="inserted") set. Typical usage:
%
% 
%   fba(tree,y, depth, lambda);
%
% Kathrin Padberg, 1.8.2001

%d = tree.dim;
%none = 0;
%hit = 1;
%inserted = 2;
%to_be_expanded = 4;
%to_be_subdivided = 8;

integrator = Integrator(tree.integrator);


k2 = lambda^(integrator.tFinal);
for i=1:length(y(1, :))
     fp=integrator.map(y(1:3, i));
     if norm(fp-y(1:3, i))>k2
tree.insert(fp, depth, 2,  2);
     end;
     end;

