function density = aim_lip(tree, varargin)

% aim_lip - adaptive computation of invariant measure.
%   aim_lip(tree [, method, no_of_steps]): an adaptive subdivision algorithm
%   for the computation of invariant measures; refines the box collection
%   in regions with high estimated error of the invariant density h;
%   estimates the local error of h by estimating its local Lipschitz constant.
%   The optional parameter 'method' specifies the way the transition matrix 
%   is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = 'exhaustion',
%     no_of_steps = 1.

% Oliver Junge, 12.6.2000

hit = 1;
to_be_subdivided = 8;
dim = tree.dim;
options.disp = 0;

no_of_steps = 1;
method = 'exhaustion';

for i=1:length(varargin),
 o = varargin{i};
 if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   method = o;
 elseif isnumeric(o)
   no_of_steps = o;
 end
end
  
for i=1:no_of_steps,
  % compute invariant measure on current collection
  A = tree.matrix(method, -1, 26);
  [m, eigenvalue] = eigs(A,1,options);
  measure = abs(m)./norm(m, 1);

  % compute corresponding invariant density
  boxes = tree.boxes(-1);
  n = size(boxes, 2);
  centers = boxes(1:dim,:);
  radii = boxes(dim+1:2*dim,:);
  if (dim==1)
    volumes = 2^dim*radii;
    diams = 2*radii;
  else
    volumes = 2^dim*prod(radii);
    diams = 2*max(radii);
  end
  density = abs(measure)./volumes';

  % estimate the local Lipschitz constant of the invariant density
  Lipschitz = lip_est(tree, centers, density);

  % estimate the local errors
  errors = Lipschitz.*diams'.*volumes';
  mean_error = sum(errors)/n;

  % subdivide only boxes with high estimated local error
  d = zeros(1, n);
  d(find(errors > mean_error)) = 1;
  flags = sprintf('%1d', d);
  tree.set_flags(flags, to_be_subdivided);
  tree.subdivide;
  disp(sprintf('step %d: %d boxes, eig = %d, mean error = %d', i, tree.count(-1), eigenvalue, mean_error));
end
