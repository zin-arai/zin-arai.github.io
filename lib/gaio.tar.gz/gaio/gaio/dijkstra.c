#include <math.h>
#include <mex.h>

#define INFINITY 100000

struct GRAPH {
	int n;
	int *ep;
	int *edge;
	double *ew;
	};

int graphNew (struct GRAPH *graph, int n, int e)
{ graph->n = n;
  if(!(graph->ep   = (int*)   mxCalloc((unsigned)(n+1),sizeof(int))) ||
     !(graph->edge = (int*)   mxCalloc((unsigned)(e),  sizeof(int))) ||
     !(graph->ew   = (double*)mxCalloc((unsigned)(e),  sizeof(double))))
  { printf("ERROR...calloc!\n"); return 1; }
  return 0;
}

void graphFree (struct GRAPH graph)
{ 
  /*  
      mxFree(graph.ep);
      mxFree(graph.edge);
      mxFree(graph.ew);
  */
}

struct BHEAP {
        int n;
        int space;
        int *ele;
        int *pos;
        };

int bheapNew (struct BHEAP *bheap, int n)
{ int i;

  bheap->n = bheap->space = n;
 
  if(!(bheap->ele = (int*)mxCalloc((unsigned)n,sizeof(int))) ||
     !(bheap->pos = (int*)mxCalloc((unsigned)n,sizeof(int))) )
  { printf("ERROR...calloc!\n"); return 1; }
  for (i=0; i<n; i++)
    bheap->ele[i] = bheap->pos[i] = i;
  return 0;
}

void bheapFree (struct BHEAP bheap)
{ 
  /*
    mxFree(bheap.ele);
    mxFree(bheap.pos);
  */
}

int bheap_size (struct BHEAP *bheap)
{
  return bheap->n;
}
 
int bheap_min (struct BHEAP *bheap)
{
  return bheap->ele[0];
}   

void bheap_check (struct BHEAP bheap, double *d)
{ int i,left,right;

  for (i=0; i<bheap.n; i++)
  { left = 2*i+1;
    right = 2*i+2;
    if ((left<bheap.n && d[bheap.ele[left]]<d[bheap.ele[i]])  ||  (right<bheap.n && d[bheap.ele[right]]<d[bheap.ele[i]]))
    { printf("ERROR...no bheap property!\n"); exit(0); }
  }
}

void heapify (struct BHEAP bheap, int root, double *d)
{ int	left=root*2+1, right=root*2+2, smallest=root, tmp; 

  if ((left < bheap.n) && (d[bheap.ele[left]] < d[bheap.ele[smallest]]))
    smallest = left;
  if((right < bheap.n) && (d[bheap.ele[right]] < d[bheap.ele[smallest]]))
    smallest = right;
  if (smallest != root)
  { bheap.pos[bheap.ele[root]] = smallest;
    bheap.pos[bheap.ele[smallest]] = root;
    tmp = bheap.ele[root];
    bheap.ele[root] = bheap.ele[smallest];
    bheap.ele[smallest] = tmp;
    heapify(bheap,smallest,d);
  }
}

void bheap_decrease_key (struct BHEAP bheap, int element, double *d)
{ int tmp, position=bheap.pos[element], father=(position-1)/2;

  while (position>0 && d[element]<d[bheap.ele[father]])
  { bheap.pos[bheap.ele[position]] = father;
    bheap.pos[bheap.ele[father]] = position;
    tmp = bheap.ele[father];
    bheap.ele[father] = bheap.ele[position];
    bheap.ele[position] = tmp;
    position = father;
    father = (father-1)/2;
  } 
}

int bheap_extract_min (struct BHEAP *bheap, double *d)
{ int min = bheap->ele[0];
  bheap->ele[0] = bheap->ele[--(bheap->n)];
  bheap->pos[bheap->ele[0]] = 0;
  heapify(*bheap,0,d);
  return min;
}

int Dijkstra (struct GRAPH graph, int sour, int dest, int **path, int *length, double *dist)
{ int		i, j, *pre;
  double	*d;
  struct BHEAP	bheap;

  if (!(d   = (double*)mxCalloc((unsigned)graph.n,sizeof(double))) ||
      !(pre = (int*)   mxCalloc((unsigned)graph.n,sizeof(int)))     )
  { printf("ERROR...calloc!\n"); return 1; }

  for (i=0; i<graph.n; i++)
    d[i] = INFINITY;

  if (bheapNew (&bheap,graph.n))
  { printf("ERROR...bheapNew!\n"); return 1; }

  d[sour] = 0.0;
  bheap_decrease_key(bheap,sour,d);
  bheap_extract_min(&bheap,d);
  for (j=graph.ep[sour]; j<graph.ep[sour+1]; j++) {
    if (d[graph.edge[j]] > d[sour] + (graph.ew[j])) { 
      d[graph.edge[j]] = d[sour] + (graph.ew[j]);
      pre[graph.edge[j]] = sour;
      bheap_decrease_key(bheap,graph.edge[j],d);
    }
  }
  
  do { 
    i = bheap_extract_min(&bheap,d);
    for (j=graph.ep[i]; j<graph.ep[i+1]; j++) {
      if (d[graph.edge[j]] > d[i] + (graph.ew[j])) { 
	d[graph.edge[j]] = d[i] + (graph.ew[j]);
        pre[graph.edge[j]] = i;
        bheap_decrease_key(bheap,graph.edge[j],d);
      }
    }
  } while (dest!=i && bheap_size(&bheap)>0 && d[bheap_min(&bheap)] < INFINITY);

  if (i == dest) { 
    /*    printf("found path.\n"); fflush(stdout); */
    *length = 0;
     while (i!=sour)
    { (*length)++;
      i = pre[i];
    }
    if(!(*path = (int*)mxCalloc((unsigned)((*length)+1),sizeof(int))))
    { printf("ERROR...calloc!\n"); return 1; }
    i = dest;
    for (j=*length; j>=0; j--)
    { (*path)[j] = i;
      i = pre[i];
    }
    *dist = d[dest];
  }
  else {
    /*    printf("found no path.\n"); fflush(stdout); */
    *length = -1;
    *dist = -1;
  }
  mxFree(d);
  mxFree(pre);
  bheapFree (bheap);
  return 0;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[]) {
  
  int i, src, dest, *path, length, debug  = 1;
  struct GRAPH graph;
  double *pr, dist;
  
  
  if (nrhs < 3)
    {mexPrintf("??? usage: shortest_path(matrix, source, destination).\n\n"); return;}
  if (nrhs==4)
    debug = (int)*mxGetPr(prhs[3]);
  if (!mxIsSparse(prhs[0]))
    {mexPrintf("??? first parameter must be sparse.\n\n"); return;}
  if (debug) printf("dijkstra: info: no 1-edgeweight any more.");

  graph.n = mxGetM(prhs[0]);
  graph.ep = mxGetJc(prhs[0]);
  graph.edge = mxGetIr(prhs[0]);
  graph.ew = mxGetPr(prhs[0]);

  src = (int)*mxGetPr(prhs[1]) - 1;
  if (src < 0 || src >= graph.n)
    {mexPrintf("??? source node out of range.\n\n"); return;}
  if (debug) printf("src = %d\n", src); fflush(stdout);
    
  dest = (int)*mxGetPr(prhs[2]) - 1;
  if (dest < 0 || dest >= graph.n)
    {mexPrintf("??? destination node out of range.\n\n"); return;}
  if (debug) printf("dest = %d\n", dest); fflush(stdout); 

  if (src==dest)
    {mexPrintf("??? source == destination.\n\n"); return;}

  if (Dijkstra (graph, src, dest, &path, &length, &dist))
    {mexPrintf("??? allocation error in Dijkstra.\n\n"); return;}

  if (debug) printf("\nlength: %f\n", dist); 

  plhs[0] = mxCreateDoubleMatrix(1, length+1, mxREAL);
  pr = mxGetPr(plhs[0]);
  for (i=0; i<length+1; i++) {
    /*    printf("\ni = %d\n", i); fflush(stdout);*/
    pr[i] = path[i] + 1;
  }
  if (nlhs > 1) {
    /*    printf("allocating second right hand side.\n"); fflush(stdout); */
    plhs[1] = mxCreateDoubleMatrix(1, 1, mxREAL);
    pr = mxGetPr(plhs[1]);
    pr[0] = dist;
  }
  
  /*  mxFree(path); */

  return;
}
