function p = Points(p_in, dim, info)

% Points   load points from a file
%    p = Points(name, dim, n) loads test point from the file
%    'name.so' and allocates space for n test points of dimension 
%    dim; for some test points the parameter n can be omitted.
% 
%    NOTE: call delete(p); clear p; to delete the points from memory.
%  
% Attributes
%    p.filename     filename as given for loading
%    p.name         descriptive name
%    p.dim          dimension
%    p.noOfPoints   number of allocated points
%
% Methods  
%    p.get(C, R)    returns a matrix of test points for the box
%                   B(C,R), one test point per column; C and R
%                   may also be matrices

% Oliver Junge, 12.6.2000

if nargin == 0
  error('Too few input arguments: filename or handle expected.')
elseif isa(p_in, 'struct')
  p = p_in;
  p = class(p, 'Points');
elseif ischar(p_in) 
  if nargin == 2 
    p.handle = load_points(p_in, dim);
  else
    p.handle = load_points(p_in, dim, info); 
  end
  p = class(p, 'Points');
else
  error('Input argument of wrong type: handle or string expected.');
end

