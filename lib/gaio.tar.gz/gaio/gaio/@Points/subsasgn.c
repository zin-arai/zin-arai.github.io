/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Points.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Points *p;
  mxArray *ptr;
  double *pr;
  
  ptr = mxGetField(prhs[0], 0, "handle");
  p = (Points *)ptrFromMxArray(ptr);
  if (p==NULL) {mexPrintf("??? Points: points are empty.\n\n"); return;}
  
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  if (!strcmp(type,".")) {
    ptr = mxGetField(prhs[1], 0, "subs");
    attr = mxArrayToString(ptr);

    if (!strcmp(attr, "dim")) {
      pr = mxGetPr(prhs[2]);
      p->dim = *pr;
    }
    mxFree(attr);
  }
  
  mxFree(type);

  plhs[0] = (mxArray*) prhs[0];

  return;
}


