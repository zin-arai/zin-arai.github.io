/* 
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Points.h>
#include <gaio/Integrator.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Points *p;
  mxArray *ptr;
  double *pr;
  int k;
  
  /* Check for proper number of arguments */
  
  if (nrhs != 2) {
    {mexPrintf("??? subsref requires two input arguments.\n\n"); return;}
  } else if (nlhs > 1) {
    {mexPrintf("??? subsref requires one output argument.\n\n"); return;}
  }
  
  ptr = mxGetField(prhs[0], 0, "handle");
  p = (Points *)ptrFromMxArray(ptr);
  if (p==NULL) {mexPrintf("??? Points: points are empty.\n\n"); return;}
  
  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  ptr = mxGetField(prhs[1], 0, "subs");
  attr = mxArrayToString(ptr);

  if (mxGetNumberOfElements(prhs[1])==1 && !strcmp(type,".")) {

    if (!strcmp(attr, "name")) {
      plhs[0] = mxCreateCharMatrixFromStrings(1, (const char**)&(p->name));
    } else if (!strcmp(attr, "dim")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = p->dim;  
    } else if (!strcmp(attr, "noOfPoints")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = p->noOfPoints; 
    } else if (!strcmp(attr, "length")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      pr[0] = p->length; 
    } else if (!strcmp(attr, "info")) {
      plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
      pr = mxGetPr(plhs[0]);
      PointsInfo(stdout, p);
    } else {
      {mexPrintf("??? Points: unknown field.\n\n"); return;}
    } 
    /* mxFree(attr) */
  }

  /* methods */
  if (mxGetNumberOfElements(prhs[1])==2 && !strcmp(type,".")) {

    ptr = mxGetField(prhs[1], 1, "type");
    type = mxArrayToString(ptr);
    ptr = mxGetField(prhs[1], 1, "subs");
   
    if (!strcmp(attr, "get")) { /* get */
      int i, mc, nc, mr, nr, d = p->dim, nop;
      Integrator *itgr = 0;
      double *Rd = 0, *c = 0, *r = 0;
      mxArray *cell0 = mxGetCell(ptr, 0), *cell1 = 0, *cell2 = 0, *cell3 = 0;
      if (mxGetNumberOfElements(ptr) < 2) 
	{mexPrintf("??? usage : points.get(center, radius).\n\n"); return;}
      cell1 = mxGetCell(ptr, 1);
      mc = mxGetM(cell0);
      mr = mxGetM(cell1);
      if (mc!=d || mr !=d)
	{mexPrintf("??? Points.get: input matrix has wrong dimension.\n\n"); return;}
      nc = mxGetN(cell0);
      nr = mxGetN(cell1);
      if (nr!=1 && nr!=nc)
	{mexPrintf("??? Points.get: radii have wrong dimension.\n\n"); return;}
      c = mxGetPr(cell0);
      r = mxGetPr(cell1);
      if (mxGetNumberOfElements(ptr) > 2) {
	cell2 = mxGetCell(ptr, 2);
	if (mxGetNumberOfElements(ptr) < 4) 
	  {mexPrintf("??? Points.get: second radius expected.\n\n"); return;}
	if (strcmp(mxGetClassName(cell2), "Integrator"))
	  {mexPrintf("??? Points.get: Integrator expected as third argument.\n\n"); return;}
	itgr = *(Integrator **)mxGetData(mxGetField(cell2, 0, "handle"));
	if (itgr==NULL)
	  {mexPrintf("??? Points.get: integrator is empty.\n\n"); return;}
	if (itgr->task==NULL)
	  {mexPrintf("??? Points.get: no model assigned to the integrator.\n\n"); return;}
	cell3 = mxGetCell(ptr, 3);
	if (mxGetM(cell3)!=d)
	  {mexPrintf("??? Points.get: second radius has wrong dimension.\n\n"); return;}
	Rd = mxGetPr(cell3);
      } 
      /* count the number of points */
      nop = 0;
      for (i=0; i<nc; i++) {
	    p->Set(p, itgr, c + i*d, r, Rd);
	    nop += p->noOfPoints;
      }      
      plhs[0] = mxCreateDoubleMatrix(d, nop, mxREAL);
      pr = mxGetPr(plhs[0]);
      nop = 0;
      for (i=0; i<nc; i++) {
	p->Set(p, itgr, c + i*d, r, Rd);
	PointsGet(p, pr + d*nop);
	nop += p->noOfPoints;
	if (nr != 1) r += d;
      }
    } else {
      {mexPrintf("??? Points: unknown method.\n\n"); return;}
    } 
  }

  mxFree(attr);
  mxFree(type);

  return;
}


