function gum(tree, depth, varargin)

% gum - global unstable manifold. 
%   gum(tree, depth [, domain_points, image_points, integrator, no_of_steps]): 
%   continuation algorithm for the computation of the unstable set of
%   a given box collection. Precondition: the tree must at least contain
%   one box which has its second flag (="inserted") set. Typical usage:
%
%   tree.insert(point, depth);
%   gum(tree, depth);

% Oliver Junge, 12.6.2000

d = tree.dim;
none = 0;
hit = 1;
inserted = 2;
to_be_expanded = 4;
to_be_subdivided = 8;
points_found = 0;

no_of_steps = 1;
integrator = Integrator(tree.integrator);
domain_points = Points(tree.domain_points);
image_points  = Points(tree.image_points);

for i=1:length(varargin),
 o = varargin{i};
 if isa(o, 'Points')
   if points_found==0
     domain_points = o;
     points_found = 1;
   else
     image_points = o;
   end
 elseif isa(o, 'Integrator')
   integrator = o
 elseif isnumeric(o)
   no_of_steps = o;
 end
end

c1 = tree.count(depth);
for i=1:no_of_steps
  c0 = c1;
  tree.change_flags('all', inserted, to_be_expanded);
  b = tree.first_box(depth);
  while (~isempty(b))
    center = b(1:d);
    radius = b(d+1:2*d);
    flags = b(2*d+1);
    if (bitand(flags, to_be_expanded))
      p = domain_points.get(center, radius, integrator, radius);
      fp = integrator.map(p);
      ip = image_points.get(fp, radius);
      tree.insert(ip, depth, inserted, none);
    end
    b = tree.next_box(depth);
  end
  tree.unset_flags('all', to_be_expanded);
  c1 = tree.count(depth);
  disp(sprintf('step %d: %d boxes', i, c1));
  if c0==c1,
    break;
  end
end

