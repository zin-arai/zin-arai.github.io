function [o,t] = intorb(t, f, df, no_pts);

% INTORB  hermite interpolation of trajectory.
%   [O, T] = INTORB(T, F, DF, N) computes a piecewise cubical
%   hermite interpolation of the given data (T, F, DF) and
%   evaluates it at intermediate positions specified by the vector
%   N. The data (T, F, DF) consists of a vector T of times, a
%   matrix F of function values, and a matrix DF of the derivatives
%   of F. The vector N (which is of size length(T)-1) specifies the
%   number of intermediate times (equidistant) at which the constructed
%   polynomials should be evaluated. It contains the cumulative sum
%   of intermediate points (between the given values in T) at which
%   the constructed polynomials should be evaluated.  
%
%   The values of the polynomial at the intermediate points is
%   output in O, the intermediate points themselves in T.
  
  

