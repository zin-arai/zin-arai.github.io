function A = adj_matrix(tree, depth)
  
  d = tree.dim;
  n = tree.count(depth);
  i = 1;
  k = 1;
  ijs = zeros(n, 3);
  b = tree.first_box(depth);
  while (~isempty(b))
    center = b(1:d);
    radius = b(d+1:2*d);
    I = tree.search_box(center, radius*1.1, depth);
    lI = length(I);
    if (lI > 0)
      if k+lI > length(ijs)
        ijs = realloc(ijs, [2*size(ijs,1), 3]);
      end
      ijs(k:k+lI-1,:) = [I i*ones(lI,1) ones(lI,1)];
    end
    k = k + lI;
    %fprintf('box no %d\r', i); 
    i = i + 1;
    b = tree.next_box(depth);
  end

A = sparse(ijs(1:k-1,1), ijs(1:k-1,2), ijs(1:k-1,3), n, n);
