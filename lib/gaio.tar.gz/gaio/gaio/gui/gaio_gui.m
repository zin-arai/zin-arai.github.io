function gaio_gui(which_action);
%
% gaio_gui contains all callback functions for the graphical user interface 
% version of GAIO 2.0
%
global GUI_MODEL;
global GUI_INTEGRATOR;
global GUI_DOMAIN_POINTS;
global GUI_IMAGE_POINTS;
global GUI_MEASURE_POINTS;
global GUI_TREE;
global CONTINUATION_DEPTH;
global GUI_MODEL_POINT;
global GUI_CURRENT_ACTION;
global XLIMITES;
global YLIMITES;
global ZLIMITES;
global MEASURE_VECTOR;

switch(which_action);


%%%%%%%%%%%%%% Load a model %%%%%%%%%%%%%%%

case 'model_load'
[fname,pname] = uigetfile('*.so', 'Load a model');
if fname == 0
warndlg('No model selected.', 'Model selection');
else GUI_MODEL = Model(fname);
set(findobj('tag', '&Model'), 'enable', 'off');
set(findobj('tag', 'Parameters'), 'enable', 'on');
set(findobj('tag', 'main_model_name_text'), 'String', GUI_MODEL.name);
end; 


%%%%%%%%%%%%%% Load an integrator %%%%%%%%%%%%%%%

case 'integrator_window'
integrator_window;
if GUI_MODEL.typ == 'map'
set(findobj('Tag', 'integrator_listbox'), 'ListboxTop', 5);
set(findobj('Tag', 'integrator_listbox'), 'Value', 6);
elseif GUI_MODEL.typ == 'ode'
set(findobj('Tag', 'integrator_listbox'), 'ListboxTop', 8);
set(findobj('Tag', 'integrator_listbox'), 'Value', 11);
elseif GUI_MODEL.typ == 'new'
set(findobj('Tag', 'integrator_listbox'), 'ListboxTop', 9);
set(findobj('Tag', 'integrator_listbox'), 'Value', 9);
end;

case 'integrator_load'
IntegratorValue = get(findobj('Tag', 'integrator_listbox'), 'Value');
IntegratorString = get(findobj('Tag', 'integrator_listbox'), 'String');
GUI_INTEGRATOR = Integrator(IntegratorString{IntegratorValue});
set(findobj('Tag', 'integrator_name_text'), 'String', GUI_INTEGRATOR.name); 
set(findobj('Tag', 'main_integrator_text'), 'String', GUI_INTEGRATOR.name); 
GUI_INTEGRATOR.model = GUI_MODEL;
set(findobj('Tag', 'integrator_tFinal_edit'), 'String', GUI_INTEGRATOR.tFinal);
set(findobj('Tag', 'integrator_h_edit'), 'String', GUI_INTEGRATOR.h);
set(findobj('Tag', '&Integrator'), 'Enable', 'off');
set(findobj('Tag', '&Points'), 'Enable', 'on');


case 'integrator_para'
tfinal = get(findobj('Tag', 'integrator_tFinal_edit'), 'String');
h = get(findobj('Tag', 'integrator_h_edit'), 'String');
if isempty(tfinal)==1 and isempty(h)== 1;
errordlg('no integrator selected');
elseif isempty(tfinal)==1 or isempty(h)== 1;
errordlg('one input argument is not defined')
else
GUI_INTEGRATOR.tFinal = str2double(tfinal);
GUI_INTEGRATOR.h = str2double(h);
close(gcbf);
end;



%%%%%%%%%%%%%% Load testpoints %%%%%%%%%%%%%%%

case 'points_window'
points_window;
set(findobj('Tag', 'domain_listbox'), 'Value', 3);
set(findobj('Tag', 'points_dno_edit'), 'String', 4*2^(GUI_MODEL.dim)+1);
set(findobj('Tag', 'points_ino_edit'), 'String', 1);

case 'points_load(domain_points)'
PointsValue = get(findobj('Tag', 'domain_listbox'), 'Value');
PointsString = get(findobj('Tag', 'domain_listbox'), 'String');
PointsNumber = str2num(get(findobj('Tag', 'points_dno_edit'), 'String'));
GUI_DOMAIN_POINTS = Points(PointsString{PointsValue}, GUI_MODEL.dim, PointsNumber);
set(findobj('Tag', 'domain_ok_text'), 'String', 'OK');

case 'points_load(image_points)'
PointsValue = get(findobj('Tag', 'image_listbox'), 'Value');
PointsString = get(findobj('Tag', 'image_listbox'), 'String');
PointsNumber = str2num(get(findobj('Tag', 'points_ino_edit'), 'String'));
GUI_IMAGE_POINTS = Points(PointsString{PointsValue}, GUI_MODEL.dim, PointsNumber);
set(findobj('Tag', 'image_ok_text'), 'String', 'OK');

%%%%%% Automatic creation of a tree when testpoints are loaded %%%%%%%%%%

case 'tree_load';
GUI_TREE = Tree(GUI_MODEL.dim, GUI_MODEL.center, GUI_MODEL.radius);
GUI_TREE.domain_points = GUI_DOMAIN_POINTS;
GUI_TREE.image_points = GUI_IMAGE_POINTS;
GUI_TREE.integrator =  GUI_INTEGRATOR;
set(findobj('Tag', 'main_points_text'), 'String', 'ok');
set(findobj('Tag', 'Algorithms'), 'Enable', 'on');
close(gcbf);
cla;
plotb(GUI_TREE);
XLIMITES = get(findobj('Tag', 'main_gaio_axes'), 'XLim');
YLIMITES = get(findobj('Tag', 'main_gaio_axes'), 'YLim');
ZLIMITES = get(findobj('Tag', 'main_gaio_axes'), 'ZLim');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
set(findobj('Tag', '&Print'),'Enable', 'on');
GUI_CURRENT_ACTION = 0;



%%%%%%%%%%%%%% Subdivision %%%%%%%%%%%%%%%

case 'subdivision_window'
subdivision_window;
set(findobj('Tag', 'main_algorithm_text'),'String', 'Subdivision');
set(findobj('Tag', 'Algorithms'), 'Enable', 'off');

case 'gui_subdivision'
no_of_steps =str2num(get(findobj('Tag','subdivision_no_edit'),'String'));
subdivision(GUI_TREE, no_of_steps);
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
visi_handle = findobj('Tag', 'subdivision_figure');
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
set(gca, 'Tag','main_gaio_axes'); 
plotb(GUI_TREE);
set(findobj('Tag', 'main_gaio_axes'), 'XLim', XLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'YLim', YLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'ZLim', ZLIMITES);
set(visi_handle, 'HandleVisibility', 'callback'); 

case 'subdivision_quit'
close(gcbf);
set(findobj('Tag', 'Algorithms'), 'Enable', 'on');
set(findobj('Tag', 'main_algorithm_text'), 'String', 'no algorithm selected');

case 'subdivision_new_tree'
GUI_TREE.delete(0);
visi_handle = findobj('Tag', 'subdivision_figure');
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
set(gca,'Tag', 'main_gaio_axes');
plotb(GUI_TREE);
set(visi_handle, 'HandleVisibility', 'callback');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
GUI_CURRENT_ACTION = 0;

%%%%%%%%%%%%%% Continuation %%%%%%%%%%%%%%%

case 'continuation_window'
continuation_window;
set(findobj('Tag', 'main_algorithm_text'), 'String', 'Continuation');
set(findobj('Tag', 'Algorithms'), 'Enable', 'off');
GUI_MODEL_POINT = eval('GUI_MODEL.fixed_point', 'GUI_MODEL.center')';
set(findobj('Tag','continuation_point_edit'),'String',num2str(GUI_MODEL_POINT));


case 'fixpoint'
GUI_MODEL_POINT = eval('GUI_MODEL.fixed_point', 'GUI_MODEL.center')';
if GUI_MODEL_POINT == GUI_MODEL.center'
msgbox('Model does not define a fixed point. Center chosen instead.');
end;
set(findobj('Tag','continuation_point_edit'),'String',num2str(GUI_MODEL_POINT));

case 'change'
point = str2num(get(findobj('Tag', 'continuation_point_edit'),'String'));
if length(point) ~= GUI_MODEL.dim
errordlg('Chosen point has wrong dimension.');
else
GUI_MODEL_POINT = point;
end;

case 'insert'
CONTINUATION_DEPTH = str2num(get(findobj('Tag','continuation_depth_edit'),'String'));
GUI_TREE.insert(GUI_MODEL_POINT', CONTINUATION_DEPTH);
visi_handle = findobj('Tag', 'continuation_figure');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
plotb(GUI_TREE);
set(gca, 'Tag','main_gaio_axes');
set(findobj('Tag', 'main_gaio_axes'),'XLim', XLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'YLim', YLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'ZLim', ZLIMITES);
set(visi_handle, 'HandleVisibility', 'callback');

case 'gui_continuation'
no_of_steps = str2num(get(findobj('Tag', 'continuation_no_edit'), 'String'));
continuation(GUI_TREE, CONTINUATION_DEPTH, no_of_steps)
visi_handle = findobj('Tag', 'continuation_figure');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
set(gca, 'Tag','main_gaio_axes'); 
plotb(GUI_TREE);
set(findobj('Tag', 'main_gaio_axes'),'XLim', XLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'YLim', YLIMITES);
set(findobj('Tag', 'main_gaio_axes'), 'ZLim', ZLIMITES);
set(visi_handle, 'HandleVisibility', 'callback'); 

case 'continuation_new_tree'
GUI_TREE.delete(0);
visi_handle = findobj('Tag', 'continuation_figure');
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
plotb(GUI_TREE);
set(gca,'Tag', 'main_gaio_axes');
set(visi_handle, 'HandleVisibility', 'callback');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);
GUI_MODEL_POINT = eval('GUI_MODEL.fixed_point', 'GUI_MODEL.center')';
set(findobj('Tag','continuation_point_edit'),'String',num2str(GUI_MODEL_POINT));
set(findobj('Tag','continuation_depth_edit'),'String', 6);
GUI_CURRENT_ACTION = 0;

case 'continuation_quit'
close(gcbf);
set(findobj('Tag', 'Algorithms'), 'Enable', 'on');
set(findobj('Tag', 'main_algorithm_text'), 'String', 'no algorithm selected');



%%%%%%%%%%%%%% Measure %%%%%%%%%%%%%%%


case 'measure_window'
measure_window;
set(findobj('Tag', 'main_algorithm_text'), 'String', 'Measure');
set(findobj('Tag', 'measure_points_listbox'), 'Value', 3);
set(findobj('Tag', 'measure_points_no_edit'), 'String', 4*2^(GUI_MODEL.dim)+1);
set(findobj('Tag', 'Algorithms'), 'Enable', 'off');
if isempty(GUI_MEASURE_POINTS) == 0
set(findobj('Tag', 'measure_ok_text'), 'String', 'OK');
end;


case 'points_load(measure_points)'
PointsValue = get(findobj('Tag', 'measure_points_listbox'), 'Value');
PointsString = get(findobj('Tag', 'measure_points_listbox'), 'String');
PointsNumber = str2num(get(findobj('Tag', 'measure_points_no_edit'), 'String'));
GUI_MEASURE_POINTS = Points(PointsString{PointsValue}, GUI_MODEL.dim, PointsNumber);
set(findobj('Tag', 'measure_ok_text'), 'String', 'OK');

case 'measure_computation'
A = GUI_TREE.matrix(GUI_MEASURE_POINTS);
[v, l] = eigs(A);
visi_handle = findobj('Tag', 'measure_figure');
set(visi_handle, 'HandleVisibility', 'off');
MEASURE_VECTOR = abs(v(:,1));
cla reset;
 if GUI_MODEL.dim >= 2
 Bar3d(GUI_TREE.boxes(-1)',MEASURE_VECTOR, 'r');
rotate3d;
GUI_CURRENT_ACTION = 2;
 elseif GUI_MODEL.dim == 1
 show1(GUI_TREE.boxes(-1)', 'r')
zoom on;
GUI_CURRENT_ACTION = 1;
 end
set(visi_handle, 'HandleVisibility', 'callback');

case 'measure_new_tree'
GUI_TREE.delete(0);
visi_handle = findobj('Tag', 'measure_figure');
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
plotb(GUI_TREE);
set(gca,'Tag', 'main_gaio_axes');
set(visi_handle, 'HandleVisibility', 'callback');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);

case 'measure_quit'
close(gcbf);
set(findobj('Tag', 'Algorithms'), 'Enable', 'on');
set(findobj('Tag', 'main_algorithm_text'), 'String', 'no algorithm selected');

case 'measure_new_tree'
GUI_TREE.delete(0);
visi_handle = findobj('Tag', 'measure_figure');
set(visi_handle, 'HandleVisibility', 'off');
cla reset;
plotb(GUI_TREE);
set(gca,'Tag', 'main_gaio_axes');
set(visi_handle, 'HandleVisibility', 'callback');
set(findobj('Tag', 'main_no_boxes_text'),'String', GUI_TREE.count(-1));
set(findobj('Tag', 'main_tree_depth_text'),'String', GUI_TREE.depth);


%%%%%%%%%%%%%%% Actions in main window %%%%%%%%%%%%%%%%%%%%%%%

case 'print'
visi_handle = findobj('Tag', 'main_gaio_figure');
set(findobj('Tag', 'Algorithms'), 'Enable', 'on');
set(visi_handle, 'HandleVisibility', 'off');
close(gcf);
cla;
if GUI_CURRENT_ACTION == 0
plotb(GUI_TREE);
title(GUI_MODEL.name);
elseif GUI_CURRENT_ACTION == 1
show1(GUI_TREE.boxes(-1)', 'r');
title(GUI_MODEL.name);
elseif GUI_CURRENT_ACTION == 2
Bar3d(GUI_TREE.boxes(-1)', MEASURE_VECTOR, 'r');
title(GUI_MODEL.name); 
end;
set(visi_handle, 'HandleVisibility', 'on');

case 'clear'
delete(GUI_MODEL);
delete(GUI_TREE);
delete(GUI_INTEGRATOR);
delete(GUI_DOMAIN_POINTS);
delete(GUI_IMAGE_POINTS);
pos = get(findobj('Tag','main_gaio_figure'), 'Position'); 
close all hidden; 
clear global;
testgui;
set(findobj('Tag','main_gaio_figure'), 'Position', pos); 


case 'quit'
delete(GUI_MODEL);
delete(GUI_TREE);
delete(GUI_INTEGRATOR);
delete(GUI_DOMAIN_POINTS);
delete(GUI_IMAGE_POINTS);
delete(GUI_MEASURE_POINTS);
clear global;
close all hidden; 
clear all;

end;


