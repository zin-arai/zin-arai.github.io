function h=show2(b, col, dim, which, p)

% show2(b, col [, dim, which])

ix=1;
iy=2;
d = 2;
if nargin > 2,
 d=dim;
end
if nargin > 3,
  ix = which(1);
  iy = which(2);
end
if nargin > 4
 fprintf('show2: color \\in [%g, %g]\n', min(p), max(p));
 col=p(:);
end
 
x = [b(:,ix)-b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)+b(:,ix+d) b(:,ix)-b(:,ix+d)];
y = [b(:,iy)-b(:,iy+d) b(:,iy)-b(:,iy+d) b(:,iy)+b(:,iy+d) b(:,iy)+b(:,iy+d)];
h = patch(x',y',col');
if nargin > 4
  shading flat
end
