function sd_periodic(t, p, k, n)
 
% sd_periodic(T, P, K, N) 
%   Performs N steps of the subdivision algorithm for the
%   computation of the set of points of period K on the tree T
%   using the testpoints P for the computation of the transition
%   matrix.
%
%   defaults: N = 1, K = 2.

hit = 1;
to_be_subdivided = 8;

if (nargin < 2)
  error('usage: sd_periodic(tree, points [, period, no_of_steps])');
end

if (nargin < 3)
  k = 2;
  n = 1;
end

if (nargin < 4)
  n = 1;
end

for i=1:n
  t.set_flags('all', to_be_subdivided);
  t.subdivide;
  A = t.matrix(p);
  d = full(diag(A^k));
  d(find(d)) = 1;
  flags = sprintf('%1d', d);
  clear d;
  t.set_flags(flags, hit);
  t.remove(hit);
  disp(sprintf('step %d: %d boxes', i, t.count(-1)));
end
