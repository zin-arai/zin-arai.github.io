/* 
 * Copyright (c) 2007 Oliver Junge, for details see COPYING
 *
 */

#include <math.h>
#include <gaio/Model.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
   char *filename;

  if (nrhs==0 || !mxIsChar(prhs[0])) {
    mexPrintf("??? filename required.\n\n"); return;
  }

  filename = mxArrayToString(prhs[0]);
  plhs[0] = ptrToMxArray((void*)IntegratorNew(filename));
  mxFree(filename);

  return;
}


