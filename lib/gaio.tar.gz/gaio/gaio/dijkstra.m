function sp = dijkstra(P, src, dest)

%dijkstra	shortest path.
%   DIJKSTRA(A, S, D) computes the shortest path between the source S and
%   the destination D, regarding the sparse matrix A as a graph, where
%   the entry (i,j) in A defines the weight of the edge j->i.
%
%   [P, C] = DIJKSTRA(A, S, D) returns the path together with the total cost
%   C of the path.
%
%   Copyright (c) 2001 by Oliver Junge and Robert Preis
