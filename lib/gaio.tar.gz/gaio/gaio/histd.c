/*
 * Copyright (c) 2000 Oliver Junge
 * 
 */

#include <math.h>

#include "mex.h"

int find_bin(double x, double *edges, int l, int r) {
  int m;

  if ((r-l)==1) return r;
  m = (l+r)/2;
  if (x < edges[m]) 
    return find_bin(x, edges, l, m);
  else
    return find_bin(x, edges, m, r);
}

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  int i, j, n_x, n_edges;
  double *x, *edges, *n, *bin;
  
  if (nrhs != 2) {
    {mexPrintf("??? histd requires two input arguments.\n\n"); return;}
  } else if (nlhs != 2) {
    {mexPrintf("??? histd requires two output arguments.\n\n"); return;}
  }
  
  x = mxGetPr(prhs[0]);
  n_x = mxGetNumberOfElements(prhs[0]);
  edges = mxGetPr(prhs[1]);
  n_edges = mxGetNumberOfElements(prhs[1]);
  plhs[0] = mxCreateDoubleMatrix(n_edges-1, 1, mxREAL);
  n = mxGetPr(plhs[0]);
  plhs[1] = mxCreateDoubleMatrix(n_x, 1, mxREAL);
  bin = mxGetPr(plhs[1]);

  for (i=0; i<n_x; i++) {
    int j;
    if ((x[i] < edges[0]) || (x[i] > edges[n_edges-1])) 
      j = 0;
    else
      j = find_bin(x[i], edges, 0, n_edges-1);
    bin[i] = j;
    if (j!=0) n[j-1]++;
  }

  return;
}
