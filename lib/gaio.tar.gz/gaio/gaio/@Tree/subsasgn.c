/*
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Integrator.h>
#include <gaio/Iter.h>
#include <gaio/Points.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  char *type, *attr;
  Iter *iter;
  Integrator *itgr;
  Points *p;
  mxArray *ptr;
  double *r, *c;
  int dim, k;
  
  ptr = mxGetField(prhs[0], 0, "handle");
  iter = (Iter *)ptrFromMxArray(ptr);
  if (iter==NULL) {mexPrintf("??? Tree: tree is empty.\n\n"); return;}
  dim = iter->tree->Q->dim;

  ptr = mxGetField(prhs[1], 0, "type");
  type = mxArrayToString(ptr);
  
  if (!strcmp(type,".")) {
    ptr = mxGetField(prhs[1], 0, "subs");
    attr = mxArrayToString(ptr);

    if (!strcmp(attr, "integrator")) {
      if (!strcmp(mxGetClassName(prhs[2]), "Integrator")) {
	ptr = mxGetField(prhs[2], 0, "handle");
	itgr = (Integrator *)ptrFromMxArray(ptr);
	iter->integrator = itgr;
      } else { 
	mexPrintf("??? Tree.integrator: right hand side must be an integrator object\n\n"); return;
      }
    } else if (!strcmp(attr, "domain_points")) {
      if (!strcmp(mxGetClassName(prhs[2]), "Points")) {
      ptr = mxGetField(prhs[2], 0, "handle");
      p = (Points *)ptrFromMxArray(ptr);
/*       PointsInfo(stdout, p); */
      iter->domPoints = p; 
      } else { 
	{mexPrintf("??? Tree.domain_points: right hand side must be a points object\n\n"); return;}
      }
    } else if (!strcmp(attr, "image_points")) {
      if (!strcmp(mxGetClassName(prhs[2]), "Points")) {
      ptr = mxGetField(prhs[2], 0, "handle");
      p = (Points *)ptrFromMxArray(ptr);
/*       PointsInfo(stdout, p); */
      iter->imgPoints = p;
      } else { 
	{mexPrintf("??? Tree.image_points: right hand side must be a points object\n\n"); return;}
      }
    } else if (!strcmp(attr, "control_points")) {
      if (!strcmp(mxGetClassName(prhs[2]), "Points")) {
      ptr = mxGetField(prhs[2], 0, "handle");
      p = *(Points **)ptrFromMxArray(ptr);
      iter->uPoints = p;
      } else { 
	{mexPrintf("??? Tree.control_points: right hand side must be a points object\n\n"); return;}
      }
    } else if (!strcmp(attr, "radius")) {
      if (mxGetNumberOfElements(prhs[2]) == dim) {
      r = mxGetPr(prhs[2]);
      for (k=0; k<dim; k++) {
/* 	printf("%f\n", r[k]); */
	iter->tree->Q->r[k] = r[k];
      }
      } else {
	{mexPrintf("??? Tree.radius: right hand side has wrong dimension\n\n"); return;}
      }
    } else if (!strcmp(attr, "center")) {
      if (mxGetNumberOfElements(prhs[2]) == dim) {
	c = mxGetPr(prhs[2]);
	for (k=0; k<dim; k++) iter->tree->Q->c[k] = c[k];
      } else {
	{mexPrintf("??? Tree.center: right hand side has wrong dimension\n\n"); return;}
      }
    } else if (!strcmp(attr, "verbose")) {
	iter->verbose = (int)*mxGetPr(prhs[2]);
    } else if (!strcmp(attr, "sd")) {
      c = mxGetPr(prhs[2]);
      for (k=0; k<mxGetNumberOfElements(prhs[2]); k++) {
/* 	printf("%f\n", c[k]); */
	iter->tree->sd[k] = c[k];
      }
    }
  }

  mxFree(attr);
  mxFree(type);
  
  plhs[0] = (mxArray*) prhs[0];

  return;
}


