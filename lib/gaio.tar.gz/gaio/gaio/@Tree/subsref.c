/*
 * Copyright (c) 2007 djs2 GmbH
 */  

#include <math.h>
#include <gaio/Iter.h>
#include <gaio/Integrator.h>
#include <gaio/Points.h>
#include <gaio/Measure.h>
#include <gaio/SparseMatrix.h>
#include <gaio/Orbit.h>
#include <gaio/mxHandling.h>

mxArray *ConvertSparse(SparseMatrix *A) {
  int nz, j;
  mwIndex *ir, *jc;
  double *entries;
  mxArray *MA;
  
  MA = mxCreateSparse(A->dim, A->dim, A->nz, mxREAL);
  
  entries = (double *)mxCalloc(A->nz+1, sizeof(double));
  for (nz=0; nz<A->nz; nz++) entries[nz]= A->entries[nz];
  mxSetPr(MA, entries);
  
  ir = (mwIndex *)mxCalloc(A->nz+1, sizeof(mwIndex));
  for (nz=0; nz<A->nz; nz++) ir[nz]= A->rows[nz];
  mxSetIr(MA, ir);
  
  jc = (mwIndex *)mxCalloc(A->dim+1, sizeof(mwIndex));
  nz = 0;
  jc[0] = 0;
  for (j=1; j<= A->dim; j++) {
    jc[j] = jc[j-1];
    while((nz < A->nz) && (A->cols[nz]==j-1)) {
      jc[j]++;
      nz++;
    }
  }
  mxSetJc(MA, jc);
  
  return MA;
}

void mexFunction(
	int nlhs,       mxArray *plhs[],
	int nrhs, const mxArray *prhs[]
	)
{
	char *type, *attr;
	mxArray *ptr;
	double *pr, *pl;
	int k, dim;
	Iter *iter;
	Points *p;
	Integrator *itgr;

	ptr = mxGetField(prhs[0], 0, "handle");
	iter = (Iter *)ptrFromMxArray(ptr);
	if (iter==NULL) {mexPrintf("??? Tree: tree is empty.\n\n"); return;}
	dim = iter->tree->Q->dim;

	ptr = mxGetField(prhs[1], 0, "type");
	type = mxArrayToString(ptr);

	ptr = mxGetField(prhs[1], 0, "subs");
	attr = mxArrayToString(ptr);

	/* attributes */
	if (mxGetNumberOfElements(prhs[1])==1 && !strcmp(type,".")) {

		if (!strcmp(attr, "dim")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = dim;
		}
		else if (!strcmp(attr, "radius")) {
			plhs[0] = mxCreateDoubleMatrix(1, dim, mxREAL);
			pr = mxGetPr(plhs[0]);
			for (k=0; k < dim; k++) pr[k] = iter->tree->Q->r[k];
		}
		else if (!strcmp(attr, "center")) {
			plhs[0] = mxCreateDoubleMatrix(1, dim, mxREAL);
			pr = mxGetPr(plhs[0]);
			for (k=0; k <dim; k++) pr[k] = iter->tree->Q->c[k];
		}
		else if (!strcmp(attr, "info")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			IterInfo(stdout, iter);
			TreeInfo(stdout, iter->tree);
		}
		else if (!strcmp(attr, "verbose")) {
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = iter->verbose;
		}
		else if (!strcmp(attr, "integrator")) {
		  mwSize dims[2] = {1,1};
		  const char *field_names[] = {"handle"};
		  if (iter->integrator == NULL) {
		    mexPrintf("??? Tree.integrator: no integrator assigned.\n\n"); return;}
		  plhs[0] = mxCreateStructArray(2, dims, 1, field_names);
		  mxSetField(plhs[0], 0, "handle", ptrToMxArray(iter->integrator));
		}
		else if (!strcmp(attr, "domain_points")) {
		  mwSize dims[2] = {1,1};
		  const char *field_names[] = {"handle"};
		  if (iter->domPoints == NULL) {
		    mexPrintf("??? Tree.domain_points: no points assigned.\n\n"); return;}
		  plhs[0] = mxCreateStructArray(2, dims, 1, field_names);
		  mxSetField(plhs[0], 0, "handle", ptrToMxArray(iter->domPoints));
		}
		else if (!strcmp(attr, "image_points")) {
		  mwSize dims[2] = {1,1};
		  const char *field_names[] = {"handle"};
		  if (iter->imgPoints == NULL) {
		    mexPrintf("??? Tree.image_points: no points assigned.\n\n"); return;}
		  plhs[0] = mxCreateStructArray(2, dims, 1, field_names);
		  mxSetField(plhs[0], 0, "handle", ptrToMxArray(iter->imgPoints));
		}
		else if (!strcmp(attr, "control_points")) {
		  mwSize dims[2] = {1,1};
		  const char *field_names[] = {"handle"};
		  if (iter->uPoints == NULL) {
		    mexPrintf("??? Tree.control_points: no points assigned.\n\n"); return;}
		  plhs[0] = mxCreateStructArray(2, dims, 1, field_names);
		  mxSetField(plhs[0], 0, "handle", ptrToMxArray(iter->uPoints));
		}
		else if (!strcmp(attr, "depth")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeDepth(iter->tree->root);
		}
		else if (!strcmp(attr, "subdivide")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeSubdivide(iter->tree, SUBDIVIDE);
		}
		else if (!strcmp(attr, "unsubdivide")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeUnsubdivide(iter->tree, SUBDIVIDE);
		}
		else if (!strcmp(attr, "unsubdivide_current_box")) {
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = BoxUnsubdivide(iter->tree->box);
		}
		else if (!strcmp(attr, "sd")) {
			int i;
			plhs[0] = mxCreateDoubleMatrix(DEPTH_MAX(dim)+1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			for (i=0; i<DEPTH_MAX(dim)+1; i++) pr[i] = iter->tree->sd[i];
		}
		else if (!strcmp(attr, "map")) {
			if (iter->integrator==NULL)
				{mexPrintf("??? Tree.map: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL)
				{mexPrintf("??? Tree.map: no model set.\n\n"); return;}
			if (iter->domPoints==NULL)
				{mexPrintf("??? Tree.map: no domain points set.\n\n"); return;}
			if (iter->imgPoints==NULL)
				{mexPrintf("??? Tree.map: no image points set.\n\n"); return;}
			IterMap(iter, -1);
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
		}
		else if (!strcmp(attr, "map_all")) {
			if (iter->integrator==NULL)
				{mexPrintf("??? Tree.map_all: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL)
				{mexPrintf("??? Tree.map_all: no model set.\n\n"); return;}
			if (iter->domPoints==NULL)
				{mexPrintf("??? Tree.map_all: no domain points set.\n\n"); return;}
			if (iter->imgPoints==NULL)
				{mexPrintf("??? Tree.map_all: no image points set.\n\n"); return;}
			IterMapAll(iter, -1);
			plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
		}
		#ifdef _MEASURE_
		else if (!strcmp(attr, "neighbours")) {
			int i = 0, no = iter->tree->box->no;
			Stack *ngbs;
			ngbs = BoxGetNeighbours(iter->tree->box, dim);
			plhs[0] = mxCreateDoubleMatrix(ngbs->n, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			while (ngbs->n) {
				Box *ngb;
				ngb = StackPop(ngbs);
				/*	if (ngb->no != no)*/
				pr[i++] = ngb->no + 1;
			}
			StackFree(&ngbs);
		}
		#endif
		else {
			{mexPrintf("??? Tree: unknown field.\n\n"); return;}
		}
	}

	/* methods */
	if (mxGetNumberOfElements(prhs[1])==2 && !strcmp(type,".")) {
		int nargin, dim0, dim1;
		mxArray *cell0, *cell1;

		ptr = mxGetField(prhs[1], 1, "subs");
		nargin = mxGetNumberOfElements(ptr);

		cell0 = mxGetCell(ptr, 0);
		dim0 = mxGetNumberOfElements(cell0);
		if (nargin > 1) {
			cell1 = mxGetCell(ptr, 1);
			dim1 = mxGetNumberOfElements(cell1);
		}

		if (!strcmp(attr, "color")) {               /* color */
			char *colors;
			int depth = -1;
			colors = mxArrayToString(cell0);
			if (nargin > 1) depth = (int)*mxGetPr(mxGetCell(ptr, 1));
			TreeColor(iter->searchTree, colors, depth);
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
		}
		else if (!strcmp(attr, "change_Q")) {        /* change_Q */
			int m_c, m_r;
			double *pr_c, *pr_r;
			Rectangle *Q;
			if (nargin < 2)
				{mexPrintf("??? Tree.change_Q: radius is missing.\n\n"); return;}
			pr_c = mxGetPr(cell0);
			m_c = mxGetNumberOfElements(cell0);
			pr_r = mxGetPr(cell1);
			m_r = mxGetNumberOfElements(cell0);
			VecPrint(stdout, pr_c, m_c);
			VecPrint(stdout, pr_r, m_r);
			if (m_c != m_r)
				{mexPrintf("??? Tree.change_Q: dim(center)!=dim(radius).\n\n"); return;}
			Q = RectangleNew(pr_c, pr_r, m_c);
			TreeFree(&(iter->searchTree));
			TreeChangeQ(iter->tree, Q);
			iter->searchTree = TreeCopy(iter->tree);
			plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
		}
		else if (!strcmp(attr, "count")) {        /* count */
			if (dim0 > 1) {mexPrintf("??? Tree.count: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeCountDepth(iter->searchTree, (int)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "delete")) {       /* delete */
			if (dim0 > 1) {mexPrintf("??? Tree.delete: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			TreeDeleteDepth(iter->tree, (int)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "first_box")) {       /* first_box */
			if (dim0 > 1) {mexPrintf("??? Tree.first_box: scalar expected.\n\n"); return;}
			if (TreeFirstBox(iter->tree, (int)*mxGetPr(cell0))) {
				plhs[0] = mxCreateDoubleMatrix(2*dim+2, 1, mxREAL);
				VecCopy(iter->tree->c, mxGetPr(plhs[0]), dim);
				VecCopy(iter->tree->r, mxGetPr(plhs[0]) + dim, dim);
				*(mxGetPr(plhs[0]) + 2*dim) = (double)iter->tree->box->flags;
                                //#ifdef _MEASURE_
				*(mxGetPr(plhs[0]) + 2*dim + 1) = (double)iter->tree->box->no + 1;
                                //#endif
			}
			else {
				plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
			}
		}
		else if (!strcmp(attr, "next_box")) {       /* next_box */
			if (dim0 > 1) {mexPrintf("??? Tree.next_box: scalar expected.\n\n"); return;}
			if (TreeNextBox(iter->tree, (int)*mxGetPr(cell0))) {
				plhs[0] = mxCreateDoubleMatrix(2*dim+2, 1, mxREAL);
				VecCopy(iter->tree->c, mxGetPr(plhs[0]), dim);
				VecCopy(iter->tree->r, mxGetPr(plhs[0]) + dim, dim);
				*(mxGetPr(plhs[0]) + 2*dim) = (double)iter->tree->box->flags;
                                //#ifdef _MEASURE_
				*(mxGetPr(plhs[0]) + 2*dim + 1) = (double)iter->tree->box->no + 1;
                                //#endif
			}
			else {
				plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
			}
		}
#ifdef _MEASURE_
		else if (!strcmp(attr, "images")) {       /* images */
			double *R;
			if (dim0 > 1) {mexPrintf("??? Tree.images: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			R = (nargin > 1 ? mxGetPr(cell1) : 0);
			pr[0] = ComputeImages(iter, (int)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "set_image")) { /* set_image */
			int m0, n0, m1, n1;
			double *pr0, *pr1;
			if (nargin < 2) {mexPrintf("??? Tree.set_image: two arguments expected.\n\n"); return;}
			/*       printf("%s\n", mxGetClassName(cell0)); */
			/*       printf("%s\n", mxGetClassName(cell1)); */
			m0 = mxGetM(cell0);
			n0 = mxGetN(cell0);
			/*       printf("m0 = %d, n0 = %d\n", m0, n0); */
			m1 = mxGetM(cell1);
			n1 = mxGetN(cell1);
			/*       printf("m1 = %d, n1 = %d\n", m1, n1); */
			if (n0!=1 || n1!=1)
				{mexPrintf("??? Tree.set_image: column vectors expected.\n\n"); return;}
			if (m0!=m1)
				{mexPrintf("??? Tree.set_image: vectors must be of the same length.\n\n"); return;}
			pr0 = mxGetPr(cell0);
			pr1 = mxGetPr(cell1);
			if (iter->tree->box->img) SparseVectorFree(&(iter->tree->box->img));
			iter->tree->box->img = SparseVectorNew(m0, m0);
			for (k=0; k<m0; k++)
				SparseVectorAddEntry(iter->tree->box->img, pr0[k], pr1[k]);
			/*       SparseVectorPrint(stdout, iter->tree->box->img); */
			plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
		}
		else if (!strcmp(attr, "get_image")) {
		  int nz, k;
		  mwIndex *ir, *jc;
		  if (iter->tree->box->img==NULL) {
		    plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
		  }
		  else {
		    nz = iter->tree->box->img->nz;
		    plhs[0] = mxCreateSparse(nz, 1, nz, mxREAL);
		    pr = mxGetPr(plhs[0]);
		    ir = mxGetIr(plhs[0]);
		    jc = mxGetJc(plhs[0]);
		    jc[0] = 0;
		    jc[1] = jc[0];
		    for (k=0; k<iter->tree->box->img->nz; k++) {
		      pr[k] = iter->tree->box->img->entries[k];
		      ir[k] = ((Box*)iter->tree->box->img->rows[k])->no;
		      jc[1]++;
		    }
		  }
		}
		else if (!strcmp(attr, "images_to_matrix")) { /* images_to_matrix */
			SparseMatrix *A;
			if (dim0 > 1) {mexPrintf("??? Tree.images_to_matrix: scalar expected.\n\n"); return;}
			A = ImagesToMatrix(iter->tree, (int)*mxGetPr(cell0));
			if (A==NULL)
				{mexPrintf("??? Tree.images_to_matrix: at least one image empty.\n\n"); return;}
			plhs[0] = ConvertSparse(A);
			SparseMatrixFree(&A);
		}
		else if (!strcmp(attr, "delete_images")) { /* delete_images */
			char *choice;
			int depth = -1, nob;
			if (nargin > 1) depth = (int)*mxGetPr(cell1);
			nob = TreeCountDepth(iter->tree, depth);
			plhs[0] = mxCreateDoubleMatrix(nob, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			if (mxIsChar(cell0)) {
				choice = mxArrayToString(cell0);
				pr[0] = DeleteImages(iter->tree, choice, depth, pr);
				mxFree(choice);
			}
			else
			    {mexPrintf("??? Tree.delete_images: string expected.\n\n"); return;}
		}
		else if (!strcmp(attr, "histogram")) {       /* histogram */
			int n, m, depth, length;
			if (nargin<2)
				{mexPrintf("??? Tree.histogram: two input arguments expected.\n\n"); return;}
			if (dim1 > 1)
				{mexPrintf("??? Tree.histogram: scalar expected.\n\n"); return;}
			length = mxGetN(mxGetCell(ptr, 0));
			m = mxGetM(mxGetCell(ptr, 0));
			if (m!=dim)
				{mexPrintf("??? Tree.histogram: orbit has wrong dimension.\n\n"); return;}
			depth = (int)*mxGetPr(cell1);
			n = TreeCountDepth(iter->tree, depth);
			plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			TreeHistogram(iter->tree, mxGetPr(cell0), length, depth, pr);
		}
		#endif
		else if (!strcmp(attr, "insert")) {       /* insert */

			double *color;
			int i, m, n, flag_inserted = INSERTED, flag_found = NONE;
			if (nargin < 1)
				{mexPrintf("??? usage: Tree.insert(x, depth).\n\n"); return;}
			m = mxGetM(cell0);
			if (m != dim)
				{mexPrintf("??? Tree.insert: matrix has wrong dimension.\n\n"); return;}
			n = mxGetN(cell0);
			plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			if (nargin > 2)
				flag_inserted = (int)*mxGetPr(mxGetCell(ptr, 2));
			if (nargin > 3)
				flag_found = (int)*mxGetPr(mxGetCell(ptr, 3));
			if (nargin > 4) {
				color = mxGetPr(mxGetCell(ptr, 4));
				for (i=0; i<n; i++)
					pr[i] = TreeInsert(iter->searchTree,
						mxGetPr(cell0) + i*dim, (int)*mxGetPr(cell1),
						flag_inserted, flag_found, (byte)*(color + i));
			}
			else
			    for (i=0; i<n; i++)
				pr[i] = TreeInsert(iter->searchTree,
					mxGetPr(cell0) + i*dim, (int)*mxGetPr(cell1),
					flag_inserted, flag_found, 1);
		}
		else if (!strcmp(attr, "insert_box")) {          /* insert_box */
			double *pr1;
			byte color = 1, flag_inserted = INSERTED, flag_found = NONE;
			int inserted, i, n0, m0, n1, m1, depth = -1;
			m0 = mxGetM(cell0);
			n0 = mxGetN(cell0);
			if (m0!=dim || n0!=1)
				{mexPrintf("??? Tree.insert_box: center has wrong dimension.\n\n"); return;}
			pr = mxGetPr(cell0);
			m1 = mxGetM(cell1);
			n1 = mxGetN(cell1);
			if (m1!=dim || n1!=1)
				{mexPrintf("??? Tree.insert_box: radius has wrong dimension.\n\n"); return;}
			pr1 = mxGetPr(cell1);
			if (nargin > 2) depth = (int)*mxGetPr(mxGetCell(ptr, 2));
			if (nargin > 3) flag_inserted = (byte)*mxGetPr(mxGetCell(ptr, 3));
			if (nargin > 4) flag_found = (byte)*mxGetPr(mxGetCell(ptr, 4));
			if (nargin > 5) color = (byte)*mxGetPr(mxGetCell(ptr, 5));
			/*       VecPrint(stdout, pr, dim); */
			/*       VecPrint(stdout, pr1, dim); */
			/*       printf("depth = %d\n", depth); */

			inserted = TreeInsertBox(iter->searchTree, pr, pr1, depth,
				flag_inserted, flag_found, color);

			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pl = mxGetPr(plhs[0]);
			pl[0] = inserted;
		}
#ifdef _ORBIT_
		else if (!strcmp(attr, "links")) {       /* links */
			if (dim0 > 1) {mexPrintf("??? Tree.links: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = ComputeLinks(iter, (int)*mxGetPr(cell0));
			/*     } else if (!strcmp(attr, "project_links")) {     */
			/*       plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL); */
			/*       ProjectLinks(iter->tree->root); */
		}
		else if (!strcmp(attr, "print_links")) {
			if (dim0 > 1) {mexPrintf("??? Tree.print_links: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			PrintLinks(iter->tree, (int)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "links_to_matrix")) {
			SparseMatrix *A;
			if (dim0 > 1) {mexPrintf("??? Tree.links_to_matrix: scalar expected.\n\n"); return;}
			A = LinksToMatrix(iter->tree, (int)*mxGetPr(cell0));
			plhs[0] = ConvertSparse(A);
			SparseMatrixFree(&A);
		}
		else if (!strcmp(attr, "connect")) {
			Box *src, *dest;
			int depth = -1;
			if (nargin < 2)
				{mexPrintf("??? Tree.connect: at least two input arguments expected.\n\n"); return;}
			if (dim0!=dim)
				{mexPrintf("??? Tree.connect: source point of wrong dimension.\n\n"); return;}
			if (dim1!=dim)
				{mexPrintf("??? Tree.connect: destination point of wrong dimension.\n\n"); return;}
			if (nargin>2)
				depth = (int)*mxGetPr(mxGetCell(ptr, 2));
			TreeSearch(iter->tree, mxGetPr(cell0), depth);
			src = iter->tree->box;
			TreeSearch(iter->tree, mxGetPr(cell1), depth);
			dest = iter->tree->box;
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = Connect(src, dest);
		}
#endif
		else if (!strcmp(attr, "boxes")) {        /* boxes */
			int dims[2];
			if (dim0 > 1) {mexPrintf("??? Tree.boxes: scalar expected.\n\n"); return;}
			dims[0] = TreeCountDepth(iter->searchTree, (int)*mxGetPr(cell0));
			dims[1] = 2*iter->tree->Q->dim + 2;
			plhs[0] = mxCreateDoubleMatrix(dims[1],dims[0],mxREAL);
			pr = mxGetPr(plhs[0]);
			TreePrintToMatrix(iter->searchTree, (int)*mxGetPr(cell0), pr);
		}
		else if (!strcmp(attr, "expand")) {       /* expand */
			byte flag0 = INSERTED;
			byte flag1 = NONE;
			int depth;
			if (iter->integrator==NULL)
				{mexPrintf("??? Tree.expand: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL)
				{mexPrintf("??? Tree.expand: no model set.\n\n"); return;}
			if (iter->domPoints==NULL)
				{mexPrintf("??? Tree.expand: no domain points set.\n\n"); return;}
			if (iter->imgPoints==NULL)
				{mexPrintf("??? Tree.expand: no image points set.\n\n"); return;}
			if (dim0 > 1) {mexPrintf("??? Tree.expand: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			depth = (int)*mxGetPr(cell0);
			if (nargin > 1) flag0 = (byte) *mxGetPr(cell1);
			if (nargin > 2) flag1 = (byte) *mxGetPr(mxGetCell(ptr, 2));
			pr[0] = IterExpand(iter, depth, depth, 0, flag0, flag1);
		}
		else if (!strcmp(attr, "get_flags")) {    /* get_flags */
			char *choice;
			byte *flags;
			int depth = -1;
			if (nargin < 2)
				{mexPrintf("??? Tree.get_flags: two arguments required.\n\n"); return;}
			depth = (int)*mxGetPr(cell1);
			if (mxIsChar(cell0)) {
				int no = TreeCountDepth(iter->tree, depth);
				mwSize dims[2];
				dims[0] = no;
				dims[1] = 1;
				plhs[0] = mxCreateNumericArray(2, dims, mxUINT8_CLASS, mxREAL);
				choice = mxArrayToString(cell0);
				if (strcmp(choice,"all"))
					{mexPrintf("??? Tree.get_flags: either 'all' or a point expected.\n\n"); return;}
				TreeGetFlags(iter->tree, depth, mxGetData(plhs[0]));
				mxFree(choice);
			}
			else {
				byte *ptr;
				mwSize dims[1];
				dims[0] = 1;
				if (dim0 != dim)
					{mexPrintf("??? Tree.get_flags: point has wrong dimension.\n\n"); return;}
				plhs[0] = mxCreateNumericArray(1, dims, mxUINT8_CLASS, mxREAL);
				ptr = mxGetData(plhs[0]);
				if (TreeSearch(iter->tree, mxGetPr(cell0), depth) > 0) {
					ptr[0] = BoxGetFlags(iter->tree->box);
				}
			}
		}
		else if (!strcmp(attr, "set_flags")) {    /* set_flags */

			char *choice;
			byte flag;
			int depth = -1;
			if (nargin < 2)
				{mexPrintf("??? Tree.set_flags: at least two arguments expected.\n\n"); return;}
			flag = (byte)*mxGetPr(cell1);
			if (nargin > 2) depth = (int)*mxGetPr(mxGetCell(ptr, 2));
			if (mxIsChar(cell0)) {
				choice = mxArrayToString(cell0);
				TreeSetFlags(iter->tree, depth, choice, flag);
				mxFree(choice);
				plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
			}
			else {
				double *ptr;
				int i, m, n, found = 0;
				m = mxGetM(cell0);
				if (m!=dim)
					{mexPrintf("??? Tree.set_flags: input matrix has wrong dimension.\n\n"); return;}
				n = mxGetN(cell0);
				pr = mxGetPr(cell0);
				for (i=0; i<n; i++)
					if (TreeSearch(iter->searchTree, pr + i*dim, depth) > 0) {
						BoxSetFlag(iter->searchTree->box, flag);
						found = 1;
					}
				plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
				ptr = mxGetPr(plhs[0]);
				ptr[0] = found;
			}
		}
		else if (!strcmp(attr, "unset_flags")) {    /* unset_flags */
			char *choice;
			byte flag;
			int depth = -1;
			if (nargin < 2)
				{mexPrintf("??? Tree.set_flags: at least two arguments expected.\n\n"); return;}
			flag = (byte)*mxGetPr(cell1);
			if (nargin > 2) depth = (int)*mxGetPr(mxGetCell(ptr, 2));
			if (mxIsChar(cell0)) {
				choice = mxArrayToString(cell0);
				TreeUnsetFlags(iter->tree, depth, choice, flag);
				mxFree(choice);
			}
			else {
				int i, m, n;
				m = mxGetM(cell0);
				if (m!=dim)
					{mexPrintf("??? Tree.set_flags: input matrix has wrong dimension.\n\n"); return;}
				n = mxGetN(cell0);
				pr = mxGetPr(cell0);
				for (i=0; i<n; i++)
					if (TreeSearch(iter->searchTree, pr + i*dim, depth) > 0)
						BoxUnsetFlag(iter->searchTree->box, flag);
			}
			plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
		}
		else if (!strcmp(attr, "change_flags")) {    /* change_flags */
			char *choice;
			byte from, to;
			int depth = -1;
			if (nargin < 3)
				{mexPrintf("??? Tree.unset_flags: at least three arguments expected.\n\n"); return;}
			from = (byte)*mxGetPr(cell1);
			to = (byte)*mxGetPr(mxGetCell(ptr, 2));
			if (nargin > 3) depth = (int)*mxGetPr(mxGetCell(ptr, 3));
			if (mxIsChar(cell0)) {
				choice = mxArrayToString(cell0);
				TreeChangeFlags(iter->tree, depth, choice, from, to);
				mxFree(choice);
			}
			else {
				int i, m, n;
				m = mxGetM(cell0);
				if (m!=dim)
					{mexPrintf("??? Tree.set_flags: input matrix has wrong dimension.\n\n"); return;}
				n = mxGetN(cell0);
				pr = mxGetPr(cell0);
				for (i=0; i<n; i++)
					if (TreeSearch(iter->searchTree, pr + i*dim, depth) > 0)
						BoxChangeFlag(iter->searchTree->box, from, to);
			}
			plhs[0] = mxCreateDoubleMatrix(0, 0, mxREAL);
		}
#ifdef _NORMALS_
		else if (!strcmp(attr, "normals")) {         /* normals */
			if (nargin<2)
				{mexPrintf("??? Tree.normals: two input arguments expected.\n\n"); return;}
			if (dim0 != dim)
				{mexPrintf("??? Tree.normals: radius has wrong dimension.\n\n"); return;}
			if (dim1 > 1)
				{mexPrintf("??? Tree.normals: scalar as second arg expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			IterNormals(iter, (int)*mxGetPr(cell1), mxGetPr(cell0));
		}
#endif
		else if (!strcmp(attr, "map")) {             /* map */
			if (iter->integrator==NULL)
				{mexPrintf("??? Tree.map: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL)
				{mexPrintf("??? Tree.map: no model set.\n\n"); return;}
			if (iter->domPoints==NULL)
				{mexPrintf("??? Tree.map: no domain points set.\n\n"); return;}
			if (iter->imgPoints==NULL)
				{mexPrintf("??? Tree.map: no image points set.\n\n"); return;}
			IterMap(iter, (int)*mxGetPr(cell0));
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
		}
		else if (!strcmp(attr, "map_all")) {         /* map_all */
			if (iter->integrator==NULL) {mexPrintf("??? Tree.map: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL) {mexPrintf("??? Tree.map: no model set.\n\n"); return;}
			if (iter->domPoints==NULL) {mexPrintf("??? Tree.map: no domain points set.\n\n"); return;}
			if (iter->imgPoints==NULL) {mexPrintf("??? Tree.map: no image points set.\n\n"); return;}
			IterMapAll(iter,(int)*mxGetPr(mxGetCell(ptr, 0)));
			plhs[0] = mxCreateDoubleMatrix(1,1,mxREAL);
		}
#ifdef _MEASURE_
		else if (!strcmp(attr, "matrix")) {          /* matrix */
			char const *classname = mxGetClassName(mxGetCell(ptr, 0));
			SparseMatrix *A;
			if (iter->integrator==NULL)
				{mexPrintf("??? Tree.matrix: no integrator set.\n\n"); return;}
			if (iter->integrator->task==NULL)
				{mexPrintf("??? Tree.matrix: no model set.\n\n"); return;}
			if (iter->imgPoints==NULL)
				{mexPrintf("??? Tree.matrix: no image_points set.\n\n"); return;}
			if (!strcmp(classname, "Points")) {
				double *R = 0, *eps = 0;
				int depth = -1;
				mxArray *m = mxGetField(cell0, 0, "handle");
				Points *p = *(Points **)mxGetData(m);
				if (nargin > 1) depth = (int)*mxGetPr(cell1);
				if (iter->verbose) printf("depth = %d\n", depth);
				if (nargin > 2) {
					R = mxGetPr(mxGetCell(ptr, 2));
					if (iter->verbose) printf("R = %lg\n", R);
				}
				if (nargin > 3) {
					eps = mxGetPr(mxGetCell(ptr, 3));
					if (iter->verbose) printf("eps = %lg\n", eps);
				}
				A = MonteCarloMatrix(iter, depth, p);
			}
			else if (!strcmp(mxArrayToString(cell0), "exhaustion")) {
				int depth = -1, depth_s = 16;
				if (nargin > 1) depth = (int)*mxGetPr(cell1);
				if (nargin > 2) depth_s = (int)*mxGetPr(mxGetCell(ptr, 2));
				if (iter->integrator->task->model->lip==NULL)
					{mexPrintf("??? Tree.matrix: model does not define a Lipschitz estimate.\n\n"); return;}
				A = ExhaustionMatrix(iter, depth, depth_s);
			}
			else
				{mexPrintf("??? Tree.matrix: first argument of wrong type.\n\n"); return;}
			plhs[0] = ConvertSparse(A);
			SparseMatrixFree(&A);
		}
#endif
		else if (!strcmp(attr, "remove")) {          /* remove */
			if (dim0 > 1) {mexPrintf("??? Tree.remove: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeRemove(iter->tree->root, (byte)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "search")) {          /* search */
		  int i, n, m, depth = -1, found;
		  mwSize dims[2];
		  double *pl1;
		  m = mxGetM(cell0);
		  if (m!=dim)
		    {mexPrintf("??? Tree.search: input matrix has wrong dimension.\n\n"); return;}
		  n = mxGetN(cell0);
		  pr = mxGetPr(cell0);
		  plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
		  pl = mxGetPr(plhs[0]);
		  if (nlhs > 1) {
		    dims[0] = n;
		    dims[1] = 1;
		    plhs[1] = mxCreateNumericArray(2, dims, mxUINT32_CLASS, mxREAL);
		    pl1 = mxGetPr(plhs[1]);
		  }
		  if (nargin > 1) depth = (int)*mxGetPr(mxGetCell(ptr, 1));
		  for (i=0; i < n; i++) {
		    found = TreeSearch(iter->searchTree, pr + i*dim, depth);
                    //#ifdef _MEASURE_
		    pl[i] = (found > 0 ? iter->searchTree->box->no + 1: -1);
                    //#else
		    //pl[i] = found;
                    //#endif
		    if (nlhs > 1)
		      pl1[i] = (unsigned int)iter->searchTree->box;
		  }
		}
		//#ifdef _MEASURE_
		else if (!strcmp(attr, "search_box")) {          /* search_box */
			double *pr1;
			SparseVector *nos;
			int i, n0, m0, n1, m1, depth = -1;
			m0 = mxGetM(cell0);
			n0 = mxGetN(cell0);
			if (m0!=dim || n0!=1)
				{mexPrintf("??? Tree.search_box: center has wrong dimension.\n\n"); return;}
			pr = mxGetPr(cell0);
			m1 = mxGetM(cell1);
			n1 = mxGetN(cell1);
			if (m1!=dim || n1!=1)
				{mexPrintf("??? Tree.search_box: radius has wrong dimension.\n\n"); return;}
			pr1 = mxGetPr(cell1);

			if (nargin > 2) depth = (int)*mxGetPr(mxGetCell(ptr, 2));
			/*       VecPrint(stdout, pr, dim); */
			/*       VecPrint(stdout, pr1, dim); */
			/*       printf("depth = %d\n", depth); */

			nos = TreeSearchBox(iter->searchTree, pr, pr1, depth);

			/*       SparseVectorInfo(stdout, nos); */
			plhs[0] = mxCreateDoubleMatrix(nos->nz, 1, mxREAL);
			pl = mxGetPr(plhs[0]);
			for (i=0; i<nos->nz; i++) pl[i] = nos->rows[i]+1;
			SparseVectorFree(&nos);

		}
		//#endif
		else if (!strcmp(attr, "save")) {            /* save */
			FILE *out;
			char *filename;
			if (!mxIsChar(cell0)) {mexPrintf("??? Tree.save: file name expected.\n\n"); return;}
			filename = mxArrayToString(cell0);
			out = fopen(filename, "w");
			if (!out) {mexPrintf("??? Tree.save: could not open file for writing.\n\n"); return;}
			IterSave(out, iter);
			fclose(out);
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			mxFree(filename);
		}
		else if (!strcmp(attr, "subdivide")) {       /* subdivide */
			if (dim0 > 1) {mexPrintf("??? Tree.subdivide: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeSubdivide(iter->tree, (byte)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "subdivide_current_box")) {
			if (dim0 > 1) {mexPrintf("??? Tree.subdivide: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = BoxSubdivide(iter->tree->box, (byte)*mxGetPr(cell0));
		}
		else if (!strcmp(attr, "unsubdivide")) {     /* unsubdivide */
			if (dim0 > 1) {mexPrintf("??? Tree.unsubdivide: scalar expected.\n\n"); return;}
			plhs[0] = mxCreateDoubleMatrix(1, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			pr[0] = TreeUnsubdivide(iter->tree, (byte)*mxGetPr(cell0));
		}
		#ifdef _MEASURE_
		else if (!strcmp(attr, "volume")) {           /* volume */
			int n, depth = (int)*mxGetPr(cell0);
			if (dim0 > 1) {mexPrintf("??? Tree.volume: scalar expected.\n\n"); return;}
			n = TreeCountDepth(iter->tree, depth);
			plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
			pr = mxGetPr(plhs[0]);
			TreeVolume(iter->tree, pr, depth);
		}
		#endif
		else {
			{mexPrintf("??? Tree: unknown method.\n\n"); return;}
		}
	}
	mxFree(attr);
	mxFree(type);

	return;
}


