/*
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Iter.h>
#include <gaio/Integrator.h>
#include <gaio/Points.h>
#include <gaio/Measure.h>
#include <gaio/SparseMatrix.h>
#include <gaio/Orbit.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
		 )
{
  mxArray *ptr;
  double *pr, *pl;
  int k, dim;
  Iter *iter;
  int i, n, m, depth = -1, found;
  double *pl1;
  
  ptr = mxGetField(prhs[0], 0, "handle");
  iter = (Iter *)ptrFromMxArray(ptr);
  if (iter==NULL) {mexPrintf("??? Tree: tree is empty.\n\n"); return;}
  dim = iter->tree->Q->dim;

  m = mxGetM(prhs[1]);
  if (m!=dim) 
    {mexPrintf("??? Tree::search: input matrix has wrong dimension.\n\n"); return;}
  n = mxGetN(prhs[1]);
  pr = mxGetPr(prhs[1]);
  plhs[0] = mxCreateDoubleMatrix(n, 1, mxREAL);
  pl = mxGetPr(plhs[0]);
  if (nlhs > 1) {
    plhs[1] = mxCreateDoubleMatrix(n, 1, mxREAL);
    pl1 = mxGetPr(plhs[1]);
  }
  if (nrhs > 2) depth = (int)*mxGetPr(prhs[2]);
  for (i=0; i < n; i++) {
    found = TreeSearch(iter->searchTree, pr + i*dim, depth);
    //#ifdef _MEASURE_
    pl[i] = (found > 0 ? iter->searchTree->box->no + 1: -1);
    //#else
    //pl[i] = found;
    //#endif
    if (nlhs > 1)
      pl1[i] = (found > 0 ? (unsigned int)iter->searchTree->box : 0);
  }
  
  return;
}

