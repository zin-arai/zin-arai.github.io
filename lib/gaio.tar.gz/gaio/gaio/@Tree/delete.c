/*
 * Copyright (c) 2007 djs2 GmbH
 */

#include <math.h>
#include <gaio/Iter.h>
#include <gaio/mxHandling.h>

void mexFunction(
                 int nlhs,       mxArray *plhs[],
                 int nrhs, const mxArray *prhs[]
				)
{
  void *ptr;
 
  ptr = ptrFromMxArray(mxGetField(prhs[0], 0, "handle"));
    
  IterFree((Iter **)&ptr);  
}


