function [m,l] = im(tree, varargin)

% im - invariant measure.
%   [m,l] = im(tree [, method, depth]): computes an (approximate) invariant 
%   measure m on the box collection of the given depth. The returned 
%   eigenvalue l should in general be (very) close to one. 
%   The optional parameter method specifies the way the transition  matrix
%   is computed:
%     - using test points, if method is a Points object;
%     - the exhaustion method, if method=='exhaustion'.
%   Defaults for the optional arguments are
%     method = tree.domain_points,
%     depth = -1.

% Oliver Junge, 12.6.2000

depth = -1;
points = Points(tree.domain_points);

for i=1:length(varargin),
 o = varargin{i};
 if (isa(o, 'Points') | strcmp(o, 'exhaustion'))
   points = o;
 elseif isnumeric(o)
   depth = o;
 end
end

options.disp = 0;
A = tree.matrix(points, depth);
[m,l,flag] = eigs(A, 1, 'LM', options);
if (flag==1)
  disp('warning: eigenvector computation did not converge.');
end
m = abs(m)./norm(m,1);
