/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * RungeKutta4.c
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>

char *name = "The Runge Kutta scheme of order 4 with constant stepsize";
double h = 0.01;
double k[4][MAXDIM], tmp[MAXDIM];

void step(Integrator *intgr, double *x, double *u, double *fx) {
  int j, dim;
  double h;

  assert(intgr);
  dim = TaskDim(intgr->task);
  h = intgr->h;

  RHS(intgr, x, u, k[0]);
  VecAdd(x, h/2, k[0], dim, tmp);

  RHS(intgr, tmp, u, k[1]);
  VecAdd(x, h/2, k[1], dim, tmp);

  RHS(intgr, tmp, u, k[2]);
  VecAdd(x, h, k[2], dim, tmp);

  RHS(intgr, tmp, u, k[3]);

  for (j=0; j < dim; j++)
    fx[j] = x[j] + (h/6)*(k[0][j] + 2*k[1][j] + 2*k[2][j] + k[3][j]);

  intgr->count += 4;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
