/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * DormandPrince853.c   an explicit embedded Runge-Kutta formula
 *                      of order 8(5,3) with adaptive stepsize control
 *                      due to Dormand and Prince
 *                      using the implementation of Hairer and Wanner
 *                      (see dop853.f)
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>

#define lwork 11*MAXDIM + 8*MAXDIM + 20
#define liwork MAXDIM+20

char *name = "DormandPrince853";

int N, 
  ITOL = 0, /* RTOL and ATOL are scalars */
  IOUT = 1, /* call SOLOUT after a successful step */
  LWORK = lwork, LIWORK = liwork, 
  IWORK[liwork], *IPAR, IDID,
  calls_to_SOLOUT,
  steps_max = 1000,
  init = 0;

double h = 0.01,
  h_min = 1e-16,
  h_max = 1.0,
  eps = 1e-9, 
  X, Y[MAXDIM*(MAXDIM+1)], XEND, RTOL, ATOL, WORK[lwork];

Task *task = 0;

void FCN(int *N, double *X, double *Y, double *F, double *RPAR, int *IPAR) {
  task->f(task, Y, RPAR, F);
}

void SOLOUT(int *NR, double *XOLD, double *X, double *Y, int *N, double *CON,
	    int *ICOMP, int *ND, double *RPAR, double *IPAR, int *IRTRN) {
  
  calls_to_SOLOUT += 1;
  if (calls_to_SOLOUT==2)
    *IRTRN = -1; /* let dop853 return after one successful step */
} 

void Init() {
  int i;

  init = 1;
  for (i=0; i<lwork; i++) WORK[i] = 0.0;
  for (i=0; i<liwork; i++) IWORK[i] = 0.0;
}

void step(Integrator *intgr, double *x, double * u, double *fx) {
  int i;

  if (!init) Init();

  assert(intgr);
  assert(intgr->task);

  if (task!=intgr->task) {
    task = intgr->task;
    N = TaskDim(task);
  }

  X = 0.0;
/*  29.7.04: Hessel: h_min missing
  XEND = min(intgr->h, intgr->h_max);*/
  XEND = sign(h)*min(max(intgr->h_min, fabs(intgr->h)), intgr->h_max);
  WORK[5] = intgr->h_max;
  WORK[6] = intgr->h;
  IWORK[2] = -1;
  RTOL = ATOL = intgr->eps;
  VecCopy(x, Y, N);
  calls_to_SOLOUT = 0;

  dop853_(&N, FCN, &X, Y, &XEND, 
	 &RTOL, &ATOL, &ITOL, 
	 SOLOUT, &IOUT, 
	 WORK, &LWORK, IWORK, &LIWORK, u, IPAR, &IDID);

  if (IDID==-2)
    printf("DormandPrince853: maximal number of steps exceeded.");
  if (IDID==-3)
    printf("DormandPrince853: step size becomes too small.");
  if (IDID==-4)
    printf("DormandPrince853: problem '%s' is probably stiff.", task->model->name);
  
  intgr->count += IWORK[16];
  intgr->h_used = X;
  intgr->h = WORK[6];
  
  VecCopy(Y, fx, N);

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  if (!(intgr->steps < intgr->steps_max)) {
    printf("DormandPrince853: maximum number of %d steps reached. Integration probably not finished. Eventually you may want to increase the value of my attribute 'steps_max'.\n", intgr->steps_max);
    return 1;
  } else
    return 0;
}
