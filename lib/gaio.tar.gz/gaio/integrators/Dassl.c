/*
 * Copyright (c) 1998 Stefan Sertl, for details see COPYING
 * 
 * Dassl.c
 *
 */

#include <gaio/Integrator.h>

char *name = "Dassl";
double h = 0.01;
double h_min = 1e-6;
double h_max = 0.1;
double eps = 1e-9;

static int neq, *info, *info_, idid, lrw, liw, *iwork, *iwork_, *ipar;
static double t, *xprime, tout, *rwork, *rwork_, *rpar;
static double *B;
static VecFunc rhs, lhs;

void _init() {

  liw = 20 + MAXDIM;
  lrw = 40 + 9*MAXDIM +MAXDIM*MAXDIM;

  NEW(info, 15);
  NEW(iwork, liw);
  NEW(rwork, lrw);
  info_ = info - 1;
  iwork_ = iwork - 1;
  rwork_ = rwork - 1;

  NEW(xprime, MAXDIM);
  NEW(B, MAXDIM*MAXDIM);

}

void _fini() {

  if (info) FREE(info);
  if (iwork) FREE(iwork);
  if (rwork) FREE(rwork);
  if (xprime) FREE(xprime);
  if (B) FREE(B);

}

void res(double *t, double *x, double *xprime, double *delta, int *ires,
	 double *rpar, int *ipar) {
  int i,j;
  rhs(x, rpar, delta);
  if (lhs) {
    VecFill(B, 0, neq*neq);
    lhs(x, rpar, B);
    for (i=0; i<neq; i++)
      for (j=0; j<neq; j++)
	if (B[i+j*neq] != 0)
	  delta[i] -= B[i+j*neq]*xprime[j];
  }
  else
    for(i=0; i<neq; i++)
      delta[i] -= xprime[i];
}

void step(Integrator *intgr, double *x, double *u, double *fx) {

  int i;
  double rtol, atol;
  assert(intgr);

  if (intgr->steps==0) {
    neq = *intgr->task->model->dim;
    rhs = intgr->task->model->rhs;
    lhs = intgr->task->model->lhs;

    t = 0;
    tout = intgr->tFinal;
    
    for (i=0; i<neq; i++) xprime[i] = 0;
    
    rtol = intgr->eps;
    atol = intgr->eps;
    
    rwork_[2] = intgr->h_max;
    rwork_[3] = intgr->h;
    
    info_[1] = 0;              /* first call of ddassl */
    info_[2] = 0;              /* rtol and atol are scalars */
    info_[3] = 1;              /* solution at next intermediate step */
    info_[4] = 0;              /* no tstop */
    info_[5] = 0;              /* no jac provided */
    info_[6] = 0;              /* use full matrix for partial derivatives */
    info_[7] = 1;              /* maximum stepsize hmax provided */
    info_[8] = 1;              /* initial stepsize h0 provided */
    info_[9] = 0;              /* use default maximum order 5 */
    info_[10] = 0;             /* no nonnegativity constraints */
    info_[11] = (lhs ? 1 : 0); /* approximate initial yprime if lhs != 0 */
  } else {      
    info_[0] = 1;
  }
  
  if (!lhs)
    rhs(x, u, xprime);
  else
    VecFill(xprime, 0, neq);
  
  ddassl_(&res, &neq, &t, x, xprime, &tout, info, &rtol, &atol, &idid,
	  rwork, &lrw, iwork, &liw, u, ipar, 0);
  if (idid > 0) {
    VecCopy(x, fx, neq);
    intgr->h_used = rwork_[7];
  }
  if (idid < 0) {
    /* Error */
    fprintf(stderr, "libgaio: SLATEC: error in ddassl, idid = %d\n", idid); 
    exit(0);
  }
}

/*
void res(double *t, double *x, double *xprime, double *delta, int *ires,
	 double *u, int *ipar) {
  double *x_rhs;
  NEW(x_rhs, 2*neq + 1);

  VecCopy(x, x_rhs, neq);
  VecCopy(xprime, x_rhs+neq, neq);
  x_rhs[2*neq] = *t;

  rhs(x_rhs, u, delta);

  FREE(x_rhs);
}
*/

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  if (!(intgr->steps < intgr->steps_max)) {
    printf("Dassl: maximum number of %d steps reached. Integration probably not finished. Eventually you may want to increase the value of my attribute 'steps_max'.\n", intgr->steps_max);
    return 1;
  } else
    return 0;
}
