
/*
 * Copyright (c) 2003 djs2 GmbH
 *
 * NewArmAda.c  Newton's method as integrator, using adaptive
 *              stepzize (Armijo) and 
 *              length of integration (Dellnitz)
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>
#include <gaio/Newton.h>
#include <gaio/Vec.h>
#include <math.h>

 
int AdaptiveArmijoStep (double *x, double *u, double *pk, double *y, 
                        Integrator *intgr);

char *name = "NewArmAda";
double h = 1.0;
Newton *newton = 0;
Task *task = 0;

void F(double *z, double *u, double *Fz) {
  task->f(task, z, u, Fz);
}

void DF(double *z, double *u, double *DFz) {
  task->Df(task, z, u, DFz);
}

#define MAX_ARMIJO 5
 
/*******************************************************************/
/* AdaptiveArmijoStep()                                            */
/*              computes damped Newton step y = Nfk(x)             */
/*              with k = Armijo value                              */
/*  x,y         input/output vector                                */
/*  pk          Newton direction Df^-1(x)*f(x)                     */
/*******************************************************************/
int AdaptiveArmijoStep (double *x, double *u, double *pk, double *y,
                        Integrator *intgr)
{
  int i,j;
  double t=1.0, tnew, xnew[MAXDIM], ynew[MAXDIM], q;
  double fnorm, fnewnorm;
  double eps = 0.2, theta_min = 0.7;

  int dim=TaskDim(task);

  F(x, u, y);
  fnorm=VecNorm (y, dim);
  
  for ( i=1;i<=MAX_ARMIJO;i++ ) { 
    VecAdd (x, t, pk, dim ,xnew);
    F (xnew, u, ynew);
    fnewnorm = VecNorm (ynew, dim);
    if( fnewnorm <= (1-0.00001*t)*fnorm ) { 
      VecCopy (xnew, y, dim);
      /* Versuch: Ansatz q > ... */
      q = min (50, log(eps*theta_min)/log(max(1-t,0.4)));
      /* Iteration mit Nf_t^q */
       
     newton->h = t;
     for ( j=1;j<=q;j++) { 
       NewtonStep(newton, x, u, y);
       VecCopy (y, x, dim);
       intgr->count++;
     }  
     
     return 1;
    } else { 
      tnew = 0.5*t*t*fnorm / ( fnewnorm-(1.0+t)*fnorm );
      t = max (0.1*t, tnew);
    }
  }
  /* no Armijo-step found --> return Newton-step */
  VecAdd (x, 1.0, pk, dim, y);

  return 0;

} /* ArmijoStep() */

void step(Integrator *intgr, double *x, double * u, double *y) {
  int i, dim, iter;
  double  pk[MAXDIM];

  assert(intgr->task);

  if (task!=intgr->task) {
    task = intgr->task;
    NewtonFree(&newton);
    if (task->Df)
      newton = NewtonNew(TaskDim(intgr->task), F, DF);
    else
      newton = NewtonNew(TaskDim(intgr->task), F, 0);
  }
  newton->h = intgr->h;

  NewtonStep (newton, x, u, y);
  VecAdd (y, -1.0, x, TaskDim(intgr->task), pk);
  AdaptiveArmijoStep(x, u, pk, y, intgr);
  intgr->h_used = intgr->h;
  intgr->count++;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  if (!(intgr->steps < intgr->steps_max)) {
    printf("NewArmAda: maximum number of %d steps reached. Integration probably not finished. Eventually you may want to increase the value of my attribute 'steps_max'.\n", intgr->steps_max);
    return 1;
  } else
    return 0;
}
