/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * Newton.c Newton's method as an integrator
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>
#include <gaio/Newton.h>

char *name = "Newton";
double h = 1.0;
Newton *newton = 0;
Task *task = 0;

void F(double *z, double *u, double *Fz) {
  task->f(task, z, u, Fz);
}

void DF(double *z, double *u, double *DFz) {
  task->Df(task, z, u, DFz);
}

void step(Integrator *intgr, double *x, double * u, double *y) {
  int i, dim, iter;

  assert(intgr->task);

  if (task!=intgr->task) {
    task = intgr->task;
    NewtonFree(&newton);
    if (task->model->drhs)
      newton = NewtonNew(TaskDim(intgr->task), F, DF);
    else
      newton = NewtonNew(TaskDim(intgr->task), F, 0);
  }
  newton->h = intgr->h;

  NewtonStep(newton, x, u, y);

  intgr->count += 1;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
