/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * Euler.c
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>

char *name = "Euler";
double h = 0.01;
double k[MAXDIM];

void step(Integrator *intgr, double *x, double * u, double *fx) {

  intgr->task->f(intgr->task, x, u, k);
  VecAdd(x, intgr->h, k, TaskDim(intgr->task), fx);
  intgr->count++;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
