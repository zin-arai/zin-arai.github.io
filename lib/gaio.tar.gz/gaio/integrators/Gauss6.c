/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * Gauss.c  Gau�-Method of order 6 with constant stepsize (symplectic)
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>
#include <gaio/Newton.h>

double a[3][3] = {
  { 0.138888888888889, -0.359766675249389e-1, 0.978944401530832e-2},
  { 0.300263194980865,  0.222222222222222, -0.224854172030868e-1},
  { 0.267988333762469,  0.480421111969383,  0.138888888888889}
};

double b[3] = { 0.277777777777778, 0.444444444444444, 0.277777777777778 };
double d[3] = { 1.66666666666667,  -1.33333333333333, 1.66666666666667 };

#define steps 3

char *name = "Gauss6";
double h = 0.01;
double x_n[MAXDIM], xpz[MAXDIM];
double f[3][MAXDIM*MAXDIM];
double z0[steps*MAXDIM], z1[steps*MAXDIM];
Newton *newton = 0;
Task *task = 0;

void F(double *z, double *u, double *Fz) {
  int i, j, s, dim = TaskDim(task);

  for (s=0; s<steps; s++) {
    for (i=0; i<dim; i++) xpz[i] = x_n[i] + z[s*dim + i];
    task->f(task, xpz, u, f[s]);
  }

  for (s=0; s<steps; s++) 
    for (i=0; i<dim; i++) 
      Fz[s*dim + i] = z[s*dim + i] 
	- h*(a[s][0]*f[0][i] + a[s][1]*f[1][i] + a[s][2]*f[2][i]);
}

void DF(double *z, double *u, double *DFz) {
  int i, j, s, t, dim = TaskDim(task);

  for (s=0; s<steps; s++) {
    for (i=0; i<dim; i++) xpz[i] = x_n[i] + z[s*dim + i];
    task->Df(task, xpz, u, f[s]);
  }
  
  for (s=0; s<steps; s++) for (t=0; t<steps; t++)
    for (i=0; i<dim; i++) for (j=0; j<dim; j++)
      DFz[i + j*steps*dim + s*dim + t*steps*dim*dim] 
	= -h*a[s][t]*f[t][i + j*dim];
  
  for (i=0; i<steps*dim; i++) DFz[i + i*steps*dim] += 1.0;

}

void step(Integrator *intgr, double *x, double * u, double *y) {
  int i, dim, iter;

  assert(intgr->task);
  dim = TaskDim(intgr->task);
  assert(dim<=MAXDIM);

  if (task!=intgr->task) {
    task = intgr->task;
    NewtonFree(&newton);
    if (task->Df)
      newton = NewtonNew(steps*dim, F, DF);
    else
      newton = NewtonNew(steps*dim, F, 0);
    VecFill(z0, 0.0, steps*dim);
  }
  h = intgr->h;

  VecCopy(x, x_n, dim);
  iter = NewtonSolve(newton, z0, u, z1);
  
  for (i=0; i<dim; i++)
    y[i] = x[i] + d[0]*z1[i] + d[1]*z1[i + dim] + d[2]*z1[i +2*dim];

  intgr->count += 2*steps*iter;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
