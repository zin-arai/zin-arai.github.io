/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * Map.c
 *
 */

#include <gaio/Integrator.h>

char *name = "Map";
double h = 1;

void step(Integrator *intgr, double *x, double * u, double *fx) {

  intgr->task->f(intgr->task, x, u, fx);
  intgr->count++;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
