/*
 * Copyright (c) 1999 Oliver Junge, for details see COPYING
 * 
 * ScaledMidpointRule.c
 *
 */

#include <gaio/Integrator.h>
#include <gaio/Task.h>
#include <gaio/Newton.h>

char *name = "Midpoint Rule";
double h = 0.01, x_2[MAXDIM+1], x_n[MAXDIM+1];
Newton *newton = 0;
Task *task;

void F(double *x_np1, double *u, double *fx) {
  int i, dim = TaskDim(task);

  for (i=0; i<dim; i++) x_2[i] = (x_n[i] + x_np1[i])/2.0;
  task->f(task, x_2, u, fx);
  for (i=0; i<dim; i++) fx[i] = x_n[i] - x_np1[i] + h*fx[i];
  
}

void DF(double *x_np1, double *u, double *Dfx) {
  int i, dim = TaskDim(task);

  for (i=0; i<dim; i++) x_2[i] = (x_n[i] + x_np1[i])/2.0;
  task->Df(task, x_2, u, Dfx);
  for (i=0; i<dim*dim; i++) Dfx[i] *= h;
  for (i=0; i<dim; i++) Dfx[i + i*dim] -= 1;
    
}

void setup(Integrator *intgr) {
  task = intgr->task;
  NewtonFree(&newton);
  if (task->Df)
    newton = NewtonNew(TaskDim(task), F, DF);
  else
    newton = NewtonNew(TaskDim(task), F, 0);
}

void step(Integrator *intgr, double *x, double * u, double *x_np1) {
  int i, iter;

  if (!task) setup(intgr);

  h = intgr->h;
  VecCopy(x, x_n, TaskDim(task));
  iter = NewtonSolve(newton, x_n, u, x_np1);

  intgr->count += iter*2;

}

int stop(Integrator *intgr, double *x, double *u, double *fx) {
  return 0;
}
