function r = sub(a,b)

%SUB computes an inclusion (interval) of the subtraction of two matrices.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'sub' is called
%
%         r = sub(a,b)
%
%     and computes the interval matrix r
%     including the true result.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: minus.
%     double: add, mul, div.

global b4m_DouBLe b4m_INTerval

b4m_DouBLe = 1;

r.val = bias_sub(b4m_DouBLe, a, b4m_DouBLe, b);
r = interval(r);
