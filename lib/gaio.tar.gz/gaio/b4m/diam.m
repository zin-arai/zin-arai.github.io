function diameter = diam(a)

%DIAM dummy routine for interval/diam (type help interval/diam).
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'diam' is called
%
%         diameter = diam(a)
%
%     and returns zeros(size(a)).
%     DIAM is needed as a dummy routine.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: rad, mid, midrad.

diameter = zeros(size(a));
