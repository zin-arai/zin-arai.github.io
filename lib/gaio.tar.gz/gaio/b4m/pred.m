function predecessor = pred(a)

%PRED computes the predecessor of a real matrix a.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'pred' is called
%
%         predecessor = pred(a)
%
%     and computes the predecessor of a given
%     real matrix a.
%     The predecessor for real argument
%     is defined as
%     pred := max {b | b < a}.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: succ.

global b4m_DouBLe b4m_INTerval

b4m_DouBLe = 1;

predecessor = bias_pred(b4m_DouBLe, a);
