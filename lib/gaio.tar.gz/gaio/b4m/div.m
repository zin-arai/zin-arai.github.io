function r = div(a,b)

%DIV computes an inclusion (interval) of division matrix by scalar.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'div' is called
%
%         r = div(a,b)
%
%     and computes the interval matrix r
%     including the true result.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mrdivide.
%     double: add, sub, mul.

global b4m_DouBLe b4m_INTerval

b4m_DouBLe = 1;

r.val = bias_div(b4m_DouBLe, a, b4m_DouBLe, b);
r = interval(r);
