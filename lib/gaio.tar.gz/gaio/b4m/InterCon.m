% The methods of the class interval of the package b4m.
%
% The most important method is the constructor
%
%   interval              - Class constructor for interval
%
% and the output routine
%
%   interval/display      - Command window display
%
% please do not edit these files.
%
% Arithmetic operators
%
%   interval/plus         - Plus                          +
%   interval/uplus        - Unary plus                    +
%   interval/minus        - Minus                         -
%   interval/uminus       - Unary minus                   -
%   interval/mtimes       - Matrix multiply               *
%   interval/times        - Array multiply               .*
%   interval/mpower       - Matrix power                  ^
%   interval/power        - Array power                  .^
%   interval/mldivide     - Left matrix divide            \
%   interval/mrdivide     - Right matrix divide           /
%   interval/ldivide      - Left array divide            .\
%   interval/rdivide      - Right array divide           ./
%
% Overloaded functions
%
%   interval/abs          - Computes the magnitude
%   interval/acos         - Inverse cosine
%   interval/acosh        - Inverse hyperbolic cosine
%   interval/acot         - Inverse cotangent
%   interval/acoth        - Inverse hyperbolic cotangent 
%   interval/asin         - Inverse sine
%   interval/asinh        - Inverse hyperbolic sine
%   interval/atan         - Inverse tangent
%   interval/atanh        - Inverse hyperbolic tangent
%   interval/cos          - Cosine
%   interval/cosh         - Hyperbolic cosine
%   interval/cot          - Cotangent
%   interval/coth         - Hyperbolic cotangent
%   interval/exp          - Exponential
%   interval/iabs         - Range evaluation for abs
%   interval/log10        - Common (base 10) logarithm
%   interval/log          - Natural logarithm
%   interval/root         - Range evaluation for n-th root
%   interval/sin          - Sine
%   interval/sinh         - Hyperbolic sine
%   interval/sqr          - Range evaluation for square
%   interval/sqrt         - Range evaluation for square root
%   interval/tan          - Tangent
%   interval/tanh         - Hyperbolic tangent
%
% Special characters
%
%   interval/transpose    - Transpose                      .'
%   interval/ctranspose   - Complex conjugate transpose     '
%   interval/horzcat      - Horizontal concatenation       [,]
%   interval/vertcat      - Vertical concatenation         [;]
%   interval/subsasgn     - Subscripted asignment        ( ),{ },.
%   interval/subsref      - Subscripted reference        ( ),{ },.
%
% Set operators
%
%   interval/eq           - Set-wise equal
%   interval/ge           - Set-wise greater equal
%   interval/gt           - Set-wise greater
%   interval/in0          - Set-wise less than
%   interval/in_interior  - Set-wise less than
%   interval/in           - Set-wise less equal
%   interval/intersection - Set-wise intersection
%   interval/le           - Set-wise less equal
%   interval/lt           - Set-wise less than
%   interval/ne           - Set-wise not equal
%
% Matrix and vector operators
%
%   interval/diag         - Extract diagonal/create diagonal matrix
%   interval/inv          - Inverse
%   interval/length       - Length of vector
%   interval/lss          - Linear System Solver
%   interval/max          - Maximum
%   interval/min          - Minimum
%   interval/norm         - Norm of vector/matrix
%   interval/prod         - Product
%   interval/size         - Size of an interval
%   interval/sum          - Sum
%   interval/trace        - Trace of a matrix
%   interval/tril         - Triangular lower part of a matrix
%   interval/triu         - Triangular upper part of a matrix
%
% Interval specific operators
%
%   interval/inf          - Infimum
%   interval/sup          - Supremum
%   interval/infsup       - Infimum and supremum
%   interval/mid          - Midpoint
%   interval/rad          - Radius
%   interval/midrad       - Midpoint and radius
%   interval/diam         - Diameter
%   interval/pred         - Predecessor
%   interval/succ         - Successor
%
% Boolean operators
%
%   interval/isempty      - True if argument is the empty set
%   interval/isfinite     - True if argument contains no NaN or +/- Inf
%   interval/isinf        - True if argument contains +/-Inf
%   interval/isnan        - True if argument contains NaN
%
% Additional output routines
%
%   interval/TeX          - Conversion interval ==> TeX/LaTeX
