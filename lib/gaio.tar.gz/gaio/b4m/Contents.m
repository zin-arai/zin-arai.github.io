% b4m Free Interval Arithmetic Toolbox
% Version  1.0.2      27-Oct-1998
%
% Revision .004       27-Oct-1998
% Author: Jens Zemke
%
% b4m version 1.0.2.004 is the first official
% release, the versions 1.0.0.000 - 1.0.2.003
% have been beta releases.
%
% This toolbox is an implementation of
% a new datatype (class) interval.
%
% It can be copied, distributed and modified
% freely as long as the right to copy,
% distribute and modify is not violated.
%
% For more information on the copyright see
% the file <path>/toolbox/b4m/docu/COPYING
%
% It uses the package BIAS (Olaf Knueppel)
% including directed roundings for the
% computation of inclusions of solutions
% of linear (and nonlinear) systems.
%
% BIAS is free for noncommercial use.
%
% The package b4m can be retrieved from
%
%  http://www.ti3.tu-harburg.de/~zemke/b4m.html.
%
% The package consists of five directories:
%
%   -- <path>/toolbox/b4m/
%   -- <path>/toolbox/b4m/@interval/
%   -- <path>/toolbox/b4m/docu/
%   -- <path>/toolbox/b4m/private/
%   -- <path>/toolbox/b4m/@interval/private/
%
% The first two contain m files, the last two
% contain mex files (or the source code and a
% Makefile) used by the m files.
%
% The directory
%   -- <path>/toolbox/b4m/
% includes
%
% files for the inclusion of the result of
% an arithmetic operation
%
%   add      - Computes inclusion of  +
%   sub      - Computes inclusion of  -
%   mul      - Computes inclusion of  *
%   div      - Computes inclusion of  /
%   lss      - Solves linear system   \
%
% files that compute machine constants
%
%   epsilon  - Computes eps (see eps)
%   eta      - Computes smallest machine number
%
% files that compute floating point neighbors
%
%   pred     - Computes predecessor
%   succ     - Computes successor
%
% dummy files for double arguments
%
%   mid      - Returns input
%   rad      - Returns zeros(size(input))
%   midrad   - Returns [mid, rad]
%   diam     - Returns zeros(size(input))
%
% The package b4m furthermore contains the
% class interval. The methods of this class
% are described in the file
%
%   InterCon - Contents of class interval
%
% For new features take a look at the
% <path>/toolbox/b4m/docu/README file.
