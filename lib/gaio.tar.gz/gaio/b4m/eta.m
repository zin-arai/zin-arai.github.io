function prec = eta(varargin)

%ETA computes the smallest machine number (machine precision) prec.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'eta' is called
%
%         prec = eta
%
%     and computes the smallest machine number.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: eps, epsilon, realmin.

% On the IBM RS/6000 eta is less than realmin.

% prec = eps;
% while (prec / 2)        % code for testing whether BIAS is compiled
%    prec = prec / 2;     % correctly, returns eta (slower) without
% end                     % the use of directed roundings.

prec = succ(0);
