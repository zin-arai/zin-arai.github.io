function r = mul(a,b)

%MUL computes an inclusion (interval) of the product of two matrices.
% 
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mul' is called
%
%         r = mul(a,b)
%
%     and computes the interval matrix r
%     inlcuding the true result.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mtimes.
%     double: add, sub, div.

global b4m_DouBLe b4m_INTerval

b4m_DouBLe = 1;

r.val = bias_mul(b4m_DouBLe, a, b4m_DouBLe, b);
r = interval(r);
