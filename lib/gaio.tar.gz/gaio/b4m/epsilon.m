function eps = epsilon(varargin)

%EPSILON computes the smallest value eps with 1 + eps > 1.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'epsilon' is called
%
%         eps = epsilon
%
%     and computes the smallest machine number
%     eps with 1 + eps > 1.
%     EPSILON equals the built-in function eps.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: eta, eps.

if nargin ~= 0
   error('Too much input arguments.');
end;

epsneu = 1;
epsneu_plus_one = 2;

while (epsneu_plus_one - 1) 
   eps = epsneu;
   epsneu = epsneu / 2;
   epsneu_plus_one = 1 + epsneu;
end
