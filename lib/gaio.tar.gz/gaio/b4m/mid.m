function midpoint = mid(a)

%MID dummy routine for interval/mid (type help interval/mid).
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mid' is called
%
%         midpoint = mid(a)
%
%     and returns a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: rad, diam, midrad.

midpoint = a;
