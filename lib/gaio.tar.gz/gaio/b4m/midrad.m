function [midpoint, radius] = midrad(a)

%MIDRAD dummy routine for interval/midrad (type help interval/midrad).
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'midrad' is called
%
%         [midpoint, radius] = midrad(a)
%
%     and returns midpoint = a and
%     radius = zeros(size(a)).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: rad, diam, mid.

midpoint = a;
radius = zeros(size(a));
