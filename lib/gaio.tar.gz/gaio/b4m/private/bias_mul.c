/**********************************************************************
 *  bias_mul - mul with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.01
 *  Date: 23.1.1998
 *  Author(s): Jens Zemke
 *********************************************************************/

#include <mex.h>
#include "Bias2.h"
#include "types.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pR;
  BIASINTERVAL *pA;
  BIASINTERVAL *pB;
  double *pa;
  double *pb;
  unsigned int Arows, Acols, Brows, Bcols;
  int Aclass, Bclass;

  BiasInit();

  Aclass = (int) *mxGetPr(prhs[0]);
  Bclass = (int) *mxGetPr(prhs[2]);

  if ((Aclass == DouBLe) && (Bclass == INTerval))
  {
    Arows = mxGetM(prhs[1]);
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3])/2;
    Bcols = mxGetN(prhs[3]);

    if (Acols == Brows)
    {

      pa =                  mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulMIMR(pR, pB, pa, Bcols, Brows, Arows);

      return;
    }

    if ((Acols == 1) && (Arows == 1))
    {

      pa =                  mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Brows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulRMI(pR, pa, pB, Bcols, Brows);

      return;
    }

    if ((Bcols == 1) && (Brows == 1))
    {

      pa =                  mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Acols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulIMR(pR, pB, pa, Acols, Arows);

      return;
    }

    plhs[0] = mxCreateString("Matrix dimensions must agree."); return;

  }

  if ((Aclass == DouBLe) && (Bclass == DouBLe))
  {

    Arows = mxGetM(prhs[1]);
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3]);
    Bcols = mxGetN(prhs[3]);

    if (Acols == Brows)
    {

      pa =                   mxGetPr(prhs[1]);
      pb =                   mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulMRMR(pR, pb, pa, Bcols, Brows, Arows);

      return;
    }

    if ((Acols == 1) && (Arows == 1))
    {

      pa =                   mxGetPr(prhs[1]);
      pb =                   mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Brows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulRMR(pR, pa, pb, Bcols, Brows);

      return;
    }

    if ((Bcols == 1) && (Brows == 1))
    {

      pa =                   mxGetPr(prhs[1]);
      pb =                   mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Acols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulRMR(pR, pb, pa, Acols, Arows);

      return;
    }

    plhs[0] = mxCreateString("Matrix dimensions must agree."); return;

  }

  if ((Aclass == INTerval) && (Bclass == INTerval))
  {
    Arows = mxGetM(prhs[1])/2;
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3])/2;
    Bcols = mxGetN(prhs[3]);

    if (Acols == Brows)
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulMIMI(pR, pB, pA, Bcols, Brows, Arows);

      return;
    }

    if ((Acols == 1) && (Arows == 1))
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Brows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulIMI(pR, pA, pB, Bcols, Brows);

      return;
    }

    if ((Bcols == 1) && (Brows == 1))
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pB = (BIASINTERVAL *) mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Acols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulIMI(pR, pB, pA, Acols, Arows);

      return;
    }

    plhs[0] = mxCreateString("Matrix dimensions must agree."); return;

  }

  if ((Aclass == INTerval) && (Bclass == DouBLe))
  {
    Arows = mxGetM(prhs[1])/2;
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3]);
    Bcols = mxGetN(prhs[3]);

    if (Acols == Brows)
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pb =                  mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulMRMI(pR, pb, pA, Bcols, Brows, Arows);

      return;
    }
    if ((Acols == 1) && (Arows == 1))
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pb =                  mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Brows * 2, Bcols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulIMR(pR, pA, pb, Bcols, Brows);

      return;
    }

    if ((Bcols == 1) && (Brows == 1))
    {

      pA = (BIASINTERVAL *) mxGetPr(prhs[1]);
      pb =                  mxGetPr(prhs[3]);

      plhs[0] = mxCreateDoubleMatrix(Arows * 2, Acols, mxREAL);
      pR = (BIASINTERVAL *) mxGetPr(plhs[0]);

      BiasMulRMI(pR, pb, pA, Acols, Arows);

      return;
    }

    plhs[0] = mxCreateString("Matrix dimensions must agree."); return;

  }

  mexErrMsgTxt("Unknown class or too few arguments."); return;

} /* mexFunction */
