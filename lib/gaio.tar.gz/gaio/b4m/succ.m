function successor = succ(a)

%SUCC computes the successor of a real matrix a.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'succ' is called
%
%         successor = succ(a)
%
%     and computes the successor of a given
%     real matrix a.
%     The successor for real arguments
%     is defined as
%     succ := min {b | a < b}.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: pred.

global b4m_DouBLe b4m_INTerval

b4m_DouBLe = 1;

successor = bias_succ(b4m_DouBLe, a);
