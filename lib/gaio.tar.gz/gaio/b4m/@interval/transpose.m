function trans = transpose(a)

%TRANSPOSE (interval) computes the transpose of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'transpose' is called
%
%         trans = a.'
%
%     with an interval matrix a and computes
%     the transpose of a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: ctranspose.
%     double: transpose.

% last revision 22.10.1998 by Jens Zemke

trans = interval(inf(a).', sup(a).');
