function y = exp(x)

%EXP (interval) implements exp for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'exp' is called
%
%         y = exp(x)
%
%     and computes the elementwise exponential
%     of a given interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: log, log10.
%     double: exp.

y.val = bias_exp(x.val);
y = class(y, 'interval');
