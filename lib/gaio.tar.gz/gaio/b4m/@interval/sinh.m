function y = sinh(x)

%SINH (interval) implements sinh for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'sinh' is called
%
%         y = sinh(x)
%
%     and computes the elementwise hyperbolic
%     sine of a given interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: cosh, tanh, coth, asinh, sin.
%     double: sinh.

y.val = bias_sinh(x.val);
y = class(y, 'interval');
