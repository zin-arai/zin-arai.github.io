function y = coth(x)

%COTH (interval) implements coth for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'coth' is called
%
%         y = coth(x)
%
%     and computes the elementwise hyperbolic
%     cotangent of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sinh, cosh, tanh, acoth, cot.
%     double: coth.

y.val = bias_coth(x.val);
y = class(y, 'interval');
