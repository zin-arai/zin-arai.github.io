function r = mrdivide(a,b)

%MRDIVIDE (interval) overloades mrdivide for interval matrices, a/b.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mrdivide' is called
%
%         r = a / b
%
%     or
%
%         r = mrdivide(a,b)
%
%     and computes a / b for given interval/double
%     matrix a and interval/double matrix b with
%     appropriate dimensions.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mldivide, lss, plus, mtimes, minus, uminus, uplus.
%     double: mrdivide.

% last revision 16.10.1998 by Jens Zemke

global b4m_DouBLe b4m_INTerval

dimb = size(b);
if (prod(dimb) == 1)

   if isa(a, 'double')     % then b must be of type interval
      if imag(a)
         error('Complex intervals are not supported.');
      elseif issparse(a)
         error('Sparse intervals are not supported.');
      end;

      r.val = bias_div(b4m_DouBLe, a, b4m_INTerval, b.val);

   elseif isa(a, 'interval') & isa(b, 'interval')
      r.val = bias_div(b4m_INTerval, a.val, b4m_INTerval, b.val);

   elseif isa(b, 'double') % then a must be of type interval
      if imag(b)
         error('Complex intervals are not supported.');
      elseif issparse(b)
         error('Sparse intervals are not supported.');
      end;

      r.val = bias_div(b4m_INTerval, a.val, b4m_DouBLe, b);

   else
      error(['No division ''' class(a) ''' by ''' class(b) ''' possible.'])
   end;

   if isa(r.val, 'char')
      error(r.val);
   else
      r = class(r, 'interval');
   end;

else

   if (dimb(1) ~= size(a,2))
      error('Matrix dimensions must agree.');
   end;
   r = (b'\a')';

end
