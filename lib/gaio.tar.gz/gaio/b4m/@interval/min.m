function [m,kinf,ksup] = min(a,b,c)

%MIN (interval) computes interval of the possible minimal values.
%
%b4m - datatype interval    Version 1.02    (c) 6.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'min' is called
%
%         m = min(a)
%
%     or
%
%         [m,kinf,ksup] = min(a)
%
%     or
%
%         ...
%
%     and computes the interval of possible
%     minimum values m, for example
%     inf(m) := min {inf(a),inf(b)} 
%     sup(m) := min {sup(a),sup(b)}
%     and two integer matrices containing
%     the indices of the minimal arguments.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: max.
%     double: min.

% Last Revision 27.5.1998 by Jens Zemke

if nargin == 1
   [ainf, asup] = infsup(a);
   [minf,kinf] = min(ainf);
   [msup,ksup] = min(asup);
elseif nargin == 2
   if any(size(a) - size(b))
      error('Matrix dimensions must agree.');
   end;
   if isa(a, 'interval')
      [ainf, asup] = infsup(a);
   elseif ~isa(a, 'double')
      error('Only the types double and interval are supported.');
   elseif imag(a)
      error('Complex intervals are not supported.');
   elseif isa(a, 'sparse')
      error('Sparse intervals are not supported.');
   else
      ainf = a;
      asup = a;
   end;
   if isa(b, 'interval')
      [binf, bsup] = infsup(b);
   elseif ~isa(b, 'double')
      error('Only the types double and interval are supported.');
   elseif imag(b)
      error('Complex intervals are not supported.');
   elseif isa(b, 'sparse')
      error('Sparse intervals are not supported.');
   else
      binf = b;
      bsup = b;
   end;
   minf = min(ainf,binf);
   msup = min(asup,bsup);
else
   if ~isempty(b)
      error('Incorrect number of inputs.');
   end;
   if ~isa(c, 'double') | imag(c) | isa(c, 'sparse') | round(c) - c | c < 1 | any(size(c)-1)
      error('Dimension argument must be a positive integer scalar.');
   end;
   [ainf, asup] = infsup(a);
   [minf,kinf] = min(ainf,[],c);
   [msup,ksup] = min(asup,[],c);
end;

m = interval(minf, msup);
