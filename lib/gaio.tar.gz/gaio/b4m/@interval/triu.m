function u = triu(a,k)

%TRIU (interval) implements triu for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'triu' is called
%
%         U = triu(A)
%
%     with an interval matrix A and generates
%     the interval matrix U which is the upper
%     triangular part of A or
%
%         U = triu(A,k)
%
%     and extracts the upper interval matrix U
%     beginning with the k-th diagonal of A.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: tril, diag.
%     double: triu.

if nargin == 1
   k = 0;
end;

if isa(k, 'struct')
   error('Function ''triu'' not defined for variables of class ''struct''.');
elseif isa(k, 'cell')
   error('Conversion to double from cell is not possible.');
elseif ~isa(k, 'double')
   error('Second argument must be of class ''double''.');
end;

[s,f] = warning;

if prod(size(k)) ~= 1
   warning on;
   warning('K-th diagonal input must be an integer scalar.');
   warning off;
end;

u = interval(triu(inf(a),k), triu(sup(a),k));

warning(s);
warning(f);
