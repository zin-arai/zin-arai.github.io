function info = isempty(a)

%ISEMPTY (interval) returns whether a given interval is the empty set.
%
%b4m - datatype interval    Version 1.02    (c) 2.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'isempty' is called
%
%         info = isempty(a)
%
%     and returns the value one if a is the empty
%     set and zero otherwise.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: isnan, isinf.
%     double: isempty.

% last revision 22.10.1998 by Jens Zemke

info = isempty(a.val);
