function r = norm(a,k)

%NORM (interval) computes the norm of interval matrices and vectors.
%
%b4m - datatype interval    Version 1.02    (c) 6.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'norm' is called
%
%         r = norm(a,k)
%
%     or simply
%
%         r = norm(a)
%
%     and computes various norms for interval
%     matrices or interval vectors a.
%     For vectors -inf, inf and p-norms (p integer)
%     and for matrices inf, 'fro' and p-norms are
%     implemented.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: max, min.
%     double: norm.

% Last revision 27.5.1998 by Jens Zemke

if nargin == 1
   k = 2;
end;

dim = size(a);

if any(dim == 1)
   if ~isa(k, 'double') | imag(k) | isa(k, 'sparse') | any(size(k)-1)
      error('Unknown command option.');
   end;
   if k == 1
      r = sum(iabs(a));
   elseif k == inf
      r = max(iabs(a));
   elseif k == -inf
      r = min(iabs(a));
   elseif k == 2
      r = sqrt(sum(sqr(a)));
   elseif ~mod(k,1) & k>0
      r = root(sum(power(a,k)),k);
   else
      error('The only vector norms available are 1, p, inf and -inf.');
   end;
else
   if ~isa(k, 'double') | imag(k) | isa(k, 'sparse') | any(size(k)-1)
      if ~strcmp(k, 'fro')
         error('Unknown command option.');
      end;
   end;
   if k == 1
      r = max(sum(iabs((a))));
   elseif k == inf
      r = max(sum(iabs((a'))));
   elseif k == 2
      error('2-norm not implemented yet.');
      % r = max(svd(a));
   elseif k == 'fro'
      s.type = '()';
      s.subs{1} = ':';
      r = sqrt(sum(sqr(subsref(a,s))));
   else
      error('The only matrix norms available are 1, 2, inf, and fro.');
   end;
end
