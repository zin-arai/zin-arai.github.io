function l = length(x)

%LENGTH (interval) computes the length of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 25.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'length' is called
%
%         l = length(x)
%
%     and computes l = max(size(x)) for a given
%     interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: size.
%     double: length.

if isempty(x)
   l = 0;
else
   [m,n] = size(x.val);
   l = max(m/2,n);
end
