function inverse = inv(A);

%INV (interval) computes the inverse of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'inv' is called
%
%         inverse = inv(A)
%
%     with an interval matrix A and computes an
%     inclusion of the inverse.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: lss, mldivide.
%     double: inv.

sizeA = size(A);

if sizeA(1) - sizeA(2)
   error('Matrix must be square.');
else
   inverse = lss(A,eye(sizeA));
end;
