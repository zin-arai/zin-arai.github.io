function info = ge(a,b)

%GE (interval) implements (g)reater (e)qual, b in a (a>=b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'ge' is called
%
%         info = a >= b
%
%     or
%
%         info = ge(a,b)
%
%     and computes whether all components of
%     a include the appropiate components of b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: gt, lt, le, eq, ne, in, in_interior, in0.
%     double: ge.

global b4m_DouBLe b4m_INTerval

if     isa(b, 'double')
   info = bias_in(b4m_DouBLe, b,       b4m_INTerval, a.val);
elseif isa(b, 'interval') & isa(a, 'interval')
   info = bias_in(b4m_INTerval, b.val, b4m_INTerval, a.val);
elseif isa(a, 'double')
   a = interval(a);
   info = bias_in(b4m_INTerval, b.val, b4m_INTerval, a.val);
else
   error('Class error.');
end
if isa(info, 'char')
   error(info);
end
