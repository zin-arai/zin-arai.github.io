function negative = uminus(a)

%UMINUS (interval) overloades uminus for interval matrices, -a.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'uminus' is called
%
%         negative = - a
%
%     or
%
%         negative = uminus(a)
%
%     and computes the unary minus -a of a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: minus, uplus.
%     double: uminus.

negative.val = bias_neg(a.val);
negative = class(negative, 'interval');
