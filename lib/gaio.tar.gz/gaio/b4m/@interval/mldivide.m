function x = mldivide(A,b)

%MLDIVIDE (interval) implements the matrix left divide for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mldivide' is called
%
%         x = mldivide(a,b)
%
%     or
%
%         x = a\b
%
%     and computes an inclusion of the matrix left
%     divide of a matrix b by another matrix a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mrdivide, ldivide.
%     double: mldivide.

% last revision: 5.10.1998 by Jens Zemke

[m,k] = size(A);
[l,n] = size(b);

s.type = '()';
s.subs{2} = ':';

if max(m,k) == 1
   x = b/A;
elseif m ~= l
   error('Matrix dimensions must agree.');
else
   if m == k
      x = lss(A,b);
   elseif m > k              % least squares problem
      y = lss([A -eye(m);zeros(k) A'],[b;zeros(k,n)]);
      if ~isempty(y);
         s.subs{1} = 1:k;
         x = subsref(y,s);
      end;
   else                      % minimal norm solution
      y = lss([A' -eye(k);zeros(m) A],[zeros(k,n);b]);
      if ~isempty(y)
         s.subs{1} = m+1:m+k;
         x = subsref(y,s);
      end;
   end;
end;
