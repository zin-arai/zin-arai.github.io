function info = in(a,b)

%IN (interval) tests whether a lies in b (a<=b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'in' is called
%
%         info = in(a,b)
%
%     and computes whether all components of
%     a lie in the appropiate components of b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: in_interior, in0.

global b4m_DouBLe b4m_INTerval

if isa(a, 'double')
   if imag(a)
      error('Complex intervals are not supported.');
   elseif isa(a, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   info = bias_in(b4m_DouBLe, a, b4m_INTerval, b.val);

elseif isa(a, 'interval') & isa(b, 'interval')

   info = bias_in(b4m_INTerval, a.val, b4m_INTerval, b.val);

elseif isa(b, 'double')
   if imag(b)
      error('Complex intervals are not supported.');
   elseif isa(b, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   info = bias_in(b4m_INTerval, a.val, b4m_DouBLe, b);

else
   error(['No test for ''' class(a) ''' in ''' class(b) '''.'])
end;

if isa(info, 'char')
   error(info);
end
