function y = acosh(x)

%ACOSH (interval) implements acosh for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'acosh' is called
%
%         y = acosh(x)
%
%     and computes the elementwise inverse
%     hyperbolic cosine of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: cosh, asinh, atanh, acoth, acos.
%     double: acosh.

y.val = bias_acosh(x.val);

%  bias_acosh can only return an error (as character string)
%  or the right value (as field of double)

if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
