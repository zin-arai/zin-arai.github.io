function y = sqr(x)

%SQR (interval) implements sqr for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'sqr' is called
%
%         y = sqr(x)
%
%     and computes the elementwise square of
%     a given interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mpower, sqrt, exp.
%     double: mpower.

y.val = bias_sqr(x.val);
y = class(y, 'interval');
