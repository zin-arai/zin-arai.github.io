function ctrans = ctranspose(a)

%CTRANSPOSE (interval) computes the complex transpose of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'ctranspose' is called
%
%         ctrans = a'
%
%     or
%
%         ctrans = ctranspose(a)
%
%     with an interval matrix a and computes
%     the (complex) transpose of a.
%
%     Because there are up to now no complex
%     intervals ctranspose equals transpose.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: transpose.
%     double: ctranspose.

% last revision 22.10.1998 by Jens Zemke

ctrans = interval(inf(a)', sup(a)');
