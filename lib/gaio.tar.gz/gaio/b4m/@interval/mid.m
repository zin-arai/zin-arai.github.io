function midpoint = mid(a)

%MID (interval) computes the midpoint of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mid' is called
%
%         midpoint = mid(a)
%
%     and computes the midpoint of a given
%     interval matrix a.
%     The midpoint is defined as
%     mid(a) := (inf(a) + sup(a)) / 2.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: rad, midrad, diam.
%     double: mid.

midpoint = bias_mid(a.val);
