function string = TeX(a)

%TEX (interval) transforms interval matrix into TeX style string.
%
%b4m - datatype interval    Version 1.02    (c) 12.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'TeX' is called
%
%         string = TeX(a)
%
%     with an interval matrix a and generates
%     a string representation of that interval
%     matrix that can be put (for example via
%     copy and paste) into a TeX document.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: char, display.

%  right now the command newline = char(10) for the newline
%  character is used, with might be wrong on other systems.

newline = char(10);

dim = size(a);
infa = inf(a);
supa = sup(a);

if isempty(a)
   string = '\emptyset';
else
   if any(dim - 1)
      string = ['\begin{pmatrix}' newline];
   else
      string = [];
   end;

   for i = 1:dim(1)-1
      s = [];
      for j = 1:dim(2)-1
         strinf = num2str(infa(i,j),16);
         strsup = num2str(supa(i,j),16);
         minlength = min(length(strinf),length(strsup));
         k = 1;
         while strinf(k) == strsup(k) & k < minlength
            strboth(k) = strinf(k);
            k = k + 1;
         end;
         if k > 1
            strinf = strinf(k:end);
            strsup = strsup(k:end);
            s = [s '[' strboth '_{' strinf '}^{' strsup '}] & ' ];
         else
            s = [s '[' strinf ',' strsup '] & ' ];
         end;
      end;
      if isempty(j)
         j = 0;
      end;
      strinf = num2str(infa(i,j+1),16);
      strsup = num2str(supa(i,j+1),16);
      minlength = min(length(strinf),length(strsup));
      k = 1;
      strboth = [];
      while strinf(k) == strsup(k) & k < minlength
         strboth(k) = strinf(k);
         k = k + 1;
      end;
      if k > 1
         strinf = strinf(k:end);
         strsup = strsup(k:end);
         s = [s '[' strboth '_{' strinf '}^{' strsup '}]' ];
      else
         s = [s '[' strinf ',' strsup ']' ];
      end;
      s = [s ' \cr' newline];
      string = [string s];
   end;
   if isempty(i)
      i = 0;
   end;
   s = [];
   for j = 1:dim(2)-1
      strinf = num2str(infa(i+1,j),16);
      strsup = num2str(supa(i+1,j),16);
      minlength = min(length(strinf),length(strsup));
      k = 1;
      strboth = [];
      while strinf(k) == strsup(k) & k < minlength
         strboth(k) = strinf(k);
         k = k + 1;
      end;
      if k > 1
         strinf = strinf(k:end);
         strsup = strsup(k:end);
         s = [s '[' strboth '_{' strinf '}^{' strsup '}] & ' ];
      else
         s = [s '[' strinf ',' strsup '] & ' ];
      end;
   end;
   if isempty(j)
      j = 0;
   end;

   strinf = num2str(infa(i+1,j+1),16);
   strsup = num2str(supa(i+1,j+1),16);
   minlength = min(length(strinf),length(strsup));
   k = 1;
   strboth = [];
   while strinf(k) == strsup(k) & k < minlength
      strboth(k) = strinf(k);
      k = k + 1;
   end;
   if k > 1
      strinf = strinf(k:end);
      strsup = strsup(k:end);
      s = [s '[' strboth '_{' strinf '}^{' strsup '}]' ];
   else
      s = [s '[' strinf ',' strsup ']' ];
   end;

   if any(dim - 1)
      string = [string s newline '\end{pmatrix}'];
   else
      string = [string s];
   end;
end
