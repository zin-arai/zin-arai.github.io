function info = isnan(a)

%ISNAN (interval) returns whether a given interval contains NaN.
%
%b4m - datatype interval    Version 1.02    (c) 22.10.1998 Jens Zemke
%
%   DESCRIPTION:
%     'isnan' is called
%
%         info = isnan(a)
%
%     and returns the value one if the interval
%     a contains any NaN.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: isempty, isinf.
%     double: isnan.

info = isnan(inf(a)) | isnan(sup(a));
