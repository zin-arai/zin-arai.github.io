function y = tan(x)

%TAN (interval) implements tan for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'tan' is called
%
%         y = tan(x)
%
%     and computes the elementwise tangent
%     of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sin, cos, cot, atan, tanh.
%     double: tan.

y.val = bias_tan(x.val);
y = class(y, 'interval');
