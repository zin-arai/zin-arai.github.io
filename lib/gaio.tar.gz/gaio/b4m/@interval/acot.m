function y = acot(x)

%ACOT (interval) implements acot for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'acot' is called
%
%         y = acot(x)
%
%     and computes the elementwise inverse
%     cotangent of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: cot, asin, acos, atan, acoth.
%     double: acot.

y.val = bias_acot(x.val);
y = class(y, 'interval');
