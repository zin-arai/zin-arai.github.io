function r = minus(a,b)

%MINUS (interval) overloades minus for interval matrices, a-b.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'minus' is called
%
%         r = a - b
%
%     or
%
%         r = minus(a,b)
%
%     and computes the subtraction of the intervals.
%     The subtraction of intervals is defined as
%     r = a - b := [sup(a)-inf(b), inf(a)-sup(b)].
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: plus, mtimes, mrdivide, uminus, uplus.
%     double: minus.

global b4m_DouBLe b4m_INTerval

if isa(a, 'double')    % then b must be of type interval
   if imag(a)
      error('Complex intervals are not supported.');
   elseif issparse(a)
      error('Sparse intervals are not supported.');
   end;

   r.val = bias_sub(b4m_DouBLe, a, b4m_INTerval, b.val);

elseif isa(a, 'interval') & isa(b, 'interval')
   r.val = bias_sub(b4m_INTerval, a.val, b4m_INTerval, b.val);

elseif isa(b, 'double') % then a must be of type interval
   if imag(b)
      error('Complex intervals are not supported.');
   elseif issparse(b)
      error('Sparse intervals are not supported.');
   end;

   r.val = bias_sub(b4m_INTerval, a.val, b4m_DouBLe, b);

else
   error(['No subtraction ''' class(a) ''' minus ''' class(b) ''' possible.'])
end;

if isa(r.val, 'char')
   error(r.val);
else
   r = class(r, 'interval');
end
