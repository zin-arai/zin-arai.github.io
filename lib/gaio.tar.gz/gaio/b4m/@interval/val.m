function v = val(a)

v = a.val;
