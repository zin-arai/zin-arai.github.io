function s = sum(a,k)

%SUM (interval) overloaded method for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'sum' is called
%
%         s = sum(a,k)
%
%     and implements the overloaded method
%     SUM for intervals.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: plus.
%     double: sum.

% Last Revision 22.10.1998 by Jens Zemke

dim = size(a);

if nargin == 1
   if dim(1) == 1
      s = a*ones(dim(2),1);
   else
      s = ones(1,dim(1))*a;
   end;

% nargin == 2 is default case

else
   if ~isa(k, 'double') | imag(k) | isa(k, 'sparse') | round(k) - k | k < 1 | any(size(k)-1)
      error('Dimension argument must be a positive integer scalar.');
   end;
   if k == 1
      s = ones(1,dim(1))*a;
   elseif k == 2
      s = a*ones(dim(2),1);
   else
      s = a;
   end;
end
