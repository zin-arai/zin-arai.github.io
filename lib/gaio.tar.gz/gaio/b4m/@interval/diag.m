function r = diag(a,k)

%DIAG (interval) implements diag for interval vectors/matrices.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'diag' is called
%
%         r = diag(a,k)
%
%     or simply
%
%         r = diag(a)
%
%     with an interval vector a and generates
%     the interval matrix r with a on the k-th
%     diagonal (if k is missing k = 0)
%     or with an interval matrix a and generates
%     the interval vector r which is the k-th
%     diagonal of a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: subsref, subsasgn.
%     double: diag.

if nargin == 1
   k = 0;
end;

if isa(k, 'struct')
   error('Function ''diag'' not defined for variables of class ''struct''.');
elseif isa(k, 'cell')
   error('Conversion to double from cell is not possible.');
elseif ~isa(k, 'double')
   error('Second argument must be of class ''double''.');
end;

[s,f] = warning;

if prod(size(k)) ~= 1
   warning on;
   warning('K-th diagonal input must be an integer scalar.');
   warning off;
end;

r = interval(diag(inf(a),k), diag(sup(a),k));

warning(s);
warning(f);
