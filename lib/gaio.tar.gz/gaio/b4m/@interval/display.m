function display(a)

%DISPLAY (interval) command window display of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 27.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'display' is called
%
%         display(a)
%
%     and generates the command window display
%     of a given interval (matrix).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: display.

global b4m_NaTiVe

%  b4m_NaTiVe is used to set the behavior of the command window display.
%  Right now there are two (unelegant) methods,
%  - the fast version using Matlab's routine
%  - the more nice routine using interpreted code (slow ;-)
%
%  It would be great, to have an C-code implementation using the right
%  decimal rounding -> coming soon (hopefully)

if isempty(b4m_NaTiVe)
   b4m_NaTiVe = 0;
end;

if b4m_NaTiVe == 1
   display(a.val);

%  default is right now set to this piece of code ...

else
   disp(' ');
   disp([inputname(1) ' =']);
   disp(' ');
   if isempty(a.val)

% the empty interval (the empty set) is written as string '{}'

      disp('{}');
   else
      s = size(a);
      infa = inf(a);
      supa = sup(a);
      for i = 1:s(1)
         string = [];
         for j = 1:s(2)
            string = [string '[' num2str(infa(i,j), 16) ',' num2str(supa(i,j), 16) ']'];
         end;
         disp(string);
      end;
   end;
   disp(' ');
end
