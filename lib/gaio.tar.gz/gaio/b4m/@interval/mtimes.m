function r = mtimes(a,b)

%MTIMES (interval) overloades mtimes for interval matrices, a*b.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mtimes' is called
%
%         r = a * b
%
%     or
%
%         r = mtimes(a,b)
%
%     and computes a * b for given interval/double
%     matrices a, b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mrdivide, mldivide, mpower, minus, plus, uminus, uplus.
%     double: mtimes.

global b4m_DouBLe b4m_INTerval

if isa(a, 'double')    % then b must be of type interval
   if imag(a)
      error('Complex intervals are not supported.');
   elseif issparse(a)
      error('Sparse intervals are not supported.');
   end;

   r.val = bias_mul(b4m_DouBLe, a, b4m_INTerval, b.val);

elseif isa(a, 'interval') & isa(b, 'interval')
   r.val = bias_mul(b4m_INTerval, a.val, b4m_INTerval, b.val);

elseif isa(b, 'double') % then a must be of type interval
   if imag(b)
      error('Complex intervals are not supported.');
   elseif issparse(b)
      error('Sparse intervals are not supported.');
   end;

   r.val = bias_mul(b4m_INTerval, a.val, b4m_DouBLe, b);

else
   error(['No multiplication ''' class(a) ''' times ''' class(b) ''' possible.'])
end;

if isa(r.val, 'char')
   error(r.val);
else
   r = class(r, 'interval');
end
