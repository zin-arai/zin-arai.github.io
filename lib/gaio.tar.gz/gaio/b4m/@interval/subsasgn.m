function r = subsasgn(r,s,a)

%SUBSASGN (interval) implements subscripted assignment for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'subsasgn' is called
%
%         r = subsasgn(r,s,a)
%
%     or (for instance)
%
%         r(i,j) = a
%
%     etc.
%
%     and implements subscripted assignment
%     for intervals.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: subsref.
%     double: subsasgn.

% This method is called iff r is of type interval or empty.
% If r is of type double, Matlab tries to invoke a method
% double.m in the class directory for a typecast.

type = s(1).type;
subs = s(1).subs;

a = interval(a);
dima = size(a);
dimr = size(r);

str1 = 'In an assignment ';
str2 = ' = B, the number of ';
str3 = 'must be the same.';
str4 = ['columns in B and' char(10) 'the number of elements in the A column index matrix must be the same.'];
str5 = ['rows in B and the' char(10) 'number of elements in the A row index matrix must be the same.'];

if strcmp(type, '()')
   lsubs = length(subs);
   if lsubs == 1
      if strcmp(subs{1}, ':')
         if dimr(1) * dimr(2) ~= dima(1)*dima(2)
            error([str1 ' A(:)' str2 'elements in A and B' char(10) str3]);
         end;
         r.val = reshape(a.val, 2*dimr(1), dimr(2));
      else
         tmp = subs{1};
         for k = 1:length(tmp)
            i(2*k-1) = 2*tmp(k)-1;
            i(2*k)   = 2*tmp(k);
         end;
         if length(tmp) ~= dima(1)*dima(2)
            error([str1 ' A(I)' str2 'elements in B and I' char(10) str3]);
         end;
         r.val(i) = a.val;
         if ~isa(r, 'interval')
            r = class(r, 'interval');
         end;
      end;
   elseif lsubs == 2
      tmp = subs{1};
      j = subs{2};
      if strcmp(tmp, ':')
         if strcmp(j, ':')
            if dimr(1) ~= dima(1)
               error('Subscripted assignment dimension mismatch.');
            elseif dimr(2) ~= dima(2)
               error('Ambiguous or mismatched subscripted assignment.');
            else
               r.val = a.val;
            end;
         else
            if length(j) ~= dima(2)
               error([str1 ' A(:,matrix)' str2 'rows in A and B' char(10) str3]);
            end;
            r.val(:,j) = a.val;
         end;
      else
         for k = 1:length(tmp)
            i(2*k-1) = 2*tmp(k)-1;
            i(2*k)   = 2*tmp(k);
         end;
         if strcmp(j, ':')
            if dimr(2) ~= dima(2)
               error([str1 ' A(matrix,:)' str2 'columns in A and B' char(10) str3]);
            end;
            r.val(i,:) = a.val;
         else
            if length(tmp) ~= dima(1)
               error([str1 ' A(matrix,matrix)' str2 str5]);
            elseif length(j) ~= dima(2)
               error([str1 ' A(matrix,matrix)' str2 str4]);
            end;
            r.val(i,j) = a.val;
         end;
      end;
      if ~isa(r, 'interval')
         r = class(r, 'interval');
      end;
   elseif lsubs > 2
      error('Only scalars, vectors and matrices are supported.');
   end;
elseif strcmp(type, '.')
   error('Structure assignment not implemented.');
elseif strcmp(type, '{}')
   error('Cell assignment not implemented.');
end
