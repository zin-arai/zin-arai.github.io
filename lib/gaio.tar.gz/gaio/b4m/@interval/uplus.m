function r = uplus(a)

%UPLUS (interval) overloades uplus for interval matrices, +a.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'uplus' is called
%
%         r = + a
%
%     or
%
%         r = uplus(a)
%
%     and returns a (a == +a).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: plus, uminus.
%     double: uplus.

r = a;
