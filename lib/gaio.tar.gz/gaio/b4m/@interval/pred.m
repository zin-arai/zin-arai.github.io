function predecessor = pred(a)

%PRED (interval) computes the predecessor of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'pred' is called
%
%         predecessor = pred(a)
%
%     and computes the predecessor of a given
%     interval matrix a.
%     The predecessor is defined as
%     pred := max {diam(y) | y < a}.
%     The predecessor doesn't need to exist.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: succ.
%     double: pred.

global b4m_DouBLe b4m_INTerval

[info, predecessor.val] = bias_pred(b4m_INTerval, a.val);

if info
   predecessor = class(predecessor, 'interval');
else
   warning('No predecessor can be computed, interval is too narrow.');
   predecessor = interval([]);
end
