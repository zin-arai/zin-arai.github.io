function y = power(x,n)

%POWER (interval) implements 
%
%b4m - datatype interval    Version 1.02    (c) 7.7.1998 Jens Zemke
%
%   DESCRIPTION:
%     'power' is called
%
%         y = x.^n
%
%     and computes the elementwise power.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mpower
%     double: power

global b4m_INTerval b4m_DouBLe

dim = size(x);
dimn = size(n);


% if any(size(x)-1)
%    error('Interval power only defined for scalars.');
% end;

if isa(x, 'double')
   if imag(x)
      error('Complex intervals are not supported.');
   elseif isa(x, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   if ~(prod(dimn)-1)
      y.val = bias_power(b4m_DouBLe, x, b4m_INTerval, n.val);
      if isa(y.val, 'char')
         error(y.val);
      end;
   elseif any(dim-dimn)
      error('Matrix dimensions must agree.');
   else
      for i = 1:dim(1)
         for j = 1:dim(2)
            id = [2*i-1 2*i];
            tmp = bias_power(b4m_DouBLe, x(i,j), b4m_INTerval, n.val(id,j));
            if isa(tmp, 'char')
               error(tmp);
            else
               y.val(id,j) = tmp;
            end;
         end;
      end;
   end; 

elseif isa(x, 'interval') & isa(n, 'interval')

   if ~(prod(dimn)-1)
      y.val = bias_power(b4m_INTerval, x.val, b4m_INTerval, n.val);
      if isa(y.val, 'char')
         error(y.val);
      end;
   elseif any(dim-dimn)
      error('Matrix dimensions must agree.');
   else
      for i = 1:dim(1)
         for j = 1:dim(2)
            id = [2*i-1 2*i];
            tmp = bias_power(b4m_INTerval, x.val(id,j), b4m_INTerval, n.val(id,j));
            if isa(tmp, 'char')
               error(tmp);
            else
               y.val(id,j) = tmp;
            end;
         end;
      end;
   end;

elseif isa(n, 'double')
   if imag(n)
      error('Complex intervals are not supported.');
   elseif isa(n, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   if ~(prod(dimn)-1)
      y.val = bias_power(b4m_INTerval, x.val, b4m_DouBLe, n);
      if isa(y.val, 'char')
         error(y.val);
      end;
   elseif any(dim-dimn)
      error('Matrix dimensions must agree.');
   else
      for i = 1:dim(1)
         for j = 1:dim(2)
            id = [2*i-1 2*i];
            tmp = bias_power(b4m_INTerval, x.val(id,j), b4m_DouBLe, n(i,j));
            if isa(tmp, 'char')
               error(tmp)
            else
               y.val(id,j) = tmp;
            end;
         end;
      end;
   end;

else
   error(['No power ''' class(x) ''' to ''' class(n) ''' possible.'])
end;

y = class(y, 'interval');
