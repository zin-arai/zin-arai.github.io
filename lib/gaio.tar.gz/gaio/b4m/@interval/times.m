function y = times(a,b)

%TIMES (interval) componentwise multiplication for intervals, a.*b.
%
%b4m - datatype interval    Version 1.02    (c) 14.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'times' is called
%
%         y = a.*b
%
%     or
%
%         y = times(a,b)
%
%     and computes the result of componentwise
%     multiplication for interval matrices a,b.
%     
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mtimes.
%     double: times.

dima = size(a);
dimb = size(b);
s.type = '()';

if all(dima == 1) | all(dimb == 1)
   y = a*b;
elseif ~all(dima == dimb)
   error('Matrix dimensions must agree.');
else
   y = interval(zeros(dima));
   for i = 1:dima(1)
      for j = 1:dima(2)
      %  y(i,j) = a(i,j) * b(i,j)    not possible because of bug ;-)
         s.subs = cell({i,j});
         y = subsasgn(y,s,subsref(a,s)*subsref(b,s));
      end;
   end;
end
