function y = tanh(x)

%TANH (interval) implements tanh for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'tanh' is called
%
%         y = tanh(x)
%
%     and computes the elementwise hyperbolic
%     tangent of a given interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sinh, cosh, coth, atanh, tan.
%     double: tanh.

y.val = bias_tanh(x.val);
y = class(y, 'interval');
