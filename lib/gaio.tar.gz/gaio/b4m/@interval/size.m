function [s,l] = size(a,k)

%SIZE (interval) overloaded method, computes size of a interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'size' is called
%
%         s = size(a)
%
%     and computes the dimension of a given
%     interval matrix a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: size.

[m n] = size(a.val);

if nargout == 2
   s = m/2;
   l = n;
else
   if nargin == 1
      s = [m/2 n];
   elseif k == 1
      s = m/2;
   elseif k == 2
      s = n;
   else
      error('Only scalars, vectors and matrices supported.');
  end;
end;
