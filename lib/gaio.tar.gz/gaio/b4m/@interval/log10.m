function y = log10(x)

%LOG10 (interval) implements log10 for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'log10' is called
%
%         y = log10(x)
%
%     and computes the elementwise base 10
%     logarithm of a given interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: log, exp.
%     double: log10.

y.val = bias_log10(x.val);

%  bias_log10 can only return an error (as character string)
%  or the right value (as field of double)

if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
