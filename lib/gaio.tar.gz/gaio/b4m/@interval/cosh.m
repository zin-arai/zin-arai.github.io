function y = cosh(x)

%COSH (interval) implements cosh for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'cosh' is called
%
%         y = cosh(x)
%
%     and computes the elementwise hyperbolic
%     cosine of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sinh, tanh, coth, acosh, cos.
%     double: cosh.

y.val = bias_cosh(x.val);
y = class(y, 'interval');
