function y = acos(x)

%ACOS (interval) implements acos for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'acos' is called
%
%         y = acos(x)
%
%     and computes the elementwise inverse
%     cosine of the interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: cos, asin, atan, acot, acosh.
%     double: acos.

y.val = bias_acos(x.val);

%  bias_acos can only return an error (as character string)
%  or the right value (as field of double)

if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
