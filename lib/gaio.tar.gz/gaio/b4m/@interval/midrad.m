function [midpoint, radius] = midrad(a)

%MIDRAD (interval) computes midpoint and radii of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'midrad' is called
%
%         [midpoint, radius] = midrad(a)
%
%     and computes the midpoint and the radius
%     of a given interval matrix a.
%     For the definition of midpoint and radius
%     see MID, RAD.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mid, rad, diam.
%     double: midrad.

[midpoint, radius] = bias_midrad(a.val);
