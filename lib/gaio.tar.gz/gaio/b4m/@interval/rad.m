function radius = rad(a)

%RAD (interval) computes the radii of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'rad' is called
%
%         radius = rad(a)
%
%     and computes the radius of a given
%     interval matrix a.
%     The radius is defined as
%     rad(a) = diam(a) / 2.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mid, midrad, diam.
%     double: rad.

[midpoint, radius] = bias_midrad(a.val);
