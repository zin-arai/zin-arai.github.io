function l = tril(a,k)

%TRIL (interval) implements tril for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'tril' is called
%
%         L = tril(A)
%
%     with an interval matrix A and generates
%     the interval matrix L which is the lower
%     triangular part of A or
%
%         L = tril(A,k)
%
%     and extracts the lower interval matrix L
%     beginning with the k-th diagonal of A.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: triu, diag.
%     double: tril.

if nargin == 1
   k = 0;
end;

if isa(k, 'struct')
   error('Function ''tril'' not defined for variables of class ''struct''.');
elseif isa(k, 'cell')
   error('Conversion to double from cell is not possible.');
elseif ~isa(k, 'double')
   error('Second argument must be of class ''double''.');
end;

[s,f] = warning;

if prod(size(k)) ~= 1
   warning on;
   warning('K-th diagonal input must be an integer scalar.');
   warning off;
end;

l = interval(tril(inf(a),k), tril(sup(a),k));

warning(s);
warning(f);
