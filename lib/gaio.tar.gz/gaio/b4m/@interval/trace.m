function y = trace(A)

%TRACE (interval) computes sum(diag(A)) for interval argument.
%
%b4m - datatype interval    Version 1.02    (c) 23.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'trace' is called
%
%         tr = trace(A)
%
%     with an interval matrix A and computes
%     the sum of the diagonal of A (equals
%     the sum of the eigenvalues of A).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sum, diag.
%     double: trace.

y = sum(diag(A));
