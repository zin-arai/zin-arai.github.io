function x = rdivide(a,b)

%RDIVIDE (interval) implements elementwise right divide for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'rdivide' is called
%
%         x = rdivide(a,b)
%
%     or
%
%         x = a./b
%
%     and computes an inclusion for the elementwise
%     right divide of a matrix a by another matrix b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mrdivide, ldivide.
%     double: rdivide.

sizea = size(a);
sizeb = size(b);

if max(sizeb) == 1
   x = a/b;
elseif max(sizea) == 1
   x = interval(zeros(sizeb));
   for i = 1:sizeb(1)
      for j = 1:sizeb(2)
         s.type = '()';
         s.subs{1} = i;
         s.subs{2} = j;
         x = subsasgn(x,s,a/subsref(b,s));
      end;
   end;
elseif any(sizea-sizeb)
   error('Matrix dimensions must agree.');
else
   x = interval(zeros(sizeb));
   for i = 1:sizeb(1)
      for j = 1:sizeb(2)
         s.type = '()';
         s.subs{1} = i;
         s.subs{2} = j;
         x = subsasgn(x,s,subsref(a,s)/subsref(b,s));
      end;
   end;
end;
