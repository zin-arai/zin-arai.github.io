function info = ne(a,b)

%NE (interval) implements (n)ot (e)qual for intervals (a~=b).
%
%b4m - datatype interval    Version 1.02    (c) 3.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'ne' is called
%
%         info = a ~= b
%
%     or
%
%         info = ne(a,b)
%
%     and computes whether a not equals b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: eq, le, lt, ge, gt, in, in_interior, in0.
%     double: ne.

if     isa(a, 'double')
   info = (    a  ~= inf(b) |     a  ~= sup(b));
elseif isa(a, 'interval') & isa(b, 'interval')
   info = (inf(a) ~= inf(b) | sup(a) ~= sup(b));
elseif isa(b, 'double')
   info = (inf(a) ~=     b  | sup(a) ~=     b );
else
   error('Class error.')
end
