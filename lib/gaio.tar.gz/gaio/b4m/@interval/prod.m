function p = prod(a,k)

%PROD (interval) overloaded method for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 16.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'prod' is called
%
%         p = prod(a,k)
%
%     and implements the overloaded method
%     PROD for intervals.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mtimes.
%     double: prod.

% Last Revision 27.5.1998 by Jens Zemke

dim = size(a);
mindim = min(dim(1), dim(2));
maxdim = max(dim(1), dim(2));
t.type = '()';

if nargin == 1
   if mindim == 1
      p = interval(1);
      for i = 1:maxdim
         t.subs = cell({i});
         p = p * subsref(a,t);
      end;
   else
      p = [];
      for i = 1:dim(2)
         pprod = interval(1);
         for j = 1:dim(1)
            t.subs = cell({j,i});
            pprod = pprod * subsref(a,t);
         end;
         p = [p pprod];
      end;
   end;

% nargin == 2 is default case ->
% only scalars, vectors and matrices of type interval exist.

else
   if ~isa(k, 'double') | imag(k) | isa(k, 'sparse') | round(k) - k | k < 1 | any(size(k)-1)
      error('Dimension argument must be a positive integer scalar.');
   end;
   if k == 1
      p = [];
      for i = 1:dim(2)
         pprod = interval(1);
         for j = 1:dim(1)
            t.subs = cell({j,i});
            pprod = pprod * subsref(a,t);
         end;
         p = [p pprod];
      end;
   elseif k == 2
      p = [];
      for i = 1:dim(1)
         pprod = interval(1);
         for j = 1:dim(2)
            t.subs = cell({i,j});
            pprod = pprod * subsref(a,t);
         end;
         p = [p;pprod];
      end;
   else
      p = a;
   end;
end;
