function [infimum, supremum] = infsup(a)

%INFSUP (interval) conversion to double from interval.
%
%b4m - datatype interval    Version 1.02    (c) 5.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'infsup' is called
%
%         [infimum, supremum] = infsup(a)
%
%     with an interval matrix a and computes
%     the lower and upper bound.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: inf, sup, mid, rad.
%     double: interval.

infimum  = bias_inf(a.val);
supremum = bias_sup(a.val);
