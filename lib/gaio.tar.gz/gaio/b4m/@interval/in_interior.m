function info = in_interior(a,b)

%IN_INTERIOR (interval) tests whether a lies in the interior of b (a<b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'in_interior' is called
%
%         info = in_interior(a,b)
%
%     and computes whether all components of
%     a lie in the interior of the appropiate
%     components of b (same as in0).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: in0, in.

global b4m_DouBLe b4m_INTerval

if isa(a, 'double')
   if imag(a)
      error('Complex intervals are not supported.');
   elseif isa(a, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   info = bias_in_interior(b4m_DouBLe, a, b4m_INTerval, b.val);

elseif isa(a, 'interval') & isa(b, 'interval')

   info = bias_in_interior(b4m_INTerval, a.val, b4m_INTerval, b.val);

elseif isa(b, 'double')
   if imag(b)
      error('Complex intervals are not supported.');
   elseif isa(b, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   info = bias_in_interior(b4m_INTerval, a.val, b4m_DouBLe, b);

else
   error(['No test for ''' class(a) ''' in interior of ''' class(b) '''.'])
end;

if isa(info, 'char')
   error(info);
end
