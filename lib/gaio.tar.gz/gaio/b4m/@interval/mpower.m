function y = mpower(x,n)

%MPOWER (interval) implements 
%
%b4m - datatype interval    Version 1.02    (c) 14.4.1998 Jens Zemke
%
%   DESCRIPTION:
%     'mpower' is called
%
%         y = x^n
%
%     or
%
%         y = mpower(x,n)
%
%     and computes (up to now only for scalar
%     argument) the nth power of x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: power.
%     double: mpower.

global b4m_INTerval b4m_DouBLe

if any(size(x)-1)
   error('Interval power only defined for scalars.');
end;

if isa(x, 'double')
   if imag(x)
      error('Complex intervals are not supported.');
   elseif isa(x, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   y.val = bias_power(b4m_DouBLe, x, b4m_INTerval, n.val);

elseif isa(x, 'interval') & isa(n, 'interval')
   y.val = bias_power(b4m_INTerval, x.val, b4m_INTerval, n.val);

elseif isa(n, 'double')
   if imag(n)
      error('Complex intervals are not supported.');
   elseif isa(n, 'sparse')
      error('Sparse intervals are not supported.');
   end;

   y.val = bias_power(b4m_INTerval, x.val, b4m_DouBLe, n);

else
   error(['No power ''' class(n) ''' to ''' class(x) ''' possible.'])
end;

if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
