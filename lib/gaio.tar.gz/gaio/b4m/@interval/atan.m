function y = atan(x)

%ATAN (interval) implements atan for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'atan' is called
%
%         y = atan(x)
%
%     and computes the elementwise inverse
%     tangent of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: tan, asin, acos, acot, atanh.
%     double: atan.

y.val = bias_atan(x.val);
y = class(y, 'interval');
