function y = cot(x)

%COT (interval) implements cot for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'cot' is called
%
%         y = cot(x)
%
%     and computes the elementwise cotangent
%     of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sin, cos, tan, acot, coth.
%     double: cot.

y.val = bias_cot(x.val);
y = class(y, 'interval');
