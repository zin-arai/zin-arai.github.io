function info = lt(a,b)

%LT (interval) implements (l)ess (t)han, a in interior of b (a<b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'lt' is called
%
%         info = a < b
%
%     or
%
%         info = lt(a,b)
%
%     and computes whether all components of
%     b include the appropiate components of b
%     in the interior.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: le, eq, ge, gt, ne, in, in_interior, in0.
%     double: lt.

global b4m_DouBLe b4m_INTerval

if     isa(a, 'double')
   info = bias_in_interior(b4m_DouBLe, a,       b4m_INTerval, b.val);
elseif isa(a, 'interval') & isa(b, 'interval')
   info = bias_in_interior(b4m_INTerval, a.val, b4m_INTerval, b.val);
elseif isa(b, 'double')
   info = 0;
else
   error('Class error.')
end;

if isa(info, 'char')
   error(info);
end
