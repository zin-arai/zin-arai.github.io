/**********************************************************************
 *  bias_midrad - midrad with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 26.1.1998
 *  Author(s): Jens Zemke
 *********************************************************************/

#include <mex.h>
#include "Bias2.h"
#include "types.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pA;
  double *pm;
  double *pr;
  unsigned int Arows, Acols;

  BiasInit();

  Arows = mxGetM(prhs[0])/2;
  Acols = mxGetN(prhs[0]);

  pA      = (BIASINTERVAL *) mxGetPr(prhs[0]);

  plhs[0] = mxCreateDoubleMatrix(Arows, Acols, mxREAL);
  pm      =                  mxGetPr(plhs[0]);
  plhs[1] = mxCreateDoubleMatrix(Arows, Acols, mxREAL);
  pr      =                  mxGetPr(plhs[1]);

  BiasMidRadM(pm, pr, pA, Acols, Arows);

  return;

} /* mexFunction */ 
