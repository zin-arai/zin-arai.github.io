/*************************************************************************
 *  bias_power - power with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 23.2.1998
 *  Author(s): Jens Zemke
 ************************************************************************/

#include <mex.h>
#include "Bias0.h"
#include "Bias2.h"
#include "BiasF.h"
#include "types.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pY;
  BIASINTERVAL *pX;
  BIASINTERVAL *pN;
  unsigned int Xrows, Xcols;
  double *pointer_to_exponent;
  long n;
  long count;
  int Xclass, Nclass;

  BiasFuncInit();

  Xclass = (int) *mxGetPr(prhs[0]);
  Nclass = (int) *mxGetPr(prhs[2]);

  if ((Xclass == INTerval) && (Nclass == DouBLe  ))
  {
    Xrows = mxGetM(prhs[1])/2;
    Xcols = mxGetN(prhs[1]);

    if (mxGetM(prhs[3]) != 1 || mxGetN(prhs[3]) != 1)
    {
      plhs[0] = mxCreateString("Exponent can only be a scalar.");
      return;
    }

    pointer_to_exponent = mxGetPr(prhs[3]);

    n = (long) *pointer_to_exponent;

    if (*pointer_to_exponent != n)
    {
      plhs[0] = mxCreateString("Exponent can only be of type integer.");
      return;
    }

    pX = (BIASINTERVAL *) mxGetPr(prhs[1]);

    plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
    pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

    for (count = 0; count < Xrows * Xcols; count++)
    {
      BiasPowerN(pY++, pX++, n);
    }
    pY -= count;

    return;
  }
  if ((Xclass == INTerval) && (Nclass == INTerval))
  {
    Xrows = mxGetM(prhs[1])/2;
    Xcols = mxGetN(prhs[1]);

    if (mxGetM(prhs[3])/2 != 1 || mxGetN(prhs[3]) != 1)
    {
      plhs[0] = mxCreateString("Exponent can only be a scalar.");
      return;
    }

    pX = (BIASINTERVAL *) mxGetPr(prhs[1]);
    pN = (BIASINTERVAL *) mxGetPr(prhs[3]);

    plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
    pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

    for (count = 0; count < Xrows * Xcols; count++)
    {
      if (BiasInf(pX) <= 0)
      {
        plhs[0] = mxCreateString("Base interval must be > 0.");
        return;
      }
      BiasPowerI(pY++, pX++, pN);
    }
    pY -= count;

    return;
  }
  if ((Xclass == DouBLe  ) && (Nclass == INTerval))
  {
    Xrows = mxGetM(prhs[0]);
    Xcols = mxGetN(prhs[0]);

    if (mxGetM(prhs[3])/2 != 1 || mxGetN(prhs[3]) != 1)
    {
      plhs[0] = mxCreateString("Exponent can only be a scalar.");
      return;
    }

    pX = (BIASINTERVAL *) mxCalloc(Xrows * Xcols, sizeof(BIASINTERVAL));
    BiasHullMR(pX, (double *) mxGetPr(prhs[1]), Xcols, Xrows);
    pN = (BIASINTERVAL *) mxGetPr(prhs[3]);

    plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
    pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

    for (count = 0; count < Xrows * Xcols; count++)
    {
      if (BiasInf(pX) <= 0)
      {
        plhs[0] = mxCreateString("Base interval must be > 0.");
        return;
      }
      BiasPowerI(pY++, pX++, pN);
    }
    pY -= count;

    return;
  }
  if ((Xclass == DouBLe  ) && (Nclass == DouBLe  ))
  {
    Xrows = mxGetM(prhs[0]);
    Xcols = mxGetN(prhs[0]);

    if (mxGetM(prhs[3]) != 1 || mxGetN(prhs[3]) != 1)
    {
      plhs[0] = mxCreateString("Exponent can only be a scalar.");
      return;
    }

    pX = (BIASINTERVAL *) mxCalloc(Xrows * Xcols, sizeof(BIASINTERVAL));
    pN = (BIASINTERVAL *) mxCalloc(1,             sizeof(BIASINTERVAL));

    BiasHullMR(pX, (double *) mxGetPr(prhs[1]), Xcols, Xrows);
    BiasHullR(pN, (double *) mxGetPr(prhs[3]));

    plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
    pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

    for (count = 0; count < Xrows * Xcols; count++)
    {
      if (BiasInf(pX) <= 0)
      {
        plhs[0] = mxCreateString("Base interval must be > 0.");
        return;
      }
      BiasPowerI(pY++, pX++, pN);
    }
    pY -= count;

    return;
  }

  mexErrMsgTxt("Unknown class or too few arguments."); return;

} /* mexFunction */
