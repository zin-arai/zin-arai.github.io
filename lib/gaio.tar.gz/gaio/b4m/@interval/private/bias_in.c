/*************************************************************************
 *  bias_in - in with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 26.1.1998
 *  Author(s): Jens Zemke
 ************************************************************************/

#include <mex.h>
#include "Bias2.h"
#include "types.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pA;
  BIASINTERVAL *pB;
  double *pa;
  double *info;
  unsigned int Arows, Acols, Brows, Bcols;
  int Aclass, Bclass;

  BiasInit();

  Aclass = (int) *mxGetPr(prhs[0]);
  Bclass = (int) *mxGetPr(prhs[2]);

  if ((Aclass == DouBLe) && (Bclass == INTerval))
  {

    Arows = mxGetM(prhs[1]);
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3])/2;
    Bcols = mxGetN(prhs[3]);

    if ((Arows != Brows) || (Acols != Bcols))
    {
      plhs[0] = mxCreateString("Matrix dimensions must agree.");
      return;
    }

    pa      =                  mxGetPr(prhs[1]);
    pB      = (BIASINTERVAL *) mxGetPr(prhs[3]);

    plhs[0] = mxCreateDoubleMatrix(1,         1,     mxREAL);
    info    =                  mxGetPr(plhs[0]);

    *info = (double) BiasInMR(pa, pB, Acols, Arows);

    return;
  }

  if ((Aclass == INTerval) && (Bclass == INTerval))
  {

    Arows = mxGetM(prhs[1])/2;
    Acols = mxGetN(prhs[1]);
    Brows = mxGetM(prhs[3])/2;
    Bcols = mxGetN(prhs[3]);

    if ((Arows != Brows) || (Acols != Bcols))
    {
      plhs[0] = mxCreateString("Matrix dimensions must agree.");
      return;
    }

    pA      = (BIASINTERVAL *) mxGetPr(prhs[1]);
    pB      = (BIASINTERVAL *) mxGetPr(prhs[3]);

    plhs[0] = mxCreateDoubleMatrix(1,         1,     mxREAL);
    info    =                  mxGetPr(plhs[0]);

    *info = (double) BiasInMI(pA, pB, Acols, Arows);

    return;
  }

  mexErrMsgTxt("Unknown class or too few arguments."); return;

} /* mexFunction */
