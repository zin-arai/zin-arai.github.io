/**********************************************************************
 *  bias_pred - pred with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 26.1.1998
 *  Author(s): Jens Zemke
 *********************************************************************/

#include <mex.h>
#include "Bias2.h"
#include "types.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pR;
  BIASINTERVAL *pA;
  double *pa;
  double *pr;
  double *info;
  unsigned int Arows, Acols;
  int Aclass;

  BiasInit();

  Aclass = (int) *mxGetPr(prhs[0]);

  if (Aclass == INTerval)
  {
    Arows = mxGetM(prhs[1])/2;
    Acols = mxGetN(prhs[1]);

    pA    = (BIASINTERVAL *) mxGetPr(prhs[1]);

    plhs[0] = mxCreateDoubleMatrix(1,         1,     mxREAL);
    plhs[1] = mxCreateDoubleMatrix(Arows * 2, Acols, mxREAL);
    info  =                  mxGetPr(plhs[0]);
    pR    = (BIASINTERVAL *) mxGetPr(plhs[1]);

    *info = (double) BiasPredMI(pR, pA, Acols, Arows);

    return;
  }

  if (Aclass == DouBLe)
  {
    Arows = mxGetM(prhs[1]);
    Acols = mxGetN(prhs[1]);

    pa    =                  mxGetPr(prhs[1]);

    plhs[0] = mxCreateDoubleMatrix(Arows, Acols, mxREAL);
    pr    =                  mxGetPr(plhs[0]);

    BiasPredMR(pr, pa, Acols, Arows);

    return;
  }

  mexErrMsgTxt("Unknown class or too few arguments."); return;

} /* mexFunction */
