/**********************************************************************
 *  types.h - header defining named constants (used in switches)
 *   -- types --  fast io version of Bias4Matlab ...
 *
 *  Date: 23.1.1998
 *  Version: 1.00
 *  Author(s): Jens Zemke
 *********************************************************************/

/*** define's ***/

#define DouBLe   1
#define INTerval 2

/*** end of types.h ***/
