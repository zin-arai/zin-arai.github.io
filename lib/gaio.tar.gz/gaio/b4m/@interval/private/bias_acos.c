/**********************************************************************
 *  bias_acos - acos with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 17.2.1998
 *  Author(s): Jens Zemke
 *********************************************************************/

#include <mex.h>
#include "BiasF.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pY;
  BIASINTERVAL *pX;
  unsigned int Xrows, Xcols;
  long count;

  BiasFuncInit();

  Xrows = mxGetM(prhs[0])/2;
  Xcols = mxGetN(prhs[0]);

  pX = (BIASINTERVAL *) mxGetPr(prhs[0]);

  plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
  pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

  for (count = 0; count < Xrows * Xcols; count++)
  {
    if (pX->inf < -1 || pX->sup > 1)
    {
      plhs[0] = mxCreateString("Return value is not a real number.");
      return;
    }
    BiasArcCos(pY++, pX++);
  }
  pY -= count;

  return;

} /* mexFunction */
