/***************************************************************************
 *  bias_root - n-th root with appropiate use of i/o MATLAB - BIAS - MATLAB
 *   -- interval --  PROFIL/BIAS storage (ultimate fast version)
 *
 *  Version: 1.00
 *  Date: 23.2.1998
 *  Author(s): Jens Zemke
 **************************************************************************/

#include <mex.h>
#include "BiasF.h"

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
  BIASINTERVAL *pY;
  BIASINTERVAL *pX;
  double *pointer_to_exponent;
  long n;
  unsigned int Xrows, Xcols;
  long count;

  BiasFuncInit();

  Xrows = mxGetM(prhs[0])/2;
  Xcols = mxGetN(prhs[0]);

  if (mxGetM(prhs[1]) != 1 || mxGetN(prhs[1]) != 1)
  {
    plhs[0] = mxCreateString("Exponent can only be a scalar.");
    return;
  }

  pointer_to_exponent = mxGetPr(prhs[1]);

  if (*pointer_to_exponent < 2)
  {
    plhs[0] = mxCreateString("Exponent must be >= 2.");
    return;
  }

  n = (long) *pointer_to_exponent;

  if (*pointer_to_exponent != n)
  {
    plhs[0] = mxCreateString("Exponent can only be of type integer.");
    return;
  }

  pX = (BIASINTERVAL *) mxGetPr(prhs[0]);

  plhs[0] = mxCreateDoubleMatrix(Xrows * 2, Xcols, mxREAL);
  pY = (BIASINTERVAL *) mxGetPr(plhs[0]);

  for (count = 0; count < Xrows * Xcols; count++)
  {
    if (BiasInf(pX) <= 0)
    {
      plhs[0] = mxCreateString("Argument must be > 0.");
      return;
    }
    BiasRoot(pY++, pX++, n);
  }
  pY -= count;

  return;

} /* mexFunction */
