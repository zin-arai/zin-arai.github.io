function r = subsref(a,s)

%SUBSREF (interval) implements subscripted reference for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'subsref' is called
%
%         r = subsref(a,s)
%
%     or (for instance)
%
%         r = a(i,j)
%
%     etc.
%
%     and implements the subscripted reference.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: subsasgn.
%     double: subsref.

% Last Revision: 26.5.1998 by Jens Zemke

vartmp = a;

while length(s) >= 1
   type = s(1).type;
   subs = s(1).subs;
   if strcmp(type, '()')
      lsubs = length(subs);
      if isa(vartmp, 'interval')
         dim = size(vartmp.val);
         if lsubs > 2
            error('Only scalars, vectors and matrices are supported.');
         end;
         if lsubs == 1
            tmp = subs{1};
            if strcmp(tmp, ':')
               vartmp.val = vartmp.val(tmp);
            else
               if dim(1)/2*dim(2) < tmp(end) | tmp(1) < 1
                  error('Index exceeds matrix dimensions.');
               end;
               ltmp = length(tmp);
               for k = 1:ltmp
                  i(2*k-1) = 2*tmp(k)-1;
                  i(2*k)   = 2*tmp(k);
               end;
               mattmp = vartmp.val(i);
               vartmp.val = reshape(mattmp,2,ltmp);
            end;
         else
            tmp = subs{1};
            if strcmp(tmp, ':')
               i = tmp;
            else
               if dim(1) < 2*tmp(end) | tmp(1) < 1
                  error('Index exceeds matrix dimensions.');
               end;
               for k = 1:length(tmp)
                  i(2*k-1) = 2*tmp(k)-1;
                  i(2*k)   = 2*tmp(k);
               end;
            end;
            j = subs{2};
            if strcmp(j, ':')
               ;               % nothing to do ..
            elseif dim(2) < j(end) | j(1) < 1
               error('Index exceeds matrix dimensions.');
            end;
            vartmp.val = vartmp.val(i,j);
         end
      elseif isa(vartmp, 'double')
         dim = size(vartmp);
         if lsubs == 1
            tmp = subs{1};
            if strcmp(tmp, ':')
               vartmp = vartmp(:);
            elseif prod(dim) < tmp(end) | tmp(1) < 1
               error('Index exceeds matrix dimensions.');
            else
               vartmp = vartmp(tmp);
            end;
         elseif lsubs == 2
            i = subs{1};
            j = subs{2};
            if strcmp(i, ':')
               if strcmp(j, ':')
                  ;              % nothing to do ...
               elseif dim(2) < j(end) | j(1) < 1
                  error('Index exceeds matrix dimensions.');
               else
                  vartmp = vartmp(:,j);
               end;
            elseif dim(1) < i(end) | i(1) < 1
               error('Index exceeds matrix dimensions.');
            else
               if strcmp(j, ':')
                  vartmp = vartmp(i,:);
               elseif dim(2) < j(end) | j(1) < 1
                  error('Index exceeds matrix dimensions.');
               else
                  vartmp = vartmp(i,j);
               end;
            end;
         else
            error('Only scalars, vectors and matrices are supported.');
         end
      end
   elseif strcmp(type, '.')
      if isa(vartmp, 'interval')
         if     strcmp(subs, 'mid')
            vartmp = mid(vartmp);
         elseif strcmp(subs, 'rad')
            vartmp = rad(vartmp);
         elseif strcmp(subs, 'inf')
            vartmp = inf(vartmp);
         elseif strcmp(subs, 'sup')
            vartmp = sup(vartmp);
         elseif strcmp(subs, 'diam')
            vartmp = diam(vartmp);
         else
            error(['Reference to non-existent field ''' subs '''.']);
         end
      else
         if     strcmp(subs, 'mid')
            vartmp = vartmp;
         elseif strcmp(subs, 'rad')
            vartmp = zeros(size(vartmp));
         elseif strcmp(subs, 'diam')
            vartmp = zeros(size(vartmp));
         else
            error(['Reference to non-existent field ''' subs '''.']);
         end
      end
   elseif strcmp(type, '{}')
     error('Cell contents reference from a non-cell array object.');
   end
   s = s(2:end);
end
r = vartmp;
