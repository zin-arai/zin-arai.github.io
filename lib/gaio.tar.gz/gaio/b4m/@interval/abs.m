function magnitude = abs(a)

%ABS (interval) computes the magnitude of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'abs' is called
%
%         magnitude = abs(x)
%
%     and computes the elementwise magnitude of
%     the interval matrix x.
%     The magnitude of an interval is defined as
%     mag(x) := max {abs(y) | y in x}.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: iabs.
%     double: abs.

magnitude = bias_abs(a.val);
