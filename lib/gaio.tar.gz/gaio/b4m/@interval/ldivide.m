function x = ldivide(a,b)

%LDIVIDE (interval) implements elementwise left divide for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.5.1998 Jens Zemke
%
%   DESCRIPTION:
%     'ldivide' is called
%
%         x = ldivide(a,b)
%
%     or
%
%         x = a.\b
%
%     and computes the elementwise left division
%     of a given matrix a by another matrix b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mldivide, rdivide.
%     double: ldivide.

sizea = size(a);
sizeb = size(b);

if max(sizea) == 1        % matrix through scalar => mrdivide
   x = b/a;
elseif max(sizeb) == 1    % scalar through matrix
   x = interval(zeros(sizea));
   for i = 1:sizea(1)
      for j = 1:sizea(2)
         s.type = '()';
         s.subs{1} = i;
         s.subs{2} = j;
         x = subsasgn(x,s,b/subsref(a,s));
      end;
   end;
elseif any(sizea-sizeb)
   error('Matrix dimensions must agree.');
else                     % a,b matrices with equal dimensions
   x = interval(zeros(sizea));
   for i = 1:sizea(1)
      for j = 1:sizea(2)
         s.type = '()';
         s.subs{1} = i;
         s.subs{2} = j;
         x = subsasgn(x,s,subsref(b,s)/subsref(a,s));
      end;
   end;
end
