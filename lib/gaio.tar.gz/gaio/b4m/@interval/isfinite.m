function info = isfinite(a)

%ISFINITE (interval) returns whether a given interval is finite.
%
%b4m - datatype interval    Version 1.02    (c) 22.10.1998 Jens Zemke
%
%   DESCRIPTION:
%     'isfinite' is called
%
%         info = isfinite(a)
%
%     and returns the value one if the interval
%     a contains no +/- Inf or NaN.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: isempty, isnan, isinf.
%     double: isfinite.

info = isfinite(inf(a)) & isfinite(sup(a));
