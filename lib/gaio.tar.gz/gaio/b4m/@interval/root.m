function y = root(x,k)

%ROOT (interval) computes the k-th root of an interval x.
%
%b4m - datatype interval    Version 1.02    (c) 3.9.1998 Jens Zemke
%
%   DESCRIPTION:
%     'root' is called
%
%         y = root(x,k)
%
%     and computes the componentwise k-th root
%     (k integer) of the interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: power, mpower, sqr, sqrt.
%     double: sqrt.

if prod(size(k))-1
   error('Exponent can only be scalar');
end;

if ~isa(k, 'double') | imag(k) | isa(k, 'sparse')
   error('Exponent must be real.');
end;

y.val = bias_root(x.val,k);
if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
