function y = sin(x)

%SIN (interval) implements sin for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'sin' is called
%
%         y = sin(x)
%
%     and computes the elementwise sine of
%     an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: cos, tan, cot, asin, sinh.
%     double: sin.

y.val = bias_sin(x.val);
y = class(y, 'interval');
