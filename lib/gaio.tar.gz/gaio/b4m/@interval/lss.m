function iv = lss(A,b)

%LSS (interval) is a (l)inear (s)ystem (s)olver (Rump).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'lss' is called
%
%         x = lss(A,b)
%
%     with a quadratic matrix A and a left side
%     vector b and generates with a Newton type
%     residual iteration an inclusion x of the
%     solution A^(-1) * b (Krawczyk Operator).
%
%     This algorithm is the implementation of
%     some ideas of S. M. Rump, including
%     the so called epsilon inflation.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mrdivide, mldivide.
%     double: lss.

dim = size(A);
if dim(1)-dim(2)
   error('Matrix must be square.');
end;

eps = interval(0.9,1.1);

[s,f] = warning;
warning on;

R = inv(mid(A));
xs = R * mid(b);
z = R * (b - interval(A) * xs);
x = z;
inflat = ones(size(x)) * interval(-realmin, realmin);
C = eye(size(A)) - R * interval(A);
k = 0;
done = 0;
while ~done & k < 15
   y = eps * x + inflat;
   x = z + C * y;
   done =  x < y;
   k = k + 1;
end
if done
   if (k==1)
      disp('Inclusion found in one step.');
   else
      disp(['Inclusion found after ' num2str(k) ' steps.']);
   end;
   iv = xs + x;
else
   warning('No inclusion found.');
   iv = interval([]);
end

warning(s);
warning(f);
