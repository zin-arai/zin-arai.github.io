function intersect = intersection(a,b)

%INTERSECTION (interval) computes (if possible) intersection of two intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'intersection' is called
%
%         intersect = intersection(a,b)
%
%     and computes (if possible) the intersection
%     of given interval matrices a, b.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: in, in0, in_interior.

global b4m_DouBLe b4m_INTerval

if isa(a, 'interval') & isa(b, 'interval')
   [info, intersect.val] = bias_intersection(b4m_INTerval, a.val, b4m_INTerval, b.val);

else
   error (['No intersection possible beetween ''' class(a) ''' and ''' class(b) '''.'])
end;

if isa(intersect.val, 'char')
   error(intersect.val);
elseif info
   intersect = class(intersect, 'interval');
else
   warning('No intersection can be computed, intervals do not intersect.');
   intersect = interval([]);
end
