function info = gt(a,b)

%GT (interval) implements (g)reater (t)han, b in interior of a (a>b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'gt' is called
%
%         info = a > b
%
%     or
%
%         info = gt(a,b)
%
%     and computes whether all components of
%     a include the appropiate components of b
%     in the interior.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: ge, le, lt, eq, ne, in, in_interior, in0.
%     double: gt.

global b4m_DouBLe b4m_INTerval

if     isa(b, 'double')
   info = bias_in_interior(b4m_DouBLe, b,       b4m_INTerval, a.val);
elseif isa(b, 'interval') & isa(a, 'interval')
   info = bias_in_interior(b4m_INTerval, b.val, b4m_INTerval, a.val);
elseif isa(a, 'double')
   info = 0;
else
   error('Class error.');
end

if isa(info, 'char')
   error(info);
end
