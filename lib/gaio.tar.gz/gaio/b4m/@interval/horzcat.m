function r = horzcat(a,b,varargin)

%HORZCAT (interval) horizontal concatenation for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 12.3.1998 Jens Zemke
%
%   DESCRIPTION:
%     'horzcat' is called
%
%         r = horzcat(a,b,...)
%
%     with interval matrices a, b, ... and
%     generates the interval matrix
%     r = [a b ...].
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: vertcat.
%     double: horzcat.

%  right now vertcat seems to call horzcat with one argument ...

str1 = 'All matrices on a row in the bracketed expression must have the';
str2 = [char(10) 'same number of rows.'];

if nargin == 1
   r = a;
else

% no typecheck has to be performed, because matlab calls implicitly
% the constructor interval.m to obtain intervals for double arguments

   dima = size(a);
   dimb = size(b);
   if dima(1)>0 & dimb(1)>0
      if dima(1)-dimb(1) error([str1 str2]); end;
   end;
   r.val = [a.val b.val];
   r = class(r, 'interval');
   for i = 1:nargin - 2
      b = varargin{i};
      dimb = size(b);
      if dima(1)>0 & dimb(1)>0
         if dima(1)-dimb(1) error([str1 str2]); end;
      end;
      r.val = [r.val b.val];
   end;
end
