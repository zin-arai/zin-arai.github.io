function y = cos(x)

%COS (interval) implements cos for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'cos' is called
%
%         y = cos(x)
%
%     and computes the elementwise cosine
%     of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: sin, tan, cot, acos, cosh.
%     double: cos.

y.val = bias_cos(x.val);
y = class(y, 'interval');
