function int = interval(x,y)

%INTERVAL class constructor for the class interval.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'interval' is called
%
%         int = interval(x,y)
%     or
%
%         int = interval(x)
%
%     with double (real) matrices x and y
%     with equal dimensions, and generates the
%     interval matrix int with inf(int) = x
%     and sup(int) = y (resp. x).
%
%     Calling interval(x) equals calling
%     interval(x,x).
%
%     When called with two values x, y
%     the dimensions, the type and x <= y
%     elementwise are checked.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: display.
%     double: double.

superiorto('double');

%  A lot of the M-files in b4m need two makros defining
%  b4m_INTerval and b4m_DouBLe

global b4m_DouBLe b4m_INTerval
b4m_DouBLe = 1;
b4m_INTerval = 2;

%  if no arguments are given, interval.m generates an explicit error.

if nargin == 0
   error('No input arguments given to constructor interval.');

%  if exactly one argument is given, there are three possibilities
%
%  - the argument is an interval -> it is only returned.
%
%  - the argument is a struct looking like an interval
%    -> why not make it an interval ?
%    Remark: This is used for functions like div/add/sub/mul etc.
%    which take input of type non interval and generate output of
%    type interval, because it is not possible to say
%    x = class(x, 'interval') outside this directory.
%
%  - the argument is of type double, non complex and non sparse
%    -> the degenerate interval [x,x] is returned.

elseif nargin == 1

%  it is an interval
%  -> return it

   if isa(x, 'interval')
      int = x;

%  it is a struct of appropiate type
%  The number of fields is checked, the fieldname is checked,
%  the type has to be double, non complex, non sparse
%  and the condition upper bound >= lower bound is checked.

   elseif isa(x, 'struct')
      if length(fieldnames(x)) > 1
         error('Struct has more than one field.');
      elseif ~isfield(x, 'val');
         error('Wrong fieldname for class interval.');
      end;
      if ~isa(x.val, 'double')
         error('The bounds of an interval can only be of type double.');
      elseif imag(x.val)
         error('Complex intervals are not supported.');
      elseif issparse(x.val)
         error('Sparse intervals are not supported.');
      end;
      dim = size(x.val);
      if mod(dim(1),2)
         error('Struct has the wrong size for an interval.');
      else
         for i = 1:2:dim(1)-1
            if any(x.val(i,:)>x.val(i+1,:))
               error('Upper bound must be greater than lower bound.');
            end;
         end;
      end;
      int = class(x, 'interval');

%  it is of type double, non complex, non sparse ??
%  -> check these conditions and generate the interval.

   else
      if ~isa(x, 'double')
         error('The bounds of an interval can only be of type double.');
      elseif imag(x)
         error('Complex intervals are not supported.');
      elseif issparse(x)
         error('Sparse intervals are not supported.');
      end;
      dim = size(x);
      if length(dim) > 2
         error('Only scalars, vectors and matrices are supported.');
      end;
      int.val = zeros(dim(1)*2, dim(2));
      index = logical(mod(1:dim(1)*2,2));
      int.val(index,:) = x;
      int.val(~index,:) = x;
      int = class(int, 'interval');
   end;

%  if nargin == 2 -> two inputs
%  There is only one possibility, both inputs have to be
%  of type double, non complex, non sparse.
%  The dimensions and y > x have to be checked.

else
   if ~isa(x, 'double')
      error('The lower bound of an interval can only be of type double.');
   elseif imag(x)
      error('Complex intervals are not supported.');
   elseif issparse(x)
      error('Sparse intervals are not supported.');
   end;
   if ~isa(y, 'double')
      error('The upper bound of an interval can only be of type double.');
   elseif imag(y)
      error('Complex intervals are not supported.');
   elseif issparse(y)
      error('Sparse intervals are not supported.');
   end;
   dimx = size(x);
   dimy = size(y);
   if length(dimx) > 2 | length(dimy) > 2
      error('Only scalars, vectors and matrices are supported.');
   end;
   if (any(dimx - dimy))
      error('Upper and lower bound must have the same size.');
   end;
   if any(any(x>y))
      error('Upper bound must be greater than lower bound.');
   end;
   int.val = zeros(dimx(1)*2, dimx(2));
   index = logical(mod(1:dimx(1)*2,2));
   int.val(index,:) = x;
   int.val(~index,:) = y;
   int = class(int, 'interval');
end
