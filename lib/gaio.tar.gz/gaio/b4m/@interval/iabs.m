function y = iabs(x)

%IABS (interval) computes the interval matrix of the absolute values.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'iabs' is called
%
%         y = iabs(x)
%
%     and computes the interval of all absolute
%     values, iabs is defined as
%     iabs(x) := {abs(y) | y in x}.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: abs.
%     double: abs.

y.val = bias_iabs(x.val);
y = class(y, 'interval');
