function info = le(a,b)

%LE (interval) implements (l)ess (e)qual, a in b (a<=b).
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'le' is called
%
%         info = a <= b
%
%     or
%
%         info = le(a,b)
%
%     and computes whether all components of
%     b include the appropiate components of a.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: lt, eq, ge, gt, ne.
%     double: lt.

global b4m_DouBLe b4m_INTerval

if     isa(a, 'double')
   info = bias_in(b4m_DouBLe, a,       b4m_INTerval, b.val);
elseif isa(a, 'interval') & isa(b, 'interval')
   info = bias_in(b4m_INTerval, a.val, b4m_INTerval, b.val);
elseif isa(b, 'double')
   b = interval(b);
   info = bias_in(b4m_INTerval, a.val, b4m_INTerval, b.val);
else
   error('Class error.');
end;

if isa(info, 'char')
   error(info);
end
