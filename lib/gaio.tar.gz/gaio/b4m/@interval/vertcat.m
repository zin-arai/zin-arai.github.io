function r = vertcat(a,b,varargin)

%VERTCAT (interval) vertical concatenation for interval matrices.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'vertcat' is called
%
%         r = vertcat(a,b,...)
%
%     with interval matrices a, b, ... and
%     generates the interval matrix
%
%           [a]
%           [b]
%       r = [.]
%           [.]
%           [.].
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: horzcat.
%     double: vertcat.

%  right now horzcat seems to call vertcat with one argument ...

str1 = 'All matrices on a row in the bracketed expression must have the';
str2 = [char(10) 'same number of columns.'];

if nargin == 1
   r = a;
else

% no typecheck has to be performed, because matlab calls implicitly
% the constructor interval.m to obtain intervals for double arguments

   dima = size(a);
   dimb = size(b);
   if dima(1)>0 & dimb(1)>0
      if dima(2)-dimb(2) error([str1 str2]); end;
   end;
   r.val = [a.val;b.val];
   r = class(r, 'interval');
   for i = 1:nargin - 2
      b = varargin{i};
      dimb = size(b);
      if dima(1)>0 & dimb(1)>0
         if dima(2)-dimb(2) error([str1 str2]); end;
      end;
      r.val = [r.val;b.val];
   end;
end
