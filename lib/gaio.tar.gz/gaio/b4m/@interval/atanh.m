function y = atanh(x)

%ATANH (interval) implements atanh for intervals.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'atanh' is called
%
%         y = atanh(x)
%
%     and computes the elementwise inverse
%     hyperbolic tangent of an interval matrix x.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: tanh, asinh, acosh, acoth, atan.
%     double: atanh.

y.val = bias_atanh(x.val);

%  bias_atanh can only return an error (as character string)
%  or the right value (as field of double)

if isa(y.val, 'char')
   error(y.val);
else
   y = class(y, 'interval');
end
