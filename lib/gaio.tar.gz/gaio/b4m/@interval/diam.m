function diameter = diam(a)

%DIAM (interval) computes the diameter of an interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'diam' is called
%
%         diameter = diam(a)
%
%     and computes the elementwise diameter
%     of a given interval matrix a.
%     The diameter of an interval is defined as
%     diam(a) := sup(a) - inf(a).
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: mid, rad, midrad.
%     double: diam.

diameter = bias_diam(a.val);
