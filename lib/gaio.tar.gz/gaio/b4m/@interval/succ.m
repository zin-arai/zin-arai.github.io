function successor = succ(a)

%SUCC (interval) computes the successor of a given interval matrix.
%
%b4m - datatype interval    Version 1.02    (c) 26.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'succ' is called
%
%         successor = succ(a)
%
%     and computes the successor of a given
%     interval matrix a.
%     The successor is defined as
%     succ := min {diam(y) | y > a}.
%
%     The operations on the datatype interval
%     are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     interval: pred.
%     double: succ.

global b4m_DouBLe b4m_INTerval

successor.val = bias_succ(b4m_INTerval, a.val);
successor = class(successor, 'interval');
