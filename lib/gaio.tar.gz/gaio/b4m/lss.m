function v = lss(A,b)
%LSS is a (l)inear (s)ystem (s)olver (Rump).
%
%INTERVAL datatype Version 1.02   (c) 25.2.1998 Jens Zemke
%
%   DESCRIPTION:
%     'lss' is called
%
%         x = lss(A,b)
%
%     with a real/interval matrix A and a real/interval
%     vector b. The solution is computed via a Newton-type
%     residual iteration (Krawczyk Operator).
%
%     This algorithm is the implementation of
%     some ideas of S. M. Rump, including
%     the so called epsilon inflation.
%
%     The arithmetic operations on the datatype
%     interval are based on BIAS by Olaf Knueppel.
%
%   SEE ALSO:
%     double: mldivide.

eps = interval(0.9,1.1);
inflat = interval(-realmin, realmin);

R = inv(A);
xs = R * b;
z = R * (b - interval(A) * xs);
x = z;
C = eye(size(A)) - R * interval(A);
k = 0;
done = 0;
while ~done & k < 15
   y = eps * x + ones(size(x)) * inflat;
   x = z + C * y;
   done =  x < y;
   k = k + 1;
end
if done
   if (k==1)
      disp('Inclusion found in one step.');
   else
      disp(['Inclusion found after ' num2str(k) ' steps.']);
   end;
   v = xs + x;
else
   error('No inclusion found.');
end
