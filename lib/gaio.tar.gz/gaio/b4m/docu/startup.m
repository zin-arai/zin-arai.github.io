%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%   add paths to include all which is wanted ...
%

  p = '/usr/local/matlab/toolbox';                    addpath(p);
  p = '/usr/local/matlab/toolbox/b4m';                addpath(p);

  clear all

  global b4m_DouBLe b4m_INTerval
  global b4m_NaTiVe
