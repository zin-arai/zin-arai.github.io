
#ifndef _lapack_h
#define _lapack_h

int dgeqrf_(int *m, int *n, double *a, int *lda, double *tau, double *work, 
	    int *lwork, int *info);
int dormqr_(char *side, char *trans, int *m, int *n, int *k, double *a, 
	    int *lda, double *tau, double *c__, int *ldc, double *work, 
	    int *lwork, int *info);
int dtrtrs_(char *uplo, char *trans, char *diag, int *n, int *nrhs, 
	    double *a, int *lda, double *b, int *ldb, int *info);
int dgetrf_(int *m, int *n, double *a, int *
	lda, int *ipiv, int *info);
int dgetrs_(char *trans, int *n, int *nrhs, 
	double *a, int *lda, int *ipiv, double *b, int *
	ldb, int *info);
int dsyevd_(char *jobz, char *uplo, int *n, double *
	a, int *lda, double *w, double *work, int *lwork, 
	int *iwork, int *liwork, int *info);
int dgeev_(char *jobvl, char *jobvr, int *n, double *
	a, int *lda, double *wr, double *wi, double *vl, 
	int *ldvl, double *vr, int *ldvr, double *work, 
	int *lwork, int *info);
 int dgesvd_(char *jobu, char *jobvt, int *m, int *n, 
	double *a, int *lda, double *s, double *u, int *
	ldu, double *vt, int *ldvt, double *work, int *lwork, 
	int *info);
int dorgqr_(int *m, int *n, int *k, double *
	a, int *lda, double *tau, double *work, int *lwork, 
	int *info);
 
#endif
