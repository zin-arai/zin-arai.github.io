/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * Points.h
 *
 */

#ifndef _Points_h
#define _Points_h

#include <gaio/defs.h>
#include <gaio/Integrator.h>

typedef struct _Points Points;

struct _Points {
   
  char *name;                  /* name indicating the type of the points */
  void *handle;                /* filehandle for points */
  char filename[256];          /* file containing testpoints */
  int dim;                     /* dimension of phase space */
  int length;                  /* length of point (i.e. number of "subpoints"
				  per point), mostly == 1 */
  int noOfPoints;              /* number of points */
  char *info;                  /* name of eventual data file */
  double *c;                   /* center of box */
  double *r;                   /* radius of box */

  int (*Init)(int dim, char *no);
  int (*Fini)(void);

  /* compute points */
  void (*Set)(Points *points, Integrator *intgr, double *c, 
	      double *r, double *R);     

  /* get the i'th point for the box B(c,r) in x */
  void (*Get)(Points *points, int i, double *x); 

};

Points *PointsNew(char *name, int dim, char *info);
Points *PointsFree(Points **points);

/* get all points into matrix X */
void PointsGet(Points *points, double *X);

void PointsInfo(FILE *out, Points *points);

void PointsSave(FILE *out, Points *points);
Points *PointsLoad(FILE *in);

#endif
