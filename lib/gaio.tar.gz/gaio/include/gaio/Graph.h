/*
 * Copyright (c) 1998,99 Oliver Junge, for details see COPYING
 * 
 * Graph.h  -- C bindings for the graph class in LEDA
 *
 */

#ifndef _graph_h
#define _graph_h

#ifdef __cplusplus
__asm__(".symver fnmatch,fnmatch@VERS_2.0");
#include <LEDA/graph.h>
#include <LEDA/graph_alg.h>
#include <LEDA/graph_misc.h>
#define idgraph GRAPH<int,double>
extern "C" {
#endif
#include <gaio/Matrix.h>
#include <gaio/SparseMatrix.h>
#include <gaio/Vec.h>

  typedef struct { int dummy; } GraphNode;
  typedef struct { int dummy; } GraphEdge;
  typedef struct {
    void *g;
    GraphNode **nodes;
    int no_of_nodes;
  } Graph;

  Graph *GraphNew();
  void GraphFree(Graph **G);

  void GraphInfo(FILE *out, Graph *graph);

  int GraphNumberOfNodes(Graph *G);

  GraphNode *GraphNewNode(Graph *G, int inf);
  void GraphNewEdge(Graph *G, GraphNode *n, GraphNode *m, double inf);

  void GraphDeleteNode(Graph *g, int i);

  Graph *TransitionGraph(SparseMatrix *A);
  Graph *TransitionGraphFromPtr(int n, int nz, int *ir, int *jc, double *pr);

  void StrongComponents(Graph *G, double *scc);
  void MaximalInvariantSet(Graph *G, double *mis);
  int *ShortestPath(Graph *G, int s, int t, int *length);
  int MinCut(Graph *G, double *node_no);

#ifdef __cplusplus
}
#endif


#endif
