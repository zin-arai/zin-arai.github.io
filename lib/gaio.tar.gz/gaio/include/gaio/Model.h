/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * Model.h
 *
 */

#ifndef _Model_h
#define _Model_h

#include <gaio/defs.h>

typedef struct {

  char *name;              /* name of Model */
  void *handle;            /* filehandle for model */
  char filename[256];      /* name of object file */
  char *typ;               /* type of rhs, "map" or "ode" */
  int* dim;                /* dimension of phase space */
  int* uDim;               /* dimension of control/perturbation space */
  int uDimDummy;           /* used if uDim is not defined in model */
  unsigned int paramDim;   /* number of parameters */
  char **paramNames;       /* names of parameters */
  double **param;          /* pointer to the parameters */
  double *c, *r;           /* center and radius of outer box */
  double tFinal;           /* integration time */

  VecFunc rhs;             /* right hand side, i.e. mapping or vector field or ..*/
  VecFunc drhs;            /* derivative of rhs */
  VecFunc lip;             /* lipschitz estimate for right hand side,
                              lip is returning a matrix L such that
			      |rhs(x) - rhs(y)| \le L |x-y| (componentwise) 
			      for all x,y in a box B(c,r) */
  ConstFunc fixed_point;   /* computes a fixed point of rhs, i.e. a fixed
			      point or a zero or ... */
  VecFunc lhs;             /* left hand side matrix of DAE */
  CostFunc cost;           /* cost function for optimal control problems */

} Model;

/* tries to load model "name" */
Model *ModelNew(char *name);    

/* frees (unloads) a model and sets *model=0 */
Model *ModelFree(Model **model);                 

/* prints some information about the model */
void ModelInfo(FILE *out, Model *model);

/* saves the model to the stream out */
void ModelSave(FILE *out, Model *model);

/* loads a model from stream in */
Model *ModelLoad(FILE *in);

#endif
