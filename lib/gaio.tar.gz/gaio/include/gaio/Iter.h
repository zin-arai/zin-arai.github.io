/*
 * Copyright (c) 1998,99 Oliver Junge, for details see COPYING
 * 
 * Iter.h   
 *
 */

#ifndef _Iter_h
#define _Iter_h

#include <gaio/defs.h>
#include <gaio/Tree.h>
#include <gaio/Points.h>
#include <gaio/Integrator.h>

typedef struct {

  Tree *tree;                 /* tree of boxes */
  Tree *searchTree;           /* copy of tree for searching */
  Integrator *integrator;     /* the dynamical system */
  Points *domPoints;          /* testpoints */
  Points *imgPoints;          /* image points */
  Points *uPoints;            /* control/perturbation points */
  int verbose;                /* output debug information, if == 1 */

} Iter;

/* creates and returns a new iter structure */
Iter *IterNew(Rectangle *Q);

/* deletes **iter and set *iter=0 */
void IterFree(Iter **iter);

/* returns, after the first imgPoint is found in iter->tree and
   sets the HIT flag of the current box */
int IterHitThis(Iter *iter, double *y, double *r, int depth); 

/* for all imgPoints p\in B(y,r): if p\in B, then set the HIT flag of B */
void IterHitAll(Iter *iter, double *y, double *r, int depth); 

/* sames as IterHit, but the boxes in question are inserted if
   necessary, returns 1, if some box has been inserted, 0, if not,
   inserted boxes get the flag 'flag'*/
int  IterInsert(Iter *iter, double *y, int length, double *r, int depth,
		byte flag0, byte flag1);

/* for all boxes: maps domPoints on depth 'depth', calling IterHitThis
   for their images, until some imgPoint is found in the tree */
void IterMap(Iter *iter, int depth); 

/* maps all domPoints in all boxes on depth 'depth', calling IterHit
   for their images */
void IterMapAll(Iter *iter, int depth); 

/* maps the domPoints in all boxes on depth 'from_depth' which have their
   EXPAND flag set, calling IterInsert(..., to_depth) for their
   images; returns 1, if some box has been inserted, 0 otherwise.
   if mode==0, then only the endpoint of each orbit is inserted,
   if mode!=0, then the whole orbit, inserted boxes get the flag
   'flag', found boxes the flag 'flag1' */
int  IterExpand(Iter *iter, int from_depth, int to_depth, int mode,
		byte flag0, byte flag1);

/* prints some information about the iter structure */
void IterInfo(FILE *out, Iter *iter);

/* saves the iter structure including the tree ti file out */
void IterSave(FILE *out, Iter *iter);

/* loads an iter structure including the tree from file in */
Iter *IterLoad(FILE *in); 

#endif
