/*
 * Copyright (c) 2000 Oliver Junge, for details see COPYING
 * 
 * Orbit.h
 *
 */


#ifndef _Orbit_h
#define _Orbit_h

#include <gaio/Box.h>

#ifdef __cplusplus
extern "C" {
#endif

int ComputeLinks(Iter *iter, int depth);

SparseMatrix *LinksToMatrix(Tree *tree, int depth);

void PrintLinks(Tree *tree, int depth);

int Connect(Box *src, Box *dest);

/* void ProjectLinks(Box *box); */
/* void IdentifyOrbit(Tree *tree, Box *src, Box *dest, int depth); */

#ifdef __cplusplus
}
#endif

#endif
