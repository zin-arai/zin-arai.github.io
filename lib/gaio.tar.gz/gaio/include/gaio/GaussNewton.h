/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * GaussNewton.h
 *
 */

#ifndef _GaussNewton_h
#define _GaussNewton_h

#include <gaio/defs.h>
#include <gaio/LinearAlgebra.h>

#include <gaio/lapack.h>

typedef struct _GaussNewton GaussNewton;

struct _GaussNewton {
  
  int n, m;           /* dimensions of the problem, i.e the objective
		         function f is a mapping from R^n to R^m */
  double h_NumDf;     /* relative increment for numerical differentiation
			 of objective function f */
  double h;           /* stepwidth (for damped GaussNewton) */
  double eps;         /* tolerance for finding solution */
  double iter_max;    /* maximal number of iterations */

  VecFunc f;          /* objective function */
  VecFunc Df;         /* its derivative */

  double *fx, *Dfx;

  int lwork, k;
  double *work, *tau;
  
};

GaussNewton *GaussNewtonNew(int m, int n, VecFunc f, VecFunc Df);
void GaussNewtonFree(GaussNewton **newton);

/* performs one GaussNewton step N(x) = x - h*Df^+(x)*f(x) */
void GaussNewtonStep(GaussNewton *newton, double *x, double *u, double *Nx);

int GaussNewtonSolve(GaussNewton *newton, double *x_0, double *u, double *x);

void GaussNewtonInfo(FILE *out, GaussNewton *newton);

#endif
