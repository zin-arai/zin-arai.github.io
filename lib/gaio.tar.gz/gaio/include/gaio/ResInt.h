/*
 * Copyright (c) 2000 Oliver Schuetze, for details see COPYING
 * 
 * ResInt.h
 * 
 */

#ifndef _ResInt_h
#define _ResInt_h


extern "C" { 
#include <stdio.h>
#include <iostream.h>
#include <complex.h>
#include <math.h>
#include <stdlib.h>

#include <gaio/defs.h>
#include <gaio/Tree.h>
#include <gaio/Iter.h>
#include <gaio/Integrator.h>
#include <gaio/defs.h>

struct Complex {  /* fuer Nag-zgetrf()-Aufruf */
  double re;
  double im;
};  

double ResIntRomberg (Iter *iter,complex<double> a, complex<double> b,
              complex<double> f(Iter *iter, complex<double>, int *zuklein),
	      double tol);
double ResIntBoxInt (Iter *iter, 
       complex<double> f(Iter *,complex<double>, int *zuklein),
       double tol, double *edge);
complex<double> ResIntF (Iter *, complex<double>, int *zuklein);
complex<double> ResIntNumF (Iter *, complex<double>, int *zuklein);
int ResIntSubdivide (Iter *iter, int ADAPTIVE);
void ResIntNumSubdivide (Iter *iter);
void ResIntAdaInit (void);
int ResIntAdaNumberofRoots (void);
int ResIntAdaGetRoots (double *r_re, double *r_im);
int ResIntAdaSubdivide (Iter *iter, int SEARCH, Points *domPoints);
int ResIntNewtonIter (Iter *iter, complex<double> z, complex<double> *root);
int ResIntNewtonStep (Iter *iter, complex<double> z, complex<double> *nfz);
int Vromberg (Iter *iter, 
    complex<double> fkt(Iter *, complex<double>, int *zuklein),
    complex<double> x, complex<double> y, double tol, int k,
    double *Integral, int *F_Auswertungen, double *Fehlerschaetzer,
    double *I_skal, int *k1, int *behaltebox);
int Vadapr (Iter *iter, 
    complex<double> fkt(Iter *, complex<double>, int *zuklein), 
    complex<double> a, complex<double> b, double tol, 
    double *Integral, int *F_auswertungen, int *behaltebox);
void ResIntSetParameter (int ada, double to);
int is_in_box (complex<double> z, double *c, double *r);
complex<double> ResIntObjF (Iter *iter, complex<double> z);
int ResIntGetEigenVectors (double *roots, int rowk, int colk,
              int noOfRoots, double T, char *file_in, char *file_out);
int get_0_eigenvector (complex<double> **A, int n, complex<double> *v);
void mat_prod (complex<double> **M, complex<double> *v, int dim);
void zgeev_ (char *jobvl, char *jobvr, int *N, Complex *MTEMP, int *N,
      Complex *EW, Complex *VL, int *ldvl, Complex *VR, int *ldvr,
      Complex *WORK, int *lwork, double *RWORK, int *info); 
}  
				      
#endif
