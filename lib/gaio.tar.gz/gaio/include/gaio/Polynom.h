/*
 * Copyright (c) 2000 Oliver Junge, Bianca Thiere, for details see COPYING
 * 
 * Polynom.h
 * 
 */

#ifndef _Polynom_h
#define _Polynom_h

typedef struct {

  int dim;            /* dimension of the model */
  int deg;            /* degree of the polynom  */
  double *x;          /* coefficients of the polynom */
  double *coeff;     /* coefficients of the polynom */

} Polynom;

Polynom *PolynomNew(int dim, int deg);

void PolynomFree(Polynom **p);
void PolynomEval(Polynom *p, double x, double *fx);
void PolynomInterp(Polynom *p, double *x, double *f);

#endif
