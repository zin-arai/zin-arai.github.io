/*
 * Copyright (c) 2000 Oliver Schuetze, for details see COPYING
 * 
 * Roots.h
 *
 */
#include <gaio/defs.h>
#include <gaio/Iter.h>

#define R_ACCUR 0.00000001
#define ACCUR 0.00000001
#define NEWTON_MAXITER 100

int RootSearch (Iter *iter, Points *domPoints, double **roots, int *fail);
int conv (Iter *iter, double *x, int *fail);
int is_in (double *c, double *r, double *x, int dim);
int isolated (Iter *iter, int depth);
int quasi_isolated (Iter *iter, int depth) ;

