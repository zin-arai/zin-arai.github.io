#ifndef _arpack_h
#define _arpack_h

  void dnaupd_(int *ido, char *bmat, int *n, char *which,
                       int *nev, double *tol, double *resid,
                       int *ncv, double *V, int *ldv,
                       int *iparam, int *ipntr, double *workd,
                       double *workl, int *lworkl, int *info);

  void dneupd_(int *rvec, char *HowMny, int *select,
                       double *dr, double *di, double *Z,
                       int *ldz, double *sigmar,
                       double *sigmai, double *workev,
                       char *bmat, int *n, char *which,
                       int *nev, double *tol, double *resid,
                       int *ncv, double *V, int *ldv,
                       int *iparam, int *ipntr,
                       double *workd, double *workl,
                       int *lworkl, int *info);


#endif
