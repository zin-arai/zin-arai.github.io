/*
 * Copyright (c) 1998,99 Oliver Junge, for details see COPYING
 * 
 * Measure.h   
 *
 */

#ifndef _Measure_h
#define _Measure_h

#include <gaio/defs.h>
#include <gaio/Tree.h>
#include <gaio/Points.h>
#include <gaio/Matrix.h>
#include <gaio/SparseMatrix.h>

/* computes the transition matrix on depth 'depth' by the exhaustion
   method, subdividing at most sd_max times */
SparseMatrix *ExhaustionMatrix(Iter *iter, int depth, int sd_max);
/* computes the transition matrix on depth 'depth', using 'points' */
SparseMatrix *MonteCarloMatrix(Iter *iter, int depth, Points *points);

/* returning a histogramm (vector) of the orbit x on depth 'depth' */
Matrix *Histogram(Iter *iter, double *x, int length, int depth);


/* computes the density of the measure m on depth 'depth'*/
Matrix *Density(Iter *iter, Matrix *m, int depth);
/* computes the max-norm of the (discrete) gradient of h on depth 'depth'*/
Matrix *DensityMaxGrad(Iter *iter, Matrix *h, int depth);
/* computes the local error between the density h on depth 'depth'
   and the density g ond depth 'depth+1' */
Matrix *DensityError(Iter *iter, Matrix *h, Matrix *g, int depth);


/* compute the transition probabilities and store them to the tree */
int ComputeImages(Iter *iter, int depth);
/* build a transition matrix out of the transition probabilities stored
   within the tree */
SparseMatrix *ImagesToMatrix(Tree *tree, int depth);
/* deletes certain images: 1. the img of a box with flags[box->no]='1'
   and 2. the img of a box for which there is a k such that 
   flags[box->img->row[k]]='1', i.e. all images which must be recomputed
   if some boxes are subdivided */
int DeleteImages(Tree *tree, byte *flags, int depth, double *deleted);

#endif
