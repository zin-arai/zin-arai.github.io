/*
 * Copyright (c) 2003 djs2 GmbH
 * 
 * cplx.h
 * 
 */

#ifndef _cplx_h
#define _cplx_h

#ifdef HPUX
#include <iostream/iostream.h>
#include <complex>
#define cplx complex<double>
#define new_cplx cplx
#define cplx_abs abs
#endif

#ifdef __GNUC__
#include <iostream.h>
#include <complex.h>
#define cplx complex<double>
#define new_cplx cplx
#define cplx_abs abs
#endif

#ifdef __LCC__
#include <complex.h>
#define cplx double _Complex
cplx new_cplx(double re, double im) { cplx a; a.re = re; a.im = im; return a; }
#define real creal
#define imag cimag
#define cplx_abs cabs
#endif

#ifdef __VC7__
#include <complex>
using namespace std;
#define cplx complex<double>
#define new_cplx cplx
#define cplx_abs abs
#endif

#endif
