/*
 * Copyright (c) 2001 Oliver Junge, for details see COPYING
 * 
 * Finder.h
 * 
 */

#ifndef _Finder_h
#define _Finder_h

#include <gaio/defs.h>
#include <gaio/Vec.h>
#include <gaio/Tree.h>
#include <gaio/Integrator.h>

#ifdef __cplusplus
extern "C" {
#endif

  double Finder(Tree *tree, int depth, Integrator *intgr, double t_start,
		double *x, double *fx); 

#ifdef __cplusplus
}
#endif


#endif

