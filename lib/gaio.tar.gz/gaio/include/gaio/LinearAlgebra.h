/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * LinearAlgebra.h
 * 
 */

#ifndef _LinearAlgebra_h
#define _LinearAlgebra_h

#include <gaio/defs.h>
#include <gaio/Matrix.h>
#include <gaio/SparseMatrix.h>

/* compute nev eigenpairs of type 'which' \in {"LM", "LX", ...}
 of the sparse matrix A, returns the number of computed eigenpairs */
int ARPACK(SparseMatrix *A, int nev, char *which, double **dr, double **di, 
	   double **w);


/* LU solver class */
typedef struct {

  int inPlace;
  Matrix *AUser, *A;
  int m, n, lda;
  int *ipiv;

} LU;

LU *LUNew(int inPlace);

void LUFree(LU **Solver);

/* computes an LU factorization of the current matrix, returns 0 if successful
   and > 0, if the resultung upper triangular matrix is singular */
int LUDecompose(LU *Solver);

int LUSolve(LU *Solver, double *x, double *b);

void LUSet(LU *Solver, Matrix *A);

/* computes eigenvalues w and eigenvectors A of a (full) symmetric matrix A */
int SymEig(unsigned int dim, double *A, double *w);
int Eig(unsigned int dim, double *A, double *wr, double *wi, double *v);

/* computes the singular value decomposition of A, i.e. matrices U ad VT
   and a vector S such that A = U*diag(S)*VT' */
int SVD(Matrix *A, Matrix **U, Matrix **S, Matrix **VT);
/* computes the QR decomposition of the matrix A */
int QR(Matrix *A, Matrix **Q, Matrix **R);


#endif
