/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * Normals.h   
 *
 */

#ifdef _NORMALS_

#ifndef _Normals_h
#define _Normals_h

#include <gaio/defs.h>
#include <gaio/Iter.h>

typedef struct {
  
  double xl[MAXDIM], xu[MAXDIM];
  int count; 
  double mean[MAXDIM];
  double *P, *A;

} CalcNormal;

void IterNormals(Iter *iter, int depth, double *R);

void IterNormalAT(Box *box, unsigned int dim, CalcNormal *C, 
		  double *xl, double *xu, int d, int depth);

#endif

#endif
