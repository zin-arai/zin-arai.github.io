/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * Newton.h
 *
 */

#ifndef _Newton_h
#define _Newton_h

#include <gaio/defs.h>
#include <gaio/LinearAlgebra.h>

typedef struct _Newton Newton;

struct _Newton {
  
  int dim;            /* dimension of the problem */
  double h_NumDf;     /* relative increment for numerical differentiation of objective function f */
  double h;           /* stepwidth (for damped Newton) */
  double eps;         /* tolerance for finding solution */
  double iter_max;    /* maximal number of iterations */

  VecFunc f;          /* objective function */
  VecFunc Df;         /* its derivative */

  double *fx, *Dfx, *tmp;
  LU *lu;

};

Newton *NewtonNew(int dim, VecFunc f, VecFunc Df);
void NewtonFree(Newton **newton);

/* performs one Newton step N(x) = x - h*Df^-1(x)*f(x) */
void NewtonStep(Newton *newton, double *x, double *u, double *Nx);

/* computes a zero f(x)=0 in the vincinity of x0 */
int NewtonSolve(Newton *newton, double *x0, double *u, double *x);

void NewtonInfo(FILE *out, Newton *newton);

#endif
