/*
 * Copyright (c) 1998,99 Oliver Junge, for details see COPYING
 * 
 * Integrator.h
 * 
 */

#ifndef _Integrator_h
#define _Integrator_h

#define MAX_ORDER 8
#define NO_OF_TMPS 6
#define ORBIT_LENGTH 100

#define RHS(intgr, x, u, fx) intgr->task->f(intgr->task, x, u, fx);

#include <gaio/defs.h>
#include <gaio/Vec.h>
#include <gaio/Task.h>
#include <gaio/Model.h>
#include <gaio/LinearAlgebra.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct _Integrator Integrator;

struct _Integrator {
  
  char *name;            
  void *handle;
  char filename[256];
  Task *task;

  double t;                 /* integration time */
  double tFinal;            /* end of integration time */
  double h;                 /* current stepwidth (for next step) */
  double h_used;            /* stepwidth used for the last integration step */
  double h_min, h_max;      /* minimal and maximal stepwidth */
  double eps;               /* error tolerance */ 
  int steps;                /* actual no of steps performed */  
  int steps_max;            /* maximum number of steps (adaptive stepsize) */
  int count;                /* no of evaluations of model->rhs */

  void (*Init)(Model *model);
  void (*Step)(Integrator *intgr, double *x, double *u, double *fx);
  int  (*Stop)(Integrator *intgr, double *x, double *u, double *fx);
};

/* constructor */
Integrator *IntegratorNew(char *name);

/* destructor */
Integrator *IntegratorFree(Integrator **intgr);

/* link to a specific model */
void IntegratorSetModel(Integrator *itgr, Model *model);

/* link to a specific task */
void IntegratorSetTask(Integrator *itgr, char *name);

/* computes the image point fx of x */
void IntegratorMap(Integrator *intgr, double *x, double *u, double *fx);

/* computes the orbit originating at x */
void IntegratorOrbit(Integrator *intgr, double *x, double *u, double **fx, 
		     double **t, int *length);

/* computes orbit until it hits a target box or tFinal is reached */
int IntegratorFinder(Integrator *intgr, double *x, double *u, double *c, double *r, 
		     double *t, double *fx);

/* returns a matrix L such that |Map(x) - Map(y)| \le L |x-y| for all
   x,y in the Box B=B(c,r) */
void IntegratorLip(Integrator *intgr, double *c, double *r, double *L);

void IntegratorInfo(FILE *out, Integrator *intgr);
void IntegratorSave(FILE *out, Integrator *intgr);
Integrator *IntegratorLoad(FILE *in);

#ifdef __cplusplus
}
#endif


#endif

