/*
 * Copyright (c) 1998 Oliver Junge, for details see COPYING
 * 
 * Task.h
 *
 */

#ifndef _Task_h
#define _Task_h

#include <gaio/defs.h>
#include <gaio/Model.h>

typedef struct _Task Task;
typedef void (*TaskFunc)(Task *task, double *x, double *u, double *fx);

struct _Task {
  
  char *name;              /* name of Task */
  void *handle;            /* filehandle for task */
  char filename[256];      /* name of object file */

  /*  int dim; */
  Model *model;
  int (*Dim)(int dim);
  TaskFunc f;
  TaskFunc Df;

};

Task *TaskNew(char *name);
Task *TaskFree(Task **task);

int TaskDim(Task *task);

void TaskInfo(FILE *out, Task *task);

#endif
