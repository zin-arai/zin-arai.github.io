function treecut(tree,tree2)

% treecut - cut boxes from a tree.
%   treecut(tree,tree2): 
%   cut the boxes in "tree2" from "tree".
%   two trees must have the same depth and dimension.
%
% Zin ARAI, 2002/10/16

hit = 1;
dim = tree.dim;
depth = tree2.depth;
if dim ~= tree2.dim
  disp('Error: dim of two trees must agree!')
  return;
end

tree.set_flags('all', hit);
tree2.set_flags('all', hit);

n = tree.count(depth);
unset = zeros(1,n);
boxes = tree.boxes(depth);
unset = (tree2.search(boxes(1:dim,:),depth) ~= -1);
flags = sprintf('%1d', unset);
tree.unset_flags(flags, hit);
tree.remove(hit);
