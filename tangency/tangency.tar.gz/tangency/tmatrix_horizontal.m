function M = tmatrix(tree, mapname, param)

% tmatrix - compute the transition (adjacent) matrix
%           using the map defined by "mapname"
%
% written by Zin ARAI (arai@math.kyoto-u.ac.jp)
% Last modified: 2004/04/22
% Last modified: 2009/04/08

depth = tree.depth;

d = tree.dim;
n = tree.count(depth);

b = tree.boxes(depth);
center = b(1:d, :);
radius = b(d+1:2*d, :);
p = CRtoI(center, radius);
[MID, RAD] = ItoCR(feval(mapname, p, param));

ij = zeros(n,2);

% Since the parameter direction is fixed, 
% we can replace intervals with their midpoints.
RAD(4, :) = 0;

nc = size(MID, 2) / n;
tmp = 1;
nnzA = 1;

clear b center radius p fp;

for j = 1:n
  for k = 0:nc-1
    no = tree.search_box(MID(:,tmp+k),RAD(:,tmp+k),depth);
    if (length(no) > 0)
      if nnzA+length(no) > length(ij)
        ij = realloc(ij, [2*size(ij,1),2]);
      end
      ij(nnzA:nnzA+length(no)-1,:) = [no j*ones(length(no),1)];
    end
    nnzA = nnzA + length(no);
  end
  tmp = tmp + nc;
  j = j + 1;
  %disp(sprintf('avarage nnz = %f',nnzA/j));
end

M = sparse(ij(1:nnzA-1,1), ij(1:nnzA-1,2), ones(nnzA-1,1), n, n);
