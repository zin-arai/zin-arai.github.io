!uname -a

mapname = 'phenonmap_boost';
mapname_inverse = 'phenonmap_inverse_boost';
filename = 'tangency';
max_depth = 88;

depth = 24;
b = - 0.3;
center = [0; 0; 0; 1.3];
radius = [3; 3; 2; 0.1];
tree = Tree(center,radius);
tree_b = Tree(center,radius);
param = [b; 0; 2];

sd = tree.sd;
sd(4) = 0;
sd(8) = 1;
sd(12) = 2;
tree.sd = sd;
tree_b.sd = sd;

step = (radius(4))/(2^(depth/4));

t = b - 1;
for a = center(4)-radius(4):step:center(4)+radius(4); 
    [Es Eu] = fixed_points(a, b);
    tree.insert(Eu, depth);
    tree_b.insert(Es, depth);
end

gum(tree, 4, mapname, param);
gum(tree_b, 2, mapname_inverse, param);

treeadd(tree, tree_b);
clear tree_b;
