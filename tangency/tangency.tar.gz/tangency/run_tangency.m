! uname -a
! date

setup
refine(tree, max_depth - tree.depth, mapname, param)

boxes = tree.boxes(tree.depth);
amin = min(boxes(4,:));
amax = max(boxes(4,:));
asize = amax - amin;

insert_fp(tree, b, amin - 2 * asize, amin + 2 * asize);
param = [b; amin - asize; amax + asize];
indexpair(tree, mapname, param, filename);

disp(' ');
disp('Created an index pair to verify the existence of a tangency contained');
disp(sprintf('in the parameter region (a, b) = ([%f, %f], %f).', param(2), param(3), param(1)));
