function readcub(tree, filename, depth)

% readcub: an add-on function for GAIO 
% Read the cubes from the file "filename "and insert these cubes 
% to the "tree" at the specified depth.
% This program assume that the origin is a vertex of the mesh.
% The property "tree.sd" should have been set correctly before
% calling this function.
% The dimension of the tree shold be 2, 3, 4, 5, or 6.  

% Zin ARAI, 2002/09/22

d = tree.dim;
center = tree.center;

tree.insert(center',depth);
b = tree.first_box(depth);
radius = b(d+1:2*d);
tree.delete(0);

form = '(';
for i =1:d-1
  form = strcat(form,'%f,');
end
form = strcat(form,'%f)\n');

fid = fopen(filename,'r');
temp = fscanf(fid, form);

for i = 1:d:size(temp)
  for j = 1:d
    temp(i+j-1) = 2 * radius(j) * temp(i+j-1) + radius(j) + center(j);
  end
  tree.insert(temp(i:i+d-1),depth);
end

fclose(fid);
