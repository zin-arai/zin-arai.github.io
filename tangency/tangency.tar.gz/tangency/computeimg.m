function computeimg(tree, mapname, param)

% Zin ARAI, 2004/01/28
% modified, 2009/04/08

depth = tree.depth;
d = tree.dim;
n = tree.count(depth);

sd = tree.sd;
temptree = Tree(tree.center, tree.radius);
temptree.sd = sd;

b = tree.boxes(depth);
center = b(1:d, :);
radius = b(d+1:2*d, :);
p = CRtoI(center, radius);
[c, r] = ItoCR(feval(mapname, p, param));

for j = 1:size(c, 2)
    temptree.insert_box(c(:, j), r(:, j), depth);
end

tree.delete(0);
treeadd(tree, temptree);
