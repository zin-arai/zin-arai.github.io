function invariantset(tree, mapname, param)

% szymis - maximal invariant set
%   szymis(tree):
%   Compute the maximal invariant set in tree
%   using Szymczak's algorithm.

% Zin ARAI, 2004/01/28

c = tree.count(-1);
d = tree.dim;
hit = 1;

M = tmatrix(tree, mapname, param);
invset = invset_szy(M);
tree.unset_flags('all', hit);
flags = sprintf('%1d', invset);
tree.set_flags(flags, hit);
tree.remove(hit);
%disp(sprintf('Invariant set: %d boxes.', tree.count(-1)));
