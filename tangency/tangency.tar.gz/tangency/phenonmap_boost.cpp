//
// phenonmap.c
//
// Projectivization of Henon map H:(x, y) -> (a - x^2 + by, x)
// considerd as a map from R^2 \times P^1 \times R to itself
// (x, y, t, a) -> (a - x^2 + by, x, T ,a)
// where T is the direction of DH(cos t, sin t)
//
// written by Zin ARAI

#include <math.h>
#include <mex.h>
#include <iostream>
#include "boost/numeric/interval.hpp"
#define max(x,y) (x>y ? x : y)
#define min(x,y) (x<y ? x : y)
#define EMPTY 9

using namespace std;
using namespace boost::numeric;
using namespace boost::numeric::interval_lib::compare::certain;
typedef interval<double> Interval;

template<typename T, typename P>
ostream& operator<<( ostream& os, const interval<T,P>& itv )
{
	return os << "[" << itv.lower() << ", " << itv.upper() << "]";
}

// function to compute the image cube
// [x(0), x(1), x(2), x(3)] is mapped to 
// [y(0), y(1), y(2), y(3)] and
// [y(4), y(5), y(6), y(7)] 
void rhs(Interval* x, Interval* y, 
         Interval b, Interval fixed, double epsilon) {

    Interval v, w, drift;

    // X
    y[0] = x[3] - x[0] * x[0] + b * x[1]; 
    y[4] = y[0];

    // Y
    y[1] = x[0]; 
    y[5] = y[1];

    // T
    if (x[2] <= Interval(0)) {
        v = - Interval(2) * x[0] * (x[2] + Interval(1)) + b;
        w = x[2] + Interval(1);
    } else {
        v = - Interval(2) * x[0] + (-x[2] + Interval(1)) * b;
        w = Interval(1);
    }

    if (zero_in(w)) {
        if (!zero_in(v + w) && !zero_in(v - w)) {
            y[2] = Interval(EMPTY);
        } else {
            y[2] = Interval(-2, 0);
        }
    } else {
        y[2] = v / w - Interval(1);
        if (overlap(y[2], Interval(-2, 0))) {
            y[2] = intersect(y[2], Interval(-2, 0));
        } else {
            y[2] = Interval(EMPTY);
        }
    }

    if (zero_in(v)) {
        if (!zero_in(v + w) && !zero_in(v - w)) {
            y[6] = Interval(EMPTY);
        } else {
            y[6] = Interval(0, 2);
        }
    } else {
        y[6] = - w / v + Interval(1);
        if (overlap(y[6], Interval(0, 2))) {
            y[6] = intersect(y[6], Interval(0, 2));
        } else {
            y[6] = Interval(EMPTY);
        }
    }

    if (zero_in(v) && zero_in(w)) {
        y[2] = Interval(-2, 0);
        y[6] = Interval(0, 2);
    }

    // A
    // if a \not\in [lobnd, upbnd], a small drift is put on it
    if (upper(x[3]) > upper(fixed)) {
        drift = Interval(max(upper(fixed), lower(x[3])), upper(x[3])) 
            - Interval(upper(fixed));
        
    } else if (lower(x[3]) < lower(fixed)) {
        drift = Interval(lower(x[3]), min(lower(fixed), upper(x[3])))
            - Interval(lower(fixed));
    } else {
        drift = Interval(0);
    }

    y[3] = x[3] + x[2] * drift;
    y[7] = y[3];

    y[0] = y[0] + Interval(-epsilon, epsilon);
    y[1] = y[1] + Interval(-epsilon, epsilon);
    y[2] = y[2] + Interval(-epsilon, epsilon);
    y[3] = y[3] + Interval(-epsilon, epsilon);
    y[4] = y[4] + Interval(-epsilon, epsilon);
    y[5] = y[5] + Interval(-epsilon, epsilon);
    y[6] = y[6] + Interval(-epsilon, epsilon);
    y[7] = y[7] + Interval(-epsilon, epsilon);
}

// main
void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    Interval *pR, *pL;
    Interval *x, *y;
    Interval b, fixed;
    double epsilon;

    epsilon = 1 / pow(2.0, 48);

    // the number of image cubes for each single domain cube
    const int nimg = 2;

    // load parameter values
    b = Interval(*(mxGetPr(prhs[1]) + 0));
    fixed = Interval(*(mxGetPr(prhs[1]) + 1), 
                             *(mxGetPr(prhs[1]) + 2));

    // load input data
    int dim = mxGetM(prhs[0]) / 2; // dimension of the input data
    int ncubs = mxGetN(prhs[0]);     // number of cubes
    pR = (Interval *) mxGetPr(prhs[0]);

    // set a pointer for the output data
    plhs[0] = mxCreateDoubleMatrix(dim * 2, ncubs * nimg, mxREAL);
    pL = (Interval *) mxGetPr(plhs[0]);

    for (int i = 0; i < ncubs; i++) {
        x = pR + i * dim;
        y = pL + i * dim * nimg;
        rhs(x, y, b, fixed, epsilon);
    }

    return;
}
