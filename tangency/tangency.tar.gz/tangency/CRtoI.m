function I = CRtoI(center, radius)

if size(center) ~= size(radius)    
    disp('Error: size of "center" and "radius" must agree!')
    return;
end

I = zeros(size(center, 1) * 2, size(center, 2));
n = 1:size(center, 1);

I(2 * n - 1, :) = center - radius;
I(2 * n, :) = center + radius;
