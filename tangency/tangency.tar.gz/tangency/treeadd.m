function treeadd(tree,tree2)

% treeadd - add boxes to a tree.
%   treeadd(tree,tree2): 
%   add the boxes in "tree2" to "tree".
%   two trees must have the same depth and dimension.

% Zin ARAI, 2002/10/16

dim = tree.dim;
depth = tree2.depth;
if dim ~= tree2.dim
  disp('Error: dim of two trees must agree!')
  return;
end

boxes = tree2.boxes(depth);
tree.insert(boxes(1:dim,:),depth);
