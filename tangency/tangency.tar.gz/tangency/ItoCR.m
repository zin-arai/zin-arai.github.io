function [center, radius] = ItoCR(I)

center = zeros(size(I, 1) / 2, size(I, 2));
radius = zeros(size(center));

for i = 1:size(center, 1)
    center(i, :) = (I(2 * i, :) + I(2 * i - 1, :)) / 2;
    radius(i, :) = (I(2 * i, :) - I(2 * i - 1, :)) / 2;
end
