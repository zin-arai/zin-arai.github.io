function [Es Eu] = fixed_points(a, b)

t = b - 1;

% The left fixed point
fix = (t - sqrt(t * t + 4 * a)) / 2;
temp = sqrt(fix * fix + b);
stable = - fix - temp;
unstable = - fix + temp;

% The right fixed point
% fix = (t + sqrt(t * t + 4 * a)) / 2;
% temp = sqrt(fix * fix + b);
% stable = - fix + temp;
% unstable = - fix - temp;

Es = [fix; fix; stable - 1; a];
Eu = [fix; fix; -1 / unstable + 1; a];
