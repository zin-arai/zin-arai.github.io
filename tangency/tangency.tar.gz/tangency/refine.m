function refine(tree, nstep, mapname, param)

% Zin ARAI, 2003/06/19
% modified, 2009/04/09

b = param(1);
center = tree.center;
radius = tree.radius;
dim = tree.dim;

for step = 0:nstep
    if step ~= 0
        tree.set_flags('all',2); tree.subdivide(2);
    end
    disp(sprintf('Step %d of %d, at depth %d',step,nstep,tree.depth));
    n = tree.count(tree.depth);

    svect  = zeros(n,1);
    uvect  = zeros(n,1);
    remain  = zeros(n,1);

    boxes =  tree.boxes(tree.depth);
    ra = boxes(8,1) / 10;

    M = tmatrix_horizontal(tree, mapname, param);
    
    a = min(boxes(4,:));
    amax = max(boxes(4,:));

    while  a <= amax
        [Es Eu] = fixed_points(a, b);
        sbox =  tree.search(Es);
        ubox =  tree.search(Eu);
        if sbox ~= -1
            svect(sbox) = 1;
        end
        if ubox ~= -1
            uvect(ubox) = 1;
        end
        a = a + ra;
    end

    lvect = nnz(uvect);
    temp = 0;
    while temp ~= lvect
        temp = lvect;
        uvect = M * uvect;
        lvect = nnz(uvect);
    end

    lvect = nnz(svect);
    temp = 0;
    while temp ~= lvect
        temp = lvect;
        svect = M' * svect;
        lvect = nnz(svect);
    end

    remain = svect & uvect;
    flags = sprintf('%1d', remain);
    tree.unset_flags('all', 1);
    tree.set_flags(flags, 1);
    tree.remove(1);

    disp(sprintf('... %d boxes',tree.count(-1)));
end
