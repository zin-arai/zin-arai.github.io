function insert_fp(tree, b, bottom, top)

center = tree.center;
radius = tree.radius;
depth = tree.depth;
dim = tree.dim;
firstbox =  tree.first_box(tree.depth);
r = firstbox(8) / 1.1;
a = bottom;

while a <= top;
    [Es Eu] = fixed_points(a, b);
    tree.insert(Eu, tree.depth);
    tree.insert(Es, tree.depth);
    a = a + r;
end
