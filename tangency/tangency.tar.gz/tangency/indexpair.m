function indexpair(tree, mapname, param, filename)

% indexpair
%   indexpair(tree, mapname, param, filename):
%
% written by Zin ARAI (arai@math.kyoto-u.ac.jp) 
% Last modified: 2003/04/29
% Last modified: 2009/04/08

d = tree.dim;
depth = tree.depth;

b = tree.first_box(depth);
radius = b(d+1:2*d);

sd = tree.sd;

tmptree = Tree(tree.center, tree.radius);
tmptree.sd = sd;

lasttree = Tree(tree.center, tree.radius);
lasttree.sd = sd;

invsize = 0;
nstep = 1;
tic;

while 1
    !date
    n = tree.count(depth);
    disp(sprintf('INDEXPAIR step %d: start with %d boxes',nstep,n));
    disp(sprintf('Computing the maximal invariant set...'));
    invariantset(tree, mapname, param);
    k = tree.count(depth);
    if k == invsize
        % write the isolating neighborhood N
        disp(sprintf('Found an isolating neighborhood!!'));
        writecub(tmptree,sprintf('%s.nbd',filename)); % tmptree = o(S)
        % write the invariant set X
        disp(sprintf('Writing the invariant set X (= S)...'));
        writecub(tree,sprintf('%s.X',filename)); % tree = S
    
        % make P1
        disp(sprintf('Making P1 and P0...'));
        treecut(tmptree,tree); % tmptree = C := collar(S)
        computeimg(tree,mapname,param) % tree = F(S)
        treecap(tree,tmptree); % tree = P0 = F(S) \cap C
        while tree.count(depth) ~= lasttree.count(depth)
            treeadd(lasttree,tree); % lastP0 := P0
            computeimg(tree,mapname,param); %tree = F(P0)
            treecap(tree,tmptree); %tree = F(F0) \cap C
            treeadd(tree,lasttree);
        end
        % writing A = P0 \ S
        disp(sprintf('Writing A (= P0 \\ S)...'));
        writecub(tree,sprintf('%s.A',filename));

        % write the multi valued map 
        disp(sprintf('Writing the multi valued map on X \\cup A (= P1)...'));
        readcub(tmptree,sprintf('%s.X',filename),depth); % tmptree = S
        treeadd(tree,tmptree); % tree = P1
        writemap(tree,mapname,param,sprintf('%s.map',filename));
        % B = f(X \cup A) \ X
        disp(sprintf('Making B = f(X \\cup A) \\ X...'));
        computeimg(tree,mapname,param);
        treecut(tree,tmptree);
        writecub(tree,sprintf('%s.B',filename));
        break;
    end
    disp(sprintf('Not found an isolating neighborhood yet...'));
    invsize = k;
    disp(sprintf('Making a neighborhood of the invariant set...'));
    boxes = tree.boxes(depth);
    for j = 1:invsize
        tmptree.insert_box(boxes(1:d,j),2*boxes(d+1:2*d,j),depth);
    end
    treeadd(tree,tmptree);
    disp(sprintf('%d boxes were added in this step', tree.count(depth) - n));
    nstep = nstep + 1;
    disp(sprintf(' '));
end

disp(sprintf('Time used by INDEXPAIR: %.2f seconds',toc));
