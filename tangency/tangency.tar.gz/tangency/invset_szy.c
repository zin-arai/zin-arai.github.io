#include <math.h>
#include <mex.h>

int nnz(double v[], int n){
    int i, j;
    j = 0;
    for (i=0;i<n;i++){
        if (v[i]!=0) j++;
    }
    return j;
}

void mexFunction(int nlhs, mxArray *plhs[], int nrhs, const mxArray *prhs[])
{
    int n, c, i, j, k;
    double *invset;
    int *Jc;
    int *Ir;
    int nnz(double *, int);

    Ir = mxGetIr(prhs[0]);
    Jc = mxGetJc(prhs[0]);
    n = mxGetN(prhs[0]);

    int hit[n];
    int remain[n];

    plhs[0] = mxCreateDoubleMatrix(1,n,mxREAL);
    invset = mxGetPr(plhs[0]);

    for (i=0;i<n;i++){
        invset[i] = 1;
    }

    do {
        c = nnz(invset,n);
        for (i=0;i<n;i++){
            hit[i] = 0;
            remain[i] = 0;
        }
        for (i=0;i<n;i++){
            if (invset[i] == 1) {
                for (j=Jc[i];j<Jc[i+1];j++){
                    if (invset[Ir[j]] == 1) {
                        remain[i] = 1;
                        for (k=Jc[i];k<Jc[i+1];k++){
                            hit[Ir[k]] = 1;
                        }
                        break;
                    }
                }
            }
        }
        for (i=0;i<n;i++) {
            invset[i] = remain[i] & hit[i];
        }
    } while (c != nnz(invset,n));
    return;
}
