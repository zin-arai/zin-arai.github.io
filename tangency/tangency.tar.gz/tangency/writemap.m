function writemap(tree, mapname, param, filename)

%   int_writemap(tree): 
%   output the tree and the map in the input form of "indexpair".

% Zin ARAI, 2003/04/29
% modified: 2009/04/08

fid = fopen(filename,'w');
d = tree.dim;

depth = tree.depth;
origin = tree.center;

n = tree.count(depth);
cubs = tree.boxes(depth);

b = tree.boxes(depth);
center = b(1:d, :);
radius = b(d+1:2*d, :);
bdiam = 2 * radius(1:d, 1);

p = CRtoI(center, radius);
[c, r] = ItoCR(feval(mapname, p, param));
nc = size(c, 2) / n;

xll = c - r;
xur = c + r;

llmin = round(-tree.radius' ./ bdiam);
urmax = round( tree.radius' ./ bdiam);

for i = 1:d
  cubs(i,:) = cubs(i,:) - origin(i);
  xll(i,:) = xll(i,:) - origin(i);
  xur(i,:) = xur(i,:) - origin(i);
  xll(i,:) = floor(xll(i,:) / bdiam(i));
  xur(i,:) = ceil(xur(i,:) / bdiam(i));
end

cubs(1:d,:) = round((cubs(1:d,:) ./ cubs(1+d:2*d,:) - 1) / 2);

form = '[(';
for i =1:d-1
  form = strcat(form,'%.0f,');
end
form = strcat(form,'%.0f)(');
for i =1:d-1
  form = strcat(form,'%.0f,');
end
form = strcat(form,'%.0f)]');

for i = 1:n
  for j = 1:nc
    if ~(xll(:,nc*(i-1)+j) > urmax | xur(:,nc*(i-1)+j) < llmin)
      fprintf(fid, form, cubs([1:d],i),cubs([1:d],i) + 1);
      fprintf(fid, form, xll(:,nc*(i-1)+j),xur(:,nc*(i-1)+j));
      fprintf(fid, '\n');
    end
  end
end