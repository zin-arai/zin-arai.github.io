function gum(tree, nstep, mapname, param)

% Zin ARAI, 2003/04/29
% modified: 2009/04/08

depth = tree.depth;
d = tree.dim;

sd = tree.sd;
temptree = Tree(tree.center, tree.radius);
temptree.sd = sd;

i = 0;
%disp(sprintf('step %d: %d boxes', i, tree.count(depth)));

while i < nstep
    b = tree.boxes(depth);
    center = b(1:d, :);
    radius = b(d+1:2*d, :);
    p = CRtoI(center, radius);
    [c, r] = ItoCR(feval(mapname, p, param));
    r(4, :) = 0;
    for j = 1:size(c, 2)
        temptree.insert_box(c(:, j), r(:, j), depth);
    end
    treeadd(tree, temptree);
    i = i + 1;
    disp(sprintf('step %d: %d boxes', i, tree.count(depth)));
end

clear temptree;
