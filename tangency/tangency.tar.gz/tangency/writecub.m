function writecub(tree, filename)

%   writecub(tree):
%   output the tree in the input form of chom programs.
%   This program assume that the origin is a left-bottom vertex of
%   a box in the tree.
% Zin ARAI, 2002/09/22

d = tree.dim;

depth = tree.depth;
n = tree.count(depth);
cubs = tree.boxes(depth);
center = tree.center;

for i = 1:d;
  cubs(i,:) = cubs(i,:) - center(i);
end;
cubs(1:d,:) = round((cubs(1:d,:) ./ cubs(1+d:2*d,:) - 1) / 2);

fid = fopen(filename,'w');

form = '(';
for i =1:d-1
  form = strcat(form,'%.0f,');
end
form = strcat(form,'%.0f)\n');

fprintf(fid, form, cubs([1:d],:));
