function treecap(tree,tree2)

% treecap - compute the intersection of two trees.
%   treecap(tree,tree2): 
%   tree = tree \cap tree2
%   two trees must have the same depth and dimension.
%
% Zin ARAI, 2002/10/16

hit = 1;
dim = tree.dim;
depth = tree.depth;
if depth ~= tree2.depth | dim ~= tree2.dim
  disp('Error: dim and depth of two trees must agree!')
  return;
end

tree.set_flags('all', hit);
tree2.set_flags('all', hit);

n = tree.count(depth);
unset = zeros(1,n);

boxes = tree.boxes(depth);
unset = (tree2.search(boxes(1:dim,:),depth) == -1);
flags = sprintf('%1d', unset);
tree.unset_flags(flags, hit);
tree.remove(hit);
