function run(param_tree, hyp_tree, param_stack, phase_sd, resume_time)
!date
!uname -mnps

param_dim = 2;
param_sd = param_tree.sd;
last_saved_time = resume_time; tic;
last_data_number = max(param_stack(:,4));

while 1
  param_stack = sortrows(param_stack,1);
  param_depth = param_stack(1,2);
  phase_depth = param_stack(1,3);
  data_number = param_stack(1,4);
  a = param_stack(1,5);
  b = param_stack(1,6);
  param_cubs = param_tree.boxes(-1);
  current_cub = param_cubs(:,param_tree.search([a;b],-1));
  param_inf = (current_cub(1:param_dim) - current_cub(param_dim+1:2*param_dim));
  param_sup = (current_cub(1:param_dim) + current_cub(param_dim+1:2*param_dim));
  filename = sprintf('data/%.8d.tree', data_number);
  eval(sprintf('!gunzip -c %s.gz >| data/tmp.tree',filename));
  tree = Tree('data/tmp.tree');
  tree.sd = phase_sd;
  tree.set_flags('all',1); tree.subdivide(1);
  if hyp_realhenon(tree,param_inf,param_sup,'once')
    %% hyperbolic case
    disp(sprintf('Hyperbolic parameter: [%13.10f, %13.10f] x [%13.10f, %13.10f]',...
                 param_inf(1), param_sup(1), param_inf(2), param_sup(2)));
    % insert the current box to hyp_tree
    hyp_tree.insert([a;b], param_depth);
    hyp_tree.save('data/hyperbolic.tree');
    % remove the current box from param_tree and param_stack
    param_tree.set_flags('all',1);
    param_tree.unset_flags([a;b],1,param_depth);
    param_tree.remove(1);
    param_stack = param_stack(2:size(param_stack,1),:);
    param_tree.save('data/remaining.tree');
  else
    % non-hyperbolic case
    if mod(tree.depth,2) == 0 % subdivide the parameter cube
      if param_sd(param_depth + 1) == 0 % subdivide a axis
        r = current_cub(param_dim + 1) / 2;
        a1 = a - r;
        a2 = a + r;
        b1 = b; b2 = b;
      else 
        r = current_cub(param_dim + 2) / 2;
        a1 = a; a2 = a;
        b1 = b - r; 
        b2 = b + r;
      end
      filename1 = sprintf('data/%.8d.tree', last_data_number + 1);
      filename2 = sprintf('data/%.8d.tree', last_data_number + 2);
      tree.save(filename1); eval(sprintf('!gzip -1f %s',filename1));
      eval(sprintf('!ln -f %s.gz %s.gz',filename1, filename2));
      param_tree.insert([a1;b1], param_depth+1); 
      param_tree.insert([a2;b2], param_depth+1);
      weight = tree.count(tree.depth) * 2^(param_depth + 1);
      param_stack = param_stack(2:size(param_stack,1),:);
      param_stack(size(param_stack,1)+1,:) = [weight, param_depth+1, phase_depth+1, last_data_number+1, a1, b1];
      param_stack(size(param_stack,1)+1,:) = [weight, param_depth+1, phase_depth+1, last_data_number+2, a2, b2];
      last_data_number = last_data_number + 2;
      param_tree.save('data/remaining.tree');
    else
      % no parameter subdivision
      filename1 = sprintf('data/%.8d.tree', last_data_number + 1);
      tree.save(filename1); eval(sprintf('!gzip -1f %s',filename1));
      weight = tree.count(tree.depth) * 2^(param_depth);
      param_stack(1,:) = [weight, param_depth, phase_depth+1, last_data_number+1, a, b];
      last_data_number = last_data_number + 1;
    end
  end
  tree.delete(0); delete(tree); clear tree;
  save 'data/param_stack' param_stack;
  %% save the current trees every one hour
  if (toc + resume_time - last_saved_time >= 3600)
    last_saved_time = round(toc + resume_time);
    filename = sprintf('snapshots/remaining_%.8d.tree',last_saved_time);
    param_tree.save(filename);
    filename = sprintf('snapshots/hyperbolic_%.8d.tree',last_saved_time);
    hyp_tree.save(filename);
    filename = sprintf('snapshots/param_stack_%.8d',last_saved_time);
    eval(sprintf('save %s param_stack', filename));
    disp(sprintf('\n%.8d seconds has passed since the beggining.\n',last_saved_time));
  end
end
