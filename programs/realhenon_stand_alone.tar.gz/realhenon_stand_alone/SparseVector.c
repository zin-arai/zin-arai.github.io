#include "SparseVector.h"

SparseVector *SparseVectorNew(int dim, int size) {
  SparseVector *v;

  NEW1(v, SparseVector*, 1);
  v->dim = dim;
  v->nz = 0;
  v->size = size;
  NEW1(v->rows, int*, size);
  NEW1(v->entries, double*, size);

  return v;
}

void SparseVectorFree(SparseVector **v) {
  if (*v) {
    FREE((*v)->entries);
    FREE((*v)->rows);
    FREE(*v);
    *v = 0;
  }
}

void SparseVectorAddEntry(SparseVector *v, int row, double entry) {
    if (v->nz >= v->size) {
        v->size *= 2;
        v->rows = (int*)realloc(v->rows, v->size*sizeof(int));
        v->entries = (double*)realloc(v->entries, v->size*sizeof(double));
    }
    v->rows[v->nz] = row;
    v->entries[v->nz] = entry;
    v->nz++;
}
