#ifndef _Tree_h
#define _Tree_h

#define SD_MAX 500 /* we allow max. 500 sd's in each coordinate */
#define DEPTH_MAX(d) ((d)*SD_MAX) 
#define DEPTH(tree, depth) (depth < 0 ? BoxDepth(tree->box) : tree->depth)

#include "Box.h"
#include "Rectangle.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    Rectangle *Q;               /* region of interest in phase space */
    Box *root;                  /* root of the tree */
    unsigned int *refcount;     /* reference count for the root box */
    Box *box;                   /* current box */
    double *c, *r;              /* center and radius of the current box */
    double *cStack, *rStack;    /* stacks for c and r */
    Box **boxStack;             /* stack for current box */
    unsigned int *branchStack;  /* stack for last visited branch in the tree */
    //unsigned long depth;        /* current depth, i.e. depth of *box */
    unsigned int depth;        /* current depth, i.e. depth of *box */
    byte *sd;                   /* array of bisection directions */
} Tree;

/* creates and returns a new tree */
Tree *TreeNew(Rectangle *Q);

/* deletes the tree *tree and sets *tree=0 */
void TreeFree(Tree **tree);                  

/* sets box=root and c and r to the values of the root box */
void TreeReset(Tree *tree);

/* creates and returns a copy of tree, sharing the boxtree at root */
Tree *TreeCopy(Tree *tree); 

/* goes to child i of box, computing the new c, r and depth */
int  TreeDown(Tree *tree, unsigned int i);

/* goes to the parent of box, computing the corresponding values of c, r and
   depth */
int  TreeUp(Tree *tree);

/* goes to the next branch */
int  TreeNextBranch(Tree *tree);   

/* first part of iterator over the boxes of a certain depth */
int  TreeFirstBox(Tree *tree, int depth);   

/* second part of this iterator */
int  TreeNextBox(Tree *tree, int depth);

/* inserts a box on depth 'depth' into the tree which contains x (if
   possible at all), returning
   1, if successful;
   0, if box has already been there;
   -1, if x is not contained in the root box,
   a inserted box gets the flag 'flag0', a found box the flag flag1.
*/
int  TreeInsert(Tree *tree, double *x, int depth, byte flag0, byte flag1);

/* inserts all boxes on depth 'depth' into the tree which intersect the
   box B=B(c,r), returning
   1, if some box has been inserted into the tree;
   0, if no box has been inserted;
   -1, if B(c,r) does not intersect the root box,
   a inserted box gets the flag 'flag0', a box which has been already
   present the flag flag1 */
int TreeInsertBox(Tree *tree, double *c, double *r, int depth,
		  byte flag0, byte flag1);

/* subdivides all leaves which have their flag 'flag' set in the next 
   coordinate direction, returns the number of subdivided boxes*/
int  TreeSubdivide(Tree *tree, byte flag);

/* unsubdivides all leaves which have their flag 'flag' set 
   returns the number of unsubdivided boxes*/
int  TreeUnsubdivide(Tree *tree, byte flag);

/* removes all boxes which don't have their flag 'flag' set */
int  TreeRemove(Box *box, byte flag);       

/* deletes the depth 'depth' and all deeper depths */
void TreeDeleteDepth(Tree *tree, int depth);

/* sets the flag 'flag' of all boxes on depth (choice==0) or of those 
   for which choice[box->no]==1 */
void TreeSetFlags(Tree *tree, int depth, char *choice, byte flag);

/* unsets the flag 'flag' of all boxes on 'depth' (choice==0) or of those 
   for which choice[box->no]==1*/
void TreeUnsetFlags(Tree *tree, int depth, char *choice, byte flag);

/* changes the flags of all boxes on 'depth' (choice==0) or of those 
   for which choice[box->no]==1*/
void TreeChangeFlags(Tree *tree, int depth, char *choice, byte from, byte to);

/* sets the values of the array 'flags' according to flags of all boxes 
   on 'depth' */
void TreeGetFlags(Tree *tree, int depth, byte *flags);

/* returns the number of boxes in the tree which starts at box */
int TreeCount(Box *box);

/* returns the number of boxes on depth 'depth' and enumerates the boxes */
int TreeCountDepth(Tree *tree, int depth);

/* returns the depth of the tree starting at box 'box' */
int TreeDepth(Box *box);

/* prints all boxes on depth 'depth' in ASCII format */
void TreePrint(FILE *out, Tree *tree, int depth); 
void TreePrintToMatrix(Tree *tree, int depth, double *boxes); 

/* saves the tree to stream out */
void TreeSave(FILE *out, Tree *tree);

/* saves the boxes in the subtree starting at box */
void TreeSaveBox(FILE *out, Box *box);

/* loads a tree from stream in */
Tree *TreeLoad(FILE *in);

/* loads a subtree starting at box from stream in */
Box *TreeLoadBox(FILE *in);


/* Zin ARAI */
void TreeSearchBoxRec(Tree *tree, double *a, double *b, int depth, SparseVector *nos);
int TreeDownLeft(Tree *tree);
int TreeDownRight(Tree *tree);

#ifdef __cplusplus
}
#endif


#endif
