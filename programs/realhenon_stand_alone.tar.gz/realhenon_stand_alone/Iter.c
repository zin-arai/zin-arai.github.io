#include "Vec.h"
#include "Iter.h"

Iter *IterNew(Rectangle *Q) {

  Iter *iter;
  NEW1(iter, Iter*, 1);
  iter->tree = TreeNew(Q);
  iter->searchTree = TreeCopy(iter->tree);

  return iter;
}

void IterFree(Iter **iter) {
  if (*iter) {
    TreeFree(&((*iter)->searchTree));
    TreeFree(&((*iter)->tree));
    FREE(*iter);
    *iter = 0;
  }
}
