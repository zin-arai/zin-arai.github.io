#include "defs.h"

void VecPrint(FILE *out, double *x, int dim);
double *VecRead(FILE *in, int dim);
void VecCopy(double *from, double *to, int dim);
