#include <fenv.h>
#include "defs.h"

void map_f(int n,
           double *param_inf, double *param_sup,
           double *pR,
           double *infv, double *supv)
{
    int i;
    double a, A, b, B;
    double x, X, y, Y, v, V, w, W;

    const int dim = 2;
    const int datalength = 2*dim;

    // paramters
    a = *(param_inf + 0);
    A = *(param_sup + 0);
    b = *(param_inf + 1);
    B = *(param_sup + 1);

    for (i = 0; i < n; i++) {

        // domain cube
        fesetround(FE_DOWNWARD);
        x = *(pR + i*datalength + 0) - *(pR + i*datalength + 2); 
        y = *(pR + i*datalength + 1) - *(pR + i*datalength + 3); 

        fesetround(FE_UPWARD);
        X = *(pR + i*datalength + 0) + *(pR + i*datalength + 2);
        Y = *(pR + i*datalength + 1) + *(pR + i*datalength + 3);

        fesetround(FE_DOWNWARD);
        *(infv + i*dim + 0) = a - SQMAX(x,X) + IPMIN(b,B,y,Y);
        *(infv + i*dim + 1) = x;

        fesetround(FE_UPWARD);
        *(supv + i*dim + 0) = A - SQMIN(x,X) + IPMAX(b,B,y,Y);
        *(supv + i*dim + 1) = X;
    }
    fesetround(FE_TONEAREST);
}

void map_Tf(double *param_inf, double *param_sup,
            double *center, double *radius,
            double *infv, double *supv)
{
    double a, A, b, B;
    double x, X, y, Y, v, V, w, W;

    // paramters
    a = *(param_inf + 0);
    A = *(param_sup + 0);
    b = *(param_inf + 1);
    B = *(param_sup + 1);

    // domain cube
    fesetround(FE_DOWNWARD);
    x = center[0] - radius[0];
    y = center[1] - radius[1];
    v = center[2] - radius[2];
    w = center[3] - radius[3];

    fesetround(FE_UPWARD);
    X = center[0] + radius[0];
    Y = center[1] + radius[1];
    V = center[2] + radius[2];
    W = center[3] + radius[3];

    fesetround(FE_DOWNWARD);
    *(infv + 0) = a - SQMAX(x,X) + IPMIN(b,B,y,Y);
    *(infv + 1) = center[0];
    *(infv + 2) = -2*IPMAX(x,X,v,V) + IPMIN(b,B,w,W);
    *(infv + 3) = center[2];

    fesetround(FE_UPWARD);
    *(supv + 0) = A - SQMIN(x,X) + IPMAX(b,B,y,Y);
    *(supv + 1) = center[0];
    *(supv + 2) = -2*IPMIN(x,X,v,V) + IPMAX(b,B,w,W);
    *(supv + 3) = center[2];

    fesetround(FE_TONEAREST);
}
