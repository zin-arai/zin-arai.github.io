#ifndef _Iter_h
#define _Iter_h

#include "defs.h"
#include "Tree.h"

typedef struct {

  Tree *tree;                 /* tree of boxes */
  Tree *searchTree;           /* copy of tree for searching */

} Iter;

/* creates and returns a new iter structure */
Iter *IterNew(Rectangle *Q);

/* deletes **iter and set *iter=0 */
void IterFree(Iter **iter);


#endif
