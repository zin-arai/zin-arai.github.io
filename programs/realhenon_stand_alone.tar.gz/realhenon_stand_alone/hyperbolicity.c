#include <stdio.h>
#include <fenv.h>
#include <string.h>
#include "Iter.h"

int TreeDownLeft(Tree *tree);
int TreeDownRight(Tree *tree);
void TreeSearchBoxRec(Tree *tree, double *a, double *b, int depth, SparseVector *nos);
void setTreeSD(Tree *tree);

void map_f(int n, double *param_inf, double *param_sup,
           double *pR, double *infv, double *supv);

void map_Tf(double *param_inf, double *param_sup,
            double *center, double *radius, double *infv, double *supv);

void TreeSetFlagRec(Tree *tree, double *a, double *b, byte flag, char *found)
{
    int i;

    if (!(tree->box->child[0]) && !(tree->box->child[1])) {
        BoxSetFlag(tree->box, flag);
        *found = 1;
        return;
    }

    i = tree->box->sd;
    if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
        if (TreeDownLeft(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
        if (TreeDownRight(tree)) {
            TreeSetFlagRec(tree, a, b, flag, found);
            TreeUp(tree);
        }
    }
    return;
}

void TreeSubdivideAll(Tree *tree) 
{
    if (TreeFirstBox(tree, -1)) {
        do {
            BoxSubdivide(tree->box, tree->sd[tree->depth]);
        } while (TreeNextBox(tree, -1));
    }
}

void TreeUnsetFlagsAll(Tree *tree, int depth, byte flag)
{
    if (TreeFirstBox(tree, depth)) {
        do {
            BoxUnsetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
    }
}

void TreeSetFlagsVect(Tree *tree, int depth, char *vect, byte flag)
{
    int i = 0;
    if (TreeFirstBox(tree, depth)) do {
        if (vect[i]) {
            BoxSetFlag(tree->box, flag);
        } else {
            BoxUnsetFlag(tree->box, flag);
        }
        i++;
    } while (TreeNextBox(tree, depth));
}

int checkIsolation(Tree *treeTM, int dimTM)
{
    int i, dimM;
    dimM = dimTM / 2;
    if (TreeFirstBox(treeTM, -1)) do {
        for (i = dimM; i < dimTM; i++) {
            if ((fabs(treeTM->c[i]) + 2 * treeTM->r[i]) >= 1) {
                return 0;
            }
        }
    } while (TreeNextBox(treeTM, -1));
    return 1;
}

int TreeFindVisitBox(Tree *tree, double *a, double *b, int *val, int *m, int k) 
{
    int i, j;
    
    if (BoxDepth(tree->box) == -1) {
        if (val[tree->box->no] == 0) {
            //printf("...val NOT defd %d\n",tree->box->no);
            return tree->box->no;
        } else {
            //printf("...val defd %d\n",tree->box->no);
            m[k] = min(m[k], val[tree->box->no]);
            return -1;
        }
    } 
    i = tree->box->sd;
    if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
        if (TreeDownLeft(tree)) {
            j = TreeFindVisitBox(tree, a, b, val, m, k);
            if (j != -1) {
                return j;
            }
            TreeUp(tree);
        }
    }
    if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
        if (TreeDownRight(tree)) {
            j = TreeFindVisitBox(tree, a, b, val, m, k);
            if (j != -1) {
                return j;
            }
            TreeUp(tree);
        }
    }
    return -1;
}

int computeInvSet(Tree *tree, Tree *searchTree, double *param_inf, double *param_sup)
{
    int n, last_n, i, dim, depth;
    double *infv, *supv; // vector for image cubes
    char *domain;

    dim = tree->Q->dim;
    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree, depth);
    infv = (double *) malloc(sizeof(double) * dim);
    supv = (double *) malloc(sizeof(double) * dim);

    do {
        last_n = n;
        domain = (char *) malloc(sizeof(char) * n);
        for (i = 0; i < n; i++) {*(domain + i) = 0;}

        //
        // Main part:
        // Set the flag "1" to the i-th cube if this cube is in the image.
        // Set domain[i] = 1 if the image of the i-th cube intersects the tree.
        // 
        TreeUnsetFlagsAll(tree, depth, 3);
        TreeFirstBox(tree, depth);
        for (i = 0; i < n; i++) {
            map_Tf(param_inf, param_sup, tree->c, tree->r, infv, supv);
            TreeReset(searchTree);
            TreeSetFlagRec(searchTree, infv, supv, 1, domain + i);
            TreeNextBox(tree, depth);
        }

        // remove non-invariant cubes
        TreeSetFlagsVect(tree, depth, domain ,2);
        TreeRemove(tree->root, 3);
        n = TreeCountDepth(tree, depth);
        free(domain);
    } while (n != last_n);

    free(infv);
    free(supv);
    return n;
}

int scc_nonrec(Tree *tree, int dim, char *crset, 
               double *infv, double *supv)
{
    int i, s, k, n, depth, next, p, q;
    int id, *val, *minimum,*m;
    char *fixed_point;
    int *stack, *track;

    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree,depth);

    stack = (int *) malloc(sizeof(int) * (n+1));
    track = (int *) malloc(sizeof(int) * (n+1));

    val = (int *) malloc(sizeof(int) * n);
    m = (int *) malloc(sizeof(int) * n);
    minimum = (int *) malloc(sizeof(int) * n);
    fixed_point = (char *) malloc(sizeof(char) * n);

    for (i=0; i<n; i++) {
        val[i] = 0;
        m[i] = n+1;
        minimum[i] = n+1;
        fixed_point[i] = 0;
    }

    // stack
    // track
    // p: pointer of "stack"
    // q: pointer of "track"
    // n: number of vertices
    // s: start vertex
    // k: current vertex
    // next: next vertex

    //printf("there are %d boxes...\n",n);

    for (s = 0; s < n; s++) {
        if (val[s] == 0) {            
            id = 1;
            k = s;
            stack[0] = k;
            track[0] = k;
            val[k] = id;
            m[k] = id;
            p = 1;
            q = 1;
            while(1) {
                TreeReset(tree);
                next = TreeFindVisitBox(tree, infv+dim*k, supv+dim*k, val, m, k);
                if (next == -1) {
                    minimum[k] = m[k];
                    if (minimum[k] == val[k]) {
                        if (stack[p - 1] == k) { 
                            p--;
                            val[k] = n + 1;
                        } else do {
                            p--;
                            crset[stack[p]] = 1;
                            val[stack[p]] = n + 1;
                        } while (stack[p] != k);
                    }
                    if (k == s) {
                        break;
                    }
                    else {
                        q--;
                        m[track[q - 1]] = min(m[track[q - 1]], minimum[k]);
                        k = track[q - 1];
                    }
                } else {
                    if (next == k) {
                        fixed_point[k] = 1;
                        crset[k] = 1;
                    }
                    id++;
                    k = next;
                    stack[p] = k;
                    track[q] = k;
                    val[k] = id;
                    m[k] = id;
                    q++;
                    p++;
                }
            }
        }
    }
    free(stack);
    free(track);
    free(val);
    free(m);
    free(minimum);
    free(fixed_point);
    return 0;
}

void computeScc(Tree *tree, double *param_inf, double *param_sup, char *crset)
{ 
    int n, i, dim, depth;
    double *infv, *supv; // vector for image cubes
    double *pR, eps, tmp;

    dim = tree->Q->dim;
    depth = TreeDepth(tree->root);
    n = TreeCountDepth(tree,depth);

    pR = (double *) malloc(sizeof(double) * (2 * dim + 2) * n);
    infv = (double *) malloc(sizeof(double) * dim * n);
    supv = (double *) malloc(sizeof(double) * dim * n);

    TreePrintToMatrix(tree, depth, pR);
    map_f(n, param_inf, param_sup, pR, infv, supv);
    free(pR);

    // Calculation of Epsilon (min { x > 0 })
    tmp = 1.0;
    do {
        eps = tmp;
        tmp = tmp / 2.0;
    } while (tmp > 0.0);
    
    eps = eps * 8;
    
    for (i=0; i<dim*n; i++) {
        *(infv+i) = *(infv+i) - eps;
        *(supv+i) = *(supv+i) + eps;
    }
    
    // call main routine
    scc_nonrec(tree, dim, crset, infv, supv);
    free(infv);
    free(supv);
}

void restrictTM(Tree *treeTM, Tree *treeM, char *crset, char *remain)
{
    int i, j, dim, ncubTM, depthTM, ncubM, depthM;
    double *ll, *ur;
    SparseVector *nos;

    dim = treeM->Q->dim;
    depthTM = TreeDepth(treeTM->root);
    ncubTM = TreeCountDepth(treeTM,depthTM);
    depthM = TreeDepth(treeM->root);
    ncubM = TreeCountDepth(treeM,depthM);
         
    for (i=0; i<ncubTM; i++) {
        remain[i] = 1;
    }

    ll = (double *) malloc(sizeof(double) * 2 * dim);
    ur = (double *) malloc(sizeof(double) * 2 * dim);
    for (i=dim; i<2*dim; i++) {
        *(ll+i) = -1.0; *(ur+i) =  1.0;
    }

    TreeFirstBox(treeM, depthM);
    for (i=0; i<ncubM; i++) {
        if (!crset[i]) {
            nos = SparseVectorNew(0, 16);
            for (j=0; j<dim; j++) {
                ll[j] = treeM->c[j];
                ur[j] = ll[j];
            }
            TreeReset(treeTM);
            TreeSearchBoxRec(treeTM, ll, ur, depthTM, nos);
            for (j=0; j<nos->nz; j++) {
                remain[nos->rows[j]] = 0;
            }
            SparseVectorFree(&nos);
        }
        TreeNextBox(treeM, depthM);
    }
    free(ll);
    free(ur);
    return;
}

int computeRf(Tree *treeTM, Tree *treeM, double *param_inf, double *param_sup)
{
    int i, dim, tmp, ncubTM, ncubM, depthTM, depthM;
    int depth_table[256];
    double *x;
    char *crset, *remain;

    dim = treeM->Q->dim;
    x = (double *) malloc(sizeof(double) * dim);

    depthTM = TreeDepth(treeTM->root);
    ncubTM = TreeCountDepth(treeTM, depthTM);

    // depth_table: a table to compute the depth of M
    // corresponding to the given depth of TM
    tmp = 0;
    for (i=0; i<256; i++) {
        depth_table[i] = tmp;
        if (treeTM->sd[i] < dim) {
            treeM->sd[tmp] = treeTM->sd[i];
            tmp++;
        }
    }

    depthM = depth_table[depthTM];
    TreeDeleteDepth(treeM, 0);

    // project TM to M
    if (TreeFirstBox(treeTM, depthTM)) do {
        for (i=0; i<dim; i++) {
            x[i] = treeTM->c[i];
        }
	TreeInsert(treeM, x, depthM, 1, 1);
    } while (TreeNextBox(treeTM, depthTM));

    // compute scc
    ncubM = TreeCountDepth(treeM, depthM);
    crset = (char *) malloc(sizeof(char) * ncubM);
    for (i=0; i<ncubM; i++) {
        crset[i] = 0;
    }
    computeScc(treeM, param_inf, param_sup, crset);

    // find the cubes of TM that lies on the crset of f:M -> M
    remain = (char *) malloc(sizeof(char) * ncubTM);
    for (i=0; i<ncubTM; i++) {
        remain[i] = 1;
    }
    restrictTM(treeTM, treeM, crset, remain);

    // remove the cubes of TM that is not on the crset of f: M -> M
    TreeSetFlagsVect(treeTM, depthTM, remain, 1);
    TreeRemove(treeTM->root, 1);
    ncubTM = TreeCountDepth(treeTM, depthTM);

    free(x);
    free(crset);
    free(remain);
    return ncubTM;
}

int main(int argc, char *argv[])
{
    int i;
    const int dimM  = 2;
    const int dimTM = 4;
    const int param_dim = 2; 
    double *center, *radius;
    double a, b;
    double eps;
    double *param_inf, *param_sup;
    Rectangle *Q;
    Iter *iterM, *iterTM;

    eps = 1;
    for (i = 0; i < 48; i++) {eps = eps / 2;}

    a = atof(argv[1]);
    b = atof(argv[2]);
    
    param_inf = (double*) malloc(sizeof(double) * param_dim);
    param_sup = (double*) malloc(sizeof(double) * param_dim);
    param_inf[0] = a - eps;
    param_sup[0] = a + eps;
    param_inf[1] = b - eps;
    param_sup[1] = b + eps;

    printf("Proving the hyperbolicity of (x, y) |-> (a - x^2 + by, x)\n");
    printf("a_inf = %.60f\n", param_inf[0]);
    printf("a_sup = %.60f\n", param_sup[0]);
    printf("b_inf = %.60f\n", param_inf[1]);
    printf("b_sup = %.60f\n", param_sup[1]);

    // make tree, the tree of the tangent bundle
    center = (double*) malloc(sizeof(double) * dimTM);
    radius = (double*) malloc(sizeof(double) * dimTM);
    center[0] = 0;
    center[1] = 0;
    center[2] = 0;
    center[3] = 0;
    radius[0] = 8;
    radius[1] = 8;
    radius[2] = 1;
    radius[3] = 1;

    Q = RectangleNew(center, radius, dimTM);
    iterTM = IterNew(Q);
    free(center);
    free(radius);

    for (i = 0; i < 4; i++) {
        iterTM->tree->sd[2*i + 0] = 0; 
        iterTM->tree->sd[2*i + 1] = 1;
    }

    //
    // Construct iterM, the tree for the base manifold M
    //
    Q = RectangleNew(iterTM->tree->Q->c, iterTM->tree->Q->r, dimM);
    iterM = IterNew(Q);
    RectangleFree(&Q);

    // mian routine
    while (1) 
    {
        TreeDeleteDepth(iterM->tree, 0);
        TreeSubdivideAll(iterTM->tree);
        printf("tree detph = %2d:\t ", TreeDepth(iterTM->tree->root));
        printf("#cubs = %7d\n", TreeCountDepth(iterTM->tree, -1));
        if (!computeRf(iterTM->tree, iterM->tree, param_inf, param_sup) ||
            !computeInvSet(iterTM->tree, iterTM->searchTree, param_inf, param_sup) ||
            checkIsolation(iterTM->tree, dimTM)) {
            printf("Hyperbolic!\n");
            return 0;
        }
    }
    TreeDeleteDepth(iterM->tree, 0);
    TreeDeleteDepth(iterTM->tree, 0);
    IterFree(&iterM);
    IterFree(&iterTM);
    free(param_inf);
    free(param_sup);

}
