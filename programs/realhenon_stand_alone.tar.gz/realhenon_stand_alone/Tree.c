#include <string.h>
#include "Tree.h"
#include "Vec.h"

Tree *TreeNew(Rectangle *Q) {

    unsigned int i, dim;
    Tree *tree;

    assert(Q);
    dim = Q->dim;
    NEW1(tree, Tree*, 1);
    tree->Q = RectangleNew(Q->c, Q->r, dim);
    tree->root = BoxNew();
    NEW1(tree->refcount, unsigned int*, 1);
    *(tree->refcount) = 1;
    NEW1(tree->c, double*, dim);
    NEW1(tree->r, double*, dim);
    NEW1(tree->cStack, double*, DEPTH_MAX(dim));
    NEW1(tree->rStack, double*, DEPTH_MAX(dim));
    NEW1(tree->boxStack, Box**, DEPTH_MAX(dim));
    NEW1(tree->branchStack, unsigned int *, DEPTH_MAX(dim));
    NEW1(tree->sd, byte*, DEPTH_MAX(dim)+1);
    for (i=0; i<DEPTH_MAX(dim)+1; i++) tree->sd[i] = i % dim;
    TreeReset(tree);

    return tree;
}

void TreeFree(Tree **tree) {
    if (*tree) {
        FREE((*tree)->branchStack);
        FREE((*tree)->boxStack);
        FREE((*tree)->rStack);
        FREE((*tree)->cStack);
        FREE((*tree)->r);
        FREE((*tree)->c);
        *((*tree)->refcount) -= 1;
        if (*((*tree)->refcount)==0) {
            BoxFree(&((*tree)->root));
            RectangleFree(&((*tree)->Q));
            FREE((*tree)->sd);
        }
        FREE(*tree);
        *tree = 0;
    }
}

void TreeReset(Tree *tree) {
    assert(tree);

    tree->box = tree->root;
    VecCopy(tree->Q->c, tree->c, tree->Q->dim);
    VecCopy(tree->Q->r, tree->r, tree->Q->dim);
    tree->depth = 0;
}

Tree *TreeCopy(Tree *tree) {
    Tree *copy;

    assert(tree);

    NEW1(copy, Tree*, 1);
    copy->Q = tree->Q;
    copy->root = tree->root;
    *(tree->refcount) += 1;
    copy->refcount = tree->refcount;
    NEW1(copy->c, double*, tree->Q->dim);
    NEW1(copy->r, double*, tree->Q->dim);
    NEW1(copy->cStack, double*, DEPTH_MAX(tree->Q->dim));
    NEW1(copy->rStack, double*, DEPTH_MAX(tree->Q->dim));
    NEW1(copy->boxStack, Box**, DEPTH_MAX(tree->Q->dim));
    NEW1(copy->branchStack, unsigned int*, DEPTH_MAX(tree->Q->dim));
    copy->sd = tree->sd;
    TreeReset(copy);

    return copy;
}

inline int TreeDownLeft(Tree *tree) {
    if (tree->box->child[0]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] -= tree->r[sd];
        tree->box = tree->box->child[0];
        tree->branchStack[tree->depth] = 0;
        tree->depth++;
        return 1;
    } else return 0;
}

inline int TreeDownRight(Tree *tree) {
    if (tree->box->child[1]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        tree->c[sd] += tree->r[sd];
        tree->box = tree->box->child[1];
        tree->branchStack[tree->depth] = 1;
        tree->depth++;
        return 1;
    } else return 0;
}

inline int TreeDown(Tree *tree, unsigned int i) {
    if (tree->box->child[i]) {
        unsigned int sd = tree->box->sd;
        tree->cStack[tree->depth] = tree->c[sd];
        tree->rStack[tree->depth] = tree->r[sd];
        tree->boxStack[tree->depth] = tree->box;
        tree->r[sd] /= 2;
        if (i==0) {
            tree->c[sd] -= tree->r[sd];
            tree->box = tree->box->child[0];
        } else {
            tree->c[sd] += tree->r[sd];
            tree->box = tree->box->child[1];
        }
        tree->branchStack[tree->depth] = i;
        tree->depth++;

        return 1;
    } else
        return 0;
}

inline int TreeUp(Tree *tree) {
    if (tree->depth==0) return 0;
    tree->depth--;
    tree->box = tree->boxStack[tree->depth];
    tree->c[tree->box->sd] = tree->cStack[tree->depth];
    tree->r[tree->box->sd] = tree->rStack[tree->depth];

    return 1;
}

int TreeNextBranch(Tree *tree) {
    int down = 0;

    do {
        if (!TreeUp(tree)) return 0;
        if (tree->branchStack[tree->depth]==0)
            down = TreeDownRight(tree);
    } while (!down);

    return 1;
}

int TreeFirstBox(Tree *tree, int depth) {

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    TreeReset(tree);

    while (DEPTH(tree, depth)!=depth)
        if (!(TreeDownLeft(tree) || TreeDownRight(tree)))
            if (!TreeNextBranch(tree)) return 0;

    return DEPTH(tree, depth)==depth;
}

int TreeNextBox(Tree *tree, int depth) {

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (!TreeNextBranch(tree)) return 0;

    while (DEPTH(tree, depth)!=depth)
        if (!(TreeDownLeft(tree) || TreeDownRight(tree)))
            if (!TreeNextBranch(tree)) return 0;

    return DEPTH(tree, depth)==depth;
}

int TreeInsert(Tree *tree, double *x, int depth, byte flag0, byte flag1) {

    assert(tree);
    assert(depth==-1 || depth<= DEPTH_MAX(tree->Q->dim));

    if (RectangleContains(tree->Q, x)) {
        int inserted = 0;
        TreeReset(tree);
        while (DEPTH(tree, depth)!=depth) {
            int i;
            if (!tree->box->child[0] && !tree->box->child[1])
                tree->box->sd = tree->sd[tree->depth];
            i = ((tree->c)[tree->box->sd] < x[tree->box->sd]);
            if (!TreeDown(tree, i)) {
                tree->box->child[i] = BoxNew();
                BoxSetFlag(tree->box->child[i], flag0);
                TreeDown(tree, i);
                inserted = 1;
            } else {
                BoxSetFlag(tree->box, flag1);
            }
        }
        return inserted;
    }
    return -1;
}

int TreeSubdivide(Tree *tree, byte flag) {
    int no = 0;

    assert(tree);

    if (TreeFirstBox(tree, -1)) do {
            if (tree->box->flags & flag) {
                BoxSubdivide(tree->box, tree->sd[tree->depth]);
                no++;
            }
        } while (TreeNextBox(tree, -1));

    return no;
}

int TreeUnsubdivide(Tree *tree, byte flag) {
    int no = 0;

    assert(tree);

    if (TreeFirstBox(tree, -2)) do {
            if (tree->box->flags & flag) {
                BoxUnsubdivide(tree->box);
                no++;
            }
        } while (TreeNextBox(tree, -2));

    return no;
}

int TreeRemove(Box *box, byte flag) {
    int i;

    for (i=0; i<2; i++) {
        if (box->child[i]) {
            if (TreeRemove(box->child[i], flag))
                BoxFree(&(box->child[i]));
            if (BoxNoOfChildren(box)==0)
                box->flags &= ~flag;
        }
    }

    return (BoxNoOfChildren(box)==0 && !((box->flags & flag)==flag));
}

void TreeDeleteDepth(Tree *tree, int depth) {
    if (depth==0) {
        BoxFree(&(tree->root->child[0]));
        BoxFree(&(tree->root->child[1]));
    } else
        if (TreeFirstBox(tree, depth-1)) do {
                BoxFree(&(tree->box->child[0]));
                BoxFree(&(tree->box->child[1]));
            } while (TreeNextBox(tree, depth-1));
}

void TreeSetFlags(Tree *tree, int depth, char *choice, byte flag) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxSetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
}

void TreeUnsetFlags(Tree *tree, int depth, char *choice, byte flag) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxUnsetFlag(tree->box, flag);
        } while (TreeNextBox(tree, depth));
}

void TreeChangeFlags(Tree *tree, int depth, char *choice, byte from, byte to) {
    int no = 0;

    if (TreeFirstBox(tree, depth)) do {
            if (!strcmp(choice, "all") || choice[no++]=='1')
                BoxChangeFlag(tree->box, from, to);
        } while (TreeNextBox(tree, depth));
}

void TreeGetFlags(Tree *tree, int depth, byte *flags) {
    int no =0;

    if (TreeFirstBox(tree, depth)) do
                                       flags[no++] = BoxGetFlags(tree->box);
        while (TreeNextBox(tree, depth));
}

int TreeCount(Box *box) {
    int no0, no1;
    if (box) {
        no0 = TreeCount(box->child[0]);
        no1 = TreeCount(box->child[1]);
        return (no0 + no1 + 1);
    } else
        return 0;
}

int TreeCountDepth(Tree *tree, int depth) {
    int no = 0;

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (TreeFirstBox(tree, depth)) do {
            tree->box->no = no++;
        } while (TreeNextBox(tree, depth));

    return no;
}

void TreeSearchBoxRec(Tree *tree, double *a, double *b, int depth,
                 SparseVector *nos) {
  int i;

  if (depth==DEPTH(tree, depth)) {
    SparseVectorAddEntry(nos, tree->box->no, 1.0);
    return;
  }
  i = tree->box->sd;
  if (interval_intersect(tree->c[i]-tree->r[i], tree->c[i], a[i], b[i])) {
    if (TreeDownLeft(tree)) {
      TreeSearchBoxRec(tree, a, b, depth, nos);
      TreeUp(tree);
    }
  }
  if (interval_intersect(tree->c[i], tree->c[i]+tree->r[i], a[i], b[i])) {
    if (TreeDownRight(tree)) {
      TreeSearchBoxRec(tree, a, b, depth, nos);
      TreeUp(tree);
    }
  }
}

int TreeDepth(Box *box) {
    int l, r;
    if (box) {
        l = TreeDepth(box->child[0]) + 1;
        r = TreeDepth(box->child[1]) + 1;
        return max(l, r);
    }
    return -1;
}

void TreePrint(FILE *out, Tree *tree, int depth) {
    //unsigned long i;
    unsigned int i;

    assert(tree);
    assert(depth==-1 || depth <= DEPTH_MAX(tree->Q->dim));

    if (TreeFirstBox(tree, depth)) do {
            for (i=0; i<tree->Q->dim; i++) fprintf(out,"%g ",tree->c[i]);
            for (i=0; i<tree->Q->dim; i++) fprintf(out,"%g ",tree->r[i]);
            fprintf(out,"%u", tree->box->flags);
            fprintf(out, "\n");
        } while (TreeNextBox(tree, depth));
}

void TreePrintToMatrix(Tree *tree, int depth, double *boxes) {
    int dim, i, j = 0;

    assert(tree);
    dim = tree->Q->dim;
    assert(depth==-1 || depth <= DEPTH_MAX(dim));

    if (TreeFirstBox(tree, depth)) do {
            for (i=0; i<dim; i++) boxes[j*2*dim + i] = tree->c[i];
            for (i=0; i<dim; i++) boxes[j*2*dim + dim + i] = tree->r[i];
            //boxes[j*(2*dim+2) + 2*dim] = tree->box->flags;
            j++;
        } while (TreeNextBox(tree, depth));

}

/*
void TreeSave(FILE *out, Tree *tree) {
    fprintf(out, "Tree at %x:\n", tree);
    if (tree) {
        float one = 1;
        RectangleSave(out, tree->Q);
        fprintf(out, "  no of boxes = %lu\n", TreeCount(tree->root));
        TreeSaveBox(out, tree->root);
    }
}

void TreeSaveBox(FILE *out, Box *box) {
    BoxSave(out, box);
    if (box) {
        TreeSaveBox(out, box->child[0]);
        TreeSaveBox(out, box->child[1]);
    }
}
*/

/*
Tree *TreeLoad(FILE *in) {
    Rectangle *Q;
    Tree *tree;
    int n;
    if (!fscanf(in, "Tree at %x:\n", &tree)) return 0;
    if (tree) {
        if (!(Q = RectangleLoad(in))) return 0;
        if (!fscanf(in, "  no of boxes = %d\n", &n)) return 0;
        if (!(tree = TreeNew(Q))) return 0;
        if (!(tree->root = TreeLoadBox(in))) return 0;

        TreeReset(tree);
        do {
            tree->sd[tree->depth] = tree->box->sd;
        } while(TreeDownLeft(tree) || TreeDownRight(tree));

        RectangleFree(&Q);
    }
    return tree;
}
*/


/*
Box *TreeLoadBox(FILE *in) {
    Box *box;
    box = BoxLoad(in);
    if (box) {
        box->child[0] = TreeLoadBox(in);
        box->child[1] = TreeLoadBox(in);
    }
    return box;
}
*/
