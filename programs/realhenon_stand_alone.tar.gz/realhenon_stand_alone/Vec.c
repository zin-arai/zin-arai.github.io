#include "Vec.h"
#include <string.h>

void VecPrint(FILE *out, double *x, int dim) {  
    int i;
    if (x) {
        for (i=0; i<dim; i++) fprintf(out, "%.15g ", x[i]);
        fprintf(out, "\n");
    } else {
        fprintf(stderr, "warning: libgaio: x=0.\n");
    }
}

double *VecRead(FILE *in, int dim) {
    int i;
    double *x;
    NEW1(x, double*, dim);
    for (i=0; i<dim; i++) fscanf(in, "%lg", &(x[i]));
    fscanf(in, "\n");
    return x;
}

void VecCopy(double *from, double *to, int dim) {  
    int i;
    for (i=0; i<dim; i++) to[i] = from[i];
}
