#ifndef _Rectangle_h
#define _Rectangle_h

#include <stdio.h>
#include "defs.h"

typedef struct {
  int dim;
  double *c, *r;
} Rectangle;

Rectangle *RectangleNew(double *c, double *r, unsigned char dim);
void RectangleFree(Rectangle **r);
int RectangleContains(Rectangle *rect, double *x);
void RectangleSave(FILE *out, Rectangle *rect);
Rectangle *RectangleLoad(FILE *in);

#endif
