#include "Rectangle.h"
#include "Vec.h"

Rectangle *RectangleNew(double *c, double *r, unsigned char dim) {
  Rectangle *rec;
  NEW1(rec, Rectangle*, 1);
  rec->dim = dim;
  NEW1(rec->c, double*, dim);
  NEW1(rec->r, double*, dim);
  VecCopy(c, rec->c, dim);
  VecCopy(r, rec->r, dim);

  return rec;
}

void RectangleFree(Rectangle **rec) {
  if (*rec) {
    FREE((*rec)->r);
    FREE((*rec)->c);
    FREE(*rec);
    *rec = 0;
  }
}

int RectangleContains(Rectangle *rect, double *x) {
  int i, in = 1;
  for (i=0; in && i<rect->dim; i++) 
    in = (fabs(x[i] - rect->c[i]) <= rect->r[i]);
  return in;
}

/*
void RectangleSave(FILE *out, Rectangle *r) {
  fprintf(out, "Rectangle at %x:\n", r);
  if (r) {  
    fprintf(out, "  dim = %d\n", r->dim);
    fprintf(out, "  center = "); VecPrint(out, r->c, r->dim);
    fprintf(out, "  radius = "); VecPrint(out, r->r, r->dim);
  }
}
*/

/*  
Rectangle *RectangleLoad(FILE *in) {
  int dim;
  double *c, *r;
  Rectangle *rect;

  fscanf(in, "Rectangle at %x:\n", &rect);
  if (rect) {
    fscanf(in, "  dim = %d\n", &dim);
    fscanf(in, "  center = "); c = VecRead(in, dim);
    fscanf(in, "  radius = "); r = VecRead(in, dim);
    rect = RectangleNew(c, r, dim);
    FREE(c);
    FREE(r);
  }
  return rect;
}
*/

