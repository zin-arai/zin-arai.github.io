#include <assert.h>
#include "Box.h"

/* creates a NEW Box */
Box *BoxNew(void) {
	Box *box;
	NEW1(box, Box*, 1);
	box->sd = 0;
	box->flags = 0;
	box->child[0] = 0;
	box->child[1] = 0;
	box->no = -1;
	return box;
}

/* deletes Box b and recursively all children of it, sets *b=0 */
void BoxFree(Box **box) {
    if (*box) {
        BoxFree(&((*box)->child[0]));
        BoxFree(&((*box)->child[1]));
        FREE(*box);
        *box = 0;
    }
}

int BoxSubdivide(Box *box, unsigned char sd) {
	if (BoxNoOfChildren(box)==0) {
		box->child[0] = BoxNew();
		box->child[1] = BoxNew();
		box->sd = sd;
		return 1;
	}
	fprintf(stderr, "warning: libgaio: BoxSubdivide(): box is no leaf.\n");
	return 0;
}

int BoxUnsubdivide(Box *box) {
	if (BoxNoOfChildren(box)!=0) {
		BoxFree(&(box->child[0]));
		BoxFree(&(box->child[1]));
		return 1;
	}
	return 0;
}

unsigned int BoxNoOfChildren(Box *box) {
	if (box) {
		if (box->child[0] && box->child[1]) return 2;
		if (box->child[0] || box->child[1]) return 1;
	}
	return 0; /* if b==0, it has no children, too */
}

void BoxSetFlag(Box *box, byte flag) {
	if (box) box->flags |= flag;
}

void BoxUnsetFlag(Box *box, byte flag) {
	if (box) box->flags &= ~flag;
}

void BoxChangeFlag(Box *box, byte from, byte to) {
	if (box) {
		if (box->flags & from) {
			box->flags &= ~from;
			box->flags |= to;
		}
	}
}

byte BoxGetFlags(Box *box) {
	if (box)
		return box->flags;
	else {
		fprintf(stderr, "error: libgaio: BoxGetFlags called with invalid argument.");
		return 0;
	}
}

int BoxDepth(Box *box) {
	if (box) {
		if (BoxNoOfChildren(box)==0) return -1;
		if (BoxNoOfChildren(box->child[0])==0 &&
			    BoxNoOfChildren(box->child[1])==0) return -2;
	}
	return 0;
}

void BoxSave(FILE *out, Box *box) {
	if (box) {
		fwrite((void *)&box->sd, 1, 1, out);
		fwrite((void *)&box->flags, 1, 1, out);
	}
	else
	    fprintf(out, "%c", 0);
	return;
}

Box *BoxLoad(FILE *in) {
	int C;
	Box *box;

	C = fgetc(in);
	if (C==EOF || C==0) return 0;

	box = BoxNew();
	fread((void *)&box->sd, 1, 1, in);
	fread((void *)&box->flags, 1, 1, in);

	return box;
}
