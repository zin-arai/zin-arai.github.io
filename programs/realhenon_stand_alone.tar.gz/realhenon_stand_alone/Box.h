#ifndef _Box_h
#define _Box_h

#include <stdio.h>
#include "defs.h"
#include "SparseVector.h"

#ifdef __cplusplus
extern "C" {
#endif

/* flags */
#define NONE               0x00
#define HIT                0x01
#define INSERTED           0x02
#define EXPAND             0x04
#define SUBDIVIDE          0x08
#define EQUILIBRIUM        0x10
#define ENTERREGION        0x20
#define EXITREGION         0x40

typedef struct _Box Box;

struct _Box {
    byte sd;         /* coordinate in which box is/will be subdivided */
    byte flags;      /* space for various flags */    
    Box *child[2];   /* pointer to the children */
    int no;            /* number, needed for measure computation */
};

/* creates and returns new box */
Box *BoxNew(void);

/* deletes box *box and all children, sets *b=0  */
void BoxFree(Box **box);

/* subdivides box, stores sd in their children */
int  BoxSubdivide(Box *box, byte sd); 

/* unsubdivides box */
int  BoxUnsubdivide(Box *box); 

/* returns the number of children */
unsigned int  BoxNoOfChildren(Box *box);    

/* flag handling functions */
void BoxSetFlag(Box *box, byte flag);
void BoxUnsetFlag(Box *box, byte flag);
void BoxChangeFlag(Box *box, byte from, byte to);
byte BoxGetFlags(Box *box);

/* returns the relative depth of the box: 
   -1, if it has no children (a "leaf"); 
   -2, if it is parent of a leaf; 
    0, otherwise */
int  BoxDepth(Box *box);

/* saves the box to the stream out */
void BoxSave(FILE *out, Box *box);

/* loads a box from the stream in */
Box *BoxLoad(FILE *in);

#ifdef __cplusplus
}
#endif

#endif
