#ifndef _SparseVector_h
#define _SparseVector_h

#include "defs.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int dim;              /* dimension of the vector */
    int nz;               /* number of nonzeros of the vector */
    int size;             /* size of rows and entries */
    int *rows;
    double *entries;
} SparseVector;
  
SparseVector *SparseVectorNew(int dim, int size);
void SparseVectorFree(SparseVector **A);
void SparseVectorAddEntry(SparseVector *A, int row, double entry);

#ifdef __cplusplus
}
#endif

#endif
